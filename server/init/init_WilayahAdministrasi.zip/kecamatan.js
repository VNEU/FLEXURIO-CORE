Meteor.startup(function(){
  if(NEGARA.find().count() == 0) {
    [
      {
        "kodeKECAMATAN": 1101010,
        "kodeKABUPATEN": 1101,
        "namaKECAMATAN": "TEUPAH SELATAN"
      },
      {
        "kodeKECAMATAN": 1101020,
        "kodeKABUPATEN": 1101,
        "namaKECAMATAN": "SIMEULUE TIMUR"
      },
      {
        "kodeKECAMATAN": 1101021,
        "kodeKABUPATEN": 1101,
        "namaKECAMATAN": "TEUPAH BARAT"
      },
      {
        "kodeKECAMATAN": 1101022,
        "kodeKABUPATEN": 1101,
        "namaKECAMATAN": "TEUPAH TENGAH"
      },
      {
        "kodeKECAMATAN": 1101030,
        "kodeKABUPATEN": 1101,
        "namaKECAMATAN": "SIMEULUE TENGAH"
      },
      {
        "kodeKECAMATAN": 1101031,
        "kodeKABUPATEN": 1101,
        "namaKECAMATAN": "TELUK DALAM"
      },
      {
        "kodeKECAMATAN": 1101032,
        "kodeKABUPATEN": 1101,
        "namaKECAMATAN": "SIMEULUE CUT"
      },
      {
        "kodeKECAMATAN": 1101040,
        "kodeKABUPATEN": 1101,
        "namaKECAMATAN": "SALANG"
      },
      {
        "kodeKECAMATAN": 1101050,
        "kodeKABUPATEN": 1101,
        "namaKECAMATAN": "SIMEULUE BARAT"
      },
      {
        "kodeKECAMATAN": 1101051,
        "kodeKABUPATEN": 1101,
        "namaKECAMATAN": "ALAFAN"
      },
      {
        "kodeKECAMATAN": 1102010,
        "kodeKABUPATEN": 1102,
        "namaKECAMATAN": "PULAU BANYAK"
      },
      {
        "kodeKECAMATAN": 1102011,
        "kodeKABUPATEN": 1102,
        "namaKECAMATAN": "PULAU BANYAK BARAT"
      },
      {
        "kodeKECAMATAN": 1102020,
        "kodeKABUPATEN": 1102,
        "namaKECAMATAN": "SINGKIL"
      },
      {
        "kodeKECAMATAN": 1102021,
        "kodeKABUPATEN": 1102,
        "namaKECAMATAN": "SINGKIL UTARA"
      },
      {
        "kodeKECAMATAN": 1102022,
        "kodeKABUPATEN": 1102,
        "namaKECAMATAN": "KUALA BARU"
      },
      {
        "kodeKECAMATAN": 1102030,
        "kodeKABUPATEN": 1102,
        "namaKECAMATAN": "SIMPANG KANAN"
      },
      {
        "kodeKECAMATAN": 1102031,
        "kodeKABUPATEN": 1102,
        "namaKECAMATAN": "GUNUNG MERIAH"
      },
      {
        "kodeKECAMATAN": 1102032,
        "kodeKABUPATEN": 1102,
        "namaKECAMATAN": "DANAU PARIS"
      },
      {
        "kodeKECAMATAN": 1102033,
        "kodeKABUPATEN": 1102,
        "namaKECAMATAN": "SURO"
      },
      {
        "kodeKECAMATAN": 1102042,
        "kodeKABUPATEN": 1102,
        "namaKECAMATAN": "SINGKOHOR"
      },
      {
        "kodeKECAMATAN": 1102043,
        "kodeKABUPATEN": 1102,
        "namaKECAMATAN": "KOTA BAHARU"
      },
      {
        "kodeKECAMATAN": 1103010,
        "kodeKABUPATEN": 1103,
        "namaKECAMATAN": "TRUMON"
      },
      {
        "kodeKECAMATAN": 1103011,
        "kodeKABUPATEN": 1103,
        "namaKECAMATAN": "TRUMON TIMUR"
      },
      {
        "kodeKECAMATAN": 1103012,
        "kodeKABUPATEN": 1103,
        "namaKECAMATAN": "TRUMON TENGAH"
      },
      {
        "kodeKECAMATAN": 1103020,
        "kodeKABUPATEN": 1103,
        "namaKECAMATAN": "BAKONGAN"
      },
      {
        "kodeKECAMATAN": 1103021,
        "kodeKABUPATEN": 1103,
        "namaKECAMATAN": "BAKONGAN TIMUR"
      },
      {
        "kodeKECAMATAN": 1103022,
        "kodeKABUPATEN": 1103,
        "namaKECAMATAN": "KOTA BAHAGIA"
      },
      {
        "kodeKECAMATAN": 1103030,
        "kodeKABUPATEN": 1103,
        "namaKECAMATAN": "KLUET SELATAN"
      },
      {
        "kodeKECAMATAN": 1103031,
        "kodeKABUPATEN": 1103,
        "namaKECAMATAN": "KLUET TIMUR"
      },
      {
        "kodeKECAMATAN": 1103040,
        "kodeKABUPATEN": 1103,
        "namaKECAMATAN": "KLUET UTARA"
      },
      {
        "kodeKECAMATAN": 1103041,
        "kodeKABUPATEN": 1103,
        "namaKECAMATAN": "PASIE RAJA"
      },
      {
        "kodeKECAMATAN": 1103042,
        "kodeKABUPATEN": 1103,
        "namaKECAMATAN": "KLUET TENGAH"
      },
      {
        "kodeKECAMATAN": 1103050,
        "kodeKABUPATEN": 1103,
        "namaKECAMATAN": "TAPAK TUAN"
      },
      {
        "kodeKECAMATAN": 1103060,
        "kodeKABUPATEN": 1103,
        "namaKECAMATAN": "SAMA DUA"
      },
      {
        "kodeKECAMATAN": 1103070,
        "kodeKABUPATEN": 1103,
        "namaKECAMATAN": "SAWANG"
      },
      {
        "kodeKECAMATAN": 1103080,
        "kodeKABUPATEN": 1103,
        "namaKECAMATAN": "MEUKEK"
      },
      {
        "kodeKECAMATAN": 1103090,
        "kodeKABUPATEN": 1103,
        "namaKECAMATAN": "LABUHAN HAJI"
      },
      {
        "kodeKECAMATAN": 1103091,
        "kodeKABUPATEN": 1103,
        "namaKECAMATAN": "LABUHAN HAJI TIMUR"
      },
      {
        "kodeKECAMATAN": 1103092,
        "kodeKABUPATEN": 1103,
        "namaKECAMATAN": "LABUHAN HAJI BARAT"
      },
      {
        "kodeKECAMATAN": 1104010,
        "kodeKABUPATEN": 1104,
        "namaKECAMATAN": "LAWE ALAS"
      },
      {
        "kodeKECAMATAN": 1104011,
        "kodeKABUPATEN": 1104,
        "namaKECAMATAN": "BABUL RAHMAH"
      },
      {
        "kodeKECAMATAN": 1104012,
        "kodeKABUPATEN": 1104,
        "namaKECAMATAN": "TANOH ALAS"
      },
      {
        "kodeKECAMATAN": 1104020,
        "kodeKABUPATEN": 1104,
        "namaKECAMATAN": "LAWE SIGALA-GALA"
      },
      {
        "kodeKECAMATAN": 1104021,
        "kodeKABUPATEN": 1104,
        "namaKECAMATAN": "BABUL MAKMUR"
      },
      {
        "kodeKECAMATAN": 1104022,
        "kodeKABUPATEN": 1104,
        "namaKECAMATAN": "SEMADAM"
      },
      {
        "kodeKECAMATAN": 1104023,
        "kodeKABUPATEN": 1104,
        "namaKECAMATAN": "LAUSER"
      },
      {
        "kodeKECAMATAN": 1104030,
        "kodeKABUPATEN": 1104,
        "namaKECAMATAN": "BAMBEL"
      },
      {
        "kodeKECAMATAN": 1104031,
        "kodeKABUPATEN": 1104,
        "namaKECAMATAN": "BUKIT TUSAM"
      },
      {
        "kodeKECAMATAN": 1104032,
        "kodeKABUPATEN": 1104,
        "namaKECAMATAN": "LAWE SUMUR"
      },
      {
        "kodeKECAMATAN": 1104040,
        "kodeKABUPATEN": 1104,
        "namaKECAMATAN": "BABUSSALAM"
      },
      {
        "kodeKECAMATAN": 1104041,
        "kodeKABUPATEN": 1104,
        "namaKECAMATAN": "LAWE BULAN"
      },
      {
        "kodeKECAMATAN": 1104050,
        "kodeKABUPATEN": 1104,
        "namaKECAMATAN": "BADAR"
      },
      {
        "kodeKECAMATAN": 1104051,
        "kodeKABUPATEN": 1104,
        "namaKECAMATAN": "DARUL HASANAH"
      },
      {
        "kodeKECAMATAN": 1104052,
        "kodeKABUPATEN": 1104,
        "namaKECAMATAN": "KETAMBE"
      },
      {
        "kodeKECAMATAN": 1104053,
        "kodeKABUPATEN": 1104,
        "namaKECAMATAN": "DELENG POKHKISEN"
      },
      {
        "kodeKECAMATAN": 1105080,
        "kodeKABUPATEN": 1105,
        "namaKECAMATAN": "SERBA JADI"
      },
      {
        "kodeKECAMATAN": 1105081,
        "kodeKABUPATEN": 1105,
        "namaKECAMATAN": "SIMPANG JERNIH"
      },
      {
        "kodeKECAMATAN": 1105082,
        "kodeKABUPATEN": 1105,
        "namaKECAMATAN": "PEUNARON"
      },
      {
        "kodeKECAMATAN": 1105090,
        "kodeKABUPATEN": 1105,
        "namaKECAMATAN": "BIREM BAYEUN"
      },
      {
        "kodeKECAMATAN": 1105100,
        "kodeKABUPATEN": 1105,
        "namaKECAMATAN": "RANTAU SELAMAT"
      },
      {
        "kodeKECAMATAN": 1105101,
        "kodeKABUPATEN": 1105,
        "namaKECAMATAN": "SUNGAI RAYA"
      },
      {
        "kodeKECAMATAN": 1105110,
        "kodeKABUPATEN": 1105,
        "namaKECAMATAN": "PEUREULAK"
      },
      {
        "kodeKECAMATAN": 1105111,
        "kodeKABUPATEN": 1105,
        "namaKECAMATAN": "PEUREULAK TIMUR"
      },
      {
        "kodeKECAMATAN": 1105112,
        "kodeKABUPATEN": 1105,
        "namaKECAMATAN": "PEUREULAK BARAT"
      },
      {
        "kodeKECAMATAN": 1105120,
        "kodeKABUPATEN": 1105,
        "namaKECAMATAN": "RANTO PEUREULAK"
      },
      {
        "kodeKECAMATAN": 1105130,
        "kodeKABUPATEN": 1105,
        "namaKECAMATAN": "IDI RAYEUK"
      },
      {
        "kodeKECAMATAN": 1105131,
        "kodeKABUPATEN": 1105,
        "namaKECAMATAN": "PEUDAWA"
      },
      {
        "kodeKECAMATAN": 1105132,
        "kodeKABUPATEN": 1105,
        "namaKECAMATAN": "BANDA ALAM"
      },
      {
        "kodeKECAMATAN": 1105133,
        "kodeKABUPATEN": 1105,
        "namaKECAMATAN": "IDI TUNONG"
      },
      {
        "kodeKECAMATAN": 1105134,
        "kodeKABUPATEN": 1105,
        "namaKECAMATAN": "DARUL IHSAN"
      },
      {
        "kodeKECAMATAN": 1105135,
        "kodeKABUPATEN": 1105,
        "namaKECAMATAN": "IDI TIMUR"
      },
      {
        "kodeKECAMATAN": 1105140,
        "kodeKABUPATEN": 1105,
        "namaKECAMATAN": "DARUL AMAN"
      },
      {
        "kodeKECAMATAN": 1105150,
        "kodeKABUPATEN": 1105,
        "namaKECAMATAN": "NURUSSALAM"
      },
      {
        "kodeKECAMATAN": 1105151,
        "kodeKABUPATEN": 1105,
        "namaKECAMATAN": "DARUL FALAH"
      },
      {
        "kodeKECAMATAN": 1105160,
        "kodeKABUPATEN": 1105,
        "namaKECAMATAN": "JULOK"
      },
      {
        "kodeKECAMATAN": 1105161,
        "kodeKABUPATEN": 1105,
        "namaKECAMATAN": "INDRA MAKMUR"
      },
      {
        "kodeKECAMATAN": 1105170,
        "kodeKABUPATEN": 1105,
        "namaKECAMATAN": "PANTE BIDARI"
      },
      {
        "kodeKECAMATAN": 1105180,
        "kodeKABUPATEN": 1105,
        "namaKECAMATAN": "SIMPANG ULIM"
      },
      {
        "kodeKECAMATAN": 1105181,
        "kodeKABUPATEN": 1105,
        "namaKECAMATAN": "MADAT"
      },
      {
        "kodeKECAMATAN": 1106010,
        "kodeKABUPATEN": 1106,
        "namaKECAMATAN": "LINGE"
      },
      {
        "kodeKECAMATAN": 1106011,
        "kodeKABUPATEN": 1106,
        "namaKECAMATAN": "ATU LINTANG"
      },
      {
        "kodeKECAMATAN": 1106012,
        "kodeKABUPATEN": 1106,
        "namaKECAMATAN": "JAGONG JEGET"
      },
      {
        "kodeKECAMATAN": 1106020,
        "kodeKABUPATEN": 1106,
        "namaKECAMATAN": "BINTANG"
      },
      {
        "kodeKECAMATAN": 1106031,
        "kodeKABUPATEN": 1106,
        "namaKECAMATAN": "LUT TAWAR"
      },
      {
        "kodeKECAMATAN": 1106032,
        "kodeKABUPATEN": 1106,
        "namaKECAMATAN": "KEBAYAKAN"
      },
      {
        "kodeKECAMATAN": 1106040,
        "kodeKABUPATEN": 1106,
        "namaKECAMATAN": "PEGASING"
      },
      {
        "kodeKECAMATAN": 1106041,
        "kodeKABUPATEN": 1106,
        "namaKECAMATAN": "BIES"
      },
      {
        "kodeKECAMATAN": 1106050,
        "kodeKABUPATEN": 1106,
        "namaKECAMATAN": "BEBESEN"
      },
      {
        "kodeKECAMATAN": 1106051,
        "kodeKABUPATEN": 1106,
        "namaKECAMATAN": "KUTE PANANG"
      },
      {
        "kodeKECAMATAN": 1106060,
        "kodeKABUPATEN": 1106,
        "namaKECAMATAN": "SILIH NARA"
      },
      {
        "kodeKECAMATAN": 1106061,
        "kodeKABUPATEN": 1106,
        "namaKECAMATAN": "KETOL"
      },
      {
        "kodeKECAMATAN": 1106062,
        "kodeKABUPATEN": 1106,
        "namaKECAMATAN": "CELALA"
      },
      {
        "kodeKECAMATAN": 1106063,
        "kodeKABUPATEN": 1106,
        "namaKECAMATAN": "RUSIP ANTARA"
      },
      {
        "kodeKECAMATAN": 1107050,
        "kodeKABUPATEN": 1107,
        "namaKECAMATAN": "JOHAN PAHLAWAN"
      },
      {
        "kodeKECAMATAN": 1107060,
        "kodeKABUPATEN": 1107,
        "namaKECAMATAN": "SAMATIGA"
      },
      {
        "kodeKECAMATAN": 1107061,
        "kodeKABUPATEN": 1107,
        "namaKECAMATAN": "BUBON"
      },
      {
        "kodeKECAMATAN": 1107062,
        "kodeKABUPATEN": 1107,
        "namaKECAMATAN": "ARONGAN LAMBALEK"
      },
      {
        "kodeKECAMATAN": 1107070,
        "kodeKABUPATEN": 1107,
        "namaKECAMATAN": "WOYLA"
      },
      {
        "kodeKECAMATAN": 1107071,
        "kodeKABUPATEN": 1107,
        "namaKECAMATAN": "WOYLA BARAT"
      },
      {
        "kodeKECAMATAN": 1107072,
        "kodeKABUPATEN": 1107,
        "namaKECAMATAN": "WOYLA TIMUR"
      },
      {
        "kodeKECAMATAN": 1107080,
        "kodeKABUPATEN": 1107,
        "namaKECAMATAN": "KAWAY XVI"
      },
      {
        "kodeKECAMATAN": 1107081,
        "kodeKABUPATEN": 1107,
        "namaKECAMATAN": "MEUREUBO"
      },
      {
        "kodeKECAMATAN": 1107082,
        "kodeKABUPATEN": 1107,
        "namaKECAMATAN": "PANTAI CEUREMEN"
      },
      {
        "kodeKECAMATAN": 1107083,
        "kodeKABUPATEN": 1107,
        "namaKECAMATAN": "PANTON REU"
      },
      {
        "kodeKECAMATAN": 1107090,
        "kodeKABUPATEN": 1107,
        "namaKECAMATAN": "SUNGAI MAS"
      },
      {
        "kodeKECAMATAN": 1108010,
        "kodeKABUPATEN": 1108,
        "namaKECAMATAN": "LHOONG"
      },
      {
        "kodeKECAMATAN": 1108020,
        "kodeKABUPATEN": 1108,
        "namaKECAMATAN": "LHOKNGA"
      },
      {
        "kodeKECAMATAN": 1108021,
        "kodeKABUPATEN": 1108,
        "namaKECAMATAN": "LEUPUNG"
      },
      {
        "kodeKECAMATAN": 1108030,
        "kodeKABUPATEN": 1108,
        "namaKECAMATAN": "INDRAPURI"
      },
      {
        "kodeKECAMATAN": 1108031,
        "kodeKABUPATEN": 1108,
        "namaKECAMATAN": "KUTA COT GLIE"
      },
      {
        "kodeKECAMATAN": 1108040,
        "kodeKABUPATEN": 1108,
        "namaKECAMATAN": "SEULIMEUM"
      },
      {
        "kodeKECAMATAN": 1108041,
        "kodeKABUPATEN": 1108,
        "namaKECAMATAN": "KOTA JANTHO"
      },
      {
        "kodeKECAMATAN": 1108042,
        "kodeKABUPATEN": 1108,
        "namaKECAMATAN": "LEMBAH SEULAWAH"
      },
      {
        "kodeKECAMATAN": 1108050,
        "kodeKABUPATEN": 1108,
        "namaKECAMATAN": "MESJID RAYA"
      },
      {
        "kodeKECAMATAN": 1108060,
        "kodeKABUPATEN": 1108,
        "namaKECAMATAN": "DARUSSALAM"
      },
      {
        "kodeKECAMATAN": 1108061,
        "kodeKABUPATEN": 1108,
        "namaKECAMATAN": "BAITUSSALAM"
      },
      {
        "kodeKECAMATAN": 1108070,
        "kodeKABUPATEN": 1108,
        "namaKECAMATAN": "KUTA BARO"
      },
      {
        "kodeKECAMATAN": 1108080,
        "kodeKABUPATEN": 1108,
        "namaKECAMATAN": "MONTASIK"
      },
      {
        "kodeKECAMATAN": 1108081,
        "kodeKABUPATEN": 1108,
        "namaKECAMATAN": "BLANG BINTANG"
      },
      {
        "kodeKECAMATAN": 1108090,
        "kodeKABUPATEN": 1108,
        "namaKECAMATAN": "INGIN JAYA"
      },
      {
        "kodeKECAMATAN": 1108091,
        "kodeKABUPATEN": 1108,
        "namaKECAMATAN": "KRUENG BARONA JAYA"
      },
      {
        "kodeKECAMATAN": 1108100,
        "kodeKABUPATEN": 1108,
        "namaKECAMATAN": "SUKA MAKMUR"
      },
      {
        "kodeKECAMATAN": 1108101,
        "kodeKABUPATEN": 1108,
        "namaKECAMATAN": "KUTA MALAKA"
      },
      {
        "kodeKECAMATAN": 1108102,
        "kodeKABUPATEN": 1108,
        "namaKECAMATAN": "SIMPANG TIGA"
      },
      {
        "kodeKECAMATAN": 1108110,
        "kodeKABUPATEN": 1108,
        "namaKECAMATAN": "DARUL IMARAH"
      },
      {
        "kodeKECAMATAN": 1108111,
        "kodeKABUPATEN": 1108,
        "namaKECAMATAN": "DARUL KAMAL"
      },
      {
        "kodeKECAMATAN": 1108120,
        "kodeKABUPATEN": 1108,
        "namaKECAMATAN": "PEUKAN BADA"
      },
      {
        "kodeKECAMATAN": 1108130,
        "kodeKABUPATEN": 1108,
        "namaKECAMATAN": "PULO ACEH"
      },
      {
        "kodeKECAMATAN": 1109010,
        "kodeKABUPATEN": 1109,
        "namaKECAMATAN": "GEUMPANG"
      },
      {
        "kodeKECAMATAN": 1109011,
        "kodeKABUPATEN": 1109,
        "namaKECAMATAN": "MANE"
      },
      {
        "kodeKECAMATAN": 1109070,
        "kodeKABUPATEN": 1109,
        "namaKECAMATAN": "GLUMPANG TIGA"
      },
      {
        "kodeKECAMATAN": 1109071,
        "kodeKABUPATEN": 1109,
        "namaKECAMATAN": "GLUMPANG BARO"
      },
      {
        "kodeKECAMATAN": 1109080,
        "kodeKABUPATEN": 1109,
        "namaKECAMATAN": "MUTIARA"
      },
      {
        "kodeKECAMATAN": 1109081,
        "kodeKABUPATEN": 1109,
        "namaKECAMATAN": "MUTIARA TIMUR"
      },
      {
        "kodeKECAMATAN": 1109090,
        "kodeKABUPATEN": 1109,
        "namaKECAMATAN": "TIRO/TRUSEB"
      },
      {
        "kodeKECAMATAN": 1109100,
        "kodeKABUPATEN": 1109,
        "namaKECAMATAN": "TANGSE"
      },
      {
        "kodeKECAMATAN": 1109111,
        "kodeKABUPATEN": 1109,
        "namaKECAMATAN": "KEUMALA"
      },
      {
        "kodeKECAMATAN": 1109112,
        "kodeKABUPATEN": 1109,
        "namaKECAMATAN": "TITEUE"
      },
      {
        "kodeKECAMATAN": 1109120,
        "kodeKABUPATEN": 1109,
        "namaKECAMATAN": "SAKTI"
      },
      {
        "kodeKECAMATAN": 1109130,
        "kodeKABUPATEN": 1109,
        "namaKECAMATAN": "MILA"
      },
      {
        "kodeKECAMATAN": 1109140,
        "kodeKABUPATEN": 1109,
        "namaKECAMATAN": "PADANG TIJI"
      },
      {
        "kodeKECAMATAN": 1109150,
        "kodeKABUPATEN": 1109,
        "namaKECAMATAN": "DELIMA"
      },
      {
        "kodeKECAMATAN": 1109151,
        "kodeKABUPATEN": 1109,
        "namaKECAMATAN": "GRONG GRONG"
      },
      {
        "kodeKECAMATAN": 1109160,
        "kodeKABUPATEN": 1109,
        "namaKECAMATAN": "INDRAJAYA"
      },
      {
        "kodeKECAMATAN": 1109170,
        "kodeKABUPATEN": 1109,
        "namaKECAMATAN": "PEUKAN BARO"
      },
      {
        "kodeKECAMATAN": 1109180,
        "kodeKABUPATEN": 1109,
        "namaKECAMATAN": "KEMBANG TANJONG"
      },
      {
        "kodeKECAMATAN": 1109190,
        "kodeKABUPATEN": 1109,
        "namaKECAMATAN": "SIMPANG TIGA"
      },
      {
        "kodeKECAMATAN": 1109200,
        "kodeKABUPATEN": 1109,
        "namaKECAMATAN": "KOTA SIGLI"
      },
      {
        "kodeKECAMATAN": 1109210,
        "kodeKABUPATEN": 1109,
        "namaKECAMATAN": "PIDIE"
      },
      {
        "kodeKECAMATAN": 1109220,
        "kodeKABUPATEN": 1109,
        "namaKECAMATAN": "BATEE"
      },
      {
        "kodeKECAMATAN": 1109230,
        "kodeKABUPATEN": 1109,
        "namaKECAMATAN": "MUARA TIGA"
      },
      {
        "kodeKECAMATAN": 1110010,
        "kodeKABUPATEN": 1110,
        "namaKECAMATAN": "SAMALANGA"
      },
      {
        "kodeKECAMATAN": 1110011,
        "kodeKABUPATEN": 1110,
        "namaKECAMATAN": "SIMPANG MAMPLAM"
      },
      {
        "kodeKECAMATAN": 1110020,
        "kodeKABUPATEN": 1110,
        "namaKECAMATAN": "PANDRAH"
      },
      {
        "kodeKECAMATAN": 1110030,
        "kodeKABUPATEN": 1110,
        "namaKECAMATAN": "JEUNIEB"
      },
      {
        "kodeKECAMATAN": 1110031,
        "kodeKABUPATEN": 1110,
        "namaKECAMATAN": "PEULIMBANG"
      },
      {
        "kodeKECAMATAN": 1110040,
        "kodeKABUPATEN": 1110,
        "namaKECAMATAN": "PEUDADA"
      },
      {
        "kodeKECAMATAN": 1110050,
        "kodeKABUPATEN": 1110,
        "namaKECAMATAN": "JULI"
      },
      {
        "kodeKECAMATAN": 1110060,
        "kodeKABUPATEN": 1110,
        "namaKECAMATAN": "JEUMPA"
      },
      {
        "kodeKECAMATAN": 1110061,
        "kodeKABUPATEN": 1110,
        "namaKECAMATAN": "KOTA JUANG"
      },
      {
        "kodeKECAMATAN": 1110062,
        "kodeKABUPATEN": 1110,
        "namaKECAMATAN": "KUALA"
      },
      {
        "kodeKECAMATAN": 1110070,
        "kodeKABUPATEN": 1110,
        "namaKECAMATAN": "JANGKA"
      },
      {
        "kodeKECAMATAN": 1110080,
        "kodeKABUPATEN": 1110,
        "namaKECAMATAN": "PEUSANGAN"
      },
      {
        "kodeKECAMATAN": 1110081,
        "kodeKABUPATEN": 1110,
        "namaKECAMATAN": "PEUSANGAN SELATAN"
      },
      {
        "kodeKECAMATAN": 1110082,
        "kodeKABUPATEN": 1110,
        "namaKECAMATAN": "PEUSANGAN SIBLAH KRUENG"
      },
      {
        "kodeKECAMATAN": 1110090,
        "kodeKABUPATEN": 1110,
        "namaKECAMATAN": "MAKMUR"
      },
      {
        "kodeKECAMATAN": 1110100,
        "kodeKABUPATEN": 1110,
        "namaKECAMATAN": "GANDA PURA"
      },
      {
        "kodeKECAMATAN": 1110101,
        "kodeKABUPATEN": 1110,
        "namaKECAMATAN": "KUTA BLANG"
      },
      {
        "kodeKECAMATAN": 1111010,
        "kodeKABUPATEN": 1111,
        "namaKECAMATAN": "SAWANG"
      },
      {
        "kodeKECAMATAN": 1111020,
        "kodeKABUPATEN": 1111,
        "namaKECAMATAN": "NISAM"
      },
      {
        "kodeKECAMATAN": 1111021,
        "kodeKABUPATEN": 1111,
        "namaKECAMATAN": "NISAM ANTARA"
      },
      {
        "kodeKECAMATAN": 1111022,
        "kodeKABUPATEN": 1111,
        "namaKECAMATAN": "BANDA BARO"
      },
      {
        "kodeKECAMATAN": 1111030,
        "kodeKABUPATEN": 1111,
        "namaKECAMATAN": "KUTA MAKMUR"
      },
      {
        "kodeKECAMATAN": 1111031,
        "kodeKABUPATEN": 1111,
        "namaKECAMATAN": "SIMPANG KERAMAT"
      },
      {
        "kodeKECAMATAN": 1111040,
        "kodeKABUPATEN": 1111,
        "namaKECAMATAN": "SYAMTALIRA BAYU"
      },
      {
        "kodeKECAMATAN": 1111041,
        "kodeKABUPATEN": 1111,
        "namaKECAMATAN": "GEUREUDONG PASE"
      },
      {
        "kodeKECAMATAN": 1111050,
        "kodeKABUPATEN": 1111,
        "namaKECAMATAN": "MEURAH MULIA"
      },
      {
        "kodeKECAMATAN": 1111060,
        "kodeKABUPATEN": 1111,
        "namaKECAMATAN": "MATANGKULI"
      },
      {
        "kodeKECAMATAN": 1111061,
        "kodeKABUPATEN": 1111,
        "namaKECAMATAN": "PAYA BAKONG"
      },
      {
        "kodeKECAMATAN": 1111062,
        "kodeKABUPATEN": 1111,
        "namaKECAMATAN": "PIRAK TIMU"
      },
      {
        "kodeKECAMATAN": 1111070,
        "kodeKABUPATEN": 1111,
        "namaKECAMATAN": "COT GIREK"
      },
      {
        "kodeKECAMATAN": 1111080,
        "kodeKABUPATEN": 1111,
        "namaKECAMATAN": "TANAH JAMBO AYE"
      },
      {
        "kodeKECAMATAN": 1111081,
        "kodeKABUPATEN": 1111,
        "namaKECAMATAN": "LANGKAHAN"
      },
      {
        "kodeKECAMATAN": 1111090,
        "kodeKABUPATEN": 1111,
        "namaKECAMATAN": "SEUNUDDON"
      },
      {
        "kodeKECAMATAN": 1111100,
        "kodeKABUPATEN": 1111,
        "namaKECAMATAN": "BAKTIYA"
      },
      {
        "kodeKECAMATAN": 1111101,
        "kodeKABUPATEN": 1111,
        "namaKECAMATAN": "BAKTIYA BARAT"
      },
      {
        "kodeKECAMATAN": 1111110,
        "kodeKABUPATEN": 1111,
        "namaKECAMATAN": "LHOKSUKON"
      },
      {
        "kodeKECAMATAN": 1111120,
        "kodeKABUPATEN": 1111,
        "namaKECAMATAN": "TANAH LUAS"
      },
      {
        "kodeKECAMATAN": 1111121,
        "kodeKABUPATEN": 1111,
        "namaKECAMATAN": "NIBONG"
      },
      {
        "kodeKECAMATAN": 1111130,
        "kodeKABUPATEN": 1111,
        "namaKECAMATAN": "SAMUDERA"
      },
      {
        "kodeKECAMATAN": 1111140,
        "kodeKABUPATEN": 1111,
        "namaKECAMATAN": "SYAMTALIRA ARON"
      },
      {
        "kodeKECAMATAN": 1111150,
        "kodeKABUPATEN": 1111,
        "namaKECAMATAN": "TANAH PASIR"
      },
      {
        "kodeKECAMATAN": 1111151,
        "kodeKABUPATEN": 1111,
        "namaKECAMATAN": "LAPANG"
      },
      {
        "kodeKECAMATAN": 1111160,
        "kodeKABUPATEN": 1111,
        "namaKECAMATAN": "MUARA BATU"
      },
      {
        "kodeKECAMATAN": 1111170,
        "kodeKABUPATEN": 1111,
        "namaKECAMATAN": "DEWANTARA"
      },
      {
        "kodeKECAMATAN": 1112010,
        "kodeKABUPATEN": 1112,
        "namaKECAMATAN": "MANGGENG"
      },
      {
        "kodeKECAMATAN": 1112011,
        "kodeKABUPATEN": 1112,
        "namaKECAMATAN": "LEMBAH SABIL"
      },
      {
        "kodeKECAMATAN": 1112020,
        "kodeKABUPATEN": 1112,
        "namaKECAMATAN": "TANGAN-TANGAN"
      },
      {
        "kodeKECAMATAN": 1112021,
        "kodeKABUPATEN": 1112,
        "namaKECAMATAN": "SETIA"
      },
      {
        "kodeKECAMATAN": 1112030,
        "kodeKABUPATEN": 1112,
        "namaKECAMATAN": "BLANG PIDIE"
      },
      {
        "kodeKECAMATAN": 1112031,
        "kodeKABUPATEN": 1112,
        "namaKECAMATAN": "JEUMPA"
      },
      {
        "kodeKECAMATAN": 1112040,
        "kodeKABUPATEN": 1112,
        "namaKECAMATAN": "SUSOH"
      },
      {
        "kodeKECAMATAN": 1112050,
        "kodeKABUPATEN": 1112,
        "namaKECAMATAN": "KUALA BATEE"
      },
      {
        "kodeKECAMATAN": 1112060,
        "kodeKABUPATEN": 1112,
        "namaKECAMATAN": "BABAH ROT"
      },
      {
        "kodeKECAMATAN": 1113010,
        "kodeKABUPATEN": 1113,
        "namaKECAMATAN": "KUTA PANJANG"
      },
      {
        "kodeKECAMATAN": 1113011,
        "kodeKABUPATEN": 1113,
        "namaKECAMATAN": "BLANG JERANGO"
      },
      {
        "kodeKECAMATAN": 1113020,
        "kodeKABUPATEN": 1113,
        "namaKECAMATAN": "BLANGKEJEREN"
      },
      {
        "kodeKECAMATAN": 1113021,
        "kodeKABUPATEN": 1113,
        "namaKECAMATAN": "PUTRI BETUNG"
      },
      {
        "kodeKECAMATAN": 1113022,
        "kodeKABUPATEN": 1113,
        "namaKECAMATAN": "DABUN GELANG"
      },
      {
        "kodeKECAMATAN": 1113023,
        "kodeKABUPATEN": 1113,
        "namaKECAMATAN": "BLANG PEGAYON"
      },
      {
        "kodeKECAMATAN": 1113030,
        "kodeKABUPATEN": 1113,
        "namaKECAMATAN": "PINING"
      },
      {
        "kodeKECAMATAN": 1113040,
        "kodeKABUPATEN": 1113,
        "namaKECAMATAN": "RIKIT GAIB"
      },
      {
        "kodeKECAMATAN": 1113041,
        "kodeKABUPATEN": 1113,
        "namaKECAMATAN": "PANTAN CUACA"
      },
      {
        "kodeKECAMATAN": 1113050,
        "kodeKABUPATEN": 1113,
        "namaKECAMATAN": "TERANGUN"
      },
      {
        "kodeKECAMATAN": 1113051,
        "kodeKABUPATEN": 1113,
        "namaKECAMATAN": "TRIPE JAYA"
      },
      {
        "kodeKECAMATAN": 1114010,
        "kodeKABUPATEN": 1114,
        "namaKECAMATAN": "TAMIANG HULU"
      },
      {
        "kodeKECAMATAN": 1114011,
        "kodeKABUPATEN": 1114,
        "namaKECAMATAN": "BANDAR PUSAKA"
      },
      {
        "kodeKECAMATAN": 1114020,
        "kodeKABUPATEN": 1114,
        "namaKECAMATAN": "KEJURUAN MUDA"
      },
      {
        "kodeKECAMATAN": 1114021,
        "kodeKABUPATEN": 1114,
        "namaKECAMATAN": "TENGGULUN"
      },
      {
        "kodeKECAMATAN": 1114030,
        "kodeKABUPATEN": 1114,
        "namaKECAMATAN": "RANTAU"
      },
      {
        "kodeKECAMATAN": 1114040,
        "kodeKABUPATEN": 1114,
        "namaKECAMATAN": "KOTA KUALA SIMPANG"
      },
      {
        "kodeKECAMATAN": 1114050,
        "kodeKABUPATEN": 1114,
        "namaKECAMATAN": "SERUWAY"
      },
      {
        "kodeKECAMATAN": 1114060,
        "kodeKABUPATEN": 1114,
        "namaKECAMATAN": "BENDAHARA"
      },
      {
        "kodeKECAMATAN": 1114061,
        "kodeKABUPATEN": 1114,
        "namaKECAMATAN": "BANDA MULIA"
      },
      {
        "kodeKECAMATAN": 1114070,
        "kodeKABUPATEN": 1114,
        "namaKECAMATAN": "KARANG BARU"
      },
      {
        "kodeKECAMATAN": 1114071,
        "kodeKABUPATEN": 1114,
        "namaKECAMATAN": "SEKERAK"
      },
      {
        "kodeKECAMATAN": 1114080,
        "kodeKABUPATEN": 1114,
        "namaKECAMATAN": "MANYAK PAYED"
      },
      {
        "kodeKECAMATAN": 1115010,
        "kodeKABUPATEN": 1115,
        "namaKECAMATAN": "DARUL MAKMUR"
      },
      {
        "kodeKECAMATAN": 1115011,
        "kodeKABUPATEN": 1115,
        "namaKECAMATAN": "TRIPA MAKMUR"
      },
      {
        "kodeKECAMATAN": 1115020,
        "kodeKABUPATEN": 1115,
        "namaKECAMATAN": "KUALA"
      },
      {
        "kodeKECAMATAN": 1115021,
        "kodeKABUPATEN": 1115,
        "namaKECAMATAN": "KUALA PESISIR"
      },
      {
        "kodeKECAMATAN": 1115022,
        "kodeKABUPATEN": 1115,
        "namaKECAMATAN": "TADU RAYA"
      },
      {
        "kodeKECAMATAN": 1115030,
        "kodeKABUPATEN": 1115,
        "namaKECAMATAN": "BEUTONG"
      },
      {
        "kodeKECAMATAN": 1115031,
        "kodeKABUPATEN": 1115,
        "namaKECAMATAN": "BEUTONG ATEUH BANGGALANG"
      },
      {
        "kodeKECAMATAN": 1115040,
        "kodeKABUPATEN": 1115,
        "namaKECAMATAN": "SEUNAGAN"
      },
      {
        "kodeKECAMATAN": 1115041,
        "kodeKABUPATEN": 1115,
        "namaKECAMATAN": "SUKA MAKMUE"
      },
      {
        "kodeKECAMATAN": 1115050,
        "kodeKABUPATEN": 1115,
        "namaKECAMATAN": "SEUNAGAN TIMUR"
      },
      {
        "kodeKECAMATAN": 1116010,
        "kodeKABUPATEN": 1116,
        "namaKECAMATAN": "TEUNOM"
      },
      {
        "kodeKECAMATAN": 1116011,
        "kodeKABUPATEN": 1116,
        "namaKECAMATAN": "PASIE RAYA"
      },
      {
        "kodeKECAMATAN": 1116020,
        "kodeKABUPATEN": 1116,
        "namaKECAMATAN": "PANGA"
      },
      {
        "kodeKECAMATAN": 1116030,
        "kodeKABUPATEN": 1116,
        "namaKECAMATAN": "KRUENG SABEE"
      },
      {
        "kodeKECAMATAN": 1116040,
        "kodeKABUPATEN": 1116,
        "namaKECAMATAN": "SETIA BAKTI"
      },
      {
        "kodeKECAMATAN": 1116050,
        "kodeKABUPATEN": 1116,
        "namaKECAMATAN": "SAMPOINIET"
      },
      {
        "kodeKECAMATAN": 1116051,
        "kodeKABUPATEN": 1116,
        "namaKECAMATAN": "DARUL HIKMAH"
      },
      {
        "kodeKECAMATAN": 1116060,
        "kodeKABUPATEN": 1116,
        "namaKECAMATAN": "JAYA"
      },
      {
        "kodeKECAMATAN": 1116061,
        "kodeKABUPATEN": 1116,
        "namaKECAMATAN": "INDRA JAYA"
      },
      {
        "kodeKECAMATAN": 1117010,
        "kodeKABUPATEN": 1117,
        "namaKECAMATAN": "TIMANG GAJAH"
      },
      {
        "kodeKECAMATAN": 1117011,
        "kodeKABUPATEN": 1117,
        "namaKECAMATAN": "GAJAH PUTIH"
      },
      {
        "kodeKECAMATAN": 1117020,
        "kodeKABUPATEN": 1117,
        "namaKECAMATAN": "PINTU RIME GAYO"
      },
      {
        "kodeKECAMATAN": 1117030,
        "kodeKABUPATEN": 1117,
        "namaKECAMATAN": "BUKIT"
      },
      {
        "kodeKECAMATAN": 1117040,
        "kodeKABUPATEN": 1117,
        "namaKECAMATAN": "WIH PESAM"
      },
      {
        "kodeKECAMATAN": 1117050,
        "kodeKABUPATEN": 1117,
        "namaKECAMATAN": "BANDAR"
      },
      {
        "kodeKECAMATAN": 1117051,
        "kodeKABUPATEN": 1117,
        "namaKECAMATAN": "BENER KELIPAH"
      },
      {
        "kodeKECAMATAN": 1117060,
        "kodeKABUPATEN": 1117,
        "namaKECAMATAN": "SYIAH UTAMA"
      },
      {
        "kodeKECAMATAN": 1117061,
        "kodeKABUPATEN": 1117,
        "namaKECAMATAN": "MESIDAH"
      },
      {
        "kodeKECAMATAN": 1117070,
        "kodeKABUPATEN": 1117,
        "namaKECAMATAN": "PERMATA"
      },
      {
        "kodeKECAMATAN": 1118010,
        "kodeKABUPATEN": 1118,
        "namaKECAMATAN": "MEUREUDU"
      },
      {
        "kodeKECAMATAN": 1118020,
        "kodeKABUPATEN": 1118,
        "namaKECAMATAN": "MEURAH DUA"
      },
      {
        "kodeKECAMATAN": 1118030,
        "kodeKABUPATEN": 1118,
        "namaKECAMATAN": "BANDAR DUA"
      },
      {
        "kodeKECAMATAN": 1118040,
        "kodeKABUPATEN": 1118,
        "namaKECAMATAN": "JANGKA BUYA"
      },
      {
        "kodeKECAMATAN": 1118050,
        "kodeKABUPATEN": 1118,
        "namaKECAMATAN": "ULIM"
      },
      {
        "kodeKECAMATAN": 1118060,
        "kodeKABUPATEN": 1118,
        "namaKECAMATAN": "TRIENGGADENG"
      },
      {
        "kodeKECAMATAN": 1118070,
        "kodeKABUPATEN": 1118,
        "namaKECAMATAN": "PANTERAJA"
      },
      {
        "kodeKECAMATAN": 1118080,
        "kodeKABUPATEN": 1118,
        "namaKECAMATAN": "BANDAR BARU"
      },
      {
        "kodeKECAMATAN": 1171010,
        "kodeKABUPATEN": 1171,
        "namaKECAMATAN": "MEURAXA"
      },
      {
        "kodeKECAMATAN": 1171011,
        "kodeKABUPATEN": 1171,
        "namaKECAMATAN": "JAYA BARU"
      },
      {
        "kodeKECAMATAN": 1171012,
        "kodeKABUPATEN": 1171,
        "namaKECAMATAN": "BANDA RAYA"
      },
      {
        "kodeKECAMATAN": 1171020,
        "kodeKABUPATEN": 1171,
        "namaKECAMATAN": "BAITURRAHMAN"
      },
      {
        "kodeKECAMATAN": 1171021,
        "kodeKABUPATEN": 1171,
        "namaKECAMATAN": "LUENG BATA"
      },
      {
        "kodeKECAMATAN": 1171030,
        "kodeKABUPATEN": 1171,
        "namaKECAMATAN": "KUTA ALAM"
      },
      {
        "kodeKECAMATAN": 1171031,
        "kodeKABUPATEN": 1171,
        "namaKECAMATAN": "KUTA RAJA"
      },
      {
        "kodeKECAMATAN": 1171040,
        "kodeKABUPATEN": 1171,
        "namaKECAMATAN": "SYIAH KUALA"
      },
      {
        "kodeKECAMATAN": 1171041,
        "kodeKABUPATEN": 1171,
        "namaKECAMATAN": "ULEE KARENG"
      },
      {
        "kodeKECAMATAN": 1172010,
        "kodeKABUPATEN": 1172,
        "namaKECAMATAN": "SUKAJAYA"
      },
      {
        "kodeKECAMATAN": 1172020,
        "kodeKABUPATEN": 1172,
        "namaKECAMATAN": "SUKAKARYA"
      },
      {
        "kodeKECAMATAN": 1173010,
        "kodeKABUPATEN": 1173,
        "namaKECAMATAN": "LANGSA TIMUR"
      },
      {
        "kodeKECAMATAN": 1173011,
        "kodeKABUPATEN": 1173,
        "namaKECAMATAN": "LANGSA LAMA"
      },
      {
        "kodeKECAMATAN": 1173020,
        "kodeKABUPATEN": 1173,
        "namaKECAMATAN": "LANGSA BARAT"
      },
      {
        "kodeKECAMATAN": 1173021,
        "kodeKABUPATEN": 1173,
        "namaKECAMATAN": "LANGSA BARO"
      },
      {
        "kodeKECAMATAN": 1173030,
        "kodeKABUPATEN": 1173,
        "namaKECAMATAN": "LANGSA KOTA"
      },
      {
        "kodeKECAMATAN": 1174010,
        "kodeKABUPATEN": 1174,
        "namaKECAMATAN": "BLANG MANGAT"
      },
      {
        "kodeKECAMATAN": 1174020,
        "kodeKABUPATEN": 1174,
        "namaKECAMATAN": "MUARA DUA"
      },
      {
        "kodeKECAMATAN": 1174021,
        "kodeKABUPATEN": 1174,
        "namaKECAMATAN": "MUARA SATU"
      },
      {
        "kodeKECAMATAN": 1174030,
        "kodeKABUPATEN": 1174,
        "namaKECAMATAN": "BANDA SAKTI"
      },
      {
        "kodeKECAMATAN": 1175010,
        "kodeKABUPATEN": 1175,
        "namaKECAMATAN": "SIMPANG KIRI"
      },
      {
        "kodeKECAMATAN": 1175020,
        "kodeKABUPATEN": 1175,
        "namaKECAMATAN": "PENANGGALAN"
      },
      {
        "kodeKECAMATAN": 1175030,
        "kodeKABUPATEN": 1175,
        "namaKECAMATAN": "RUNDENG"
      },
      {
        "kodeKECAMATAN": 1175040,
        "kodeKABUPATEN": 1175,
        "namaKECAMATAN": "SULTAN DAULAT"
      },
      {
        "kodeKECAMATAN": 1175050,
        "kodeKABUPATEN": 1175,
        "namaKECAMATAN": "LONGKIB"
      },
      {
        "kodeKECAMATAN": 1201060,
        "kodeKABUPATEN": 1201,
        "namaKECAMATAN": "IDANO GAWO"
      },
      {
        "kodeKECAMATAN": 1201061,
        "kodeKABUPATEN": 1201,
        "namaKECAMATAN": "BAWOLATO"
      },
      {
        "kodeKECAMATAN": 1201062,
        "kodeKABUPATEN": 1201,
        "namaKECAMATAN": "ULUGAWO"
      },
      {
        "kodeKECAMATAN": 1201070,
        "kodeKABUPATEN": 1201,
        "namaKECAMATAN": "GIDO"
      },
      {
        "kodeKECAMATAN": 1201071,
        "kodeKABUPATEN": 1201,
        "namaKECAMATAN": "SOGAEADU"
      },
      {
        "kodeKECAMATAN": 1201081,
        "kodeKABUPATEN": 1201,
        "namaKECAMATAN": "MA U"
      },
      {
        "kodeKECAMATAN": 1201082,
        "kodeKABUPATEN": 1201,
        "namaKECAMATAN": "SOMOLO - MOLO"
      },
      {
        "kodeKECAMATAN": 1201130,
        "kodeKABUPATEN": 1201,
        "namaKECAMATAN": "HILIDUHO"
      },
      {
        "kodeKECAMATAN": 1201131,
        "kodeKABUPATEN": 1201,
        "namaKECAMATAN": "HILI SERANGKAI"
      },
      {
        "kodeKECAMATAN": 1201132,
        "kodeKABUPATEN": 1201,
        "namaKECAMATAN": "BOTOMUZOI"
      },
      {
        "kodeKECAMATAN": 1202010,
        "kodeKABUPATEN": 1202,
        "namaKECAMATAN": "BATAHAN"
      },
      {
        "kodeKECAMATAN": 1202011,
        "kodeKABUPATEN": 1202,
        "namaKECAMATAN": "SINUNUKAN"
      },
      {
        "kodeKECAMATAN": 1202020,
        "kodeKABUPATEN": 1202,
        "namaKECAMATAN": "BATANG NATAL"
      },
      {
        "kodeKECAMATAN": 1202021,
        "kodeKABUPATEN": 1202,
        "namaKECAMATAN": "LINGGA BAYU"
      },
      {
        "kodeKECAMATAN": 1202022,
        "kodeKABUPATEN": 1202,
        "namaKECAMATAN": "RANTO BAEK"
      },
      {
        "kodeKECAMATAN": 1202030,
        "kodeKABUPATEN": 1202,
        "namaKECAMATAN": "KOTANOPAN"
      },
      {
        "kodeKECAMATAN": 1202031,
        "kodeKABUPATEN": 1202,
        "namaKECAMATAN": "ULU PUNGKUT"
      },
      {
        "kodeKECAMATAN": 1202032,
        "kodeKABUPATEN": 1202,
        "namaKECAMATAN": "TAMBANGAN"
      },
      {
        "kodeKECAMATAN": 1202033,
        "kodeKABUPATEN": 1202,
        "namaKECAMATAN": "LEMBAH SORIK MARAPI"
      },
      {
        "kodeKECAMATAN": 1202034,
        "kodeKABUPATEN": 1202,
        "namaKECAMATAN": "PUNCAK SORIK MARAPI"
      },
      {
        "kodeKECAMATAN": 1202040,
        "kodeKABUPATEN": 1202,
        "namaKECAMATAN": "MUARA SIPONGI"
      },
      {
        "kodeKECAMATAN": 1202041,
        "kodeKABUPATEN": 1202,
        "namaKECAMATAN": "PAKANTAN"
      },
      {
        "kodeKECAMATAN": 1202050,
        "kodeKABUPATEN": 1202,
        "namaKECAMATAN": "PANYABUNGAN"
      },
      {
        "kodeKECAMATAN": 1202051,
        "kodeKABUPATEN": 1202,
        "namaKECAMATAN": "PANYABUNGAN SELATAN"
      },
      {
        "kodeKECAMATAN": 1202052,
        "kodeKABUPATEN": 1202,
        "namaKECAMATAN": "PANYABUNGAN BARAT"
      },
      {
        "kodeKECAMATAN": 1202053,
        "kodeKABUPATEN": 1202,
        "namaKECAMATAN": "PANYABUNGAN UTARA"
      },
      {
        "kodeKECAMATAN": 1202054,
        "kodeKABUPATEN": 1202,
        "namaKECAMATAN": "PANYABUNGAN TIMUR"
      },
      {
        "kodeKECAMATAN": 1202055,
        "kodeKABUPATEN": 1202,
        "namaKECAMATAN": "HUTA BARGOT"
      },
      {
        "kodeKECAMATAN": 1202060,
        "kodeKABUPATEN": 1202,
        "namaKECAMATAN": "NATAL"
      },
      {
        "kodeKECAMATAN": 1202070,
        "kodeKABUPATEN": 1202,
        "namaKECAMATAN": "MUARA BATANG GADIS"
      },
      {
        "kodeKECAMATAN": 1202080,
        "kodeKABUPATEN": 1202,
        "namaKECAMATAN": "SIABU"
      },
      {
        "kodeKECAMATAN": 1202081,
        "kodeKABUPATEN": 1202,
        "namaKECAMATAN": "BUKIT MALINTANG"
      },
      {
        "kodeKECAMATAN": 1202082,
        "kodeKABUPATEN": 1202,
        "namaKECAMATAN": "NAGA JUANG"
      },
      {
        "kodeKECAMATAN": 1203010,
        "kodeKABUPATEN": 1203,
        "namaKECAMATAN": "BATANG ANGKOLA"
      },
      {
        "kodeKECAMATAN": 1203011,
        "kodeKABUPATEN": 1203,
        "namaKECAMATAN": "SAYUR MATINGGI"
      },
      {
        "kodeKECAMATAN": 1203012,
        "kodeKABUPATEN": 1203,
        "namaKECAMATAN": "TANO TOMBANGAN ANGKOLA"
      },
      {
        "kodeKECAMATAN": 1203070,
        "kodeKABUPATEN": 1203,
        "namaKECAMATAN": "ANGKOLA TIMUR"
      },
      {
        "kodeKECAMATAN": 1203080,
        "kodeKABUPATEN": 1203,
        "namaKECAMATAN": "ANGKOLA SELATAN"
      },
      {
        "kodeKECAMATAN": 1203090,
        "kodeKABUPATEN": 1203,
        "namaKECAMATAN": "ANGKOLA  BARAT"
      },
      {
        "kodeKECAMATAN": 1203091,
        "kodeKABUPATEN": 1203,
        "namaKECAMATAN": "ANGKOLA SANGKUNUR"
      },
      {
        "kodeKECAMATAN": 1203100,
        "kodeKABUPATEN": 1203,
        "namaKECAMATAN": "BATANG TORU"
      },
      {
        "kodeKECAMATAN": 1203101,
        "kodeKABUPATEN": 1203,
        "namaKECAMATAN": "MARANCAR"
      },
      {
        "kodeKECAMATAN": 1203102,
        "kodeKABUPATEN": 1203,
        "namaKECAMATAN": "MUARA BATANG TORU"
      },
      {
        "kodeKECAMATAN": 1203110,
        "kodeKABUPATEN": 1203,
        "namaKECAMATAN": "SIPIROK"
      },
      {
        "kodeKECAMATAN": 1203120,
        "kodeKABUPATEN": 1203,
        "namaKECAMATAN": "ARSE"
      },
      {
        "kodeKECAMATAN": 1203160,
        "kodeKABUPATEN": 1203,
        "namaKECAMATAN": "SAIPAR DOLOK HOLE"
      },
      {
        "kodeKECAMATAN": 1203161,
        "kodeKABUPATEN": 1203,
        "namaKECAMATAN": "AEK BILAH"
      },
      {
        "kodeKECAMATAN": 1204010,
        "kodeKABUPATEN": 1204,
        "namaKECAMATAN": "PINANG SORI"
      },
      {
        "kodeKECAMATAN": 1204011,
        "kodeKABUPATEN": 1204,
        "namaKECAMATAN": "BADIRI"
      },
      {
        "kodeKECAMATAN": 1204020,
        "kodeKABUPATEN": 1204,
        "namaKECAMATAN": "SIBABANGUN"
      },
      {
        "kodeKECAMATAN": 1204021,
        "kodeKABUPATEN": 1204,
        "namaKECAMATAN": "LUMUT"
      },
      {
        "kodeKECAMATAN": 1204022,
        "kodeKABUPATEN": 1204,
        "namaKECAMATAN": "SUKABANGUN"
      },
      {
        "kodeKECAMATAN": 1204030,
        "kodeKABUPATEN": 1204,
        "namaKECAMATAN": "PANDAN"
      },
      {
        "kodeKECAMATAN": 1204031,
        "kodeKABUPATEN": 1204,
        "namaKECAMATAN": "TUKKA"
      },
      {
        "kodeKECAMATAN": 1204032,
        "kodeKABUPATEN": 1204,
        "namaKECAMATAN": "SARUDIK"
      },
      {
        "kodeKECAMATAN": 1204040,
        "kodeKABUPATEN": 1204,
        "namaKECAMATAN": "TAPIAN NAULI"
      },
      {
        "kodeKECAMATAN": 1204041,
        "kodeKABUPATEN": 1204,
        "namaKECAMATAN": "SITAHUIS"
      },
      {
        "kodeKECAMATAN": 1204050,
        "kodeKABUPATEN": 1204,
        "namaKECAMATAN": "KOLANG"
      },
      {
        "kodeKECAMATAN": 1204060,
        "kodeKABUPATEN": 1204,
        "namaKECAMATAN": "SORKAM"
      },
      {
        "kodeKECAMATAN": 1204061,
        "kodeKABUPATEN": 1204,
        "namaKECAMATAN": "SORKAM BARAT"
      },
      {
        "kodeKECAMATAN": 1204062,
        "kodeKABUPATEN": 1204,
        "namaKECAMATAN": "PASARIBU TOBING"
      },
      {
        "kodeKECAMATAN": 1204070,
        "kodeKABUPATEN": 1204,
        "namaKECAMATAN": "BARUS"
      },
      {
        "kodeKECAMATAN": 1204071,
        "kodeKABUPATEN": 1204,
        "namaKECAMATAN": "SOSOR GADONG"
      },
      {
        "kodeKECAMATAN": 1204072,
        "kodeKABUPATEN": 1204,
        "namaKECAMATAN": "ANDAM DEWI"
      },
      {
        "kodeKECAMATAN": 1204073,
        "kodeKABUPATEN": 1204,
        "namaKECAMATAN": "BARUS UTARA"
      },
      {
        "kodeKECAMATAN": 1204080,
        "kodeKABUPATEN": 1204,
        "namaKECAMATAN": "MANDUAMAS"
      },
      {
        "kodeKECAMATAN": 1204081,
        "kodeKABUPATEN": 1204,
        "namaKECAMATAN": "SIRANDORUNG"
      },
      {
        "kodeKECAMATAN": 1205030,
        "kodeKABUPATEN": 1205,
        "namaKECAMATAN": "PARMONANGAN"
      },
      {
        "kodeKECAMATAN": 1205040,
        "kodeKABUPATEN": 1205,
        "namaKECAMATAN": "ADIAN KOTING"
      },
      {
        "kodeKECAMATAN": 1205050,
        "kodeKABUPATEN": 1205,
        "namaKECAMATAN": "SIPOHOLON"
      },
      {
        "kodeKECAMATAN": 1205060,
        "kodeKABUPATEN": 1205,
        "namaKECAMATAN": "TARUTUNG"
      },
      {
        "kodeKECAMATAN": 1205061,
        "kodeKABUPATEN": 1205,
        "namaKECAMATAN": "SIATAS BARITA"
      },
      {
        "kodeKECAMATAN": 1205070,
        "kodeKABUPATEN": 1205,
        "namaKECAMATAN": "PAHAE JULU"
      },
      {
        "kodeKECAMATAN": 1205080,
        "kodeKABUPATEN": 1205,
        "namaKECAMATAN": "PAHAE JAE"
      },
      {
        "kodeKECAMATAN": 1205081,
        "kodeKABUPATEN": 1205,
        "namaKECAMATAN": "PURBATUA"
      },
      {
        "kodeKECAMATAN": 1205082,
        "kodeKABUPATEN": 1205,
        "namaKECAMATAN": "SIMANGUMBAN"
      },
      {
        "kodeKECAMATAN": 1205090,
        "kodeKABUPATEN": 1205,
        "namaKECAMATAN": "PANGARIBUAN"
      },
      {
        "kodeKECAMATAN": 1205100,
        "kodeKABUPATEN": 1205,
        "namaKECAMATAN": "GAROGA"
      },
      {
        "kodeKECAMATAN": 1205110,
        "kodeKABUPATEN": 1205,
        "namaKECAMATAN": "SIPAHUTAR"
      },
      {
        "kodeKECAMATAN": 1205120,
        "kodeKABUPATEN": 1205,
        "namaKECAMATAN": "SIBORONG-BORONG"
      },
      {
        "kodeKECAMATAN": 1205130,
        "kodeKABUPATEN": 1205,
        "namaKECAMATAN": "PAGARAN"
      },
      {
        "kodeKECAMATAN": 1205180,
        "kodeKABUPATEN": 1205,
        "namaKECAMATAN": "MUARA"
      },
      {
        "kodeKECAMATAN": 1206030,
        "kodeKABUPATEN": 1206,
        "namaKECAMATAN": "BALIGE"
      },
      {
        "kodeKECAMATAN": 1206031,
        "kodeKABUPATEN": 1206,
        "namaKECAMATAN": "TAMPAHAN"
      },
      {
        "kodeKECAMATAN": 1206040,
        "kodeKABUPATEN": 1206,
        "namaKECAMATAN": "LAGUBOTI"
      },
      {
        "kodeKECAMATAN": 1206050,
        "kodeKABUPATEN": 1206,
        "namaKECAMATAN": "HABINSARAN"
      },
      {
        "kodeKECAMATAN": 1206051,
        "kodeKABUPATEN": 1206,
        "namaKECAMATAN": "BORBOR"
      },
      {
        "kodeKECAMATAN": 1206052,
        "kodeKABUPATEN": 1206,
        "namaKECAMATAN": "NASSAU"
      },
      {
        "kodeKECAMATAN": 1206060,
        "kodeKABUPATEN": 1206,
        "namaKECAMATAN": "SILAEN"
      },
      {
        "kodeKECAMATAN": 1206061,
        "kodeKABUPATEN": 1206,
        "namaKECAMATAN": "SIGUMPAR"
      },
      {
        "kodeKECAMATAN": 1206070,
        "kodeKABUPATEN": 1206,
        "namaKECAMATAN": "PORSEA"
      },
      {
        "kodeKECAMATAN": 1206071,
        "kodeKABUPATEN": 1206,
        "namaKECAMATAN": "PINTU POHAN MERANTI"
      },
      {
        "kodeKECAMATAN": 1206072,
        "kodeKABUPATEN": 1206,
        "namaKECAMATAN": "SIANTAR NARUMONDA"
      },
      {
        "kodeKECAMATAN": 1206073,
        "kodeKABUPATEN": 1206,
        "namaKECAMATAN": "PARMAKSIAN"
      },
      {
        "kodeKECAMATAN": 1206080,
        "kodeKABUPATEN": 1206,
        "namaKECAMATAN": "LUMBAN JULU"
      },
      {
        "kodeKECAMATAN": 1206081,
        "kodeKABUPATEN": 1206,
        "namaKECAMATAN": "ULUAN"
      },
      {
        "kodeKECAMATAN": 1206082,
        "kodeKABUPATEN": 1206,
        "namaKECAMATAN": "AJIBATA"
      },
      {
        "kodeKECAMATAN": 1206083,
        "kodeKABUPATEN": 1206,
        "namaKECAMATAN": "BONATUA LUNASI"
      },
      {
        "kodeKECAMATAN": 1207050,
        "kodeKABUPATEN": 1207,
        "namaKECAMATAN": "BILAH HULU"
      },
      {
        "kodeKECAMATAN": 1207070,
        "kodeKABUPATEN": 1207,
        "namaKECAMATAN": "PANGKATAN"
      },
      {
        "kodeKECAMATAN": 1207080,
        "kodeKABUPATEN": 1207,
        "namaKECAMATAN": "BILAH BARAT"
      },
      {
        "kodeKECAMATAN": 1207130,
        "kodeKABUPATEN": 1207,
        "namaKECAMATAN": "BILAH HILIR"
      },
      {
        "kodeKECAMATAN": 1207140,
        "kodeKABUPATEN": 1207,
        "namaKECAMATAN": "PANAI HULU"
      },
      {
        "kodeKECAMATAN": 1207150,
        "kodeKABUPATEN": 1207,
        "namaKECAMATAN": "PANAI TENGAH"
      },
      {
        "kodeKECAMATAN": 1207160,
        "kodeKABUPATEN": 1207,
        "namaKECAMATAN": "PANAI HILIR"
      },
      {
        "kodeKECAMATAN": 1207210,
        "kodeKABUPATEN": 1207,
        "namaKECAMATAN": "RANTAU SELATAN"
      },
      {
        "kodeKECAMATAN": 1207220,
        "kodeKABUPATEN": 1207,
        "namaKECAMATAN": "RANTAU UTARA"
      },
      {
        "kodeKECAMATAN": 1208010,
        "kodeKABUPATEN": 1208,
        "namaKECAMATAN": "BANDAR PASIR MANDOGE"
      },
      {
        "kodeKECAMATAN": 1208020,
        "kodeKABUPATEN": 1208,
        "namaKECAMATAN": "BANDAR PULAU"
      },
      {
        "kodeKECAMATAN": 1208021,
        "kodeKABUPATEN": 1208,
        "namaKECAMATAN": "AEK SONGSONGAN"
      },
      {
        "kodeKECAMATAN": 1208022,
        "kodeKABUPATEN": 1208,
        "namaKECAMATAN": "RAHUNING"
      },
      {
        "kodeKECAMATAN": 1208030,
        "kodeKABUPATEN": 1208,
        "namaKECAMATAN": "PULAU RAKYAT"
      },
      {
        "kodeKECAMATAN": 1208031,
        "kodeKABUPATEN": 1208,
        "namaKECAMATAN": "AEK KUASAN"
      },
      {
        "kodeKECAMATAN": 1208032,
        "kodeKABUPATEN": 1208,
        "namaKECAMATAN": "AEK LEDONG"
      },
      {
        "kodeKECAMATAN": 1208040,
        "kodeKABUPATEN": 1208,
        "namaKECAMATAN": "SEI KEPAYANG"
      },
      {
        "kodeKECAMATAN": 1208041,
        "kodeKABUPATEN": 1208,
        "namaKECAMATAN": "SEI KEPAYANG BARAT"
      },
      {
        "kodeKECAMATAN": 1208042,
        "kodeKABUPATEN": 1208,
        "namaKECAMATAN": "SEI KEPAYANG TIMUR"
      },
      {
        "kodeKECAMATAN": 1208050,
        "kodeKABUPATEN": 1208,
        "namaKECAMATAN": "TANJUNG BALAI"
      },
      {
        "kodeKECAMATAN": 1208060,
        "kodeKABUPATEN": 1208,
        "namaKECAMATAN": "SIMPANG EMPAT"
      },
      {
        "kodeKECAMATAN": 1208061,
        "kodeKABUPATEN": 1208,
        "namaKECAMATAN": "TELUK DALAM"
      },
      {
        "kodeKECAMATAN": 1208070,
        "kodeKABUPATEN": 1208,
        "namaKECAMATAN": "AIR BATU"
      },
      {
        "kodeKECAMATAN": 1208071,
        "kodeKABUPATEN": 1208,
        "namaKECAMATAN": "SEI DADAP"
      },
      {
        "kodeKECAMATAN": 1208080,
        "kodeKABUPATEN": 1208,
        "namaKECAMATAN": "BUNTU PANE"
      },
      {
        "kodeKECAMATAN": 1208081,
        "kodeKABUPATEN": 1208,
        "namaKECAMATAN": "TINGGI RAJA"
      },
      {
        "kodeKECAMATAN": 1208082,
        "kodeKABUPATEN": 1208,
        "namaKECAMATAN": "SETIA JANJI"
      },
      {
        "kodeKECAMATAN": 1208090,
        "kodeKABUPATEN": 1208,
        "namaKECAMATAN": "MERANTI"
      },
      {
        "kodeKECAMATAN": 1208091,
        "kodeKABUPATEN": 1208,
        "namaKECAMATAN": "PULO BANDRING"
      },
      {
        "kodeKECAMATAN": 1208092,
        "kodeKABUPATEN": 1208,
        "namaKECAMATAN": "RAWANG PANCA ARGA"
      },
      {
        "kodeKECAMATAN": 1208100,
        "kodeKABUPATEN": 1208,
        "namaKECAMATAN": "AIR JOMAN"
      },
      {
        "kodeKECAMATAN": 1208101,
        "kodeKABUPATEN": 1208,
        "namaKECAMATAN": "SILAU LAUT"
      },
      {
        "kodeKECAMATAN": 1208160,
        "kodeKABUPATEN": 1208,
        "namaKECAMATAN": "KISARAN BARAT"
      },
      {
        "kodeKECAMATAN": 1208170,
        "kodeKABUPATEN": 1208,
        "namaKECAMATAN": "KISARAN TIMUR"
      },
      {
        "kodeKECAMATAN": 1209010,
        "kodeKABUPATEN": 1209,
        "namaKECAMATAN": "SILIMAKUTA"
      },
      {
        "kodeKECAMATAN": 1209011,
        "kodeKABUPATEN": 1209,
        "namaKECAMATAN": "PEMATANG SILIMAHUTA"
      },
      {
        "kodeKECAMATAN": 1209020,
        "kodeKABUPATEN": 1209,
        "namaKECAMATAN": "PURBA"
      },
      {
        "kodeKECAMATAN": 1209021,
        "kodeKABUPATEN": 1209,
        "namaKECAMATAN": "HARANGGAOL HORISON"
      },
      {
        "kodeKECAMATAN": 1209030,
        "kodeKABUPATEN": 1209,
        "namaKECAMATAN": "DOLOK PARDAMEAN"
      },
      {
        "kodeKECAMATAN": 1209040,
        "kodeKABUPATEN": 1209,
        "namaKECAMATAN": "SIDAMANIK"
      },
      {
        "kodeKECAMATAN": 1209041,
        "kodeKABUPATEN": 1209,
        "namaKECAMATAN": "PEMATANG SIDAMANIK"
      },
      {
        "kodeKECAMATAN": 1209050,
        "kodeKABUPATEN": 1209,
        "namaKECAMATAN": "GIRSANG SIPANGAN BOLON"
      },
      {
        "kodeKECAMATAN": 1209060,
        "kodeKABUPATEN": 1209,
        "namaKECAMATAN": "TANAH JAWA"
      },
      {
        "kodeKECAMATAN": 1209061,
        "kodeKABUPATEN": 1209,
        "namaKECAMATAN": "HATONDUHAN"
      },
      {
        "kodeKECAMATAN": 1209070,
        "kodeKABUPATEN": 1209,
        "namaKECAMATAN": "DOLOK PANRIBUAN"
      },
      {
        "kodeKECAMATAN": 1209080,
        "kodeKABUPATEN": 1209,
        "namaKECAMATAN": "JORLANG HATARAN"
      },
      {
        "kodeKECAMATAN": 1209090,
        "kodeKABUPATEN": 1209,
        "namaKECAMATAN": "PANEI"
      },
      {
        "kodeKECAMATAN": 1209091,
        "kodeKABUPATEN": 1209,
        "namaKECAMATAN": "PANOMBEAN PANEI"
      },
      {
        "kodeKECAMATAN": 1209100,
        "kodeKABUPATEN": 1209,
        "namaKECAMATAN": "RAYA"
      },
      {
        "kodeKECAMATAN": 1209110,
        "kodeKABUPATEN": 1209,
        "namaKECAMATAN": "DOLOK SILAU"
      },
      {
        "kodeKECAMATAN": 1209120,
        "kodeKABUPATEN": 1209,
        "namaKECAMATAN": "SILAU KAHEAN"
      },
      {
        "kodeKECAMATAN": 1209130,
        "kodeKABUPATEN": 1209,
        "namaKECAMATAN": "RAYA KAHEAN"
      },
      {
        "kodeKECAMATAN": 1209140,
        "kodeKABUPATEN": 1209,
        "namaKECAMATAN": "TAPIAN DOLOK"
      },
      {
        "kodeKECAMATAN": 1209150,
        "kodeKABUPATEN": 1209,
        "namaKECAMATAN": "DOLOK BATU NANGGAR"
      },
      {
        "kodeKECAMATAN": 1209160,
        "kodeKABUPATEN": 1209,
        "namaKECAMATAN": "SIANTAR"
      },
      {
        "kodeKECAMATAN": 1209161,
        "kodeKABUPATEN": 1209,
        "namaKECAMATAN": "GUNUNG MALELA"
      },
      {
        "kodeKECAMATAN": 1209162,
        "kodeKABUPATEN": 1209,
        "namaKECAMATAN": "GUNUNG MALIGAS"
      },
      {
        "kodeKECAMATAN": 1209170,
        "kodeKABUPATEN": 1209,
        "namaKECAMATAN": "HUTABAYU RAJA"
      },
      {
        "kodeKECAMATAN": 1209171,
        "kodeKABUPATEN": 1209,
        "namaKECAMATAN": "JAWA MARAJA BAH JAMBI"
      },
      {
        "kodeKECAMATAN": 1209180,
        "kodeKABUPATEN": 1209,
        "namaKECAMATAN": "PEMATANG BANDAR"
      },
      {
        "kodeKECAMATAN": 1209181,
        "kodeKABUPATEN": 1209,
        "namaKECAMATAN": "BANDAR HULUAN"
      },
      {
        "kodeKECAMATAN": 1209190,
        "kodeKABUPATEN": 1209,
        "namaKECAMATAN": "BANDAR"
      },
      {
        "kodeKECAMATAN": 1209191,
        "kodeKABUPATEN": 1209,
        "namaKECAMATAN": "BANDAR MASILAM"
      },
      {
        "kodeKECAMATAN": 1209200,
        "kodeKABUPATEN": 1209,
        "namaKECAMATAN": "BOSAR MALIGAS"
      },
      {
        "kodeKECAMATAN": 1209210,
        "kodeKABUPATEN": 1209,
        "namaKECAMATAN": "UJUNG PADANG"
      },
      {
        "kodeKECAMATAN": 1210030,
        "kodeKABUPATEN": 1210,
        "namaKECAMATAN": "SIDIKALANG"
      },
      {
        "kodeKECAMATAN": 1210031,
        "kodeKABUPATEN": 1210,
        "namaKECAMATAN": "BERAMPU"
      },
      {
        "kodeKECAMATAN": 1210032,
        "kodeKABUPATEN": 1210,
        "namaKECAMATAN": "SITINJO"
      },
      {
        "kodeKECAMATAN": 1210040,
        "kodeKABUPATEN": 1210,
        "namaKECAMATAN": "PARBULUAN"
      },
      {
        "kodeKECAMATAN": 1210050,
        "kodeKABUPATEN": 1210,
        "namaKECAMATAN": "SUMBUL"
      },
      {
        "kodeKECAMATAN": 1210051,
        "kodeKABUPATEN": 1210,
        "namaKECAMATAN": "SILAHI SABUNGAN"
      },
      {
        "kodeKECAMATAN": 1210060,
        "kodeKABUPATEN": 1210,
        "namaKECAMATAN": "SILIMA PUNGGA-PUNGGA"
      },
      {
        "kodeKECAMATAN": 1210061,
        "kodeKABUPATEN": 1210,
        "namaKECAMATAN": "LAE PARIRA"
      },
      {
        "kodeKECAMATAN": 1210070,
        "kodeKABUPATEN": 1210,
        "namaKECAMATAN": "SIEMPAT NEMPU"
      },
      {
        "kodeKECAMATAN": 1210080,
        "kodeKABUPATEN": 1210,
        "namaKECAMATAN": "SIEMPAT NEMPU HULU"
      },
      {
        "kodeKECAMATAN": 1210090,
        "kodeKABUPATEN": 1210,
        "namaKECAMATAN": "SIEMPAT NEMPU HILIR"
      },
      {
        "kodeKECAMATAN": 1210100,
        "kodeKABUPATEN": 1210,
        "namaKECAMATAN": "TIGA LINGGA"
      },
      {
        "kodeKECAMATAN": 1210101,
        "kodeKABUPATEN": 1210,
        "namaKECAMATAN": "GUNUNG SITEMBER"
      },
      {
        "kodeKECAMATAN": 1210110,
        "kodeKABUPATEN": 1210,
        "namaKECAMATAN": "PEGAGAN HILIR"
      },
      {
        "kodeKECAMATAN": 1210120,
        "kodeKABUPATEN": 1210,
        "namaKECAMATAN": "TANAH PINEM"
      },
      {
        "kodeKECAMATAN": 1211010,
        "kodeKABUPATEN": 1211,
        "namaKECAMATAN": "MARDINGDING"
      },
      {
        "kodeKECAMATAN": 1211020,
        "kodeKABUPATEN": 1211,
        "namaKECAMATAN": "LAUBALENG"
      },
      {
        "kodeKECAMATAN": 1211030,
        "kodeKABUPATEN": 1211,
        "namaKECAMATAN": "TIGA BINANGA"
      },
      {
        "kodeKECAMATAN": 1211040,
        "kodeKABUPATEN": 1211,
        "namaKECAMATAN": "JUHAR"
      },
      {
        "kodeKECAMATAN": 1211050,
        "kodeKABUPATEN": 1211,
        "namaKECAMATAN": "MUNTE"
      },
      {
        "kodeKECAMATAN": 1211060,
        "kodeKABUPATEN": 1211,
        "namaKECAMATAN": "KUTA BULUH"
      },
      {
        "kodeKECAMATAN": 1211070,
        "kodeKABUPATEN": 1211,
        "namaKECAMATAN": "PAYUNG"
      },
      {
        "kodeKECAMATAN": 1211071,
        "kodeKABUPATEN": 1211,
        "namaKECAMATAN": "TIGANDERKET"
      },
      {
        "kodeKECAMATAN": 1211080,
        "kodeKABUPATEN": 1211,
        "namaKECAMATAN": "SIMPANG EMPAT"
      },
      {
        "kodeKECAMATAN": 1211081,
        "kodeKABUPATEN": 1211,
        "namaKECAMATAN": "NAMAN TERAN"
      },
      {
        "kodeKECAMATAN": 1211082,
        "kodeKABUPATEN": 1211,
        "namaKECAMATAN": "MERDEKA"
      },
      {
        "kodeKECAMATAN": 1211090,
        "kodeKABUPATEN": 1211,
        "namaKECAMATAN": "KABANJAHE"
      },
      {
        "kodeKECAMATAN": 1211100,
        "kodeKABUPATEN": 1211,
        "namaKECAMATAN": "BERASTAGI"
      },
      {
        "kodeKECAMATAN": 1211110,
        "kodeKABUPATEN": 1211,
        "namaKECAMATAN": "TIGAPANAH"
      },
      {
        "kodeKECAMATAN": 1211111,
        "kodeKABUPATEN": 1211,
        "namaKECAMATAN": "DOLAT RAYAT"
      },
      {
        "kodeKECAMATAN": 1211120,
        "kodeKABUPATEN": 1211,
        "namaKECAMATAN": "MEREK"
      },
      {
        "kodeKECAMATAN": 1211130,
        "kodeKABUPATEN": 1211,
        "namaKECAMATAN": "BARUSJAHE"
      },
      {
        "kodeKECAMATAN": 1212010,
        "kodeKABUPATEN": 1212,
        "namaKECAMATAN": "GUNUNG MERIAH"
      },
      {
        "kodeKECAMATAN": 1212020,
        "kodeKABUPATEN": 1212,
        "namaKECAMATAN": "SINEMBAH TANJUNG MUDA HULU"
      },
      {
        "kodeKECAMATAN": 1212030,
        "kodeKABUPATEN": 1212,
        "namaKECAMATAN": "SIBOLANGIT"
      },
      {
        "kodeKECAMATAN": 1212040,
        "kodeKABUPATEN": 1212,
        "namaKECAMATAN": "KUTALIMBARU"
      },
      {
        "kodeKECAMATAN": 1212050,
        "kodeKABUPATEN": 1212,
        "namaKECAMATAN": "PANCUR BATU"
      },
      {
        "kodeKECAMATAN": 1212060,
        "kodeKABUPATEN": 1212,
        "namaKECAMATAN": "NAMO RAMBE"
      },
      {
        "kodeKECAMATAN": 1212070,
        "kodeKABUPATEN": 1212,
        "namaKECAMATAN": "BIRU-BIRU"
      },
      {
        "kodeKECAMATAN": 1212080,
        "kodeKABUPATEN": 1212,
        "namaKECAMATAN": "SINEMBAH TANJUNG MUDA HILIR"
      },
      {
        "kodeKECAMATAN": 1212090,
        "kodeKABUPATEN": 1212,
        "namaKECAMATAN": "BANGUN PURBA"
      },
      {
        "kodeKECAMATAN": 1212190,
        "kodeKABUPATEN": 1212,
        "namaKECAMATAN": "GALANG"
      },
      {
        "kodeKECAMATAN": 1212200,
        "kodeKABUPATEN": 1212,
        "namaKECAMATAN": "TANJUNG MORAWA"
      },
      {
        "kodeKECAMATAN": 1212210,
        "kodeKABUPATEN": 1212,
        "namaKECAMATAN": "PATUMBAK"
      },
      {
        "kodeKECAMATAN": 1212220,
        "kodeKABUPATEN": 1212,
        "namaKECAMATAN": "DELI TUA"
      },
      {
        "kodeKECAMATAN": 1212230,
        "kodeKABUPATEN": 1212,
        "namaKECAMATAN": "SUNGGAL"
      },
      {
        "kodeKECAMATAN": 1212240,
        "kodeKABUPATEN": 1212,
        "namaKECAMATAN": "HAMPARAN PERAK"
      },
      {
        "kodeKECAMATAN": 1212250,
        "kodeKABUPATEN": 1212,
        "namaKECAMATAN": "LABUHAN DELI"
      },
      {
        "kodeKECAMATAN": 1212260,
        "kodeKABUPATEN": 1212,
        "namaKECAMATAN": "PERCUT SEI TUAN"
      },
      {
        "kodeKECAMATAN": 1212270,
        "kodeKABUPATEN": 1212,
        "namaKECAMATAN": "BATANG KUIS"
      },
      {
        "kodeKECAMATAN": 1212280,
        "kodeKABUPATEN": 1212,
        "namaKECAMATAN": "PANTAI LABU"
      },
      {
        "kodeKECAMATAN": 1212290,
        "kodeKABUPATEN": 1212,
        "namaKECAMATAN": "BERINGIN"
      },
      {
        "kodeKECAMATAN": 1212300,
        "kodeKABUPATEN": 1212,
        "namaKECAMATAN": "LUBUK PAKAM"
      },
      {
        "kodeKECAMATAN": 1212310,
        "kodeKABUPATEN": 1212,
        "namaKECAMATAN": "PAGAR MERBAU"
      },
      {
        "kodeKECAMATAN": 1213010,
        "kodeKABUPATEN": 1213,
        "namaKECAMATAN": "BOHOROK"
      },
      {
        "kodeKECAMATAN": 1213011,
        "kodeKABUPATEN": 1213,
        "namaKECAMATAN": "SIRAPIT"
      },
      {
        "kodeKECAMATAN": 1213020,
        "kodeKABUPATEN": 1213,
        "namaKECAMATAN": "SALAPIAN"
      },
      {
        "kodeKECAMATAN": 1213021,
        "kodeKABUPATEN": 1213,
        "namaKECAMATAN": "KUTAMBARU"
      },
      {
        "kodeKECAMATAN": 1213030,
        "kodeKABUPATEN": 1213,
        "namaKECAMATAN": "SEI BINGAI"
      },
      {
        "kodeKECAMATAN": 1213040,
        "kodeKABUPATEN": 1213,
        "namaKECAMATAN": "KUALA"
      },
      {
        "kodeKECAMATAN": 1213050,
        "kodeKABUPATEN": 1213,
        "namaKECAMATAN": "SELESAI"
      },
      {
        "kodeKECAMATAN": 1213060,
        "kodeKABUPATEN": 1213,
        "namaKECAMATAN": "BINJAI"
      },
      {
        "kodeKECAMATAN": 1213070,
        "kodeKABUPATEN": 1213,
        "namaKECAMATAN": "STABAT"
      },
      {
        "kodeKECAMATAN": 1213080,
        "kodeKABUPATEN": 1213,
        "namaKECAMATAN": "WAMPU"
      },
      {
        "kodeKECAMATAN": 1213090,
        "kodeKABUPATEN": 1213,
        "namaKECAMATAN": "BATANG SERANGAN"
      },
      {
        "kodeKECAMATAN": 1213100,
        "kodeKABUPATEN": 1213,
        "namaKECAMATAN": "SAWIT SEBERANG"
      },
      {
        "kodeKECAMATAN": 1213110,
        "kodeKABUPATEN": 1213,
        "namaKECAMATAN": "PADANG TUALANG"
      },
      {
        "kodeKECAMATAN": 1213120,
        "kodeKABUPATEN": 1213,
        "namaKECAMATAN": "HINAI"
      },
      {
        "kodeKECAMATAN": 1213130,
        "kodeKABUPATEN": 1213,
        "namaKECAMATAN": "SECANGGANG"
      },
      {
        "kodeKECAMATAN": 1213140,
        "kodeKABUPATEN": 1213,
        "namaKECAMATAN": "TANJUNG PURA"
      },
      {
        "kodeKECAMATAN": 1213150,
        "kodeKABUPATEN": 1213,
        "namaKECAMATAN": "GEBANG"
      },
      {
        "kodeKECAMATAN": 1213160,
        "kodeKABUPATEN": 1213,
        "namaKECAMATAN": "BABALAN"
      },
      {
        "kodeKECAMATAN": 1213170,
        "kodeKABUPATEN": 1213,
        "namaKECAMATAN": "SEI LEPAN"
      },
      {
        "kodeKECAMATAN": 1213180,
        "kodeKABUPATEN": 1213,
        "namaKECAMATAN": "BRANDAN BARAT"
      },
      {
        "kodeKECAMATAN": 1213190,
        "kodeKABUPATEN": 1213,
        "namaKECAMATAN": "BESITANG"
      },
      {
        "kodeKECAMATAN": 1213200,
        "kodeKABUPATEN": 1213,
        "namaKECAMATAN": "PANGKALAN SUSU"
      },
      {
        "kodeKECAMATAN": 1213201,
        "kodeKABUPATEN": 1213,
        "namaKECAMATAN": "PEMATANG JAYA"
      },
      {
        "kodeKECAMATAN": 1214010,
        "kodeKABUPATEN": 1214,
        "namaKECAMATAN": "HIBALA"
      },
      {
        "kodeKECAMATAN": 1214011,
        "kodeKABUPATEN": 1214,
        "namaKECAMATAN": "TANAH MASA"
      },
      {
        "kodeKECAMATAN": 1214020,
        "kodeKABUPATEN": 1214,
        "namaKECAMATAN": "PULAU-PULAU BATU"
      },
      {
        "kodeKECAMATAN": 1214021,
        "kodeKABUPATEN": 1214,
        "namaKECAMATAN": "PULAU-PULAU BATU TIMUR"
      },
      {
        "kodeKECAMATAN": 1214022,
        "kodeKABUPATEN": 1214,
        "namaKECAMATAN": "SIMUK"
      },
      {
        "kodeKECAMATAN": 1214023,
        "kodeKABUPATEN": 1214,
        "namaKECAMATAN": "PULAU-PULAU BATU BARAT"
      },
      {
        "kodeKECAMATAN": 1214024,
        "kodeKABUPATEN": 1214,
        "namaKECAMATAN": "PULAU-PULAU BATU UTARA"
      },
      {
        "kodeKECAMATAN": 1214030,
        "kodeKABUPATEN": 1214,
        "namaKECAMATAN": "TELUK DALAM"
      },
      {
        "kodeKECAMATAN": 1214031,
        "kodeKABUPATEN": 1214,
        "namaKECAMATAN": "FANAYAMA"
      },
      {
        "kodeKECAMATAN": 1214032,
        "kodeKABUPATEN": 1214,
        "namaKECAMATAN": "TOMA"
      },
      {
        "kodeKECAMATAN": 1214033,
        "kodeKABUPATEN": 1214,
        "namaKECAMATAN": "MANIAMOLO"
      },
      {
        "kodeKECAMATAN": 1214034,
        "kodeKABUPATEN": 1214,
        "namaKECAMATAN": "MAZINO"
      },
      {
        "kodeKECAMATAN": 1214035,
        "kodeKABUPATEN": 1214,
        "namaKECAMATAN": "LUAHAGUNDRE MANIAMOLO"
      },
      {
        "kodeKECAMATAN": 1214036,
        "kodeKABUPATEN": 1214,
        "namaKECAMATAN": "ONOLALU"
      },
      {
        "kodeKECAMATAN": 1214040,
        "kodeKABUPATEN": 1214,
        "namaKECAMATAN": "AMANDRAYA"
      },
      {
        "kodeKECAMATAN": 1214041,
        "kodeKABUPATEN": 1214,
        "namaKECAMATAN": "ARAMO"
      },
      {
        "kodeKECAMATAN": 1214042,
        "kodeKABUPATEN": 1214,
        "namaKECAMATAN": "ULUSUSUA"
      },
      {
        "kodeKECAMATAN": 1214050,
        "kodeKABUPATEN": 1214,
        "namaKECAMATAN": "LAHUSA"
      },
      {
        "kodeKECAMATAN": 1214051,
        "kodeKABUPATEN": 1214,
        "namaKECAMATAN": "SIDUAORI"
      },
      {
        "kodeKECAMATAN": 1214052,
        "kodeKABUPATEN": 1214,
        "namaKECAMATAN": "SOMAMBAWA"
      },
      {
        "kodeKECAMATAN": 1214060,
        "kodeKABUPATEN": 1214,
        "namaKECAMATAN": "GOMO"
      },
      {
        "kodeKECAMATAN": 1214061,
        "kodeKABUPATEN": 1214,
        "namaKECAMATAN": "SUSUA"
      },
      {
        "kodeKECAMATAN": 1214062,
        "kodeKABUPATEN": 1214,
        "namaKECAMATAN": "MAZO"
      },
      {
        "kodeKECAMATAN": 1214063,
        "kodeKABUPATEN": 1214,
        "namaKECAMATAN": "UMBUNASI"
      },
      {
        "kodeKECAMATAN": 1214064,
        "kodeKABUPATEN": 1214,
        "namaKECAMATAN": "IDANOTAE"
      },
      {
        "kodeKECAMATAN": 1214065,
        "kodeKABUPATEN": 1214,
        "namaKECAMATAN": "ULUIDANOTAE"
      },
      {
        "kodeKECAMATAN": 1214066,
        "kodeKABUPATEN": 1214,
        "namaKECAMATAN": "BORONADU"
      },
      {
        "kodeKECAMATAN": 1214070,
        "kodeKABUPATEN": 1214,
        "namaKECAMATAN": "LOLOMATUA"
      },
      {
        "kodeKECAMATAN": 1214071,
        "kodeKABUPATEN": 1214,
        "namaKECAMATAN": "ULUNOYO"
      },
      {
        "kodeKECAMATAN": 1214072,
        "kodeKABUPATEN": 1214,
        "namaKECAMATAN": "HURUNA"
      },
      {
        "kodeKECAMATAN": 1214080,
        "kodeKABUPATEN": 1214,
        "namaKECAMATAN": "LOLOWA'U"
      },
      {
        "kodeKECAMATAN": 1214081,
        "kodeKABUPATEN": 1214,
        "namaKECAMATAN": "HILIMEGAI"
      },
      {
        "kodeKECAMATAN": 1214082,
        "kodeKABUPATEN": 1214,
        "namaKECAMATAN": "OOU"
      },
      {
        "kodeKECAMATAN": 1214083,
        "kodeKABUPATEN": 1214,
        "namaKECAMATAN": "ONOHAZUMBA"
      },
      {
        "kodeKECAMATAN": 1214084,
        "kodeKABUPATEN": 1214,
        "namaKECAMATAN": "HILISALAWAAHE"
      },
      {
        "kodeKECAMATAN": 1215010,
        "kodeKABUPATEN": 1215,
        "namaKECAMATAN": "PAKKAT"
      },
      {
        "kodeKECAMATAN": 1215020,
        "kodeKABUPATEN": 1215,
        "namaKECAMATAN": "ONAN GANJANG"
      },
      {
        "kodeKECAMATAN": 1215030,
        "kodeKABUPATEN": 1215,
        "namaKECAMATAN": "SIJAMA POLANG"
      },
      {
        "kodeKECAMATAN": 1215040,
        "kodeKABUPATEN": 1215,
        "namaKECAMATAN": "DOLOK SANGGUL"
      },
      {
        "kodeKECAMATAN": 1215050,
        "kodeKABUPATEN": 1215,
        "namaKECAMATAN": "LINTONG NIHUTA"
      },
      {
        "kodeKECAMATAN": 1215060,
        "kodeKABUPATEN": 1215,
        "namaKECAMATAN": "PARANGINAN"
      },
      {
        "kodeKECAMATAN": 1215070,
        "kodeKABUPATEN": 1215,
        "namaKECAMATAN": "BAKTI RAJA"
      },
      {
        "kodeKECAMATAN": 1215080,
        "kodeKABUPATEN": 1215,
        "namaKECAMATAN": "POLLUNG"
      },
      {
        "kodeKECAMATAN": 1215090,
        "kodeKABUPATEN": 1215,
        "namaKECAMATAN": "PARLILITAN"
      },
      {
        "kodeKECAMATAN": 1215100,
        "kodeKABUPATEN": 1215,
        "namaKECAMATAN": "TARA BINTANG"
      },
      {
        "kodeKECAMATAN": 1216010,
        "kodeKABUPATEN": 1216,
        "namaKECAMATAN": "SALAK"
      },
      {
        "kodeKECAMATAN": 1216011,
        "kodeKABUPATEN": 1216,
        "namaKECAMATAN": "SITELLU TALI URANG JEHE"
      },
      {
        "kodeKECAMATAN": 1216012,
        "kodeKABUPATEN": 1216,
        "namaKECAMATAN": "PAGINDAR"
      },
      {
        "kodeKECAMATAN": 1216013,
        "kodeKABUPATEN": 1216,
        "namaKECAMATAN": "SITELLU TALI URANG JULU"
      },
      {
        "kodeKECAMATAN": 1216014,
        "kodeKABUPATEN": 1216,
        "namaKECAMATAN": "PERGETTENG-GETTENG SENGKUT"
      },
      {
        "kodeKECAMATAN": 1216020,
        "kodeKABUPATEN": 1216,
        "namaKECAMATAN": "KERAJAAN"
      },
      {
        "kodeKECAMATAN": 1216021,
        "kodeKABUPATEN": 1216,
        "namaKECAMATAN": "TINADA"
      },
      {
        "kodeKECAMATAN": 1216022,
        "kodeKABUPATEN": 1216,
        "namaKECAMATAN": "SIEMPAT RUBE"
      },
      {
        "kodeKECAMATAN": 1217010,
        "kodeKABUPATEN": 1217,
        "namaKECAMATAN": "SIANJUR MULA MULA"
      },
      {
        "kodeKECAMATAN": 1217020,
        "kodeKABUPATEN": 1217,
        "namaKECAMATAN": "HARIAN"
      },
      {
        "kodeKECAMATAN": 1217030,
        "kodeKABUPATEN": 1217,
        "namaKECAMATAN": "SITIO-TIO"
      },
      {
        "kodeKECAMATAN": 1217040,
        "kodeKABUPATEN": 1217,
        "namaKECAMATAN": "ONAN RUNGGU"
      },
      {
        "kodeKECAMATAN": 1217050,
        "kodeKABUPATEN": 1217,
        "namaKECAMATAN": "NAINGGOLAN"
      },
      {
        "kodeKECAMATAN": 1217060,
        "kodeKABUPATEN": 1217,
        "namaKECAMATAN": "PALIPI"
      },
      {
        "kodeKECAMATAN": 1217070,
        "kodeKABUPATEN": 1217,
        "namaKECAMATAN": "RONGGUR NIHUTA"
      },
      {
        "kodeKECAMATAN": 1217080,
        "kodeKABUPATEN": 1217,
        "namaKECAMATAN": "PANGURURAN"
      },
      {
        "kodeKECAMATAN": 1217090,
        "kodeKABUPATEN": 1217,
        "namaKECAMATAN": "SIMANINDO"
      },
      {
        "kodeKECAMATAN": 1218010,
        "kodeKABUPATEN": 1218,
        "namaKECAMATAN": "KOTARIH"
      },
      {
        "kodeKECAMATAN": 1218011,
        "kodeKABUPATEN": 1218,
        "namaKECAMATAN": "SILINDA"
      },
      {
        "kodeKECAMATAN": 1218012,
        "kodeKABUPATEN": 1218,
        "namaKECAMATAN": "BINTANG BAYU"
      },
      {
        "kodeKECAMATAN": 1218020,
        "kodeKABUPATEN": 1218,
        "namaKECAMATAN": "DOLOK MASIHUL"
      },
      {
        "kodeKECAMATAN": 1218021,
        "kodeKABUPATEN": 1218,
        "namaKECAMATAN": "SERBAJADI"
      },
      {
        "kodeKECAMATAN": 1218030,
        "kodeKABUPATEN": 1218,
        "namaKECAMATAN": "SIPISPIS"
      },
      {
        "kodeKECAMATAN": 1218040,
        "kodeKABUPATEN": 1218,
        "namaKECAMATAN": "DOLOK MERAWAN"
      },
      {
        "kodeKECAMATAN": 1218050,
        "kodeKABUPATEN": 1218,
        "namaKECAMATAN": "TEBINGTINGGI"
      },
      {
        "kodeKECAMATAN": 1218051,
        "kodeKABUPATEN": 1218,
        "namaKECAMATAN": "TEBING SYAHBANDAR"
      },
      {
        "kodeKECAMATAN": 1218060,
        "kodeKABUPATEN": 1218,
        "namaKECAMATAN": "BANDAR KHALIPAH"
      },
      {
        "kodeKECAMATAN": 1218070,
        "kodeKABUPATEN": 1218,
        "namaKECAMATAN": "TANJUNG BERINGIN"
      },
      {
        "kodeKECAMATAN": 1218080,
        "kodeKABUPATEN": 1218,
        "namaKECAMATAN": "SEI RAMPAH"
      },
      {
        "kodeKECAMATAN": 1218081,
        "kodeKABUPATEN": 1218,
        "namaKECAMATAN": "SEI BAMBAN"
      },
      {
        "kodeKECAMATAN": 1218090,
        "kodeKABUPATEN": 1218,
        "namaKECAMATAN": "TELUK MENGKUDU"
      },
      {
        "kodeKECAMATAN": 1218100,
        "kodeKABUPATEN": 1218,
        "namaKECAMATAN": "PERBAUNGAN"
      },
      {
        "kodeKECAMATAN": 1218101,
        "kodeKABUPATEN": 1218,
        "namaKECAMATAN": "PEGAJAHAN"
      },
      {
        "kodeKECAMATAN": 1218110,
        "kodeKABUPATEN": 1218,
        "namaKECAMATAN": "PANTAI CERMIN"
      },
      {
        "kodeKECAMATAN": 1219010,
        "kodeKABUPATEN": 1219,
        "namaKECAMATAN": "SEI BALAI"
      },
      {
        "kodeKECAMATAN": 1219020,
        "kodeKABUPATEN": 1219,
        "namaKECAMATAN": "TANJUNG TIRAM"
      },
      {
        "kodeKECAMATAN": 1219030,
        "kodeKABUPATEN": 1219,
        "namaKECAMATAN": "TALAWI"
      },
      {
        "kodeKECAMATAN": 1219040,
        "kodeKABUPATEN": 1219,
        "namaKECAMATAN": "LIMAPULUH"
      },
      {
        "kodeKECAMATAN": 1219050,
        "kodeKABUPATEN": 1219,
        "namaKECAMATAN": "AIR PUTIH"
      },
      {
        "kodeKECAMATAN": 1219060,
        "kodeKABUPATEN": 1219,
        "namaKECAMATAN": "SEI SUKA"
      },
      {
        "kodeKECAMATAN": 1219070,
        "kodeKABUPATEN": 1219,
        "namaKECAMATAN": "MEDANG DERAS"
      },
      {
        "kodeKECAMATAN": 1220010,
        "kodeKABUPATEN": 1220,
        "namaKECAMATAN": "BATANG ONANG"
      },
      {
        "kodeKECAMATAN": 1220020,
        "kodeKABUPATEN": 1220,
        "namaKECAMATAN": "PADANG BOLAK JULU"
      },
      {
        "kodeKECAMATAN": 1220030,
        "kodeKABUPATEN": 1220,
        "namaKECAMATAN": "PORTIBI"
      },
      {
        "kodeKECAMATAN": 1220040,
        "kodeKABUPATEN": 1220,
        "namaKECAMATAN": "PADANG BOLAK"
      },
      {
        "kodeKECAMATAN": 1220050,
        "kodeKABUPATEN": 1220,
        "namaKECAMATAN": "SIMANGAMBAT"
      },
      {
        "kodeKECAMATAN": 1220060,
        "kodeKABUPATEN": 1220,
        "namaKECAMATAN": "HALONGONAN"
      },
      {
        "kodeKECAMATAN": 1220070,
        "kodeKABUPATEN": 1220,
        "namaKECAMATAN": "DOLOK"
      },
      {
        "kodeKECAMATAN": 1220080,
        "kodeKABUPATEN": 1220,
        "namaKECAMATAN": "DOLOK SIGOMPULON"
      },
      {
        "kodeKECAMATAN": 1220090,
        "kodeKABUPATEN": 1220,
        "namaKECAMATAN": "HULU SIHAPAS"
      },
      {
        "kodeKECAMATAN": 1221010,
        "kodeKABUPATEN": 1221,
        "namaKECAMATAN": "SOSOPAN"
      },
      {
        "kodeKECAMATAN": 1221020,
        "kodeKABUPATEN": 1221,
        "namaKECAMATAN": "ULU BARUMUN"
      },
      {
        "kodeKECAMATAN": 1221030,
        "kodeKABUPATEN": 1221,
        "namaKECAMATAN": "BARUMUN"
      },
      {
        "kodeKECAMATAN": 1221031,
        "kodeKABUPATEN": 1221,
        "namaKECAMATAN": "BARUMUN SELATAN"
      },
      {
        "kodeKECAMATAN": 1221040,
        "kodeKABUPATEN": 1221,
        "namaKECAMATAN": "LUBUK BARUMUN"
      },
      {
        "kodeKECAMATAN": 1221050,
        "kodeKABUPATEN": 1221,
        "namaKECAMATAN": "SOSA"
      },
      {
        "kodeKECAMATAN": 1221060,
        "kodeKABUPATEN": 1221,
        "namaKECAMATAN": "BATANG LUBU SUTAM"
      },
      {
        "kodeKECAMATAN": 1221070,
        "kodeKABUPATEN": 1221,
        "namaKECAMATAN": "HUTA RAJA TINGGI"
      },
      {
        "kodeKECAMATAN": 1221080,
        "kodeKABUPATEN": 1221,
        "namaKECAMATAN": "HURISTAK"
      },
      {
        "kodeKECAMATAN": 1221090,
        "kodeKABUPATEN": 1221,
        "namaKECAMATAN": "BARUMUN TENGAH"
      },
      {
        "kodeKECAMATAN": 1221091,
        "kodeKABUPATEN": 1221,
        "namaKECAMATAN": "AEK NABARA BARUMUN"
      },
      {
        "kodeKECAMATAN": 1221092,
        "kodeKABUPATEN": 1221,
        "namaKECAMATAN": "SIHAPAS BARUMUN"
      },
      {
        "kodeKECAMATAN": 1222010,
        "kodeKABUPATEN": 1222,
        "namaKECAMATAN": "SUNGAI KANAN"
      },
      {
        "kodeKECAMATAN": 1222020,
        "kodeKABUPATEN": 1222,
        "namaKECAMATAN": "TORGAMBA"
      },
      {
        "kodeKECAMATAN": 1222030,
        "kodeKABUPATEN": 1222,
        "namaKECAMATAN": "KOTA PINANG"
      },
      {
        "kodeKECAMATAN": 1222040,
        "kodeKABUPATEN": 1222,
        "namaKECAMATAN": "SILANGKITANG"
      },
      {
        "kodeKECAMATAN": 1222050,
        "kodeKABUPATEN": 1222,
        "namaKECAMATAN": "KAMPUNG RAKYAT"
      },
      {
        "kodeKECAMATAN": 1223010,
        "kodeKABUPATEN": 1223,
        "namaKECAMATAN": "NA IX-X"
      },
      {
        "kodeKECAMATAN": 1223020,
        "kodeKABUPATEN": 1223,
        "namaKECAMATAN": "MARBAU"
      },
      {
        "kodeKECAMATAN": 1223030,
        "kodeKABUPATEN": 1223,
        "namaKECAMATAN": "AEK KUO"
      },
      {
        "kodeKECAMATAN": 1223040,
        "kodeKABUPATEN": 1223,
        "namaKECAMATAN": "AEK NATAS"
      },
      {
        "kodeKECAMATAN": 1223050,
        "kodeKABUPATEN": 1223,
        "namaKECAMATAN": "KUALUH SELATAN"
      },
      {
        "kodeKECAMATAN": 1223060,
        "kodeKABUPATEN": 1223,
        "namaKECAMATAN": "KUALUH HILIR"
      },
      {
        "kodeKECAMATAN": 1223070,
        "kodeKABUPATEN": 1223,
        "namaKECAMATAN": "KUALUH HULU"
      },
      {
        "kodeKECAMATAN": 1223080,
        "kodeKABUPATEN": 1223,
        "namaKECAMATAN": "KUALUH LEIDONG"
      },
      {
        "kodeKECAMATAN": 1224010,
        "kodeKABUPATEN": 1224,
        "namaKECAMATAN": "TUGALA OYO"
      },
      {
        "kodeKECAMATAN": 1224020,
        "kodeKABUPATEN": 1224,
        "namaKECAMATAN": "ALASA"
      },
      {
        "kodeKECAMATAN": 1224030,
        "kodeKABUPATEN": 1224,
        "namaKECAMATAN": "ALASA TALU MUZOI"
      },
      {
        "kodeKECAMATAN": 1224040,
        "kodeKABUPATEN": 1224,
        "namaKECAMATAN": "NAMOHALU ESIWA"
      },
      {
        "kodeKECAMATAN": 1224050,
        "kodeKABUPATEN": 1224,
        "namaKECAMATAN": "SITOLU ORI"
      },
      {
        "kodeKECAMATAN": 1224060,
        "kodeKABUPATEN": 1224,
        "namaKECAMATAN": "TUHEMBERUA"
      },
      {
        "kodeKECAMATAN": 1224070,
        "kodeKABUPATEN": 1224,
        "namaKECAMATAN": "SAWO"
      },
      {
        "kodeKECAMATAN": 1224080,
        "kodeKABUPATEN": 1224,
        "namaKECAMATAN": "LOTU"
      },
      {
        "kodeKECAMATAN": 1224090,
        "kodeKABUPATEN": 1224,
        "namaKECAMATAN": "LAHEWA TIMUR"
      },
      {
        "kodeKECAMATAN": 1224100,
        "kodeKABUPATEN": 1224,
        "namaKECAMATAN": "AFULU"
      },
      {
        "kodeKECAMATAN": 1224110,
        "kodeKABUPATEN": 1224,
        "namaKECAMATAN": "LAHEWA"
      },
      {
        "kodeKECAMATAN": 1225010,
        "kodeKABUPATEN": 1225,
        "namaKECAMATAN": "SIROMBU"
      },
      {
        "kodeKECAMATAN": 1225020,
        "kodeKABUPATEN": 1225,
        "namaKECAMATAN": "LAHOMI"
      },
      {
        "kodeKECAMATAN": 1225030,
        "kodeKABUPATEN": 1225,
        "namaKECAMATAN": "ULU MORO O"
      },
      {
        "kodeKECAMATAN": 1225040,
        "kodeKABUPATEN": 1225,
        "namaKECAMATAN": "LOLOFITU MOI"
      },
      {
        "kodeKECAMATAN": 1225050,
        "kodeKABUPATEN": 1225,
        "namaKECAMATAN": "MANDREHE UTARA"
      },
      {
        "kodeKECAMATAN": 1225060,
        "kodeKABUPATEN": 1225,
        "namaKECAMATAN": "MANDREHE"
      },
      {
        "kodeKECAMATAN": 1225070,
        "kodeKABUPATEN": 1225,
        "namaKECAMATAN": "MANDREHE BARAT"
      },
      {
        "kodeKECAMATAN": 1225080,
        "kodeKABUPATEN": 1225,
        "namaKECAMATAN": "MORO O"
      },
      {
        "kodeKECAMATAN": 1271010,
        "kodeKABUPATEN": 1271,
        "namaKECAMATAN": "SIBOLGA UTARA"
      },
      {
        "kodeKECAMATAN": 1271020,
        "kodeKABUPATEN": 1271,
        "namaKECAMATAN": "SIBOLGA KOTA"
      },
      {
        "kodeKECAMATAN": 1271030,
        "kodeKABUPATEN": 1271,
        "namaKECAMATAN": "SIBOLGA SELATAN"
      },
      {
        "kodeKECAMATAN": 1271031,
        "kodeKABUPATEN": 1271,
        "namaKECAMATAN": "SIBOLGA SAMBAS"
      },
      {
        "kodeKECAMATAN": 1272010,
        "kodeKABUPATEN": 1272,
        "namaKECAMATAN": "DATUK BANDAR"
      },
      {
        "kodeKECAMATAN": 1272011,
        "kodeKABUPATEN": 1272,
        "namaKECAMATAN": "DATUK BANDAR TIMUR"
      },
      {
        "kodeKECAMATAN": 1272020,
        "kodeKABUPATEN": 1272,
        "namaKECAMATAN": "TANJUNG BALAI SELATAN"
      },
      {
        "kodeKECAMATAN": 1272030,
        "kodeKABUPATEN": 1272,
        "namaKECAMATAN": "TANJUNG BALAI UTARA"
      },
      {
        "kodeKECAMATAN": 1272040,
        "kodeKABUPATEN": 1272,
        "namaKECAMATAN": "SEI TUALANG RASO"
      },
      {
        "kodeKECAMATAN": 1272050,
        "kodeKABUPATEN": 1272,
        "namaKECAMATAN": "TELUK NIBUNG"
      },
      {
        "kodeKECAMATAN": 1273010,
        "kodeKABUPATEN": 1273,
        "namaKECAMATAN": "SIANTAR MARIHAT"
      },
      {
        "kodeKECAMATAN": 1273011,
        "kodeKABUPATEN": 1273,
        "namaKECAMATAN": "SIANTAR MARIMBUN"
      },
      {
        "kodeKECAMATAN": 1273020,
        "kodeKABUPATEN": 1273,
        "namaKECAMATAN": "SIANTAR SELATAN"
      },
      {
        "kodeKECAMATAN": 1273030,
        "kodeKABUPATEN": 1273,
        "namaKECAMATAN": "SIANTAR BARAT"
      },
      {
        "kodeKECAMATAN": 1273040,
        "kodeKABUPATEN": 1273,
        "namaKECAMATAN": "SIANTAR UTARA"
      },
      {
        "kodeKECAMATAN": 1273050,
        "kodeKABUPATEN": 1273,
        "namaKECAMATAN": "SIANTAR TIMUR"
      },
      {
        "kodeKECAMATAN": 1273060,
        "kodeKABUPATEN": 1273,
        "namaKECAMATAN": "SIANTAR MARTOBA"
      },
      {
        "kodeKECAMATAN": 1273061,
        "kodeKABUPATEN": 1273,
        "namaKECAMATAN": "SIANTAR SITALASARI"
      },
      {
        "kodeKECAMATAN": 1274010,
        "kodeKABUPATEN": 1274,
        "namaKECAMATAN": "PADANG HULU"
      },
      {
        "kodeKECAMATAN": 1274011,
        "kodeKABUPATEN": 1274,
        "namaKECAMATAN": "TEBING TINGGI KOTA"
      },
      {
        "kodeKECAMATAN": 1274020,
        "kodeKABUPATEN": 1274,
        "namaKECAMATAN": "RAMBUTAN"
      },
      {
        "kodeKECAMATAN": 1274021,
        "kodeKABUPATEN": 1274,
        "namaKECAMATAN": "BAJENIS"
      },
      {
        "kodeKECAMATAN": 1274030,
        "kodeKABUPATEN": 1274,
        "namaKECAMATAN": "PADANG HILIR"
      },
      {
        "kodeKECAMATAN": 1275010,
        "kodeKABUPATEN": 1275,
        "namaKECAMATAN": "MEDAN TUNTUNGAN"
      },
      {
        "kodeKECAMATAN": 1275020,
        "kodeKABUPATEN": 1275,
        "namaKECAMATAN": "MEDAN JOHOR"
      },
      {
        "kodeKECAMATAN": 1275030,
        "kodeKABUPATEN": 1275,
        "namaKECAMATAN": "MEDAN AMPLAS"
      },
      {
        "kodeKECAMATAN": 1275040,
        "kodeKABUPATEN": 1275,
        "namaKECAMATAN": "MEDAN DENAI"
      },
      {
        "kodeKECAMATAN": 1275050,
        "kodeKABUPATEN": 1275,
        "namaKECAMATAN": "MEDAN AREA"
      },
      {
        "kodeKECAMATAN": 1275060,
        "kodeKABUPATEN": 1275,
        "namaKECAMATAN": "MEDAN KOTA"
      },
      {
        "kodeKECAMATAN": 1275070,
        "kodeKABUPATEN": 1275,
        "namaKECAMATAN": "MEDAN MAIMUN"
      },
      {
        "kodeKECAMATAN": 1275080,
        "kodeKABUPATEN": 1275,
        "namaKECAMATAN": "MEDAN POLONIA"
      },
      {
        "kodeKECAMATAN": 1275090,
        "kodeKABUPATEN": 1275,
        "namaKECAMATAN": "MEDAN BARU"
      },
      {
        "kodeKECAMATAN": 1275100,
        "kodeKABUPATEN": 1275,
        "namaKECAMATAN": "MEDAN SELAYANG"
      },
      {
        "kodeKECAMATAN": 1275110,
        "kodeKABUPATEN": 1275,
        "namaKECAMATAN": "MEDAN SUNGGAL"
      },
      {
        "kodeKECAMATAN": 1275120,
        "kodeKABUPATEN": 1275,
        "namaKECAMATAN": "MEDAN HELVETIA"
      },
      {
        "kodeKECAMATAN": 1275130,
        "kodeKABUPATEN": 1275,
        "namaKECAMATAN": "MEDAN PETISAH"
      },
      {
        "kodeKECAMATAN": 1275140,
        "kodeKABUPATEN": 1275,
        "namaKECAMATAN": "MEDAN BARAT"
      },
      {
        "kodeKECAMATAN": 1275150,
        "kodeKABUPATEN": 1275,
        "namaKECAMATAN": "MEDAN TIMUR"
      },
      {
        "kodeKECAMATAN": 1275160,
        "kodeKABUPATEN": 1275,
        "namaKECAMATAN": "MEDAN PERJUANGAN"
      },
      {
        "kodeKECAMATAN": 1275170,
        "kodeKABUPATEN": 1275,
        "namaKECAMATAN": "MEDAN TEMBUNG"
      },
      {
        "kodeKECAMATAN": 1275180,
        "kodeKABUPATEN": 1275,
        "namaKECAMATAN": "MEDAN DELI"
      },
      {
        "kodeKECAMATAN": 1275190,
        "kodeKABUPATEN": 1275,
        "namaKECAMATAN": "MEDAN LABUHAN"
      },
      {
        "kodeKECAMATAN": 1275200,
        "kodeKABUPATEN": 1275,
        "namaKECAMATAN": "MEDAN MARELAN"
      },
      {
        "kodeKECAMATAN": 1275210,
        "kodeKABUPATEN": 1275,
        "namaKECAMATAN": "MEDAN BELAWAN"
      },
      {
        "kodeKECAMATAN": 1276010,
        "kodeKABUPATEN": 1276,
        "namaKECAMATAN": "BINJAI SELATAN"
      },
      {
        "kodeKECAMATAN": 1276020,
        "kodeKABUPATEN": 1276,
        "namaKECAMATAN": "BINJAI KOTA"
      },
      {
        "kodeKECAMATAN": 1276030,
        "kodeKABUPATEN": 1276,
        "namaKECAMATAN": "BINJAI TIMUR"
      },
      {
        "kodeKECAMATAN": 1276040,
        "kodeKABUPATEN": 1276,
        "namaKECAMATAN": "BINJAI UTARA"
      },
      {
        "kodeKECAMATAN": 1276050,
        "kodeKABUPATEN": 1276,
        "namaKECAMATAN": "BINJAI BARAT"
      },
      {
        "kodeKECAMATAN": 1277010,
        "kodeKABUPATEN": 1277,
        "namaKECAMATAN": "PADANGSIDIMPUAN TENGGARA"
      },
      {
        "kodeKECAMATAN": 1277020,
        "kodeKABUPATEN": 1277,
        "namaKECAMATAN": "PADANGSIDIMPUAN SELATAN"
      },
      {
        "kodeKECAMATAN": 1277030,
        "kodeKABUPATEN": 1277,
        "namaKECAMATAN": "PADANGSIDIMPUAN BATUNADUA"
      },
      {
        "kodeKECAMATAN": 1277040,
        "kodeKABUPATEN": 1277,
        "namaKECAMATAN": "PADANGSIDIMPUAN UTARA"
      },
      {
        "kodeKECAMATAN": 1277050,
        "kodeKABUPATEN": 1277,
        "namaKECAMATAN": "PADANGSIDIMPUAN HUTAIMBARU"
      },
      {
        "kodeKECAMATAN": 1277051,
        "kodeKABUPATEN": 1277,
        "namaKECAMATAN": "PADANGSIDIMPUAN ANGKOLA JULU"
      },
      {
        "kodeKECAMATAN": 1278010,
        "kodeKABUPATEN": 1278,
        "namaKECAMATAN": "GUNUNGSITOLI IDANOI"
      },
      {
        "kodeKECAMATAN": 1278020,
        "kodeKABUPATEN": 1278,
        "namaKECAMATAN": "GUNUNGSITOLI SELATAN"
      },
      {
        "kodeKECAMATAN": 1278030,
        "kodeKABUPATEN": 1278,
        "namaKECAMATAN": "GUNUNGSITOLI BARAT"
      },
      {
        "kodeKECAMATAN": 1278040,
        "kodeKABUPATEN": 1278,
        "namaKECAMATAN": "GUNUNG SITOLI"
      },
      {
        "kodeKECAMATAN": 1278050,
        "kodeKABUPATEN": 1278,
        "namaKECAMATAN": "GUNUNGSITOLI ALO OA"
      },
      {
        "kodeKECAMATAN": 1278060,
        "kodeKABUPATEN": 1278,
        "namaKECAMATAN": "GUNUNGSITOLI UTARA"
      },
      {
        "kodeKECAMATAN": 1301011,
        "kodeKABUPATEN": 1301,
        "namaKECAMATAN": "PAGAI SELATAN"
      },
      {
        "kodeKECAMATAN": 1301012,
        "kodeKABUPATEN": 1301,
        "namaKECAMATAN": "SIKAKAP"
      },
      {
        "kodeKECAMATAN": 1301013,
        "kodeKABUPATEN": 1301,
        "namaKECAMATAN": "PAGAI UTARA"
      },
      {
        "kodeKECAMATAN": 1301021,
        "kodeKABUPATEN": 1301,
        "namaKECAMATAN": "SIPORA SELATAN"
      },
      {
        "kodeKECAMATAN": 1301022,
        "kodeKABUPATEN": 1301,
        "namaKECAMATAN": "SIPORA UTARA"
      },
      {
        "kodeKECAMATAN": 1301030,
        "kodeKABUPATEN": 1301,
        "namaKECAMATAN": "SIBERUT SELATAN"
      },
      {
        "kodeKECAMATAN": 1301031,
        "kodeKABUPATEN": 1301,
        "namaKECAMATAN": "SEBERUT BARAT DAYA"
      },
      {
        "kodeKECAMATAN": 1301032,
        "kodeKABUPATEN": 1301,
        "namaKECAMATAN": "SIBERUT TENGAH"
      },
      {
        "kodeKECAMATAN": 1301040,
        "kodeKABUPATEN": 1301,
        "namaKECAMATAN": "SIBERUT UTARA"
      },
      {
        "kodeKECAMATAN": 1301041,
        "kodeKABUPATEN": 1301,
        "namaKECAMATAN": "SIBERUT BARAT"
      },
      {
        "kodeKECAMATAN": 1302011,
        "kodeKABUPATEN": 1302,
        "namaKECAMATAN": "SILAUT"
      },
      {
        "kodeKECAMATAN": 1302012,
        "kodeKABUPATEN": 1302,
        "namaKECAMATAN": "LUNANG"
      },
      {
        "kodeKECAMATAN": 1302020,
        "kodeKABUPATEN": 1302,
        "namaKECAMATAN": "BASA AMPEK BALAI TAPAN"
      },
      {
        "kodeKECAMATAN": 1302021,
        "kodeKABUPATEN": 1302,
        "namaKECAMATAN": "RANAH AMPEK HULU TAPAN"
      },
      {
        "kodeKECAMATAN": 1302030,
        "kodeKABUPATEN": 1302,
        "namaKECAMATAN": "PANCUNG SOAL"
      },
      {
        "kodeKECAMATAN": 1302031,
        "kodeKABUPATEN": 1302,
        "namaKECAMATAN": "AIRPURA"
      },
      {
        "kodeKECAMATAN": 1302040,
        "kodeKABUPATEN": 1302,
        "namaKECAMATAN": "LINGGO SARI BAGANTI"
      },
      {
        "kodeKECAMATAN": 1302050,
        "kodeKABUPATEN": 1302,
        "namaKECAMATAN": "RANAH PESISIR"
      },
      {
        "kodeKECAMATAN": 1302060,
        "kodeKABUPATEN": 1302,
        "namaKECAMATAN": "LENGAYANG"
      },
      {
        "kodeKECAMATAN": 1302070,
        "kodeKABUPATEN": 1302,
        "namaKECAMATAN": "SUTERA"
      },
      {
        "kodeKECAMATAN": 1302080,
        "kodeKABUPATEN": 1302,
        "namaKECAMATAN": "BATANG KAPAS"
      },
      {
        "kodeKECAMATAN": 1302090,
        "kodeKABUPATEN": 1302,
        "namaKECAMATAN": "IV JURAI"
      },
      {
        "kodeKECAMATAN": 1302100,
        "kodeKABUPATEN": 1302,
        "namaKECAMATAN": "BAYANG"
      },
      {
        "kodeKECAMATAN": 1302101,
        "kodeKABUPATEN": 1302,
        "namaKECAMATAN": "IV  NAGARI BAYANG UTARA"
      },
      {
        "kodeKECAMATAN": 1302110,
        "kodeKABUPATEN": 1302,
        "namaKECAMATAN": "KOTO XI TARUSAN"
      },
      {
        "kodeKECAMATAN": 1303040,
        "kodeKABUPATEN": 1303,
        "namaKECAMATAN": "PANTAI CERMIN"
      },
      {
        "kodeKECAMATAN": 1303050,
        "kodeKABUPATEN": 1303,
        "namaKECAMATAN": "LEMBAH GUMANTI"
      },
      {
        "kodeKECAMATAN": 1303051,
        "kodeKABUPATEN": 1303,
        "namaKECAMATAN": "HILIRAN GUMANTI"
      },
      {
        "kodeKECAMATAN": 1303060,
        "kodeKABUPATEN": 1303,
        "namaKECAMATAN": "PAYUNG SEKAKI"
      },
      {
        "kodeKECAMATAN": 1303061,
        "kodeKABUPATEN": 1303,
        "namaKECAMATAN": "TIGO LURAH"
      },
      {
        "kodeKECAMATAN": 1303070,
        "kodeKABUPATEN": 1303,
        "namaKECAMATAN": "LEMBANG JAYA"
      },
      {
        "kodeKECAMATAN": 1303071,
        "kodeKABUPATEN": 1303,
        "namaKECAMATAN": "DANAU KEMBAR"
      },
      {
        "kodeKECAMATAN": 1303080,
        "kodeKABUPATEN": 1303,
        "namaKECAMATAN": "GUNUNG TALANG"
      },
      {
        "kodeKECAMATAN": 1303090,
        "kodeKABUPATEN": 1303,
        "namaKECAMATAN": "BUKIT SUNDI"
      },
      {
        "kodeKECAMATAN": 1303100,
        "kodeKABUPATEN": 1303,
        "namaKECAMATAN": "IX KOTO SUNGAI LASI"
      },
      {
        "kodeKECAMATAN": 1303110,
        "kodeKABUPATEN": 1303,
        "namaKECAMATAN": "KUBUNG"
      },
      {
        "kodeKECAMATAN": 1303120,
        "kodeKABUPATEN": 1303,
        "namaKECAMATAN": "X KOTO DIATAS"
      },
      {
        "kodeKECAMATAN": 1303130,
        "kodeKABUPATEN": 1303,
        "namaKECAMATAN": "X KOTO SINGKARAK"
      },
      {
        "kodeKECAMATAN": 1303140,
        "kodeKABUPATEN": 1303,
        "namaKECAMATAN": "JUNJUNG SIRIH"
      },
      {
        "kodeKECAMATAN": 1304050,
        "kodeKABUPATEN": 1304,
        "namaKECAMATAN": "KAMANG BARU"
      },
      {
        "kodeKECAMATAN": 1304060,
        "kodeKABUPATEN": 1304,
        "namaKECAMATAN": "TANJUNG GADANG"
      },
      {
        "kodeKECAMATAN": 1304070,
        "kodeKABUPATEN": 1304,
        "namaKECAMATAN": "SIJUNJUNG"
      },
      {
        "kodeKECAMATAN": 1304071,
        "kodeKABUPATEN": 1304,
        "namaKECAMATAN": "LUBUK TAROK"
      },
      {
        "kodeKECAMATAN": 1304080,
        "kodeKABUPATEN": 1304,
        "namaKECAMATAN": "IV NAGARI"
      },
      {
        "kodeKECAMATAN": 1304090,
        "kodeKABUPATEN": 1304,
        "namaKECAMATAN": "KUPITAN"
      },
      {
        "kodeKECAMATAN": 1304100,
        "kodeKABUPATEN": 1304,
        "namaKECAMATAN": "KOTO TUJUH"
      },
      {
        "kodeKECAMATAN": 1304110,
        "kodeKABUPATEN": 1304,
        "namaKECAMATAN": "SUMPUR KUDUS"
      },
      {
        "kodeKECAMATAN": 1305010,
        "kodeKABUPATEN": 1305,
        "namaKECAMATAN": "SEPULUH KOTO"
      },
      {
        "kodeKECAMATAN": 1305020,
        "kodeKABUPATEN": 1305,
        "namaKECAMATAN": "BATIPUH"
      },
      {
        "kodeKECAMATAN": 1305021,
        "kodeKABUPATEN": 1305,
        "namaKECAMATAN": "BATIPUH SELATAN"
      },
      {
        "kodeKECAMATAN": 1305030,
        "kodeKABUPATEN": 1305,
        "namaKECAMATAN": "PARIANGAN"
      },
      {
        "kodeKECAMATAN": 1305040,
        "kodeKABUPATEN": 1305,
        "namaKECAMATAN": "RAMBATAN"
      },
      {
        "kodeKECAMATAN": 1305050,
        "kodeKABUPATEN": 1305,
        "namaKECAMATAN": "LIMA KAUM"
      },
      {
        "kodeKECAMATAN": 1305060,
        "kodeKABUPATEN": 1305,
        "namaKECAMATAN": "TANJUNG EMAS"
      },
      {
        "kodeKECAMATAN": 1305070,
        "kodeKABUPATEN": 1305,
        "namaKECAMATAN": "PADANG GANTING"
      },
      {
        "kodeKECAMATAN": 1305080,
        "kodeKABUPATEN": 1305,
        "namaKECAMATAN": "LINTAU BUO"
      },
      {
        "kodeKECAMATAN": 1305081,
        "kodeKABUPATEN": 1305,
        "namaKECAMATAN": "LINTAU BUO UTARA"
      },
      {
        "kodeKECAMATAN": 1305090,
        "kodeKABUPATEN": 1305,
        "namaKECAMATAN": "SUNGAYANG"
      },
      {
        "kodeKECAMATAN": 1305100,
        "kodeKABUPATEN": 1305,
        "namaKECAMATAN": "SUNGAI TARAB"
      },
      {
        "kodeKECAMATAN": 1305110,
        "kodeKABUPATEN": 1305,
        "namaKECAMATAN": "SALIMPAUNG"
      },
      {
        "kodeKECAMATAN": 1305111,
        "kodeKABUPATEN": 1305,
        "namaKECAMATAN": "TANJUNG BARU"
      },
      {
        "kodeKECAMATAN": 1306010,
        "kodeKABUPATEN": 1306,
        "namaKECAMATAN": "BATANG ANAI"
      },
      {
        "kodeKECAMATAN": 1306020,
        "kodeKABUPATEN": 1306,
        "namaKECAMATAN": "LUBUK ALUNG"
      },
      {
        "kodeKECAMATAN": 1306021,
        "kodeKABUPATEN": 1306,
        "namaKECAMATAN": "SINTUK TOBOH GADANG"
      },
      {
        "kodeKECAMATAN": 1306030,
        "kodeKABUPATEN": 1306,
        "namaKECAMATAN": "ULAKAN TAPAKIS"
      },
      {
        "kodeKECAMATAN": 1306040,
        "kodeKABUPATEN": 1306,
        "namaKECAMATAN": "NAN SABARIS"
      },
      {
        "kodeKECAMATAN": 1306050,
        "kodeKABUPATEN": 1306,
        "namaKECAMATAN": "2 X 11 ENAM LINGKUNG"
      },
      {
        "kodeKECAMATAN": 1306051,
        "kodeKABUPATEN": 1306,
        "namaKECAMATAN": "ENAM LINGKUNG"
      },
      {
        "kodeKECAMATAN": 1306052,
        "kodeKABUPATEN": 1306,
        "namaKECAMATAN": "2 X 11 KAYU TANAM"
      },
      {
        "kodeKECAMATAN": 1306060,
        "kodeKABUPATEN": 1306,
        "namaKECAMATAN": "VII KOTO SUNGAI SARIAK"
      },
      {
        "kodeKECAMATAN": 1306061,
        "kodeKABUPATEN": 1306,
        "namaKECAMATAN": "PATAMUAN"
      },
      {
        "kodeKECAMATAN": 1306062,
        "kodeKABUPATEN": 1306,
        "namaKECAMATAN": "PADANG SAGO"
      },
      {
        "kodeKECAMATAN": 1306070,
        "kodeKABUPATEN": 1306,
        "namaKECAMATAN": "V KOTO KP DALAM"
      },
      {
        "kodeKECAMATAN": 1306071,
        "kodeKABUPATEN": 1306,
        "namaKECAMATAN": "V KOTO TIMUR"
      },
      {
        "kodeKECAMATAN": 1306080,
        "kodeKABUPATEN": 1306,
        "namaKECAMATAN": "SUNGAI LIMAU"
      },
      {
        "kodeKECAMATAN": 1306081,
        "kodeKABUPATEN": 1306,
        "namaKECAMATAN": "BATANG GASAN"
      },
      {
        "kodeKECAMATAN": 1306090,
        "kodeKABUPATEN": 1306,
        "namaKECAMATAN": "SUNGAI GERINGGING"
      },
      {
        "kodeKECAMATAN": 1306100,
        "kodeKABUPATEN": 1306,
        "namaKECAMATAN": "IV KOTO AUR MALINTANG"
      },
      {
        "kodeKECAMATAN": 1307010,
        "kodeKABUPATEN": 1307,
        "namaKECAMATAN": "TANJUNG MUTIARA"
      },
      {
        "kodeKECAMATAN": 1307020,
        "kodeKABUPATEN": 1307,
        "namaKECAMATAN": "LUBUK BASUNG"
      },
      {
        "kodeKECAMATAN": 1307021,
        "kodeKABUPATEN": 1307,
        "namaKECAMATAN": "AMPEK NAGARI"
      },
      {
        "kodeKECAMATAN": 1307030,
        "kodeKABUPATEN": 1307,
        "namaKECAMATAN": "TANJUNG RAYA"
      },
      {
        "kodeKECAMATAN": 1307040,
        "kodeKABUPATEN": 1307,
        "namaKECAMATAN": "MATUR"
      },
      {
        "kodeKECAMATAN": 1307050,
        "kodeKABUPATEN": 1307,
        "namaKECAMATAN": "IV KOTO"
      },
      {
        "kodeKECAMATAN": 1307051,
        "kodeKABUPATEN": 1307,
        "namaKECAMATAN": "MALALAK"
      },
      {
        "kodeKECAMATAN": 1307061,
        "kodeKABUPATEN": 1307,
        "namaKECAMATAN": "BANUHAMPU"
      },
      {
        "kodeKECAMATAN": 1307062,
        "kodeKABUPATEN": 1307,
        "namaKECAMATAN": "SUNGAI PUA"
      },
      {
        "kodeKECAMATAN": 1307070,
        "kodeKABUPATEN": 1307,
        "namaKECAMATAN": "AMPEK ANGKEK"
      },
      {
        "kodeKECAMATAN": 1307071,
        "kodeKABUPATEN": 1307,
        "namaKECAMATAN": "CANDUANG"
      },
      {
        "kodeKECAMATAN": 1307080,
        "kodeKABUPATEN": 1307,
        "namaKECAMATAN": "BASO"
      },
      {
        "kodeKECAMATAN": 1307090,
        "kodeKABUPATEN": 1307,
        "namaKECAMATAN": "TILATANG KAMANG"
      },
      {
        "kodeKECAMATAN": 1307091,
        "kodeKABUPATEN": 1307,
        "namaKECAMATAN": "KAMANG MAGEK"
      },
      {
        "kodeKECAMATAN": 1307100,
        "kodeKABUPATEN": 1307,
        "namaKECAMATAN": "PALEMBAYAN"
      },
      {
        "kodeKECAMATAN": 1307110,
        "kodeKABUPATEN": 1307,
        "namaKECAMATAN": "PALUPUH"
      },
      {
        "kodeKECAMATAN": 1308010,
        "kodeKABUPATEN": 1308,
        "namaKECAMATAN": "PAYAKUMBUH"
      },
      {
        "kodeKECAMATAN": 1308011,
        "kodeKABUPATEN": 1308,
        "namaKECAMATAN": "AKABILURU"
      },
      {
        "kodeKECAMATAN": 1308020,
        "kodeKABUPATEN": 1308,
        "namaKECAMATAN": "LUAK"
      },
      {
        "kodeKECAMATAN": 1308021,
        "kodeKABUPATEN": 1308,
        "namaKECAMATAN": "LAREH SAGO HALABAN"
      },
      {
        "kodeKECAMATAN": 1308022,
        "kodeKABUPATEN": 1308,
        "namaKECAMATAN": "SITUJUAH LIMO NAGARI"
      },
      {
        "kodeKECAMATAN": 1308030,
        "kodeKABUPATEN": 1308,
        "namaKECAMATAN": "HARAU"
      },
      {
        "kodeKECAMATAN": 1308040,
        "kodeKABUPATEN": 1308,
        "namaKECAMATAN": "GUGUAK"
      },
      {
        "kodeKECAMATAN": 1308041,
        "kodeKABUPATEN": 1308,
        "namaKECAMATAN": "MUNGKA"
      },
      {
        "kodeKECAMATAN": 1308050,
        "kodeKABUPATEN": 1308,
        "namaKECAMATAN": "SULIKI"
      },
      {
        "kodeKECAMATAN": 1308051,
        "kodeKABUPATEN": 1308,
        "namaKECAMATAN": "BUKIK BARISAN"
      },
      {
        "kodeKECAMATAN": 1308060,
        "kodeKABUPATEN": 1308,
        "namaKECAMATAN": "GUNUANG OMEH"
      },
      {
        "kodeKECAMATAN": 1308070,
        "kodeKABUPATEN": 1308,
        "namaKECAMATAN": "KAPUR IX"
      },
      {
        "kodeKECAMATAN": 1308080,
        "kodeKABUPATEN": 1308,
        "namaKECAMATAN": "PANGKALAN KOTO BARU"
      },
      {
        "kodeKECAMATAN": 1309070,
        "kodeKABUPATEN": 1309,
        "namaKECAMATAN": "BONJOL"
      },
      {
        "kodeKECAMATAN": 1309071,
        "kodeKABUPATEN": 1309,
        "namaKECAMATAN": "TIGO NAGARI"
      },
      {
        "kodeKECAMATAN": 1309072,
        "kodeKABUPATEN": 1309,
        "namaKECAMATAN": "SIMPANG ALAHAN MATI"
      },
      {
        "kodeKECAMATAN": 1309080,
        "kodeKABUPATEN": 1309,
        "namaKECAMATAN": "LUBUK SIKAPING"
      },
      {
        "kodeKECAMATAN": 1309100,
        "kodeKABUPATEN": 1309,
        "namaKECAMATAN": "DUA KOTO"
      },
      {
        "kodeKECAMATAN": 1309110,
        "kodeKABUPATEN": 1309,
        "namaKECAMATAN": "PANTI"
      },
      {
        "kodeKECAMATAN": 1309111,
        "kodeKABUPATEN": 1309,
        "namaKECAMATAN": "PADANG GELUGUR"
      },
      {
        "kodeKECAMATAN": 1309121,
        "kodeKABUPATEN": 1309,
        "namaKECAMATAN": "RAO"
      },
      {
        "kodeKECAMATAN": 1309122,
        "kodeKABUPATEN": 1309,
        "namaKECAMATAN": "MAPAT TUNGGUL"
      },
      {
        "kodeKECAMATAN": 1309123,
        "kodeKABUPATEN": 1309,
        "namaKECAMATAN": "MAPAT TUNGGUL SELATAN"
      },
      {
        "kodeKECAMATAN": 1309124,
        "kodeKABUPATEN": 1309,
        "namaKECAMATAN": "RAO SELATAN"
      },
      {
        "kodeKECAMATAN": 1309125,
        "kodeKABUPATEN": 1309,
        "namaKECAMATAN": "RAO UTARA"
      },
      {
        "kodeKECAMATAN": 1310010,
        "kodeKABUPATEN": 1310,
        "namaKECAMATAN": "SANGIR"
      },
      {
        "kodeKECAMATAN": 1310020,
        "kodeKABUPATEN": 1310,
        "namaKECAMATAN": "SANGIR JUJUAN"
      },
      {
        "kodeKECAMATAN": 1310021,
        "kodeKABUPATEN": 1310,
        "namaKECAMATAN": "SANGIR BALAI JANGGO"
      },
      {
        "kodeKECAMATAN": 1310030,
        "kodeKABUPATEN": 1310,
        "namaKECAMATAN": "SANGIR BATANG HARI"
      },
      {
        "kodeKECAMATAN": 1310040,
        "kodeKABUPATEN": 1310,
        "namaKECAMATAN": "SUNGAI PAGU"
      },
      {
        "kodeKECAMATAN": 1310041,
        "kodeKABUPATEN": 1310,
        "namaKECAMATAN": "PAUAH DUO"
      },
      {
        "kodeKECAMATAN": 1310050,
        "kodeKABUPATEN": 1310,
        "namaKECAMATAN": "KOTO PARIK GADANG DIATEH"
      },
      {
        "kodeKECAMATAN": 1311010,
        "kodeKABUPATEN": 1311,
        "namaKECAMATAN": "SUNGAI RUMBAI"
      },
      {
        "kodeKECAMATAN": 1311011,
        "kodeKABUPATEN": 1311,
        "namaKECAMATAN": "KOTO BESAR"
      },
      {
        "kodeKECAMATAN": 1311012,
        "kodeKABUPATEN": 1311,
        "namaKECAMATAN": "ASAM JUJUHAN"
      },
      {
        "kodeKECAMATAN": 1311020,
        "kodeKABUPATEN": 1311,
        "namaKECAMATAN": "KOTO BARU"
      },
      {
        "kodeKECAMATAN": 1311021,
        "kodeKABUPATEN": 1311,
        "namaKECAMATAN": "KOTO SALAK"
      },
      {
        "kodeKECAMATAN": 1311022,
        "kodeKABUPATEN": 1311,
        "namaKECAMATAN": "TIUMANG"
      },
      {
        "kodeKECAMATAN": 1311023,
        "kodeKABUPATEN": 1311,
        "namaKECAMATAN": "PADANG LAWEH"
      },
      {
        "kodeKECAMATAN": 1311030,
        "kodeKABUPATEN": 1311,
        "namaKECAMATAN": "SITIUNG"
      },
      {
        "kodeKECAMATAN": 1311031,
        "kodeKABUPATEN": 1311,
        "namaKECAMATAN": "TIMPEH"
      },
      {
        "kodeKECAMATAN": 1311040,
        "kodeKABUPATEN": 1311,
        "namaKECAMATAN": "PULAU PUNJUNG"
      },
      {
        "kodeKECAMATAN": 1311041,
        "kodeKABUPATEN": 1311,
        "namaKECAMATAN": "IX KOTO"
      },
      {
        "kodeKECAMATAN": 1312010,
        "kodeKABUPATEN": 1312,
        "namaKECAMATAN": "SUNGAI BEREMAS"
      },
      {
        "kodeKECAMATAN": 1312020,
        "kodeKABUPATEN": 1312,
        "namaKECAMATAN": "RANAH BATAHAN"
      },
      {
        "kodeKECAMATAN": 1312030,
        "kodeKABUPATEN": 1312,
        "namaKECAMATAN": "KOTO BALINGKA"
      },
      {
        "kodeKECAMATAN": 1312040,
        "kodeKABUPATEN": 1312,
        "namaKECAMATAN": "SUNGAI AUR"
      },
      {
        "kodeKECAMATAN": 1312050,
        "kodeKABUPATEN": 1312,
        "namaKECAMATAN": "LEMBAH MALINTANG"
      },
      {
        "kodeKECAMATAN": 1312060,
        "kodeKABUPATEN": 1312,
        "namaKECAMATAN": "GUNUNG TULEH"
      },
      {
        "kodeKECAMATAN": 1312070,
        "kodeKABUPATEN": 1312,
        "namaKECAMATAN": "TALAMAU"
      },
      {
        "kodeKECAMATAN": 1312080,
        "kodeKABUPATEN": 1312,
        "namaKECAMATAN": "PASAMAN"
      },
      {
        "kodeKECAMATAN": 1312090,
        "kodeKABUPATEN": 1312,
        "namaKECAMATAN": "LUHAK NAN DUO"
      },
      {
        "kodeKECAMATAN": 1312100,
        "kodeKABUPATEN": 1312,
        "namaKECAMATAN": "SASAK RANAH PASISIE"
      },
      {
        "kodeKECAMATAN": 1312110,
        "kodeKABUPATEN": 1312,
        "namaKECAMATAN": "KINALI"
      },
      {
        "kodeKECAMATAN": 1371010,
        "kodeKABUPATEN": 1371,
        "namaKECAMATAN": "BUNGUS TELUK KABUNG"
      },
      {
        "kodeKECAMATAN": 1371020,
        "kodeKABUPATEN": 1371,
        "namaKECAMATAN": "LUBUK KILANGAN"
      },
      {
        "kodeKECAMATAN": 1371030,
        "kodeKABUPATEN": 1371,
        "namaKECAMATAN": "LUBUK BEGALUNG"
      },
      {
        "kodeKECAMATAN": 1371040,
        "kodeKABUPATEN": 1371,
        "namaKECAMATAN": "PADANG SELATAN"
      },
      {
        "kodeKECAMATAN": 1371050,
        "kodeKABUPATEN": 1371,
        "namaKECAMATAN": "PADANG TIMUR"
      },
      {
        "kodeKECAMATAN": 1371060,
        "kodeKABUPATEN": 1371,
        "namaKECAMATAN": "PADANG BARAT"
      },
      {
        "kodeKECAMATAN": 1371070,
        "kodeKABUPATEN": 1371,
        "namaKECAMATAN": "PADANG UTARA"
      },
      {
        "kodeKECAMATAN": 1371080,
        "kodeKABUPATEN": 1371,
        "namaKECAMATAN": "NANGGALO"
      },
      {
        "kodeKECAMATAN": 1371090,
        "kodeKABUPATEN": 1371,
        "namaKECAMATAN": "KURANJI"
      },
      {
        "kodeKECAMATAN": 1371100,
        "kodeKABUPATEN": 1371,
        "namaKECAMATAN": "PAUH"
      },
      {
        "kodeKECAMATAN": 1371110,
        "kodeKABUPATEN": 1371,
        "namaKECAMATAN": "KOTO TANGAH"
      },
      {
        "kodeKECAMATAN": 1372010,
        "kodeKABUPATEN": 1372,
        "namaKECAMATAN": "LUBUK SIKARAH"
      },
      {
        "kodeKECAMATAN": 1372020,
        "kodeKABUPATEN": 1372,
        "namaKECAMATAN": "TANJUNG HARAPAN"
      },
      {
        "kodeKECAMATAN": 1373010,
        "kodeKABUPATEN": 1373,
        "namaKECAMATAN": "SILUNGKANG"
      },
      {
        "kodeKECAMATAN": 1373020,
        "kodeKABUPATEN": 1373,
        "namaKECAMATAN": "LEMBAH SEGAR"
      },
      {
        "kodeKECAMATAN": 1373030,
        "kodeKABUPATEN": 1373,
        "namaKECAMATAN": "BARANGIN"
      },
      {
        "kodeKECAMATAN": 1373040,
        "kodeKABUPATEN": 1373,
        "namaKECAMATAN": "TALAWI"
      },
      {
        "kodeKECAMATAN": 1374010,
        "kodeKABUPATEN": 1374,
        "namaKECAMATAN": "PADANG PANJANG BARAT"
      },
      {
        "kodeKECAMATAN": 1374020,
        "kodeKABUPATEN": 1374,
        "namaKECAMATAN": "PADANG PANJANG TIMUR"
      },
      {
        "kodeKECAMATAN": 1375010,
        "kodeKABUPATEN": 1375,
        "namaKECAMATAN": "GUGUK PANJANG"
      },
      {
        "kodeKECAMATAN": 1375020,
        "kodeKABUPATEN": 1375,
        "namaKECAMATAN": "MANDIANGIN KOTO SELAYAN"
      },
      {
        "kodeKECAMATAN": 1375030,
        "kodeKABUPATEN": 1375,
        "namaKECAMATAN": "AUR BIRUGO TIGO BALEH"
      },
      {
        "kodeKECAMATAN": 1376010,
        "kodeKABUPATEN": 1376,
        "namaKECAMATAN": "PAYAKUMBUH BARAT"
      },
      {
        "kodeKECAMATAN": 1376011,
        "kodeKABUPATEN": 1376,
        "namaKECAMATAN": "PAYAKUMBUH SELATAN"
      },
      {
        "kodeKECAMATAN": 1376020,
        "kodeKABUPATEN": 1376,
        "namaKECAMATAN": "PAYAKUMBUH TIMUR"
      },
      {
        "kodeKECAMATAN": 1376030,
        "kodeKABUPATEN": 1376,
        "namaKECAMATAN": "PAYAKUMBUH UTARA"
      },
      {
        "kodeKECAMATAN": 1376031,
        "kodeKABUPATEN": 1376,
        "namaKECAMATAN": "LAMPOSI TIGO NAGORI"
      },
      {
        "kodeKECAMATAN": 1377010,
        "kodeKABUPATEN": 1377,
        "namaKECAMATAN": "PARIAMAN SELATAN"
      },
      {
        "kodeKECAMATAN": 1377020,
        "kodeKABUPATEN": 1377,
        "namaKECAMATAN": "PARIAMAN TENGAH"
      },
      {
        "kodeKECAMATAN": 1377021,
        "kodeKABUPATEN": 1377,
        "namaKECAMATAN": "PARIAMAN TIMUR"
      },
      {
        "kodeKECAMATAN": 1377030,
        "kodeKABUPATEN": 1377,
        "namaKECAMATAN": "PARIAMAN UTARA"
      },
      {
        "kodeKECAMATAN": 1401010,
        "kodeKABUPATEN": 1401,
        "namaKECAMATAN": "KUANTAN MUDIK"
      },
      {
        "kodeKECAMATAN": 1401011,
        "kodeKABUPATEN": 1401,
        "namaKECAMATAN": "HULU KUANTAN"
      },
      {
        "kodeKECAMATAN": 1401012,
        "kodeKABUPATEN": 1401,
        "namaKECAMATAN": "GUNUNG TOAR"
      },
      {
        "kodeKECAMATAN": 1401013,
        "kodeKABUPATEN": 1401,
        "namaKECAMATAN": "PUCUK RANTAU"
      },
      {
        "kodeKECAMATAN": 1401020,
        "kodeKABUPATEN": 1401,
        "namaKECAMATAN": "SINGINGI"
      },
      {
        "kodeKECAMATAN": 1401021,
        "kodeKABUPATEN": 1401,
        "namaKECAMATAN": "SINGINGI HILIR"
      },
      {
        "kodeKECAMATAN": 1401030,
        "kodeKABUPATEN": 1401,
        "namaKECAMATAN": "KUANTAN TENGAH"
      },
      {
        "kodeKECAMATAN": 1401031,
        "kodeKABUPATEN": 1401,
        "namaKECAMATAN": "SENTAJO RAYA"
      },
      {
        "kodeKECAMATAN": 1401040,
        "kodeKABUPATEN": 1401,
        "namaKECAMATAN": "BENAI"
      },
      {
        "kodeKECAMATAN": 1401050,
        "kodeKABUPATEN": 1401,
        "namaKECAMATAN": "KUANTAN HILIR"
      },
      {
        "kodeKECAMATAN": 1401051,
        "kodeKABUPATEN": 1401,
        "namaKECAMATAN": "PANGEAN"
      },
      {
        "kodeKECAMATAN": 1401052,
        "kodeKABUPATEN": 1401,
        "namaKECAMATAN": "LOGAS TANAH DARAT"
      },
      {
        "kodeKECAMATAN": 1401053,
        "kodeKABUPATEN": 1401,
        "namaKECAMATAN": "KUANTAN HILIR SEBERANG"
      },
      {
        "kodeKECAMATAN": 1401060,
        "kodeKABUPATEN": 1401,
        "namaKECAMATAN": "CERENTI"
      },
      {
        "kodeKECAMATAN": 1401061,
        "kodeKABUPATEN": 1401,
        "namaKECAMATAN": "INUMAN"
      },
      {
        "kodeKECAMATAN": 1402010,
        "kodeKABUPATEN": 1402,
        "namaKECAMATAN": "PERANAP"
      },
      {
        "kodeKECAMATAN": 1402011,
        "kodeKABUPATEN": 1402,
        "namaKECAMATAN": "BATANG PERANAP"
      },
      {
        "kodeKECAMATAN": 1402020,
        "kodeKABUPATEN": 1402,
        "namaKECAMATAN": "SEBERIDA"
      },
      {
        "kodeKECAMATAN": 1402021,
        "kodeKABUPATEN": 1402,
        "namaKECAMATAN": "BATANG CENAKU"
      },
      {
        "kodeKECAMATAN": 1402022,
        "kodeKABUPATEN": 1402,
        "namaKECAMATAN": "BATANG GANSAL"
      },
      {
        "kodeKECAMATAN": 1402030,
        "kodeKABUPATEN": 1402,
        "namaKECAMATAN": "KELAYANG"
      },
      {
        "kodeKECAMATAN": 1402031,
        "kodeKABUPATEN": 1402,
        "namaKECAMATAN": "RAKIT KULIM"
      },
      {
        "kodeKECAMATAN": 1402040,
        "kodeKABUPATEN": 1402,
        "namaKECAMATAN": "PASIR PENYU"
      },
      {
        "kodeKECAMATAN": 1402041,
        "kodeKABUPATEN": 1402,
        "namaKECAMATAN": "LIRIK"
      },
      {
        "kodeKECAMATAN": 1402042,
        "kodeKABUPATEN": 1402,
        "namaKECAMATAN": "SUNGAI LALA"
      },
      {
        "kodeKECAMATAN": 1402043,
        "kodeKABUPATEN": 1402,
        "namaKECAMATAN": "LUBUK BATU JAYA"
      },
      {
        "kodeKECAMATAN": 1402050,
        "kodeKABUPATEN": 1402,
        "namaKECAMATAN": "RENGAT BARAT"
      },
      {
        "kodeKECAMATAN": 1402060,
        "kodeKABUPATEN": 1402,
        "namaKECAMATAN": "RENGAT"
      },
      {
        "kodeKECAMATAN": 1402061,
        "kodeKABUPATEN": 1402,
        "namaKECAMATAN": "KUALA CENAKU"
      },
      {
        "kodeKECAMATAN": 1403010,
        "kodeKABUPATEN": 1403,
        "namaKECAMATAN": "KERITANG"
      },
      {
        "kodeKECAMATAN": 1403011,
        "kodeKABUPATEN": 1403,
        "namaKECAMATAN": "KEMUNING"
      },
      {
        "kodeKECAMATAN": 1403020,
        "kodeKABUPATEN": 1403,
        "namaKECAMATAN": "RETEH"
      },
      {
        "kodeKECAMATAN": 1403021,
        "kodeKABUPATEN": 1403,
        "namaKECAMATAN": "SUNGAI BATANG"
      },
      {
        "kodeKECAMATAN": 1403030,
        "kodeKABUPATEN": 1403,
        "namaKECAMATAN": "ENOK"
      },
      {
        "kodeKECAMATAN": 1403040,
        "kodeKABUPATEN": 1403,
        "namaKECAMATAN": "TANAH MERAH"
      },
      {
        "kodeKECAMATAN": 1403050,
        "kodeKABUPATEN": 1403,
        "namaKECAMATAN": "KUALA INDRAGIRI"
      },
      {
        "kodeKECAMATAN": 1403051,
        "kodeKABUPATEN": 1403,
        "namaKECAMATAN": "CONCONG"
      },
      {
        "kodeKECAMATAN": 1403060,
        "kodeKABUPATEN": 1403,
        "namaKECAMATAN": "TEMBILAHAN"
      },
      {
        "kodeKECAMATAN": 1403061,
        "kodeKABUPATEN": 1403,
        "namaKECAMATAN": "TEMBILAHAN HULU"
      },
      {
        "kodeKECAMATAN": 1403070,
        "kodeKABUPATEN": 1403,
        "namaKECAMATAN": "TEMPULING"
      },
      {
        "kodeKECAMATAN": 1403071,
        "kodeKABUPATEN": 1403,
        "namaKECAMATAN": "KEMPAS"
      },
      {
        "kodeKECAMATAN": 1403080,
        "kodeKABUPATEN": 1403,
        "namaKECAMATAN": "BATANG TUAKA"
      },
      {
        "kodeKECAMATAN": 1403090,
        "kodeKABUPATEN": 1403,
        "namaKECAMATAN": "GAUNG ANAK SERKA"
      },
      {
        "kodeKECAMATAN": 1403100,
        "kodeKABUPATEN": 1403,
        "namaKECAMATAN": "GAUNG"
      },
      {
        "kodeKECAMATAN": 1403110,
        "kodeKABUPATEN": 1403,
        "namaKECAMATAN": "MANDAH"
      },
      {
        "kodeKECAMATAN": 1403120,
        "kodeKABUPATEN": 1403,
        "namaKECAMATAN": "KATEMAN"
      },
      {
        "kodeKECAMATAN": 1403121,
        "kodeKABUPATEN": 1403,
        "namaKECAMATAN": "PELANGIRAN"
      },
      {
        "kodeKECAMATAN": 1403122,
        "kodeKABUPATEN": 1403,
        "namaKECAMATAN": "TELUK BELENGKONG"
      },
      {
        "kodeKECAMATAN": 1403123,
        "kodeKABUPATEN": 1403,
        "namaKECAMATAN": "PULAU BURUNG"
      },
      {
        "kodeKECAMATAN": 1404010,
        "kodeKABUPATEN": 1404,
        "namaKECAMATAN": "LANGGAM"
      },
      {
        "kodeKECAMATAN": 1404011,
        "kodeKABUPATEN": 1404,
        "namaKECAMATAN": "PANGKALAN KERINCI"
      },
      {
        "kodeKECAMATAN": 1404012,
        "kodeKABUPATEN": 1404,
        "namaKECAMATAN": "BANDAR SEIKIJANG"
      },
      {
        "kodeKECAMATAN": 1404020,
        "kodeKABUPATEN": 1404,
        "namaKECAMATAN": "PANGKALAN KURAS"
      },
      {
        "kodeKECAMATAN": 1404021,
        "kodeKABUPATEN": 1404,
        "namaKECAMATAN": "UKUI"
      },
      {
        "kodeKECAMATAN": 1404022,
        "kodeKABUPATEN": 1404,
        "namaKECAMATAN": "PANGKALAN LESUNG"
      },
      {
        "kodeKECAMATAN": 1404030,
        "kodeKABUPATEN": 1404,
        "namaKECAMATAN": "BUNUT"
      },
      {
        "kodeKECAMATAN": 1404031,
        "kodeKABUPATEN": 1404,
        "namaKECAMATAN": "PELALAWAN"
      },
      {
        "kodeKECAMATAN": 1404032,
        "kodeKABUPATEN": 1404,
        "namaKECAMATAN": "BANDAR PETALANGAN"
      },
      {
        "kodeKECAMATAN": 1404040,
        "kodeKABUPATEN": 1404,
        "namaKECAMATAN": "KUALA KAMPAR"
      },
      {
        "kodeKECAMATAN": 1404041,
        "kodeKABUPATEN": 1404,
        "namaKECAMATAN": "KERUMUTAN"
      },
      {
        "kodeKECAMATAN": 1404042,
        "kodeKABUPATEN": 1404,
        "namaKECAMATAN": "TELUK MERANTI"
      },
      {
        "kodeKECAMATAN": 1405010,
        "kodeKABUPATEN": 1405,
        "namaKECAMATAN": "MINAS"
      },
      {
        "kodeKECAMATAN": 1405011,
        "kodeKABUPATEN": 1405,
        "namaKECAMATAN": "SUNGAI MANDAU"
      },
      {
        "kodeKECAMATAN": 1405012,
        "kodeKABUPATEN": 1405,
        "namaKECAMATAN": "KANDIS"
      },
      {
        "kodeKECAMATAN": 1405020,
        "kodeKABUPATEN": 1405,
        "namaKECAMATAN": "SIAK"
      },
      {
        "kodeKECAMATAN": 1405021,
        "kodeKABUPATEN": 1405,
        "namaKECAMATAN": "KERINCI KANAN"
      },
      {
        "kodeKECAMATAN": 1405022,
        "kodeKABUPATEN": 1405,
        "namaKECAMATAN": "TUALANG"
      },
      {
        "kodeKECAMATAN": 1405023,
        "kodeKABUPATEN": 1405,
        "namaKECAMATAN": "DAYUN"
      },
      {
        "kodeKECAMATAN": 1405024,
        "kodeKABUPATEN": 1405,
        "namaKECAMATAN": "LUBUK DALAM"
      },
      {
        "kodeKECAMATAN": 1405025,
        "kodeKABUPATEN": 1405,
        "namaKECAMATAN": "KOTO GASIB"
      },
      {
        "kodeKECAMATAN": 1405026,
        "kodeKABUPATEN": 1405,
        "namaKECAMATAN": "MEMPURA"
      },
      {
        "kodeKECAMATAN": 1405030,
        "kodeKABUPATEN": 1405,
        "namaKECAMATAN": "SUNGAI APIT"
      },
      {
        "kodeKECAMATAN": 1405031,
        "kodeKABUPATEN": 1405,
        "namaKECAMATAN": "BUNGA RAYA"
      },
      {
        "kodeKECAMATAN": 1405032,
        "kodeKABUPATEN": 1405,
        "namaKECAMATAN": "SABAK AUH"
      },
      {
        "kodeKECAMATAN": 1405033,
        "kodeKABUPATEN": 1405,
        "namaKECAMATAN": "PUSAKO"
      },
      {
        "kodeKECAMATAN": 1406010,
        "kodeKABUPATEN": 1406,
        "namaKECAMATAN": "KAMPAR KIRI"
      },
      {
        "kodeKECAMATAN": 1406011,
        "kodeKABUPATEN": 1406,
        "namaKECAMATAN": "KAMPAR KIRI HULU"
      },
      {
        "kodeKECAMATAN": 1406012,
        "kodeKABUPATEN": 1406,
        "namaKECAMATAN": "KAMPAR KIRI HILIR"
      },
      {
        "kodeKECAMATAN": 1406013,
        "kodeKABUPATEN": 1406,
        "namaKECAMATAN": "GUNUNG SAHILAN"
      },
      {
        "kodeKECAMATAN": 1406014,
        "kodeKABUPATEN": 1406,
        "namaKECAMATAN": "KAMPAR KIRI TENGAH"
      },
      {
        "kodeKECAMATAN": 1406020,
        "kodeKABUPATEN": 1406,
        "namaKECAMATAN": "XIII KOTO KAMPAR"
      },
      {
        "kodeKECAMATAN": 1406021,
        "kodeKABUPATEN": 1406,
        "namaKECAMATAN": "KOTO KAMPAR HULU"
      },
      {
        "kodeKECAMATAN": 1406030,
        "kodeKABUPATEN": 1406,
        "namaKECAMATAN": "KUOK"
      },
      {
        "kodeKECAMATAN": 1406031,
        "kodeKABUPATEN": 1406,
        "namaKECAMATAN": "SALO"
      },
      {
        "kodeKECAMATAN": 1406040,
        "kodeKABUPATEN": 1406,
        "namaKECAMATAN": "TAPUNG"
      },
      {
        "kodeKECAMATAN": 1406041,
        "kodeKABUPATEN": 1406,
        "namaKECAMATAN": "TAPUNG HULU"
      },
      {
        "kodeKECAMATAN": 1406042,
        "kodeKABUPATEN": 1406,
        "namaKECAMATAN": "TAPUNG HILIR"
      },
      {
        "kodeKECAMATAN": 1406050,
        "kodeKABUPATEN": 1406,
        "namaKECAMATAN": "BANGKINANG KOTA"
      },
      {
        "kodeKECAMATAN": 1406051,
        "kodeKABUPATEN": 1406,
        "namaKECAMATAN": "BANGKINANG"
      },
      {
        "kodeKECAMATAN": 1406060,
        "kodeKABUPATEN": 1406,
        "namaKECAMATAN": "KAMPAR"
      },
      {
        "kodeKECAMATAN": 1406061,
        "kodeKABUPATEN": 1406,
        "namaKECAMATAN": "KAMPAR TIMUR"
      },
      {
        "kodeKECAMATAN": 1406062,
        "kodeKABUPATEN": 1406,
        "namaKECAMATAN": "RUMBIO JAYA"
      },
      {
        "kodeKECAMATAN": 1406063,
        "kodeKABUPATEN": 1406,
        "namaKECAMATAN": "KAMPAR UTARA"
      },
      {
        "kodeKECAMATAN": 1406070,
        "kodeKABUPATEN": 1406,
        "namaKECAMATAN": "TAMBANG"
      },
      {
        "kodeKECAMATAN": 1406080,
        "kodeKABUPATEN": 1406,
        "namaKECAMATAN": "SIAK HULU"
      },
      {
        "kodeKECAMATAN": 1406081,
        "kodeKABUPATEN": 1406,
        "namaKECAMATAN": "PERHENTIAN RAJA"
      },
      {
        "kodeKECAMATAN": 1407010,
        "kodeKABUPATEN": 1407,
        "namaKECAMATAN": "ROKAN IV KOTO"
      },
      {
        "kodeKECAMATAN": 1407011,
        "kodeKABUPATEN": 1407,
        "namaKECAMATAN": "PENDALIAN IV KOTO"
      },
      {
        "kodeKECAMATAN": 1407020,
        "kodeKABUPATEN": 1407,
        "namaKECAMATAN": "TANDUN"
      },
      {
        "kodeKECAMATAN": 1407021,
        "kodeKABUPATEN": 1407,
        "namaKECAMATAN": "KABUN"
      },
      {
        "kodeKECAMATAN": 1407022,
        "kodeKABUPATEN": 1407,
        "namaKECAMATAN": "UJUNG BATU"
      },
      {
        "kodeKECAMATAN": 1407030,
        "kodeKABUPATEN": 1407,
        "namaKECAMATAN": "RAMBAH SAMO"
      },
      {
        "kodeKECAMATAN": 1407040,
        "kodeKABUPATEN": 1407,
        "namaKECAMATAN": "RAMBAH"
      },
      {
        "kodeKECAMATAN": 1407041,
        "kodeKABUPATEN": 1407,
        "namaKECAMATAN": "RAMBAH HILIR"
      },
      {
        "kodeKECAMATAN": 1407042,
        "kodeKABUPATEN": 1407,
        "namaKECAMATAN": "BANGUN PURBA"
      },
      {
        "kodeKECAMATAN": 1407050,
        "kodeKABUPATEN": 1407,
        "namaKECAMATAN": "TAMBUSAI"
      },
      {
        "kodeKECAMATAN": 1407051,
        "kodeKABUPATEN": 1407,
        "namaKECAMATAN": "TAMBUSAI UTARA"
      },
      {
        "kodeKECAMATAN": 1407060,
        "kodeKABUPATEN": 1407,
        "namaKECAMATAN": "KEPENUHAN"
      },
      {
        "kodeKECAMATAN": 1407061,
        "kodeKABUPATEN": 1407,
        "namaKECAMATAN": "KEPENUHAN HULU"
      },
      {
        "kodeKECAMATAN": 1407070,
        "kodeKABUPATEN": 1407,
        "namaKECAMATAN": "KUNTO DARUSSALAM"
      },
      {
        "kodeKECAMATAN": 1407071,
        "kodeKABUPATEN": 1407,
        "namaKECAMATAN": "PAGARAN TAPAH DARUSSALAM"
      },
      {
        "kodeKECAMATAN": 1407072,
        "kodeKABUPATEN": 1407,
        "namaKECAMATAN": "BONAI DARUSSALAM"
      },
      {
        "kodeKECAMATAN": 1408010,
        "kodeKABUPATEN": 1408,
        "namaKECAMATAN": "MANDAU"
      },
      {
        "kodeKECAMATAN": 1408011,
        "kodeKABUPATEN": 1408,
        "namaKECAMATAN": "PINGGIR"
      },
      {
        "kodeKECAMATAN": 1408020,
        "kodeKABUPATEN": 1408,
        "namaKECAMATAN": "BUKIT BATU"
      },
      {
        "kodeKECAMATAN": 1408021,
        "kodeKABUPATEN": 1408,
        "namaKECAMATAN": "SIAK KECIL"
      },
      {
        "kodeKECAMATAN": 1408030,
        "kodeKABUPATEN": 1408,
        "namaKECAMATAN": "RUPAT"
      },
      {
        "kodeKECAMATAN": 1408031,
        "kodeKABUPATEN": 1408,
        "namaKECAMATAN": "RUPAT UTARA"
      },
      {
        "kodeKECAMATAN": 1408040,
        "kodeKABUPATEN": 1408,
        "namaKECAMATAN": "BENGKALIS"
      },
      {
        "kodeKECAMATAN": 1408050,
        "kodeKABUPATEN": 1408,
        "namaKECAMATAN": "BANTAN"
      },
      {
        "kodeKECAMATAN": 1409010,
        "kodeKABUPATEN": 1409,
        "namaKECAMATAN": "TANAH PUTIH"
      },
      {
        "kodeKECAMATAN": 1409011,
        "kodeKABUPATEN": 1409,
        "namaKECAMATAN": "PUJUD"
      },
      {
        "kodeKECAMATAN": 1409012,
        "kodeKABUPATEN": 1409,
        "namaKECAMATAN": "TANAH PUTIH TANJUNG MELAWAN"
      },
      {
        "kodeKECAMATAN": 1409013,
        "kodeKABUPATEN": 1409,
        "namaKECAMATAN": "RANTAU KOPAR"
      },
      {
        "kodeKECAMATAN": 1409014,
        "kodeKABUPATEN": 1409,
        "namaKECAMATAN": "TANJUNG MEDAN"
      },
      {
        "kodeKECAMATAN": 1409020,
        "kodeKABUPATEN": 1409,
        "namaKECAMATAN": "BAGAN SINEMBAH"
      },
      {
        "kodeKECAMATAN": 1409021,
        "kodeKABUPATEN": 1409,
        "namaKECAMATAN": "SIMPANG KANAN"
      },
      {
        "kodeKECAMATAN": 1409022,
        "kodeKABUPATEN": 1409,
        "namaKECAMATAN": "BAGAN SINEMBAH RAYA"
      },
      {
        "kodeKECAMATAN": 1409023,
        "kodeKABUPATEN": 1409,
        "namaKECAMATAN": "BALAI JAYA"
      },
      {
        "kodeKECAMATAN": 1409030,
        "kodeKABUPATEN": 1409,
        "namaKECAMATAN": "KUBU"
      },
      {
        "kodeKECAMATAN": 1409031,
        "kodeKABUPATEN": 1409,
        "namaKECAMATAN": "PASIR LIMAU KAPAS"
      },
      {
        "kodeKECAMATAN": 1409032,
        "kodeKABUPATEN": 1409,
        "namaKECAMATAN": "KUBU BABUSSALAM"
      },
      {
        "kodeKECAMATAN": 1409040,
        "kodeKABUPATEN": 1409,
        "namaKECAMATAN": "BANGKO"
      },
      {
        "kodeKECAMATAN": 1409041,
        "kodeKABUPATEN": 1409,
        "namaKECAMATAN": "SINABOI"
      },
      {
        "kodeKECAMATAN": 1409042,
        "kodeKABUPATEN": 1409,
        "namaKECAMATAN": "BATU HAMPAR"
      },
      {
        "kodeKECAMATAN": 1409043,
        "kodeKABUPATEN": 1409,
        "namaKECAMATAN": "PEKAITAN"
      },
      {
        "kodeKECAMATAN": 1409050,
        "kodeKABUPATEN": 1409,
        "namaKECAMATAN": "RIMBA MELINTANG"
      },
      {
        "kodeKECAMATAN": 1409051,
        "kodeKABUPATEN": 1409,
        "namaKECAMATAN": "BANGKO PUSAKO"
      },
      {
        "kodeKECAMATAN": 1410010,
        "kodeKABUPATEN": 1410,
        "namaKECAMATAN": "TEBING TINGGI BARAT"
      },
      {
        "kodeKECAMATAN": 1410020,
        "kodeKABUPATEN": 1410,
        "namaKECAMATAN": "TEBING TINGGI"
      },
      {
        "kodeKECAMATAN": 1410021,
        "kodeKABUPATEN": 1410,
        "namaKECAMATAN": "TEBING TINGGI TIMUR"
      },
      {
        "kodeKECAMATAN": 1410030,
        "kodeKABUPATEN": 1410,
        "namaKECAMATAN": "RANGSANG"
      },
      {
        "kodeKECAMATAN": 1410031,
        "kodeKABUPATEN": 1410,
        "namaKECAMATAN": "RANGSANG PESISIR"
      },
      {
        "kodeKECAMATAN": 1410040,
        "kodeKABUPATEN": 1410,
        "namaKECAMATAN": "RANGSANG BARAT"
      },
      {
        "kodeKECAMATAN": 1410050,
        "kodeKABUPATEN": 1410,
        "namaKECAMATAN": "MERBAU"
      },
      {
        "kodeKECAMATAN": 1410051,
        "kodeKABUPATEN": 1410,
        "namaKECAMATAN": "PULAU MERBAU"
      },
      {
        "kodeKECAMATAN": 1410052,
        "kodeKABUPATEN": 1410,
        "namaKECAMATAN": "PUTRI PUYU"
      },
      {
        "kodeKECAMATAN": 1471010,
        "kodeKABUPATEN": 1471,
        "namaKECAMATAN": "TAMPAN"
      },
      {
        "kodeKECAMATAN": 1471011,
        "kodeKABUPATEN": 1471,
        "namaKECAMATAN": "PAYUNG SEKAKI"
      },
      {
        "kodeKECAMATAN": 1471020,
        "kodeKABUPATEN": 1471,
        "namaKECAMATAN": "BUKIT RAYA"
      },
      {
        "kodeKECAMATAN": 1471021,
        "kodeKABUPATEN": 1471,
        "namaKECAMATAN": "MARPOYAN DAMAI"
      },
      {
        "kodeKECAMATAN": 1471022,
        "kodeKABUPATEN": 1471,
        "namaKECAMATAN": "TENAYAN RAYA"
      },
      {
        "kodeKECAMATAN": 1471030,
        "kodeKABUPATEN": 1471,
        "namaKECAMATAN": "LIMAPULUH"
      },
      {
        "kodeKECAMATAN": 1471040,
        "kodeKABUPATEN": 1471,
        "namaKECAMATAN": "SAIL"
      },
      {
        "kodeKECAMATAN": 1471050,
        "kodeKABUPATEN": 1471,
        "namaKECAMATAN": "PEKANBARU KOTA"
      },
      {
        "kodeKECAMATAN": 1471060,
        "kodeKABUPATEN": 1471,
        "namaKECAMATAN": "SUKAJADI"
      },
      {
        "kodeKECAMATAN": 1471070,
        "kodeKABUPATEN": 1471,
        "namaKECAMATAN": "SENAPELAN"
      },
      {
        "kodeKECAMATAN": 1471080,
        "kodeKABUPATEN": 1471,
        "namaKECAMATAN": "RUMBAI"
      },
      {
        "kodeKECAMATAN": 1471081,
        "kodeKABUPATEN": 1471,
        "namaKECAMATAN": "RUMBAI PESISIR"
      },
      {
        "kodeKECAMATAN": 1473010,
        "kodeKABUPATEN": 1473,
        "namaKECAMATAN": "BUKIT KAPUR"
      },
      {
        "kodeKECAMATAN": 1473011,
        "kodeKABUPATEN": 1473,
        "namaKECAMATAN": "MEDANG KAMPAI"
      },
      {
        "kodeKECAMATAN": 1473012,
        "kodeKABUPATEN": 1473,
        "namaKECAMATAN": "SUNGAI SEMBILAN"
      },
      {
        "kodeKECAMATAN": 1473020,
        "kodeKABUPATEN": 1473,
        "namaKECAMATAN": "DUMAI BARAT"
      },
      {
        "kodeKECAMATAN": 1473021,
        "kodeKABUPATEN": 1473,
        "namaKECAMATAN": "DUMAI SELATAN"
      },
      {
        "kodeKECAMATAN": 1473030,
        "kodeKABUPATEN": 1473,
        "namaKECAMATAN": "DUMAI TIMUR"
      },
      {
        "kodeKECAMATAN": 1473031,
        "kodeKABUPATEN": 1473,
        "namaKECAMATAN": "DUMAI KOTA"
      },
      {
        "kodeKECAMATAN": 1501010,
        "kodeKABUPATEN": 1501,
        "namaKECAMATAN": "GUNUNG RAYA"
      },
      {
        "kodeKECAMATAN": 1501011,
        "kodeKABUPATEN": 1501,
        "namaKECAMATAN": "BUKIT KERMAN"
      },
      {
        "kodeKECAMATAN": 1501020,
        "kodeKABUPATEN": 1501,
        "namaKECAMATAN": "BATANG MERANGIN"
      },
      {
        "kodeKECAMATAN": 1501030,
        "kodeKABUPATEN": 1501,
        "namaKECAMATAN": "KELILING DANAU"
      },
      {
        "kodeKECAMATAN": 1501040,
        "kodeKABUPATEN": 1501,
        "namaKECAMATAN": "DANAU KERINCI"
      },
      {
        "kodeKECAMATAN": 1501050,
        "kodeKABUPATEN": 1501,
        "namaKECAMATAN": "SITINJAU LAUT"
      },
      {
        "kodeKECAMATAN": 1501070,
        "kodeKABUPATEN": 1501,
        "namaKECAMATAN": "AIR HANGAT"
      },
      {
        "kodeKECAMATAN": 1501071,
        "kodeKABUPATEN": 1501,
        "namaKECAMATAN": "AIR HANGAT TIMUR"
      },
      {
        "kodeKECAMATAN": 1501072,
        "kodeKABUPATEN": 1501,
        "namaKECAMATAN": "DEPATI VII"
      },
      {
        "kodeKECAMATAN": 1501073,
        "kodeKABUPATEN": 1501,
        "namaKECAMATAN": "AIR HANGAT BARAT"
      },
      {
        "kodeKECAMATAN": 1501080,
        "kodeKABUPATEN": 1501,
        "namaKECAMATAN": "GUNUNG KERINCI"
      },
      {
        "kodeKECAMATAN": 1501081,
        "kodeKABUPATEN": 1501,
        "namaKECAMATAN": "SIULAK"
      },
      {
        "kodeKECAMATAN": 1501082,
        "kodeKABUPATEN": 1501,
        "namaKECAMATAN": "SIULAK MUKAI"
      },
      {
        "kodeKECAMATAN": 1501090,
        "kodeKABUPATEN": 1501,
        "namaKECAMATAN": "KAYU ARO"
      },
      {
        "kodeKECAMATAN": 1501091,
        "kodeKABUPATEN": 1501,
        "namaKECAMATAN": "GUNUNG TUJUH"
      },
      {
        "kodeKECAMATAN": 1501092,
        "kodeKABUPATEN": 1501,
        "namaKECAMATAN": "KAYU ARO BARAT"
      },
      {
        "kodeKECAMATAN": 1502010,
        "kodeKABUPATEN": 1502,
        "namaKECAMATAN": "JANGKAT"
      },
      {
        "kodeKECAMATAN": 1502011,
        "kodeKABUPATEN": 1502,
        "namaKECAMATAN": "SUNGAI TENANG"
      },
      {
        "kodeKECAMATAN": 1502020,
        "kodeKABUPATEN": 1502,
        "namaKECAMATAN": "MUARA SIAU"
      },
      {
        "kodeKECAMATAN": 1502021,
        "kodeKABUPATEN": 1502,
        "namaKECAMATAN": "LEMBAH MASURAI"
      },
      {
        "kodeKECAMATAN": 1502022,
        "kodeKABUPATEN": 1502,
        "namaKECAMATAN": "TIANG PUMPUNG"
      },
      {
        "kodeKECAMATAN": 1502030,
        "kodeKABUPATEN": 1502,
        "namaKECAMATAN": "PAMENANG"
      },
      {
        "kodeKECAMATAN": 1502031,
        "kodeKABUPATEN": 1502,
        "namaKECAMATAN": "PAMENANG BARAT"
      },
      {
        "kodeKECAMATAN": 1502032,
        "kodeKABUPATEN": 1502,
        "namaKECAMATAN": "RENAH PAMENANG"
      },
      {
        "kodeKECAMATAN": 1502033,
        "kodeKABUPATEN": 1502,
        "namaKECAMATAN": "PAMENANG SELATAN"
      },
      {
        "kodeKECAMATAN": 1502040,
        "kodeKABUPATEN": 1502,
        "namaKECAMATAN": "BANGKO"
      },
      {
        "kodeKECAMATAN": 1502041,
        "kodeKABUPATEN": 1502,
        "namaKECAMATAN": "BANGKO BARAT"
      },
      {
        "kodeKECAMATAN": 1502042,
        "kodeKABUPATEN": 1502,
        "namaKECAMATAN": "NALO TANTAN"
      },
      {
        "kodeKECAMATAN": 1502043,
        "kodeKABUPATEN": 1502,
        "namaKECAMATAN": "BATANG MASUMAI"
      },
      {
        "kodeKECAMATAN": 1502050,
        "kodeKABUPATEN": 1502,
        "namaKECAMATAN": "SUNGAI MANAU"
      },
      {
        "kodeKECAMATAN": 1502051,
        "kodeKABUPATEN": 1502,
        "namaKECAMATAN": "RENAH PEMBARAP"
      },
      {
        "kodeKECAMATAN": 1502052,
        "kodeKABUPATEN": 1502,
        "namaKECAMATAN": "PANGKALAN JAMBU"
      },
      {
        "kodeKECAMATAN": 1502060,
        "kodeKABUPATEN": 1502,
        "namaKECAMATAN": "TABIR"
      },
      {
        "kodeKECAMATAN": 1502061,
        "kodeKABUPATEN": 1502,
        "namaKECAMATAN": "TABIR ULU"
      },
      {
        "kodeKECAMATAN": 1502062,
        "kodeKABUPATEN": 1502,
        "namaKECAMATAN": "TABIR SELATAN"
      },
      {
        "kodeKECAMATAN": 1502063,
        "kodeKABUPATEN": 1502,
        "namaKECAMATAN": "TABIR ILIR"
      },
      {
        "kodeKECAMATAN": 1502064,
        "kodeKABUPATEN": 1502,
        "namaKECAMATAN": "TABIR TIMUR"
      },
      {
        "kodeKECAMATAN": 1502065,
        "kodeKABUPATEN": 1502,
        "namaKECAMATAN": "TABIR LINTAS"
      },
      {
        "kodeKECAMATAN": 1502066,
        "kodeKABUPATEN": 1502,
        "namaKECAMATAN": "MARGO TABIR"
      },
      {
        "kodeKECAMATAN": 1502067,
        "kodeKABUPATEN": 1502,
        "namaKECAMATAN": "TABIR BARAT"
      },
      {
        "kodeKECAMATAN": 1503010,
        "kodeKABUPATEN": 1503,
        "namaKECAMATAN": "BATANG ASAI"
      },
      {
        "kodeKECAMATAN": 1503020,
        "kodeKABUPATEN": 1503,
        "namaKECAMATAN": "LIMUN"
      },
      {
        "kodeKECAMATAN": 1503021,
        "kodeKABUPATEN": 1503,
        "namaKECAMATAN": "CERMIN NAN GEDANG"
      },
      {
        "kodeKECAMATAN": 1503030,
        "kodeKABUPATEN": 1503,
        "namaKECAMATAN": "PELAWAN"
      },
      {
        "kodeKECAMATAN": 1503031,
        "kodeKABUPATEN": 1503,
        "namaKECAMATAN": "SINGKUT"
      },
      {
        "kodeKECAMATAN": 1503040,
        "kodeKABUPATEN": 1503,
        "namaKECAMATAN": "SAROLANGUN"
      },
      {
        "kodeKECAMATAN": 1503041,
        "kodeKABUPATEN": 1503,
        "namaKECAMATAN": "BATHIN VIII"
      },
      {
        "kodeKECAMATAN": 1503050,
        "kodeKABUPATEN": 1503,
        "namaKECAMATAN": "PAUH"
      },
      {
        "kodeKECAMATAN": 1503051,
        "kodeKABUPATEN": 1503,
        "namaKECAMATAN": "AIR HITAM"
      },
      {
        "kodeKECAMATAN": 1503060,
        "kodeKABUPATEN": 1503,
        "namaKECAMATAN": "MANDIANGIN"
      },
      {
        "kodeKECAMATAN": 1504010,
        "kodeKABUPATEN": 1504,
        "namaKECAMATAN": "MERSAM"
      },
      {
        "kodeKECAMATAN": 1504011,
        "kodeKABUPATEN": 1504,
        "namaKECAMATAN": "MARO SEBO ULU"
      },
      {
        "kodeKECAMATAN": 1504020,
        "kodeKABUPATEN": 1504,
        "namaKECAMATAN": "BATIN XXIV"
      },
      {
        "kodeKECAMATAN": 1504030,
        "kodeKABUPATEN": 1504,
        "namaKECAMATAN": "MUARA TEMBESI"
      },
      {
        "kodeKECAMATAN": 1504040,
        "kodeKABUPATEN": 1504,
        "namaKECAMATAN": "MUARA BULIAN"
      },
      {
        "kodeKECAMATAN": 1504041,
        "kodeKABUPATEN": 1504,
        "namaKECAMATAN": "BAJUBANG"
      },
      {
        "kodeKECAMATAN": 1504042,
        "kodeKABUPATEN": 1504,
        "namaKECAMATAN": "MARO SEBO ILIR"
      },
      {
        "kodeKECAMATAN": 1504050,
        "kodeKABUPATEN": 1504,
        "namaKECAMATAN": "PEMAYUNG"
      },
      {
        "kodeKECAMATAN": 1505010,
        "kodeKABUPATEN": 1505,
        "namaKECAMATAN": "MESTONG"
      },
      {
        "kodeKECAMATAN": 1505011,
        "kodeKABUPATEN": 1505,
        "namaKECAMATAN": "SUNGAI BAHAR"
      },
      {
        "kodeKECAMATAN": 1505012,
        "kodeKABUPATEN": 1505,
        "namaKECAMATAN": "BAHAR SELATAN"
      },
      {
        "kodeKECAMATAN": 1505013,
        "kodeKABUPATEN": 1505,
        "namaKECAMATAN": "BAHAR UTARA"
      },
      {
        "kodeKECAMATAN": 1505020,
        "kodeKABUPATEN": 1505,
        "namaKECAMATAN": "KUMPEH ULU"
      },
      {
        "kodeKECAMATAN": 1505021,
        "kodeKABUPATEN": 1505,
        "namaKECAMATAN": "SUNGAI GELAM"
      },
      {
        "kodeKECAMATAN": 1505030,
        "kodeKABUPATEN": 1505,
        "namaKECAMATAN": "KUMPEH"
      },
      {
        "kodeKECAMATAN": 1505040,
        "kodeKABUPATEN": 1505,
        "namaKECAMATAN": "MARO SEBO"
      },
      {
        "kodeKECAMATAN": 1505041,
        "kodeKABUPATEN": 1505,
        "namaKECAMATAN": "TAMAN RAJO"
      },
      {
        "kodeKECAMATAN": 1505050,
        "kodeKABUPATEN": 1505,
        "namaKECAMATAN": "JAMBI LUAR KOTA"
      },
      {
        "kodeKECAMATAN": 1505060,
        "kodeKABUPATEN": 1505,
        "namaKECAMATAN": "SEKERNAN"
      },
      {
        "kodeKECAMATAN": 1506010,
        "kodeKABUPATEN": 1506,
        "namaKECAMATAN": "MENDAHARA"
      },
      {
        "kodeKECAMATAN": 1506011,
        "kodeKABUPATEN": 1506,
        "namaKECAMATAN": "MENDAHARA ULU"
      },
      {
        "kodeKECAMATAN": 1506012,
        "kodeKABUPATEN": 1506,
        "namaKECAMATAN": "GERAGAI"
      },
      {
        "kodeKECAMATAN": 1506020,
        "kodeKABUPATEN": 1506,
        "namaKECAMATAN": "DENDANG"
      },
      {
        "kodeKECAMATAN": 1506031,
        "kodeKABUPATEN": 1506,
        "namaKECAMATAN": "MUARA SABAK BARAT"
      },
      {
        "kodeKECAMATAN": 1506032,
        "kodeKABUPATEN": 1506,
        "namaKECAMATAN": "MUARA SABAK TIMUR"
      },
      {
        "kodeKECAMATAN": 1506033,
        "kodeKABUPATEN": 1506,
        "namaKECAMATAN": "KUALA JAMBI"
      },
      {
        "kodeKECAMATAN": 1506040,
        "kodeKABUPATEN": 1506,
        "namaKECAMATAN": "RANTAU RASAU"
      },
      {
        "kodeKECAMATAN": 1506041,
        "kodeKABUPATEN": 1506,
        "namaKECAMATAN": "BERBAK"
      },
      {
        "kodeKECAMATAN": 1506050,
        "kodeKABUPATEN": 1506,
        "namaKECAMATAN": "NIPAH PANJANG"
      },
      {
        "kodeKECAMATAN": 1506060,
        "kodeKABUPATEN": 1506,
        "namaKECAMATAN": "SADU"
      },
      {
        "kodeKECAMATAN": 1507010,
        "kodeKABUPATEN": 1507,
        "namaKECAMATAN": "TUNGKAL ULU"
      },
      {
        "kodeKECAMATAN": 1507011,
        "kodeKABUPATEN": 1507,
        "namaKECAMATAN": "MERLUNG"
      },
      {
        "kodeKECAMATAN": 1507012,
        "kodeKABUPATEN": 1507,
        "namaKECAMATAN": "BATANG ASAM"
      },
      {
        "kodeKECAMATAN": 1507013,
        "kodeKABUPATEN": 1507,
        "namaKECAMATAN": "TEBING TINGGI"
      },
      {
        "kodeKECAMATAN": 1507014,
        "kodeKABUPATEN": 1507,
        "namaKECAMATAN": "RENAH MENDALUH"
      },
      {
        "kodeKECAMATAN": 1507015,
        "kodeKABUPATEN": 1507,
        "namaKECAMATAN": "MUARA PAPALIK"
      },
      {
        "kodeKECAMATAN": 1507020,
        "kodeKABUPATEN": 1507,
        "namaKECAMATAN": "PENGABUAN"
      },
      {
        "kodeKECAMATAN": 1507021,
        "kodeKABUPATEN": 1507,
        "namaKECAMATAN": "SENYERANG"
      },
      {
        "kodeKECAMATAN": 1507030,
        "kodeKABUPATEN": 1507,
        "namaKECAMATAN": "TUNGKAL ILIR"
      },
      {
        "kodeKECAMATAN": 1507031,
        "kodeKABUPATEN": 1507,
        "namaKECAMATAN": "BRAM ITAM"
      },
      {
        "kodeKECAMATAN": 1507032,
        "kodeKABUPATEN": 1507,
        "namaKECAMATAN": "SEBERANG KOTA"
      },
      {
        "kodeKECAMATAN": 1507040,
        "kodeKABUPATEN": 1507,
        "namaKECAMATAN": "BETARA"
      },
      {
        "kodeKECAMATAN": 1507041,
        "kodeKABUPATEN": 1507,
        "namaKECAMATAN": "KUALA BETARA"
      },
      {
        "kodeKECAMATAN": 1508010,
        "kodeKABUPATEN": 1508,
        "namaKECAMATAN": "TEBO ILIR"
      },
      {
        "kodeKECAMATAN": 1508011,
        "kodeKABUPATEN": 1508,
        "namaKECAMATAN": "MUARA TABIR"
      },
      {
        "kodeKECAMATAN": 1508020,
        "kodeKABUPATEN": 1508,
        "namaKECAMATAN": "TEBO TENGAH"
      },
      {
        "kodeKECAMATAN": 1508021,
        "kodeKABUPATEN": 1508,
        "namaKECAMATAN": "SUMAY"
      },
      {
        "kodeKECAMATAN": 1508022,
        "kodeKABUPATEN": 1508,
        "namaKECAMATAN": "TENGAH ILIR"
      },
      {
        "kodeKECAMATAN": 1508030,
        "kodeKABUPATEN": 1508,
        "namaKECAMATAN": "RIMBO BUJANG"
      },
      {
        "kodeKECAMATAN": 1508031,
        "kodeKABUPATEN": 1508,
        "namaKECAMATAN": "RIMBO ULU"
      },
      {
        "kodeKECAMATAN": 1508032,
        "kodeKABUPATEN": 1508,
        "namaKECAMATAN": "RIMBO ILIR"
      },
      {
        "kodeKECAMATAN": 1508040,
        "kodeKABUPATEN": 1508,
        "namaKECAMATAN": "TEBO ULU"
      },
      {
        "kodeKECAMATAN": 1508041,
        "kodeKABUPATEN": 1508,
        "namaKECAMATAN": "VII KOTO"
      },
      {
        "kodeKECAMATAN": 1508042,
        "kodeKABUPATEN": 1508,
        "namaKECAMATAN": "SERAI SERUMPUN"
      },
      {
        "kodeKECAMATAN": 1508043,
        "kodeKABUPATEN": 1508,
        "namaKECAMATAN": "VII KOTO ILIR"
      },
      {
        "kodeKECAMATAN": 1509010,
        "kodeKABUPATEN": 1509,
        "namaKECAMATAN": "PELEPAT"
      },
      {
        "kodeKECAMATAN": 1509011,
        "kodeKABUPATEN": 1509,
        "namaKECAMATAN": "PELEPAT ILIR"
      },
      {
        "kodeKECAMATAN": 1509021,
        "kodeKABUPATEN": 1509,
        "namaKECAMATAN": "BATHIN II BABEKO"
      },
      {
        "kodeKECAMATAN": 1509022,
        "kodeKABUPATEN": 1509,
        "namaKECAMATAN": "RIMBO TENGAH"
      },
      {
        "kodeKECAMATAN": 1509023,
        "kodeKABUPATEN": 1509,
        "namaKECAMATAN": "BUNGO DANI"
      },
      {
        "kodeKECAMATAN": 1509024,
        "kodeKABUPATEN": 1509,
        "namaKECAMATAN": "PASAR MUARA BUNGO"
      },
      {
        "kodeKECAMATAN": 1509025,
        "kodeKABUPATEN": 1509,
        "namaKECAMATAN": "BATHIN III"
      },
      {
        "kodeKECAMATAN": 1509030,
        "kodeKABUPATEN": 1509,
        "namaKECAMATAN": "RANTAU PANDAN"
      },
      {
        "kodeKECAMATAN": 1509031,
        "kodeKABUPATEN": 1509,
        "namaKECAMATAN": "MUKO-MUKO BATHIN VII"
      },
      {
        "kodeKECAMATAN": 1509032,
        "kodeKABUPATEN": 1509,
        "namaKECAMATAN": "BATHIN III ULU"
      },
      {
        "kodeKECAMATAN": 1509040,
        "kodeKABUPATEN": 1509,
        "namaKECAMATAN": "TANAH SEPENGGAL"
      },
      {
        "kodeKECAMATAN": 1509041,
        "kodeKABUPATEN": 1509,
        "namaKECAMATAN": "TANAH SEPENGGAL LINTAS"
      },
      {
        "kodeKECAMATAN": 1509050,
        "kodeKABUPATEN": 1509,
        "namaKECAMATAN": "TANAH TUMBUH"
      },
      {
        "kodeKECAMATAN": 1509051,
        "kodeKABUPATEN": 1509,
        "namaKECAMATAN": "LIMBUR LUBUK MENGKUANG"
      },
      {
        "kodeKECAMATAN": 1509052,
        "kodeKABUPATEN": 1509,
        "namaKECAMATAN": "BATHIN II PELAYANG"
      },
      {
        "kodeKECAMATAN": 1509060,
        "kodeKABUPATEN": 1509,
        "namaKECAMATAN": "JUJUHAN"
      },
      {
        "kodeKECAMATAN": 1509061,
        "kodeKABUPATEN": 1509,
        "namaKECAMATAN": "JUJUHAN ILIR"
      },
      {
        "kodeKECAMATAN": 1571010,
        "kodeKABUPATEN": 1571,
        "namaKECAMATAN": "KOTA BARU"
      },
      {
        "kodeKECAMATAN": 1571020,
        "kodeKABUPATEN": 1571,
        "namaKECAMATAN": "JAMBI SELATAN"
      },
      {
        "kodeKECAMATAN": 1571030,
        "kodeKABUPATEN": 1571,
        "namaKECAMATAN": "JELUTUNG"
      },
      {
        "kodeKECAMATAN": 1571040,
        "kodeKABUPATEN": 1571,
        "namaKECAMATAN": "PASAR JAMBI"
      },
      {
        "kodeKECAMATAN": 1571050,
        "kodeKABUPATEN": 1571,
        "namaKECAMATAN": "TELANAIPURA"
      },
      {
        "kodeKECAMATAN": 1571060,
        "kodeKABUPATEN": 1571,
        "namaKECAMATAN": "DANAU TELUK"
      },
      {
        "kodeKECAMATAN": 1571070,
        "kodeKABUPATEN": 1571,
        "namaKECAMATAN": "PELAYANGAN"
      },
      {
        "kodeKECAMATAN": 1571080,
        "kodeKABUPATEN": 1571,
        "namaKECAMATAN": "JAMBI TIMUR"
      },
      {
        "kodeKECAMATAN": 1572010,
        "kodeKABUPATEN": 1572,
        "namaKECAMATAN": "TANAH KAMPUNG"
      },
      {
        "kodeKECAMATAN": 1572020,
        "kodeKABUPATEN": 1572,
        "namaKECAMATAN": "KUMUN DEBAI"
      },
      {
        "kodeKECAMATAN": 1572030,
        "kodeKABUPATEN": 1572,
        "namaKECAMATAN": "SUNGAI PENUH"
      },
      {
        "kodeKECAMATAN": 1572031,
        "kodeKABUPATEN": 1572,
        "namaKECAMATAN": "PONDOK TINGGGI"
      },
      {
        "kodeKECAMATAN": 1572032,
        "kodeKABUPATEN": 1572,
        "namaKECAMATAN": "SUNGAI BUNGKAL"
      },
      {
        "kodeKECAMATAN": 1572040,
        "kodeKABUPATEN": 1572,
        "namaKECAMATAN": "HAMPARAN RAWANG"
      },
      {
        "kodeKECAMATAN": 1572050,
        "kodeKABUPATEN": 1572,
        "namaKECAMATAN": "PESISIR BUKIT"
      },
      {
        "kodeKECAMATAN": 1572051,
        "kodeKABUPATEN": 1572,
        "namaKECAMATAN": "KOTO BARU"
      },
      {
        "kodeKECAMATAN": 1601052,
        "kodeKABUPATEN": 1601,
        "namaKECAMATAN": "LENGKITI"
      },
      {
        "kodeKECAMATAN": 1601070,
        "kodeKABUPATEN": 1601,
        "namaKECAMATAN": "SOSOH BUAY RAYAP"
      },
      {
        "kodeKECAMATAN": 1601080,
        "kodeKABUPATEN": 1601,
        "namaKECAMATAN": "PENGANDONAN"
      },
      {
        "kodeKECAMATAN": 1601081,
        "kodeKABUPATEN": 1601,
        "namaKECAMATAN": "SEMIDANG AJI"
      },
      {
        "kodeKECAMATAN": 1601082,
        "kodeKABUPATEN": 1601,
        "namaKECAMATAN": "ULU OGAN"
      },
      {
        "kodeKECAMATAN": 1601083,
        "kodeKABUPATEN": 1601,
        "namaKECAMATAN": "MUARA JAYA"
      },
      {
        "kodeKECAMATAN": 1601090,
        "kodeKABUPATEN": 1601,
        "namaKECAMATAN": "PENINJAUAN"
      },
      {
        "kodeKECAMATAN": 1601091,
        "kodeKABUPATEN": 1601,
        "namaKECAMATAN": "LUBUK BATANG"
      },
      {
        "kodeKECAMATAN": 1601092,
        "kodeKABUPATEN": 1601,
        "namaKECAMATAN": "SINAR PENINJAUAN"
      },
      {
        "kodeKECAMATAN": 1601093,
        "kodeKABUPATEN": 1601,
        "namaKECAMATAN": "KEDATON PENINJAUAN RAYA"
      },
      {
        "kodeKECAMATAN": 1601130,
        "kodeKABUPATEN": 1601,
        "namaKECAMATAN": "BATU RAJA TIMUR"
      },
      {
        "kodeKECAMATAN": 1601131,
        "kodeKABUPATEN": 1601,
        "namaKECAMATAN": "LUBUK RAJA"
      },
      {
        "kodeKECAMATAN": 1601140,
        "kodeKABUPATEN": 1601,
        "namaKECAMATAN": "BATU RAJA BARAT"
      },
      {
        "kodeKECAMATAN": 1602010,
        "kodeKABUPATEN": 1602,
        "namaKECAMATAN": "LEMPUING"
      },
      {
        "kodeKECAMATAN": 1602011,
        "kodeKABUPATEN": 1602,
        "namaKECAMATAN": "LEMPUING JAYA"
      },
      {
        "kodeKECAMATAN": 1602020,
        "kodeKABUPATEN": 1602,
        "namaKECAMATAN": "MESUJI"
      },
      {
        "kodeKECAMATAN": 1602021,
        "kodeKABUPATEN": 1602,
        "namaKECAMATAN": "SUNGAI MENANG"
      },
      {
        "kodeKECAMATAN": 1602022,
        "kodeKABUPATEN": 1602,
        "namaKECAMATAN": "MESUJI MAKMUR"
      },
      {
        "kodeKECAMATAN": 1602023,
        "kodeKABUPATEN": 1602,
        "namaKECAMATAN": "MESUJI RAYA"
      },
      {
        "kodeKECAMATAN": 1602030,
        "kodeKABUPATEN": 1602,
        "namaKECAMATAN": "TULUNG SELAPAN"
      },
      {
        "kodeKECAMATAN": 1602031,
        "kodeKABUPATEN": 1602,
        "namaKECAMATAN": "CENGAL"
      },
      {
        "kodeKECAMATAN": 1602040,
        "kodeKABUPATEN": 1602,
        "namaKECAMATAN": "PEDAMARAN"
      },
      {
        "kodeKECAMATAN": 1602041,
        "kodeKABUPATEN": 1602,
        "namaKECAMATAN": "PEDAMARAN TIMUR"
      },
      {
        "kodeKECAMATAN": 1602050,
        "kodeKABUPATEN": 1602,
        "namaKECAMATAN": "TANJUNG LUBUK"
      },
      {
        "kodeKECAMATAN": 1602051,
        "kodeKABUPATEN": 1602,
        "namaKECAMATAN": "TELUK GELAM"
      },
      {
        "kodeKECAMATAN": 1602060,
        "kodeKABUPATEN": 1602,
        "namaKECAMATAN": "KOTA KAYU AGUNG"
      },
      {
        "kodeKECAMATAN": 1602120,
        "kodeKABUPATEN": 1602,
        "namaKECAMATAN": "SIRAH PULAU PADANG"
      },
      {
        "kodeKECAMATAN": 1602121,
        "kodeKABUPATEN": 1602,
        "namaKECAMATAN": "JEJAWI"
      },
      {
        "kodeKECAMATAN": 1602130,
        "kodeKABUPATEN": 1602,
        "namaKECAMATAN": "PAMPANGAN"
      },
      {
        "kodeKECAMATAN": 1602131,
        "kodeKABUPATEN": 1602,
        "namaKECAMATAN": "PANGKALAN LAPAM"
      },
      {
        "kodeKECAMATAN": 1602140,
        "kodeKABUPATEN": 1602,
        "namaKECAMATAN": "AIR SUGIHAN"
      },
      {
        "kodeKECAMATAN": 1603010,
        "kodeKABUPATEN": 1603,
        "namaKECAMATAN": "SEMENDO DARAT LAUT"
      },
      {
        "kodeKECAMATAN": 1603011,
        "kodeKABUPATEN": 1603,
        "namaKECAMATAN": "SEMENDO DARAT ULU"
      },
      {
        "kodeKECAMATAN": 1603012,
        "kodeKABUPATEN": 1603,
        "namaKECAMATAN": "SEMENDO DARAT TENGAH"
      },
      {
        "kodeKECAMATAN": 1603020,
        "kodeKABUPATEN": 1603,
        "namaKECAMATAN": "TANJUNG AGUNG"
      },
      {
        "kodeKECAMATAN": 1603031,
        "kodeKABUPATEN": 1603,
        "namaKECAMATAN": "RAMBANG"
      },
      {
        "kodeKECAMATAN": 1603032,
        "kodeKABUPATEN": 1603,
        "namaKECAMATAN": "LUBAI"
      },
      {
        "kodeKECAMATAN": 1603033,
        "kodeKABUPATEN": 1603,
        "namaKECAMATAN": "LUBAI ULU"
      },
      {
        "kodeKECAMATAN": 1603040,
        "kodeKABUPATEN": 1603,
        "namaKECAMATAN": "LAWANG KIDUL"
      },
      {
        "kodeKECAMATAN": 1603050,
        "kodeKABUPATEN": 1603,
        "namaKECAMATAN": "MUARA ENIM"
      },
      {
        "kodeKECAMATAN": 1603051,
        "kodeKABUPATEN": 1603,
        "namaKECAMATAN": "UJAN MAS"
      },
      {
        "kodeKECAMATAN": 1603060,
        "kodeKABUPATEN": 1603,
        "namaKECAMATAN": "GUNUNG MEGANG"
      },
      {
        "kodeKECAMATAN": 1603061,
        "kodeKABUPATEN": 1603,
        "namaKECAMATAN": "BENAKAT"
      },
      {
        "kodeKECAMATAN": 1603062,
        "kodeKABUPATEN": 1603,
        "namaKECAMATAN": "BELIMBING"
      },
      {
        "kodeKECAMATAN": 1603070,
        "kodeKABUPATEN": 1603,
        "namaKECAMATAN": "RAMBANG DANGKU"
      },
      {
        "kodeKECAMATAN": 1603090,
        "kodeKABUPATEN": 1603,
        "namaKECAMATAN": "GELUMBANG"
      },
      {
        "kodeKECAMATAN": 1603091,
        "kodeKABUPATEN": 1603,
        "namaKECAMATAN": "LEMBAK"
      },
      {
        "kodeKECAMATAN": 1603092,
        "kodeKABUPATEN": 1603,
        "namaKECAMATAN": "SUNGAI ROTAN"
      },
      {
        "kodeKECAMATAN": 1603093,
        "kodeKABUPATEN": 1603,
        "namaKECAMATAN": "MUARA BELIDA"
      },
      {
        "kodeKECAMATAN": 1603094,
        "kodeKABUPATEN": 1603,
        "namaKECAMATAN": "KELEKAR"
      },
      {
        "kodeKECAMATAN": 1603095,
        "kodeKABUPATEN": 1603,
        "namaKECAMATAN": "BELIDA DARAT"
      },
      {
        "kodeKECAMATAN": 1604011,
        "kodeKABUPATEN": 1604,
        "namaKECAMATAN": "TANJUNG SAKTI PUMI"
      },
      {
        "kodeKECAMATAN": 1604012,
        "kodeKABUPATEN": 1604,
        "namaKECAMATAN": "TANJUNG SAKTI PUMU"
      },
      {
        "kodeKECAMATAN": 1604040,
        "kodeKABUPATEN": 1604,
        "namaKECAMATAN": "KOTA AGUNG"
      },
      {
        "kodeKECAMATAN": 1604041,
        "kodeKABUPATEN": 1604,
        "namaKECAMATAN": "MULAK ULU"
      },
      {
        "kodeKECAMATAN": 1604042,
        "kodeKABUPATEN": 1604,
        "namaKECAMATAN": "TANJUNG TEBAT"
      },
      {
        "kodeKECAMATAN": 1604050,
        "kodeKABUPATEN": 1604,
        "namaKECAMATAN": "PULAU PINANG"
      },
      {
        "kodeKECAMATAN": 1604051,
        "kodeKABUPATEN": 1604,
        "namaKECAMATAN": "PAGAR GUNUNG"
      },
      {
        "kodeKECAMATAN": 1604052,
        "kodeKABUPATEN": 1604,
        "namaKECAMATAN": "GUMAY ULU"
      },
      {
        "kodeKECAMATAN": 1604060,
        "kodeKABUPATEN": 1604,
        "namaKECAMATAN": "JARAI"
      },
      {
        "kodeKECAMATAN": 1604061,
        "kodeKABUPATEN": 1604,
        "namaKECAMATAN": "PAJAR BULAN"
      },
      {
        "kodeKECAMATAN": 1604062,
        "kodeKABUPATEN": 1604,
        "namaKECAMATAN": "MUARA PAYANG"
      },
      {
        "kodeKECAMATAN": 1604063,
        "kodeKABUPATEN": 1604,
        "namaKECAMATAN": "SUKAMERINDU"
      },
      {
        "kodeKECAMATAN": 1604111,
        "kodeKABUPATEN": 1604,
        "namaKECAMATAN": "KIKIM BARAT"
      },
      {
        "kodeKECAMATAN": 1604112,
        "kodeKABUPATEN": 1604,
        "namaKECAMATAN": "KIKIM TIMUR"
      },
      {
        "kodeKECAMATAN": 1604113,
        "kodeKABUPATEN": 1604,
        "namaKECAMATAN": "KIKIM SELATAN"
      },
      {
        "kodeKECAMATAN": 1604114,
        "kodeKABUPATEN": 1604,
        "namaKECAMATAN": "KIKIM TENGAH"
      },
      {
        "kodeKECAMATAN": 1604120,
        "kodeKABUPATEN": 1604,
        "namaKECAMATAN": "LAHAT"
      },
      {
        "kodeKECAMATAN": 1604121,
        "kodeKABUPATEN": 1604,
        "namaKECAMATAN": "GUMAY TALANG"
      },
      {
        "kodeKECAMATAN": 1604122,
        "kodeKABUPATEN": 1604,
        "namaKECAMATAN": "PSEKSU"
      },
      {
        "kodeKECAMATAN": 1604131,
        "kodeKABUPATEN": 1604,
        "namaKECAMATAN": "MERAPI BARAT"
      },
      {
        "kodeKECAMATAN": 1604132,
        "kodeKABUPATEN": 1604,
        "namaKECAMATAN": "MERAPI TIMUR"
      },
      {
        "kodeKECAMATAN": 1604133,
        "kodeKABUPATEN": 1604,
        "namaKECAMATAN": "MERAPI SELATAN"
      },
      {
        "kodeKECAMATAN": 1605030,
        "kodeKABUPATEN": 1605,
        "namaKECAMATAN": "SUKU TENGAH LAKITAN ULU"
      },
      {
        "kodeKECAMATAN": 1605031,
        "kodeKABUPATEN": 1605,
        "namaKECAMATAN": "SELANGIT"
      },
      {
        "kodeKECAMATAN": 1605032,
        "kodeKABUPATEN": 1605,
        "namaKECAMATAN": "SUMBER HARTA"
      },
      {
        "kodeKECAMATAN": 1605040,
        "kodeKABUPATEN": 1605,
        "namaKECAMATAN": "TUGUMULYO"
      },
      {
        "kodeKECAMATAN": 1605041,
        "kodeKABUPATEN": 1605,
        "namaKECAMATAN": "PURWODADI"
      },
      {
        "kodeKECAMATAN": 1605050,
        "kodeKABUPATEN": 1605,
        "namaKECAMATAN": "MUARA BELITI"
      },
      {
        "kodeKECAMATAN": 1605051,
        "kodeKABUPATEN": 1605,
        "namaKECAMATAN": "TIANG PUMPUNG KEPUNGUT"
      },
      {
        "kodeKECAMATAN": 1605060,
        "kodeKABUPATEN": 1605,
        "namaKECAMATAN": "JAYALOKA"
      },
      {
        "kodeKECAMATAN": 1605061,
        "kodeKABUPATEN": 1605,
        "namaKECAMATAN": "SUKA KARYA"
      },
      {
        "kodeKECAMATAN": 1605070,
        "kodeKABUPATEN": 1605,
        "namaKECAMATAN": "MUARA KELINGI"
      },
      {
        "kodeKECAMATAN": 1605071,
        "kodeKABUPATEN": 1605,
        "namaKECAMATAN": "BULANG TENGAH SUKU ULU"
      },
      {
        "kodeKECAMATAN": 1605072,
        "kodeKABUPATEN": 1605,
        "namaKECAMATAN": "TUAH NEGERI"
      },
      {
        "kodeKECAMATAN": 1605080,
        "kodeKABUPATEN": 1605,
        "namaKECAMATAN": "MUARA LAKITAN"
      },
      {
        "kodeKECAMATAN": 1605090,
        "kodeKABUPATEN": 1605,
        "namaKECAMATAN": "MEGANG SAKTI"
      },
      {
        "kodeKECAMATAN": 1606010,
        "kodeKABUPATEN": 1606,
        "namaKECAMATAN": "SANGA DESA"
      },
      {
        "kodeKECAMATAN": 1606020,
        "kodeKABUPATEN": 1606,
        "namaKECAMATAN": "BABAT TOMAN"
      },
      {
        "kodeKECAMATAN": 1606021,
        "kodeKABUPATEN": 1606,
        "namaKECAMATAN": "BATANGHARI LEKO"
      },
      {
        "kodeKECAMATAN": 1606022,
        "kodeKABUPATEN": 1606,
        "namaKECAMATAN": "PLAKAT TINGGI"
      },
      {
        "kodeKECAMATAN": 1606023,
        "kodeKABUPATEN": 1606,
        "namaKECAMATAN": "LAWANG WETAN"
      },
      {
        "kodeKECAMATAN": 1606030,
        "kodeKABUPATEN": 1606,
        "namaKECAMATAN": "SUNGAI KERUH"
      },
      {
        "kodeKECAMATAN": 1606040,
        "kodeKABUPATEN": 1606,
        "namaKECAMATAN": "SEKAYU"
      },
      {
        "kodeKECAMATAN": 1606041,
        "kodeKABUPATEN": 1606,
        "namaKECAMATAN": "LAIS"
      },
      {
        "kodeKECAMATAN": 1606090,
        "kodeKABUPATEN": 1606,
        "namaKECAMATAN": "SUNGAI LILIN"
      },
      {
        "kodeKECAMATAN": 1606091,
        "kodeKABUPATEN": 1606,
        "namaKECAMATAN": "KELUANG"
      },
      {
        "kodeKECAMATAN": 1606092,
        "kodeKABUPATEN": 1606,
        "namaKECAMATAN": "BABAT SUPAT"
      },
      {
        "kodeKECAMATAN": 1606100,
        "kodeKABUPATEN": 1606,
        "namaKECAMATAN": "BAYUNG LENCIR"
      },
      {
        "kodeKECAMATAN": 1606101,
        "kodeKABUPATEN": 1606,
        "namaKECAMATAN": "LALAN"
      },
      {
        "kodeKECAMATAN": 1606102,
        "kodeKABUPATEN": 1606,
        "namaKECAMATAN": "TUNGKAL JAYA"
      },
      {
        "kodeKECAMATAN": 1607010,
        "kodeKABUPATEN": 1607,
        "namaKECAMATAN": "RANTAU BAYUR"
      },
      {
        "kodeKECAMATAN": 1607020,
        "kodeKABUPATEN": 1607,
        "namaKECAMATAN": "BETUNG"
      },
      {
        "kodeKECAMATAN": 1607021,
        "kodeKABUPATEN": 1607,
        "namaKECAMATAN": "SUAK TAPEH"
      },
      {
        "kodeKECAMATAN": 1607030,
        "kodeKABUPATEN": 1607,
        "namaKECAMATAN": "PULAU RIMAU"
      },
      {
        "kodeKECAMATAN": 1607031,
        "kodeKABUPATEN": 1607,
        "namaKECAMATAN": "TUNGKAL ILIR"
      },
      {
        "kodeKECAMATAN": 1607040,
        "kodeKABUPATEN": 1607,
        "namaKECAMATAN": "BANYUASIN III"
      },
      {
        "kodeKECAMATAN": 1607041,
        "kodeKABUPATEN": 1607,
        "namaKECAMATAN": "SEMBAWA"
      },
      {
        "kodeKECAMATAN": 1607050,
        "kodeKABUPATEN": 1607,
        "namaKECAMATAN": "TALANG KELAPA"
      },
      {
        "kodeKECAMATAN": 1607051,
        "kodeKABUPATEN": 1607,
        "namaKECAMATAN": "TANJUNG LAGO"
      },
      {
        "kodeKECAMATAN": 1607060,
        "kodeKABUPATEN": 1607,
        "namaKECAMATAN": "BANYUASIN I"
      },
      {
        "kodeKECAMATAN": 1607061,
        "kodeKABUPATEN": 1607,
        "namaKECAMATAN": "AIR KUMBANG"
      },
      {
        "kodeKECAMATAN": 1607070,
        "kodeKABUPATEN": 1607,
        "namaKECAMATAN": "RAMBUTAN"
      },
      {
        "kodeKECAMATAN": 1607080,
        "kodeKABUPATEN": 1607,
        "namaKECAMATAN": "MUARA PADANG"
      },
      {
        "kodeKECAMATAN": 1607081,
        "kodeKABUPATEN": 1607,
        "namaKECAMATAN": "MUARA SUGIHAN"
      },
      {
        "kodeKECAMATAN": 1607090,
        "kodeKABUPATEN": 1607,
        "namaKECAMATAN": "MAKARTI JAYA"
      },
      {
        "kodeKECAMATAN": 1607091,
        "kodeKABUPATEN": 1607,
        "namaKECAMATAN": "AIR SALEH"
      },
      {
        "kodeKECAMATAN": 1607100,
        "kodeKABUPATEN": 1607,
        "namaKECAMATAN": "BANYUASIN II"
      },
      {
        "kodeKECAMATAN": 1607110,
        "kodeKABUPATEN": 1607,
        "namaKECAMATAN": "MUARA TELANG"
      },
      {
        "kodeKECAMATAN": 1607111,
        "kodeKABUPATEN": 1607,
        "namaKECAMATAN": "SUMBER MARGA TELANG"
      },
      {
        "kodeKECAMATAN": 1608010,
        "kodeKABUPATEN": 1608,
        "namaKECAMATAN": "MEKAKAU ILIR"
      },
      {
        "kodeKECAMATAN": 1608020,
        "kodeKABUPATEN": 1608,
        "namaKECAMATAN": "BANDING AGUNG"
      },
      {
        "kodeKECAMATAN": 1608021,
        "kodeKABUPATEN": 1608,
        "namaKECAMATAN": "WARKUK RANAU SELATAN"
      },
      {
        "kodeKECAMATAN": 1608022,
        "kodeKABUPATEN": 1608,
        "namaKECAMATAN": "BUAY PEMATANG RIBU RANAU TENGAH"
      },
      {
        "kodeKECAMATAN": 1608030,
        "kodeKABUPATEN": 1608,
        "namaKECAMATAN": "BUAY PEMACA"
      },
      {
        "kodeKECAMATAN": 1608040,
        "kodeKABUPATEN": 1608,
        "namaKECAMATAN": "SIMPANG"
      },
      {
        "kodeKECAMATAN": 1608041,
        "kodeKABUPATEN": 1608,
        "namaKECAMATAN": "BUANA PEMACA"
      },
      {
        "kodeKECAMATAN": 1608050,
        "kodeKABUPATEN": 1608,
        "namaKECAMATAN": "MUARADUA"
      },
      {
        "kodeKECAMATAN": 1608051,
        "kodeKABUPATEN": 1608,
        "namaKECAMATAN": "BUAY RAWAN"
      },
      {
        "kodeKECAMATAN": 1608060,
        "kodeKABUPATEN": 1608,
        "namaKECAMATAN": "BUAY SANDANG AJI"
      },
      {
        "kodeKECAMATAN": 1608061,
        "kodeKABUPATEN": 1608,
        "namaKECAMATAN": "TIGA DIHAJI"
      },
      {
        "kodeKECAMATAN": 1608070,
        "kodeKABUPATEN": 1608,
        "namaKECAMATAN": "BUAY RUNJUNG"
      },
      {
        "kodeKECAMATAN": 1608071,
        "kodeKABUPATEN": 1608,
        "namaKECAMATAN": "RUNJUNG AGUNG"
      },
      {
        "kodeKECAMATAN": 1608080,
        "kodeKABUPATEN": 1608,
        "namaKECAMATAN": "KISAM TINGGI"
      },
      {
        "kodeKECAMATAN": 1608090,
        "kodeKABUPATEN": 1608,
        "namaKECAMATAN": "MUARADUA KISAM"
      },
      {
        "kodeKECAMATAN": 1608091,
        "kodeKABUPATEN": 1608,
        "namaKECAMATAN": "KISAM ILIR"
      },
      {
        "kodeKECAMATAN": 1608100,
        "kodeKABUPATEN": 1608,
        "namaKECAMATAN": "PULAU BERINGIN"
      },
      {
        "kodeKECAMATAN": 1608101,
        "kodeKABUPATEN": 1608,
        "namaKECAMATAN": "SINDANG DANAU"
      },
      {
        "kodeKECAMATAN": 1608102,
        "kodeKABUPATEN": 1608,
        "namaKECAMATAN": "SUNGAI ARE"
      },
      {
        "kodeKECAMATAN": 1609010,
        "kodeKABUPATEN": 1609,
        "namaKECAMATAN": "MARTAPURA"
      },
      {
        "kodeKECAMATAN": 1609011,
        "kodeKABUPATEN": 1609,
        "namaKECAMATAN": "BUNGA MAYANG"
      },
      {
        "kodeKECAMATAN": 1609012,
        "kodeKABUPATEN": 1609,
        "namaKECAMATAN": "JAYA PURA"
      },
      {
        "kodeKECAMATAN": 1609020,
        "kodeKABUPATEN": 1609,
        "namaKECAMATAN": "BUAY PEMUKA PELIUNG"
      },
      {
        "kodeKECAMATAN": 1609030,
        "kodeKABUPATEN": 1609,
        "namaKECAMATAN": "BUAY MADANG"
      },
      {
        "kodeKECAMATAN": 1609031,
        "kodeKABUPATEN": 1609,
        "namaKECAMATAN": "BUAY MADANG TIMUR"
      },
      {
        "kodeKECAMATAN": 1609032,
        "kodeKABUPATEN": 1609,
        "namaKECAMATAN": "BUAY PEMUKA BANGSA RAJA"
      },
      {
        "kodeKECAMATAN": 1609040,
        "kodeKABUPATEN": 1609,
        "namaKECAMATAN": "MADANG SUKU II"
      },
      {
        "kodeKECAMATAN": 1609041,
        "kodeKABUPATEN": 1609,
        "namaKECAMATAN": "MADANG SUKU III"
      },
      {
        "kodeKECAMATAN": 1609050,
        "kodeKABUPATEN": 1609,
        "namaKECAMATAN": "MADANG SUKU I"
      },
      {
        "kodeKECAMATAN": 1609051,
        "kodeKABUPATEN": 1609,
        "namaKECAMATAN": "BELITANG MADANG RAYA"
      },
      {
        "kodeKECAMATAN": 1609060,
        "kodeKABUPATEN": 1609,
        "namaKECAMATAN": "BELITANG"
      },
      {
        "kodeKECAMATAN": 1609061,
        "kodeKABUPATEN": 1609,
        "namaKECAMATAN": "BELITANG JAYA"
      },
      {
        "kodeKECAMATAN": 1609070,
        "kodeKABUPATEN": 1609,
        "namaKECAMATAN": "BELITANG III"
      },
      {
        "kodeKECAMATAN": 1609080,
        "kodeKABUPATEN": 1609,
        "namaKECAMATAN": "BELITANG II"
      },
      {
        "kodeKECAMATAN": 1609081,
        "kodeKABUPATEN": 1609,
        "namaKECAMATAN": "BELITANG MULYA"
      },
      {
        "kodeKECAMATAN": 1609090,
        "kodeKABUPATEN": 1609,
        "namaKECAMATAN": "SEMENDAWAI SUKU III"
      },
      {
        "kodeKECAMATAN": 1609091,
        "kodeKABUPATEN": 1609,
        "namaKECAMATAN": "SEMENDAWAI TIMUR"
      },
      {
        "kodeKECAMATAN": 1609100,
        "kodeKABUPATEN": 1609,
        "namaKECAMATAN": "CEMPAKA"
      },
      {
        "kodeKECAMATAN": 1609101,
        "kodeKABUPATEN": 1609,
        "namaKECAMATAN": "SEMENDAWAI BARAT"
      },
      {
        "kodeKECAMATAN": 1610010,
        "kodeKABUPATEN": 1610,
        "namaKECAMATAN": "MUARA KUANG"
      },
      {
        "kodeKECAMATAN": 1610011,
        "kodeKABUPATEN": 1610,
        "namaKECAMATAN": "RAMBANG KUANG"
      },
      {
        "kodeKECAMATAN": 1610012,
        "kodeKABUPATEN": 1610,
        "namaKECAMATAN": "LUBUK KELIAT"
      },
      {
        "kodeKECAMATAN": 1610020,
        "kodeKABUPATEN": 1610,
        "namaKECAMATAN": "TANJUNG BATU"
      },
      {
        "kodeKECAMATAN": 1610021,
        "kodeKABUPATEN": 1610,
        "namaKECAMATAN": "PAYARAMAN"
      },
      {
        "kodeKECAMATAN": 1610030,
        "kodeKABUPATEN": 1610,
        "namaKECAMATAN": "RANTAU ALAI"
      },
      {
        "kodeKECAMATAN": 1610031,
        "kodeKABUPATEN": 1610,
        "namaKECAMATAN": "KANDIS"
      },
      {
        "kodeKECAMATAN": 1610040,
        "kodeKABUPATEN": 1610,
        "namaKECAMATAN": "TANJUNG RAJA"
      },
      {
        "kodeKECAMATAN": 1610041,
        "kodeKABUPATEN": 1610,
        "namaKECAMATAN": "RANTAU PANJANG"
      },
      {
        "kodeKECAMATAN": 1610042,
        "kodeKABUPATEN": 1610,
        "namaKECAMATAN": "SUNGAI PINANG"
      },
      {
        "kodeKECAMATAN": 1610050,
        "kodeKABUPATEN": 1610,
        "namaKECAMATAN": "PEMULUTAN"
      },
      {
        "kodeKECAMATAN": 1610051,
        "kodeKABUPATEN": 1610,
        "namaKECAMATAN": "PEMULUTAN SELATAN"
      },
      {
        "kodeKECAMATAN": 1610052,
        "kodeKABUPATEN": 1610,
        "namaKECAMATAN": "PEMULUTAN BARAT"
      },
      {
        "kodeKECAMATAN": 1610060,
        "kodeKABUPATEN": 1610,
        "namaKECAMATAN": "INDRALAYA"
      },
      {
        "kodeKECAMATAN": 1610061,
        "kodeKABUPATEN": 1610,
        "namaKECAMATAN": "INDRALAYA UTARA"
      },
      {
        "kodeKECAMATAN": 1610062,
        "kodeKABUPATEN": 1610,
        "namaKECAMATAN": "INDRALAYA SELATAN"
      },
      {
        "kodeKECAMATAN": 1611010,
        "kodeKABUPATEN": 1611,
        "namaKECAMATAN": "MUARA PINANG"
      },
      {
        "kodeKECAMATAN": 1611020,
        "kodeKABUPATEN": 1611,
        "namaKECAMATAN": "LINTANG KANAN"
      },
      {
        "kodeKECAMATAN": 1611030,
        "kodeKABUPATEN": 1611,
        "namaKECAMATAN": "PENDOPO"
      },
      {
        "kodeKECAMATAN": 1611031,
        "kodeKABUPATEN": 1611,
        "namaKECAMATAN": "PENDOPO BARAT"
      },
      {
        "kodeKECAMATAN": 1611040,
        "kodeKABUPATEN": 1611,
        "namaKECAMATAN": "PASEMAH AIR KERUH"
      },
      {
        "kodeKECAMATAN": 1611050,
        "kodeKABUPATEN": 1611,
        "namaKECAMATAN": "ULU MUSI"
      },
      {
        "kodeKECAMATAN": 1611051,
        "kodeKABUPATEN": 1611,
        "namaKECAMATAN": "SIKAP DALAM"
      },
      {
        "kodeKECAMATAN": 1611060,
        "kodeKABUPATEN": 1611,
        "namaKECAMATAN": "TALANG PADANG"
      },
      {
        "kodeKECAMATAN": 1611070,
        "kodeKABUPATEN": 1611,
        "namaKECAMATAN": "TEBING TINGGI"
      },
      {
        "kodeKECAMATAN": 1611071,
        "kodeKABUPATEN": 1611,
        "namaKECAMATAN": "SALING"
      },
      {
        "kodeKECAMATAN": 1612010,
        "kodeKABUPATEN": 1612,
        "namaKECAMATAN": "TALANG UBI"
      },
      {
        "kodeKECAMATAN": 1612020,
        "kodeKABUPATEN": 1612,
        "namaKECAMATAN": "TANAH ABANG"
      },
      {
        "kodeKECAMATAN": 1612030,
        "kodeKABUPATEN": 1612,
        "namaKECAMATAN": "ABAB"
      },
      {
        "kodeKECAMATAN": 1612040,
        "kodeKABUPATEN": 1612,
        "namaKECAMATAN": "PENUKAL"
      },
      {
        "kodeKECAMATAN": 1612050,
        "kodeKABUPATEN": 1612,
        "namaKECAMATAN": "PENUKAL UTARA"
      },
      {
        "kodeKECAMATAN": 1613010,
        "kodeKABUPATEN": 1613,
        "namaKECAMATAN": "ULU RAWAS"
      },
      {
        "kodeKECAMATAN": 1613020,
        "kodeKABUPATEN": 1613,
        "namaKECAMATAN": "KARANG JAYA"
      },
      {
        "kodeKECAMATAN": 1613030,
        "kodeKABUPATEN": 1613,
        "namaKECAMATAN": "RAWAS ULU"
      },
      {
        "kodeKECAMATAN": 1613040,
        "kodeKABUPATEN": 1613,
        "namaKECAMATAN": "RUPIT"
      },
      {
        "kodeKECAMATAN": 1613050,
        "kodeKABUPATEN": 1613,
        "namaKECAMATAN": "KARANG DAPO"
      },
      {
        "kodeKECAMATAN": 1613060,
        "kodeKABUPATEN": 1613,
        "namaKECAMATAN": "RAWAS ILIR"
      },
      {
        "kodeKECAMATAN": 1613070,
        "kodeKABUPATEN": 1613,
        "namaKECAMATAN": "NIBUNG"
      },
      {
        "kodeKECAMATAN": 1671010,
        "kodeKABUPATEN": 1671,
        "namaKECAMATAN": "ILIR BARAT II"
      },
      {
        "kodeKECAMATAN": 1671011,
        "kodeKABUPATEN": 1671,
        "namaKECAMATAN": "GANDUS"
      },
      {
        "kodeKECAMATAN": 1671020,
        "kodeKABUPATEN": 1671,
        "namaKECAMATAN": "SEBERANG ULU I"
      },
      {
        "kodeKECAMATAN": 1671021,
        "kodeKABUPATEN": 1671,
        "namaKECAMATAN": "KERTAPATI"
      },
      {
        "kodeKECAMATAN": 1671030,
        "kodeKABUPATEN": 1671,
        "namaKECAMATAN": "SEBERANG ULU II"
      },
      {
        "kodeKECAMATAN": 1671031,
        "kodeKABUPATEN": 1671,
        "namaKECAMATAN": "PLAJU"
      },
      {
        "kodeKECAMATAN": 1671040,
        "kodeKABUPATEN": 1671,
        "namaKECAMATAN": "ILIR BARAT I"
      },
      {
        "kodeKECAMATAN": 1671041,
        "kodeKABUPATEN": 1671,
        "namaKECAMATAN": "BUKIT KECIL"
      },
      {
        "kodeKECAMATAN": 1671050,
        "kodeKABUPATEN": 1671,
        "namaKECAMATAN": "ILIR TIMUR I"
      },
      {
        "kodeKECAMATAN": 1671051,
        "kodeKABUPATEN": 1671,
        "namaKECAMATAN": "KEMUNING"
      },
      {
        "kodeKECAMATAN": 1671060,
        "kodeKABUPATEN": 1671,
        "namaKECAMATAN": "ILIR TIMUR II"
      },
      {
        "kodeKECAMATAN": 1671061,
        "kodeKABUPATEN": 1671,
        "namaKECAMATAN": "KALIDONI"
      },
      {
        "kodeKECAMATAN": 1671070,
        "kodeKABUPATEN": 1671,
        "namaKECAMATAN": "SAKO"
      },
      {
        "kodeKECAMATAN": 1671071,
        "kodeKABUPATEN": 1671,
        "namaKECAMATAN": "SEMATANG BORANG"
      },
      {
        "kodeKECAMATAN": 1671080,
        "kodeKABUPATEN": 1671,
        "namaKECAMATAN": "SUKARAMI"
      },
      {
        "kodeKECAMATAN": 1671081,
        "kodeKABUPATEN": 1671,
        "namaKECAMATAN": "ALANG ALANG LEBAR"
      },
      {
        "kodeKECAMATAN": 1672010,
        "kodeKABUPATEN": 1672,
        "namaKECAMATAN": "RAMBANG KAPAK TENGAH"
      },
      {
        "kodeKECAMATAN": 1672020,
        "kodeKABUPATEN": 1672,
        "namaKECAMATAN": "PRABUMULIH TIMUR"
      },
      {
        "kodeKECAMATAN": 1672021,
        "kodeKABUPATEN": 1672,
        "namaKECAMATAN": "PRABUMULIH SELATAN"
      },
      {
        "kodeKECAMATAN": 1672030,
        "kodeKABUPATEN": 1672,
        "namaKECAMATAN": "PRABUMULIH BARAT"
      },
      {
        "kodeKECAMATAN": 1672031,
        "kodeKABUPATEN": 1672,
        "namaKECAMATAN": "PRABUMULIH UTARA"
      },
      {
        "kodeKECAMATAN": 1672040,
        "kodeKABUPATEN": 1672,
        "namaKECAMATAN": "CAMBAI"
      },
      {
        "kodeKECAMATAN": 1673010,
        "kodeKABUPATEN": 1673,
        "namaKECAMATAN": "DEMPO SELATAN"
      },
      {
        "kodeKECAMATAN": 1673011,
        "kodeKABUPATEN": 1673,
        "namaKECAMATAN": "DEMPO TENGAH"
      },
      {
        "kodeKECAMATAN": 1673020,
        "kodeKABUPATEN": 1673,
        "namaKECAMATAN": "DEMPO UTARA"
      },
      {
        "kodeKECAMATAN": 1673030,
        "kodeKABUPATEN": 1673,
        "namaKECAMATAN": "PAGAR ALAM SELATAN"
      },
      {
        "kodeKECAMATAN": 1673040,
        "kodeKABUPATEN": 1673,
        "namaKECAMATAN": "PAGAR ALAM UTARA"
      },
      {
        "kodeKECAMATAN": 1674011,
        "kodeKABUPATEN": 1674,
        "namaKECAMATAN": "LUBUK LINGGAU BARAT I"
      },
      {
        "kodeKECAMATAN": 1674012,
        "kodeKABUPATEN": 1674,
        "namaKECAMATAN": "LUBUK LINGGAU BARAT II"
      },
      {
        "kodeKECAMATAN": 1674021,
        "kodeKABUPATEN": 1674,
        "namaKECAMATAN": "LUBUK LINGGAU SELATAN I"
      },
      {
        "kodeKECAMATAN": 1674022,
        "kodeKABUPATEN": 1674,
        "namaKECAMATAN": "LUBUK LINGGAU SELATAN II"
      },
      {
        "kodeKECAMATAN": 1674031,
        "kodeKABUPATEN": 1674,
        "namaKECAMATAN": "LUBUK LINGGAU TIMUR I"
      },
      {
        "kodeKECAMATAN": 1674032,
        "kodeKABUPATEN": 1674,
        "namaKECAMATAN": "LUBUK LINGGAU TIMUR II"
      },
      {
        "kodeKECAMATAN": 1674041,
        "kodeKABUPATEN": 1674,
        "namaKECAMATAN": "LUBUK LINGGAU UTARA I"
      },
      {
        "kodeKECAMATAN": 1674042,
        "kodeKABUPATEN": 1674,
        "namaKECAMATAN": "LUBUK LINGGAU UTARA II"
      },
      {
        "kodeKECAMATAN": 1701040,
        "kodeKABUPATEN": 1701,
        "namaKECAMATAN": "MANNA"
      },
      {
        "kodeKECAMATAN": 1701041,
        "kodeKABUPATEN": 1701,
        "namaKECAMATAN": "KOTA MANNA"
      },
      {
        "kodeKECAMATAN": 1701042,
        "kodeKABUPATEN": 1701,
        "namaKECAMATAN": "KEDURANG"
      },
      {
        "kodeKECAMATAN": 1701043,
        "kodeKABUPATEN": 1701,
        "namaKECAMATAN": "BUNGA MAS"
      },
      {
        "kodeKECAMATAN": 1701044,
        "kodeKABUPATEN": 1701,
        "namaKECAMATAN": "PASAR MANNA"
      },
      {
        "kodeKECAMATAN": 1701045,
        "kodeKABUPATEN": 1701,
        "namaKECAMATAN": "KEDURANG ILIR"
      },
      {
        "kodeKECAMATAN": 1701050,
        "kodeKABUPATEN": 1701,
        "namaKECAMATAN": "SEGINIM"
      },
      {
        "kodeKECAMATAN": 1701051,
        "kodeKABUPATEN": 1701,
        "namaKECAMATAN": "AIR NIPIS"
      },
      {
        "kodeKECAMATAN": 1701060,
        "kodeKABUPATEN": 1701,
        "namaKECAMATAN": "PINO"
      },
      {
        "kodeKECAMATAN": 1701061,
        "kodeKABUPATEN": 1701,
        "namaKECAMATAN": "PINORAYA"
      },
      {
        "kodeKECAMATAN": 1701062,
        "kodeKABUPATEN": 1701,
        "namaKECAMATAN": "ULU MANNA"
      },
      {
        "kodeKECAMATAN": 1702020,
        "kodeKABUPATEN": 1702,
        "namaKECAMATAN": "KOTA PADANG"
      },
      {
        "kodeKECAMATAN": 1702021,
        "kodeKABUPATEN": 1702,
        "namaKECAMATAN": "SINDANG BELITI ILIR"
      },
      {
        "kodeKECAMATAN": 1702030,
        "kodeKABUPATEN": 1702,
        "namaKECAMATAN": "PADANG ULAK TANDING"
      },
      {
        "kodeKECAMATAN": 1702031,
        "kodeKABUPATEN": 1702,
        "namaKECAMATAN": "SINDANG KELINGI"
      },
      {
        "kodeKECAMATAN": 1702032,
        "kodeKABUPATEN": 1702,
        "namaKECAMATAN": "BINDU RIANG"
      },
      {
        "kodeKECAMATAN": 1702033,
        "kodeKABUPATEN": 1702,
        "namaKECAMATAN": "SINDANG BELITI ULU"
      },
      {
        "kodeKECAMATAN": 1702034,
        "kodeKABUPATEN": 1702,
        "namaKECAMATAN": "SINDANG DATARAN"
      },
      {
        "kodeKECAMATAN": 1702040,
        "kodeKABUPATEN": 1702,
        "namaKECAMATAN": "CURUP"
      },
      {
        "kodeKECAMATAN": 1702041,
        "kodeKABUPATEN": 1702,
        "namaKECAMATAN": "BERMANI ULU"
      },
      {
        "kodeKECAMATAN": 1702042,
        "kodeKABUPATEN": 1702,
        "namaKECAMATAN": "SELUPU REJANG"
      },
      {
        "kodeKECAMATAN": 1702043,
        "kodeKABUPATEN": 1702,
        "namaKECAMATAN": "CURUP SELATAN"
      },
      {
        "kodeKECAMATAN": 1702044,
        "kodeKABUPATEN": 1702,
        "namaKECAMATAN": "CURUP TENGAH"
      },
      {
        "kodeKECAMATAN": 1702045,
        "kodeKABUPATEN": 1702,
        "namaKECAMATAN": "BERMANI ULU RAYA"
      },
      {
        "kodeKECAMATAN": 1702046,
        "kodeKABUPATEN": 1702,
        "namaKECAMATAN": "CURUP UTARA"
      },
      {
        "kodeKECAMATAN": 1702047,
        "kodeKABUPATEN": 1702,
        "namaKECAMATAN": "CURUP TIMUR"
      },
      {
        "kodeKECAMATAN": 1703010,
        "kodeKABUPATEN": 1703,
        "namaKECAMATAN": "ENGGANO"
      },
      {
        "kodeKECAMATAN": 1703050,
        "kodeKABUPATEN": 1703,
        "namaKECAMATAN": "KERKAP"
      },
      {
        "kodeKECAMATAN": 1703051,
        "kodeKABUPATEN": 1703,
        "namaKECAMATAN": "AIR NAPAL"
      },
      {
        "kodeKECAMATAN": 1703052,
        "kodeKABUPATEN": 1703,
        "namaKECAMATAN": "AIR BESI"
      },
      {
        "kodeKECAMATAN": 1703053,
        "kodeKABUPATEN": 1703,
        "namaKECAMATAN": "HULU PALIK"
      },
      {
        "kodeKECAMATAN": 1703054,
        "kodeKABUPATEN": 1703,
        "namaKECAMATAN": "TANJUNG AGUNG PALIK"
      },
      {
        "kodeKECAMATAN": 1703060,
        "kodeKABUPATEN": 1703,
        "namaKECAMATAN": "ARGA MAKMUR"
      },
      {
        "kodeKECAMATAN": 1703061,
        "kodeKABUPATEN": 1703,
        "namaKECAMATAN": "ARMA JAYA"
      },
      {
        "kodeKECAMATAN": 1703070,
        "kodeKABUPATEN": 1703,
        "namaKECAMATAN": "LAIS"
      },
      {
        "kodeKECAMATAN": 1703071,
        "kodeKABUPATEN": 1703,
        "namaKECAMATAN": "BATIK NAU"
      },
      {
        "kodeKECAMATAN": 1703072,
        "kodeKABUPATEN": 1703,
        "namaKECAMATAN": "GIRI MULYA"
      },
      {
        "kodeKECAMATAN": 1703073,
        "kodeKABUPATEN": 1703,
        "namaKECAMATAN": "AIR PADANG"
      },
      {
        "kodeKECAMATAN": 1703080,
        "kodeKABUPATEN": 1703,
        "namaKECAMATAN": "PADANG JAYA"
      },
      {
        "kodeKECAMATAN": 1703090,
        "kodeKABUPATEN": 1703,
        "namaKECAMATAN": "KETAHUN"
      },
      {
        "kodeKECAMATAN": 1703091,
        "kodeKABUPATEN": 1703,
        "namaKECAMATAN": "NAPAL PUTIH"
      },
      {
        "kodeKECAMATAN": 1703092,
        "kodeKABUPATEN": 1703,
        "namaKECAMATAN": "ULOK KUPAI"
      },
      {
        "kodeKECAMATAN": 1703093,
        "kodeKABUPATEN": 1703,
        "namaKECAMATAN": "PINANG RAYA"
      },
      {
        "kodeKECAMATAN": 1703100,
        "kodeKABUPATEN": 1703,
        "namaKECAMATAN": "PUTRI HIJAU"
      },
      {
        "kodeKECAMATAN": 1703101,
        "kodeKABUPATEN": 1703,
        "namaKECAMATAN": "MARGA SAKTI SEBELAT"
      },
      {
        "kodeKECAMATAN": 1704010,
        "kodeKABUPATEN": 1704,
        "namaKECAMATAN": "NASAL"
      },
      {
        "kodeKECAMATAN": 1704020,
        "kodeKABUPATEN": 1704,
        "namaKECAMATAN": "MAJE"
      },
      {
        "kodeKECAMATAN": 1704030,
        "kodeKABUPATEN": 1704,
        "namaKECAMATAN": "KAUR SELATAN"
      },
      {
        "kodeKECAMATAN": 1704031,
        "kodeKABUPATEN": 1704,
        "namaKECAMATAN": "TETAP"
      },
      {
        "kodeKECAMATAN": 1704040,
        "kodeKABUPATEN": 1704,
        "namaKECAMATAN": "KAUR TENGAH"
      },
      {
        "kodeKECAMATAN": 1704041,
        "kodeKABUPATEN": 1704,
        "namaKECAMATAN": "LUAS"
      },
      {
        "kodeKECAMATAN": 1704042,
        "kodeKABUPATEN": 1704,
        "namaKECAMATAN": "MUARA SAHUNG"
      },
      {
        "kodeKECAMATAN": 1704050,
        "kodeKABUPATEN": 1704,
        "namaKECAMATAN": "KINAL"
      },
      {
        "kodeKECAMATAN": 1704051,
        "kodeKABUPATEN": 1704,
        "namaKECAMATAN": "SEMIDANG GUMAY"
      },
      {
        "kodeKECAMATAN": 1704060,
        "kodeKABUPATEN": 1704,
        "namaKECAMATAN": "TANJUNG KEMUNING"
      },
      {
        "kodeKECAMATAN": 1704061,
        "kodeKABUPATEN": 1704,
        "namaKECAMATAN": "KELAM TENGAH"
      },
      {
        "kodeKECAMATAN": 1704070,
        "kodeKABUPATEN": 1704,
        "namaKECAMATAN": "KAUR UTARA"
      },
      {
        "kodeKECAMATAN": 1704071,
        "kodeKABUPATEN": 1704,
        "namaKECAMATAN": "PADANG GUCI HILIR"
      },
      {
        "kodeKECAMATAN": 1704072,
        "kodeKABUPATEN": 1704,
        "namaKECAMATAN": "LUNGKANG KULE"
      },
      {
        "kodeKECAMATAN": 1704073,
        "kodeKABUPATEN": 1704,
        "namaKECAMATAN": "PADANG GUCI HULU"
      },
      {
        "kodeKECAMATAN": 1705010,
        "kodeKABUPATEN": 1705,
        "namaKECAMATAN": "SEMIDANG ALAS MARAS"
      },
      {
        "kodeKECAMATAN": 1705020,
        "kodeKABUPATEN": 1705,
        "namaKECAMATAN": "SEMIDANG ALAS"
      },
      {
        "kodeKECAMATAN": 1705030,
        "kodeKABUPATEN": 1705,
        "namaKECAMATAN": "TALO"
      },
      {
        "kodeKECAMATAN": 1705031,
        "kodeKABUPATEN": 1705,
        "namaKECAMATAN": "ILIR TALO"
      },
      {
        "kodeKECAMATAN": 1705032,
        "kodeKABUPATEN": 1705,
        "namaKECAMATAN": "TALO KECIL"
      },
      {
        "kodeKECAMATAN": 1705033,
        "kodeKABUPATEN": 1705,
        "namaKECAMATAN": "ULU TALO"
      },
      {
        "kodeKECAMATAN": 1705040,
        "kodeKABUPATEN": 1705,
        "namaKECAMATAN": "SELUMA"
      },
      {
        "kodeKECAMATAN": 1705041,
        "kodeKABUPATEN": 1705,
        "namaKECAMATAN": "SELUMA SELATAN"
      },
      {
        "kodeKECAMATAN": 1705042,
        "kodeKABUPATEN": 1705,
        "namaKECAMATAN": "SELUMA BARAT"
      },
      {
        "kodeKECAMATAN": 1705043,
        "kodeKABUPATEN": 1705,
        "namaKECAMATAN": "SELUMA TIMUR"
      },
      {
        "kodeKECAMATAN": 1705044,
        "kodeKABUPATEN": 1705,
        "namaKECAMATAN": "SELUMA UTARA"
      },
      {
        "kodeKECAMATAN": 1705050,
        "kodeKABUPATEN": 1705,
        "namaKECAMATAN": "SUKARAJA"
      },
      {
        "kodeKECAMATAN": 1705051,
        "kodeKABUPATEN": 1705,
        "namaKECAMATAN": "AIR PERIUKAN"
      },
      {
        "kodeKECAMATAN": 1705052,
        "kodeKABUPATEN": 1705,
        "namaKECAMATAN": "LUBUK SANDI"
      },
      {
        "kodeKECAMATAN": 1706010,
        "kodeKABUPATEN": 1706,
        "namaKECAMATAN": "IPUH"
      },
      {
        "kodeKECAMATAN": 1706011,
        "kodeKABUPATEN": 1706,
        "namaKECAMATAN": "AIR RAMI"
      },
      {
        "kodeKECAMATAN": 1706012,
        "kodeKABUPATEN": 1706,
        "namaKECAMATAN": "MALIN DEMAN"
      },
      {
        "kodeKECAMATAN": 1706020,
        "kodeKABUPATEN": 1706,
        "namaKECAMATAN": "PONDOK SUGUH"
      },
      {
        "kodeKECAMATAN": 1706021,
        "kodeKABUPATEN": 1706,
        "namaKECAMATAN": "SUNGAI RUMBAI"
      },
      {
        "kodeKECAMATAN": 1706022,
        "kodeKABUPATEN": 1706,
        "namaKECAMATAN": "TERAMANG JAYA"
      },
      {
        "kodeKECAMATAN": 1706030,
        "kodeKABUPATEN": 1706,
        "namaKECAMATAN": "TERAS TERUNJAM"
      },
      {
        "kodeKECAMATAN": 1706031,
        "kodeKABUPATEN": 1706,
        "namaKECAMATAN": "PENARIK"
      },
      {
        "kodeKECAMATAN": 1706032,
        "kodeKABUPATEN": 1706,
        "namaKECAMATAN": "SELAGAN RAYA"
      },
      {
        "kodeKECAMATAN": 1706040,
        "kodeKABUPATEN": 1706,
        "namaKECAMATAN": "KOTA MUKOMUKO"
      },
      {
        "kodeKECAMATAN": 1706041,
        "kodeKABUPATEN": 1706,
        "namaKECAMATAN": "AIR DIKIT"
      },
      {
        "kodeKECAMATAN": 1706042,
        "kodeKABUPATEN": 1706,
        "namaKECAMATAN": "XIV KOTO"
      },
      {
        "kodeKECAMATAN": 1706050,
        "kodeKABUPATEN": 1706,
        "namaKECAMATAN": "LUBUK PINANG"
      },
      {
        "kodeKECAMATAN": 1706051,
        "kodeKABUPATEN": 1706,
        "namaKECAMATAN": "AIR MANJUNTO"
      },
      {
        "kodeKECAMATAN": 1706052,
        "kodeKABUPATEN": 1706,
        "namaKECAMATAN": "V KOTO"
      },
      {
        "kodeKECAMATAN": 1707010,
        "kodeKABUPATEN": 1707,
        "namaKECAMATAN": "RIMBO PENGADANG"
      },
      {
        "kodeKECAMATAN": 1707011,
        "kodeKABUPATEN": 1707,
        "namaKECAMATAN": "TOPOS"
      },
      {
        "kodeKECAMATAN": 1707020,
        "kodeKABUPATEN": 1707,
        "namaKECAMATAN": "LEBONG SELATAN"
      },
      {
        "kodeKECAMATAN": 1707021,
        "kodeKABUPATEN": 1707,
        "namaKECAMATAN": "BINGIN KUNING"
      },
      {
        "kodeKECAMATAN": 1707030,
        "kodeKABUPATEN": 1707,
        "namaKECAMATAN": "LEBONG TENGAH"
      },
      {
        "kodeKECAMATAN": 1707031,
        "kodeKABUPATEN": 1707,
        "namaKECAMATAN": "LEBONG SAKTI"
      },
      {
        "kodeKECAMATAN": 1707040,
        "kodeKABUPATEN": 1707,
        "namaKECAMATAN": "LEBONG ATAS"
      },
      {
        "kodeKECAMATAN": 1707041,
        "kodeKABUPATEN": 1707,
        "namaKECAMATAN": "PADANG BANO"
      },
      {
        "kodeKECAMATAN": 1707042,
        "kodeKABUPATEN": 1707,
        "namaKECAMATAN": "PELABAI"
      },
      {
        "kodeKECAMATAN": 1707050,
        "kodeKABUPATEN": 1707,
        "namaKECAMATAN": "LEBONG UTARA"
      },
      {
        "kodeKECAMATAN": 1707051,
        "kodeKABUPATEN": 1707,
        "namaKECAMATAN": "AMEN"
      },
      {
        "kodeKECAMATAN": 1707052,
        "kodeKABUPATEN": 1707,
        "namaKECAMATAN": "URAM JAYA"
      },
      {
        "kodeKECAMATAN": 1707053,
        "kodeKABUPATEN": 1707,
        "namaKECAMATAN": "PINANG BELAPIS"
      },
      {
        "kodeKECAMATAN": 1708010,
        "kodeKABUPATEN": 1708,
        "namaKECAMATAN": "MUARA KEMUMU"
      },
      {
        "kodeKECAMATAN": 1708020,
        "kodeKABUPATEN": 1708,
        "namaKECAMATAN": "BERMANI ILIR"
      },
      {
        "kodeKECAMATAN": 1708030,
        "kodeKABUPATEN": 1708,
        "namaKECAMATAN": "SEBERANG MUSI"
      },
      {
        "kodeKECAMATAN": 1708040,
        "kodeKABUPATEN": 1708,
        "namaKECAMATAN": "TEBAT KARAI"
      },
      {
        "kodeKECAMATAN": 1708050,
        "kodeKABUPATEN": 1708,
        "namaKECAMATAN": "KEPAHIANG"
      },
      {
        "kodeKECAMATAN": 1708060,
        "kodeKABUPATEN": 1708,
        "namaKECAMATAN": "KABA WETAN"
      },
      {
        "kodeKECAMATAN": 1708070,
        "kodeKABUPATEN": 1708,
        "namaKECAMATAN": "UJAN MAS"
      },
      {
        "kodeKECAMATAN": 1708080,
        "kodeKABUPATEN": 1708,
        "namaKECAMATAN": "MERIGI"
      },
      {
        "kodeKECAMATAN": 1709010,
        "kodeKABUPATEN": 1709,
        "namaKECAMATAN": "TALANG EMPAT"
      },
      {
        "kodeKECAMATAN": 1709020,
        "kodeKABUPATEN": 1709,
        "namaKECAMATAN": "KARANG TINGGI"
      },
      {
        "kodeKECAMATAN": 1709030,
        "kodeKABUPATEN": 1709,
        "namaKECAMATAN": "TABA PENANJUNG"
      },
      {
        "kodeKECAMATAN": 1709031,
        "kodeKABUPATEN": 1709,
        "namaKECAMATAN": "MERIGI KELINDANG"
      },
      {
        "kodeKECAMATAN": 1709040,
        "kodeKABUPATEN": 1709,
        "namaKECAMATAN": "PAGAR JATI"
      },
      {
        "kodeKECAMATAN": 1709041,
        "kodeKABUPATEN": 1709,
        "namaKECAMATAN": "MERIGI SAKTI"
      },
      {
        "kodeKECAMATAN": 1709050,
        "kodeKABUPATEN": 1709,
        "namaKECAMATAN": "PONDOK KELAPA"
      },
      {
        "kodeKECAMATAN": 1709051,
        "kodeKABUPATEN": 1709,
        "namaKECAMATAN": "PONDOK KUBANG"
      },
      {
        "kodeKECAMATAN": 1709060,
        "kodeKABUPATEN": 1709,
        "namaKECAMATAN": "PEMATANG TIGA"
      },
      {
        "kodeKECAMATAN": 1709061,
        "kodeKABUPATEN": 1709,
        "namaKECAMATAN": "BANG HAJI"
      },
      {
        "kodeKECAMATAN": 1771010,
        "kodeKABUPATEN": 1771,
        "namaKECAMATAN": "SELEBAR"
      },
      {
        "kodeKECAMATAN": 1771011,
        "kodeKABUPATEN": 1771,
        "namaKECAMATAN": "KAMPUNG MELAYU"
      },
      {
        "kodeKECAMATAN": 1771020,
        "kodeKABUPATEN": 1771,
        "namaKECAMATAN": "GADING CEMPAKA"
      },
      {
        "kodeKECAMATAN": 1771021,
        "kodeKABUPATEN": 1771,
        "namaKECAMATAN": "RATU AGUNG"
      },
      {
        "kodeKECAMATAN": 1771022,
        "kodeKABUPATEN": 1771,
        "namaKECAMATAN": "RATU SAMBAN"
      },
      {
        "kodeKECAMATAN": 1771023,
        "kodeKABUPATEN": 1771,
        "namaKECAMATAN": "SINGARAN PATI"
      },
      {
        "kodeKECAMATAN": 1771030,
        "kodeKABUPATEN": 1771,
        "namaKECAMATAN": "TELUK SEGARA"
      },
      {
        "kodeKECAMATAN": 1771031,
        "kodeKABUPATEN": 1771,
        "namaKECAMATAN": "SUNGAI SERUT"
      },
      {
        "kodeKECAMATAN": 1771040,
        "kodeKABUPATEN": 1771,
        "namaKECAMATAN": "MUARA BANGKA HULU"
      },
      {
        "kodeKECAMATAN": 1801040,
        "kodeKABUPATEN": 1801,
        "namaKECAMATAN": "BALIK BUKIT"
      },
      {
        "kodeKECAMATAN": 1801041,
        "kodeKABUPATEN": 1801,
        "namaKECAMATAN": "SUKAU"
      },
      {
        "kodeKECAMATAN": 1801042,
        "kodeKABUPATEN": 1801,
        "namaKECAMATAN": "LUMBOK SEMINUNG"
      },
      {
        "kodeKECAMATAN": 1801050,
        "kodeKABUPATEN": 1801,
        "namaKECAMATAN": "BELALAU"
      },
      {
        "kodeKECAMATAN": 1801051,
        "kodeKABUPATEN": 1801,
        "namaKECAMATAN": "SEKINCAU"
      },
      {
        "kodeKECAMATAN": 1801052,
        "kodeKABUPATEN": 1801,
        "namaKECAMATAN": "SUOH"
      },
      {
        "kodeKECAMATAN": 1801053,
        "kodeKABUPATEN": 1801,
        "namaKECAMATAN": "BATU BRAK"
      },
      {
        "kodeKECAMATAN": 1801054,
        "kodeKABUPATEN": 1801,
        "namaKECAMATAN": "PAGAR DEWA"
      },
      {
        "kodeKECAMATAN": 1801055,
        "kodeKABUPATEN": 1801,
        "namaKECAMATAN": "BATU KETULIS"
      },
      {
        "kodeKECAMATAN": 1801056,
        "kodeKABUPATEN": 1801,
        "namaKECAMATAN": "BANDAR NEGERI SUOH"
      },
      {
        "kodeKECAMATAN": 1801060,
        "kodeKABUPATEN": 1801,
        "namaKECAMATAN": "SUMBER JAYA"
      },
      {
        "kodeKECAMATAN": 1801061,
        "kodeKABUPATEN": 1801,
        "namaKECAMATAN": "WAY TENONG"
      },
      {
        "kodeKECAMATAN": 1801062,
        "kodeKABUPATEN": 1801,
        "namaKECAMATAN": "GEDUNG SURIAN"
      },
      {
        "kodeKECAMATAN": 1801063,
        "kodeKABUPATEN": 1801,
        "namaKECAMATAN": "KEBUN TEBU"
      },
      {
        "kodeKECAMATAN": 1801064,
        "kodeKABUPATEN": 1801,
        "namaKECAMATAN": "AIR HITAM"
      },
      {
        "kodeKECAMATAN": 1802010,
        "kodeKABUPATEN": 1802,
        "namaKECAMATAN": "WONOSOBO"
      },
      {
        "kodeKECAMATAN": 1802011,
        "kodeKABUPATEN": 1802,
        "namaKECAMATAN": "SEMAKA"
      },
      {
        "kodeKECAMATAN": 1802012,
        "kodeKABUPATEN": 1802,
        "namaKECAMATAN": "BANDAR NEGERI SEMUONG"
      },
      {
        "kodeKECAMATAN": 1802020,
        "kodeKABUPATEN": 1802,
        "namaKECAMATAN": "KOTA AGUNG"
      },
      {
        "kodeKECAMATAN": 1802021,
        "kodeKABUPATEN": 1802,
        "namaKECAMATAN": "PEMATANG SAWA"
      },
      {
        "kodeKECAMATAN": 1802022,
        "kodeKABUPATEN": 1802,
        "namaKECAMATAN": "KOTA AGUNG TIMUR"
      },
      {
        "kodeKECAMATAN": 1802023,
        "kodeKABUPATEN": 1802,
        "namaKECAMATAN": "KOTA AGUNG BARAT"
      },
      {
        "kodeKECAMATAN": 1802030,
        "kodeKABUPATEN": 1802,
        "namaKECAMATAN": "PULAU PANGGUNG"
      },
      {
        "kodeKECAMATAN": 1802031,
        "kodeKABUPATEN": 1802,
        "namaKECAMATAN": "ULUBELU"
      },
      {
        "kodeKECAMATAN": 1802032,
        "kodeKABUPATEN": 1802,
        "namaKECAMATAN": "AIR NANINGAN"
      },
      {
        "kodeKECAMATAN": 1802040,
        "kodeKABUPATEN": 1802,
        "namaKECAMATAN": "TALANG PADANG"
      },
      {
        "kodeKECAMATAN": 1802041,
        "kodeKABUPATEN": 1802,
        "namaKECAMATAN": "SUMBEREJO"
      },
      {
        "kodeKECAMATAN": 1802042,
        "kodeKABUPATEN": 1802,
        "namaKECAMATAN": "GISTING"
      },
      {
        "kodeKECAMATAN": 1802043,
        "kodeKABUPATEN": 1802,
        "namaKECAMATAN": "GUNUNG ALIP"
      },
      {
        "kodeKECAMATAN": 1802050,
        "kodeKABUPATEN": 1802,
        "namaKECAMATAN": "PUGUNG"
      },
      {
        "kodeKECAMATAN": 1802101,
        "kodeKABUPATEN": 1802,
        "namaKECAMATAN": "BULOK"
      },
      {
        "kodeKECAMATAN": 1802110,
        "kodeKABUPATEN": 1802,
        "namaKECAMATAN": "CUKUH BALAK"
      },
      {
        "kodeKECAMATAN": 1802111,
        "kodeKABUPATEN": 1802,
        "namaKECAMATAN": "KELUMBAYAN"
      },
      {
        "kodeKECAMATAN": 1802112,
        "kodeKABUPATEN": 1802,
        "namaKECAMATAN": "LIMAU"
      },
      {
        "kodeKECAMATAN": 1802113,
        "kodeKABUPATEN": 1802,
        "namaKECAMATAN": "KELUMBAYAN BARAT"
      },
      {
        "kodeKECAMATAN": 1803060,
        "kodeKABUPATEN": 1803,
        "namaKECAMATAN": "NATAR"
      },
      {
        "kodeKECAMATAN": 1803070,
        "kodeKABUPATEN": 1803,
        "namaKECAMATAN": "JATI AGUNG"
      },
      {
        "kodeKECAMATAN": 1803080,
        "kodeKABUPATEN": 1803,
        "namaKECAMATAN": "TANJUNG BINTANG"
      },
      {
        "kodeKECAMATAN": 1803081,
        "kodeKABUPATEN": 1803,
        "namaKECAMATAN": "TANJUNG SARI"
      },
      {
        "kodeKECAMATAN": 1803090,
        "kodeKABUPATEN": 1803,
        "namaKECAMATAN": "KATIBUNG"
      },
      {
        "kodeKECAMATAN": 1803091,
        "kodeKABUPATEN": 1803,
        "namaKECAMATAN": "MERBAU MATARAM"
      },
      {
        "kodeKECAMATAN": 1803092,
        "kodeKABUPATEN": 1803,
        "namaKECAMATAN": "WAY SULAN"
      },
      {
        "kodeKECAMATAN": 1803100,
        "kodeKABUPATEN": 1803,
        "namaKECAMATAN": "SIDOMULYO"
      },
      {
        "kodeKECAMATAN": 1803101,
        "kodeKABUPATEN": 1803,
        "namaKECAMATAN": "CANDIPURO"
      },
      {
        "kodeKECAMATAN": 1803102,
        "kodeKABUPATEN": 1803,
        "namaKECAMATAN": "WAY PANJI"
      },
      {
        "kodeKECAMATAN": 1803110,
        "kodeKABUPATEN": 1803,
        "namaKECAMATAN": "KALIANDA"
      },
      {
        "kodeKECAMATAN": 1803111,
        "kodeKABUPATEN": 1803,
        "namaKECAMATAN": "RAJABASA"
      },
      {
        "kodeKECAMATAN": 1803120,
        "kodeKABUPATEN": 1803,
        "namaKECAMATAN": "PALAS"
      },
      {
        "kodeKECAMATAN": 1803121,
        "kodeKABUPATEN": 1803,
        "namaKECAMATAN": "SRAGI"
      },
      {
        "kodeKECAMATAN": 1803130,
        "kodeKABUPATEN": 1803,
        "namaKECAMATAN": "PENENGAHAN"
      },
      {
        "kodeKECAMATAN": 1803131,
        "kodeKABUPATEN": 1803,
        "namaKECAMATAN": "KETAPANG"
      },
      {
        "kodeKECAMATAN": 1803132,
        "kodeKABUPATEN": 1803,
        "namaKECAMATAN": "BAKAUHENI"
      },
      {
        "kodeKECAMATAN": 1804010,
        "kodeKABUPATEN": 1804,
        "namaKECAMATAN": "METRO KIBANG"
      },
      {
        "kodeKECAMATAN": 1804020,
        "kodeKABUPATEN": 1804,
        "namaKECAMATAN": "BATANGHARI"
      },
      {
        "kodeKECAMATAN": 1804030,
        "kodeKABUPATEN": 1804,
        "namaKECAMATAN": "SEKAMPUNG"
      },
      {
        "kodeKECAMATAN": 1804040,
        "kodeKABUPATEN": 1804,
        "namaKECAMATAN": "MARGATIGA"
      },
      {
        "kodeKECAMATAN": 1804050,
        "kodeKABUPATEN": 1804,
        "namaKECAMATAN": "SEKAMPUNG UDIK"
      },
      {
        "kodeKECAMATAN": 1804060,
        "kodeKABUPATEN": 1804,
        "namaKECAMATAN": "JABUNG"
      },
      {
        "kodeKECAMATAN": 1804061,
        "kodeKABUPATEN": 1804,
        "namaKECAMATAN": "PASIR SAKTI"
      },
      {
        "kodeKECAMATAN": 1804062,
        "kodeKABUPATEN": 1804,
        "namaKECAMATAN": "WAWAY KARYA"
      },
      {
        "kodeKECAMATAN": 1804063,
        "kodeKABUPATEN": 1804,
        "namaKECAMATAN": "MARGA SEKAMPUNG"
      },
      {
        "kodeKECAMATAN": 1804070,
        "kodeKABUPATEN": 1804,
        "namaKECAMATAN": "LABUHAN MARINGGAI"
      },
      {
        "kodeKECAMATAN": 1804071,
        "kodeKABUPATEN": 1804,
        "namaKECAMATAN": "MATARAM BARU"
      },
      {
        "kodeKECAMATAN": 1804072,
        "kodeKABUPATEN": 1804,
        "namaKECAMATAN": "BANDAR SRIBAWONO"
      },
      {
        "kodeKECAMATAN": 1804073,
        "kodeKABUPATEN": 1804,
        "namaKECAMATAN": "MELINTING"
      },
      {
        "kodeKECAMATAN": 1804074,
        "kodeKABUPATEN": 1804,
        "namaKECAMATAN": "GUNUNG PELINDUNG"
      },
      {
        "kodeKECAMATAN": 1804080,
        "kodeKABUPATEN": 1804,
        "namaKECAMATAN": "WAY JEPARA"
      },
      {
        "kodeKECAMATAN": 1804081,
        "kodeKABUPATEN": 1804,
        "namaKECAMATAN": "BRAJA SLEBAH"
      },
      {
        "kodeKECAMATAN": 1804082,
        "kodeKABUPATEN": 1804,
        "namaKECAMATAN": "LABUHAN RATU"
      },
      {
        "kodeKECAMATAN": 1804090,
        "kodeKABUPATEN": 1804,
        "namaKECAMATAN": "SUKADANA"
      },
      {
        "kodeKECAMATAN": 1804091,
        "kodeKABUPATEN": 1804,
        "namaKECAMATAN": "BUMI AGUNG"
      },
      {
        "kodeKECAMATAN": 1804092,
        "kodeKABUPATEN": 1804,
        "namaKECAMATAN": "BATANGHARI NUBAN"
      },
      {
        "kodeKECAMATAN": 1804100,
        "kodeKABUPATEN": 1804,
        "namaKECAMATAN": "PEKALONGAN"
      },
      {
        "kodeKECAMATAN": 1804110,
        "kodeKABUPATEN": 1804,
        "namaKECAMATAN": "RAMAN UTARA"
      },
      {
        "kodeKECAMATAN": 1804120,
        "kodeKABUPATEN": 1804,
        "namaKECAMATAN": "PURBOLINGGO"
      },
      {
        "kodeKECAMATAN": 1804121,
        "kodeKABUPATEN": 1804,
        "namaKECAMATAN": "WAY BUNGUR"
      },
      {
        "kodeKECAMATAN": 1805010,
        "kodeKABUPATEN": 1805,
        "namaKECAMATAN": "PADANG RATU"
      },
      {
        "kodeKECAMATAN": 1805011,
        "kodeKABUPATEN": 1805,
        "namaKECAMATAN": "SELAGAI LINGGA"
      },
      {
        "kodeKECAMATAN": 1805012,
        "kodeKABUPATEN": 1805,
        "namaKECAMATAN": "PUBIAN"
      },
      {
        "kodeKECAMATAN": 1805013,
        "kodeKABUPATEN": 1805,
        "namaKECAMATAN": "ANAK TUHA"
      },
      {
        "kodeKECAMATAN": 1805014,
        "kodeKABUPATEN": 1805,
        "namaKECAMATAN": "ANAK RATU AJI"
      },
      {
        "kodeKECAMATAN": 1805020,
        "kodeKABUPATEN": 1805,
        "namaKECAMATAN": "KALIREJO"
      },
      {
        "kodeKECAMATAN": 1805021,
        "kodeKABUPATEN": 1805,
        "namaKECAMATAN": "SENDANG AGUNG"
      },
      {
        "kodeKECAMATAN": 1805030,
        "kodeKABUPATEN": 1805,
        "namaKECAMATAN": "BANGUNREJO"
      },
      {
        "kodeKECAMATAN": 1805040,
        "kodeKABUPATEN": 1805,
        "namaKECAMATAN": "GUNUNG SUGIH"
      },
      {
        "kodeKECAMATAN": 1805041,
        "kodeKABUPATEN": 1805,
        "namaKECAMATAN": "BEKRI"
      },
      {
        "kodeKECAMATAN": 1805042,
        "kodeKABUPATEN": 1805,
        "namaKECAMATAN": "BUMI RATU NUBAN"
      },
      {
        "kodeKECAMATAN": 1805050,
        "kodeKABUPATEN": 1805,
        "namaKECAMATAN": "TRIMURJO"
      },
      {
        "kodeKECAMATAN": 1805060,
        "kodeKABUPATEN": 1805,
        "namaKECAMATAN": "PUNGGUR"
      },
      {
        "kodeKECAMATAN": 1805061,
        "kodeKABUPATEN": 1805,
        "namaKECAMATAN": "KOTA GAJAH"
      },
      {
        "kodeKECAMATAN": 1805070,
        "kodeKABUPATEN": 1805,
        "namaKECAMATAN": "SEPUTIH RAMAN"
      },
      {
        "kodeKECAMATAN": 1805080,
        "kodeKABUPATEN": 1805,
        "namaKECAMATAN": "TERBANGGI BESAR"
      },
      {
        "kodeKECAMATAN": 1805081,
        "kodeKABUPATEN": 1805,
        "namaKECAMATAN": "SEPUTIH AGUNG"
      },
      {
        "kodeKECAMATAN": 1805082,
        "kodeKABUPATEN": 1805,
        "namaKECAMATAN": "WAY PENGUBUAN"
      },
      {
        "kodeKECAMATAN": 1805090,
        "kodeKABUPATEN": 1805,
        "namaKECAMATAN": "TERUSAN NUNYAI"
      },
      {
        "kodeKECAMATAN": 1805100,
        "kodeKABUPATEN": 1805,
        "namaKECAMATAN": "SEPUTIH MATARAM"
      },
      {
        "kodeKECAMATAN": 1805101,
        "kodeKABUPATEN": 1805,
        "namaKECAMATAN": "BANDAR MATARAM"
      },
      {
        "kodeKECAMATAN": 1805110,
        "kodeKABUPATEN": 1805,
        "namaKECAMATAN": "SEPUTIH BANYAK"
      },
      {
        "kodeKECAMATAN": 1805111,
        "kodeKABUPATEN": 1805,
        "namaKECAMATAN": "WAY SEPUTIH"
      },
      {
        "kodeKECAMATAN": 1805120,
        "kodeKABUPATEN": 1805,
        "namaKECAMATAN": "RUMBIA"
      },
      {
        "kodeKECAMATAN": 1805121,
        "kodeKABUPATEN": 1805,
        "namaKECAMATAN": "BUMI NABUNG"
      },
      {
        "kodeKECAMATAN": 1805122,
        "kodeKABUPATEN": 1805,
        "namaKECAMATAN": "PUTRA RUMBIA"
      },
      {
        "kodeKECAMATAN": 1805130,
        "kodeKABUPATEN": 1805,
        "namaKECAMATAN": "SEPUTIH SURABAYA"
      },
      {
        "kodeKECAMATAN": 1805131,
        "kodeKABUPATEN": 1805,
        "namaKECAMATAN": "BANDAR SURABAYA"
      },
      {
        "kodeKECAMATAN": 1806010,
        "kodeKABUPATEN": 1806,
        "namaKECAMATAN": "BUKIT KEMUNING"
      },
      {
        "kodeKECAMATAN": 1806011,
        "kodeKABUPATEN": 1806,
        "namaKECAMATAN": "ABUNG TINGGI"
      },
      {
        "kodeKECAMATAN": 1806020,
        "kodeKABUPATEN": 1806,
        "namaKECAMATAN": "TANJUNG RAJA"
      },
      {
        "kodeKECAMATAN": 1806030,
        "kodeKABUPATEN": 1806,
        "namaKECAMATAN": "ABUNG BARAT"
      },
      {
        "kodeKECAMATAN": 1806031,
        "kodeKABUPATEN": 1806,
        "namaKECAMATAN": "ABUNG TENGAH"
      },
      {
        "kodeKECAMATAN": 1806032,
        "kodeKABUPATEN": 1806,
        "namaKECAMATAN": "ABUNG  KUNANG"
      },
      {
        "kodeKECAMATAN": 1806033,
        "kodeKABUPATEN": 1806,
        "namaKECAMATAN": "ABUNG PEKURUN"
      },
      {
        "kodeKECAMATAN": 1806040,
        "kodeKABUPATEN": 1806,
        "namaKECAMATAN": "KOTABUMI"
      },
      {
        "kodeKECAMATAN": 1806041,
        "kodeKABUPATEN": 1806,
        "namaKECAMATAN": "KOTABUMI UTARA"
      },
      {
        "kodeKECAMATAN": 1806042,
        "kodeKABUPATEN": 1806,
        "namaKECAMATAN": "KOTABUMI SELATAN"
      },
      {
        "kodeKECAMATAN": 1806050,
        "kodeKABUPATEN": 1806,
        "namaKECAMATAN": "ABUNG SELATAN"
      },
      {
        "kodeKECAMATAN": 1806051,
        "kodeKABUPATEN": 1806,
        "namaKECAMATAN": "ABUNG SEMULI"
      },
      {
        "kodeKECAMATAN": 1806052,
        "kodeKABUPATEN": 1806,
        "namaKECAMATAN": "BLAMBANGAN PAGAR"
      },
      {
        "kodeKECAMATAN": 1806060,
        "kodeKABUPATEN": 1806,
        "namaKECAMATAN": "ABUNG TIMUR"
      },
      {
        "kodeKECAMATAN": 1806061,
        "kodeKABUPATEN": 1806,
        "namaKECAMATAN": "ABUNG SURAKARTA"
      },
      {
        "kodeKECAMATAN": 1806070,
        "kodeKABUPATEN": 1806,
        "namaKECAMATAN": "SUNGKAI SELATAN"
      },
      {
        "kodeKECAMATAN": 1806071,
        "kodeKABUPATEN": 1806,
        "namaKECAMATAN": "MUARA SUNGKAI"
      },
      {
        "kodeKECAMATAN": 1806072,
        "kodeKABUPATEN": 1806,
        "namaKECAMATAN": "BUNGA MAYANG"
      },
      {
        "kodeKECAMATAN": 1806073,
        "kodeKABUPATEN": 1806,
        "namaKECAMATAN": "SUNGKAI  BARAT"
      },
      {
        "kodeKECAMATAN": 1806074,
        "kodeKABUPATEN": 1806,
        "namaKECAMATAN": "SUNGKAI JAYA"
      },
      {
        "kodeKECAMATAN": 1806080,
        "kodeKABUPATEN": 1806,
        "namaKECAMATAN": "SUNGKAI UTARA"
      },
      {
        "kodeKECAMATAN": 1806081,
        "kodeKABUPATEN": 1806,
        "namaKECAMATAN": "HULUSUNGKAI"
      },
      {
        "kodeKECAMATAN": 1806082,
        "kodeKABUPATEN": 1806,
        "namaKECAMATAN": "SUNGKAI TENGAH"
      },
      {
        "kodeKECAMATAN": 1807010,
        "kodeKABUPATEN": 1807,
        "namaKECAMATAN": "BANJIT"
      },
      {
        "kodeKECAMATAN": 1807020,
        "kodeKABUPATEN": 1807,
        "namaKECAMATAN": "BARADATU"
      },
      {
        "kodeKECAMATAN": 1807021,
        "kodeKABUPATEN": 1807,
        "namaKECAMATAN": "GUNUNG LABUHAN"
      },
      {
        "kodeKECAMATAN": 1807030,
        "kodeKABUPATEN": 1807,
        "namaKECAMATAN": "KASUI"
      },
      {
        "kodeKECAMATAN": 1807031,
        "kodeKABUPATEN": 1807,
        "namaKECAMATAN": "REBANG TANGKAS"
      },
      {
        "kodeKECAMATAN": 1807040,
        "kodeKABUPATEN": 1807,
        "namaKECAMATAN": "BLAMBANGAN UMPU"
      },
      {
        "kodeKECAMATAN": 1807041,
        "kodeKABUPATEN": 1807,
        "namaKECAMATAN": "WAY TUBA"
      },
      {
        "kodeKECAMATAN": 1807042,
        "kodeKABUPATEN": 1807,
        "namaKECAMATAN": "NEGERI AGUNG"
      },
      {
        "kodeKECAMATAN": 1807050,
        "kodeKABUPATEN": 1807,
        "namaKECAMATAN": "BAHUGA"
      },
      {
        "kodeKECAMATAN": 1807051,
        "kodeKABUPATEN": 1807,
        "namaKECAMATAN": "BUAY  BAHUGA"
      },
      {
        "kodeKECAMATAN": 1807052,
        "kodeKABUPATEN": 1807,
        "namaKECAMATAN": "BUMI AGUNG"
      },
      {
        "kodeKECAMATAN": 1807060,
        "kodeKABUPATEN": 1807,
        "namaKECAMATAN": "PAKUAN RATU"
      },
      {
        "kodeKECAMATAN": 1807061,
        "kodeKABUPATEN": 1807,
        "namaKECAMATAN": "NEGARA BATIN"
      },
      {
        "kodeKECAMATAN": 1807062,
        "kodeKABUPATEN": 1807,
        "namaKECAMATAN": "NEGERI BESAR"
      },
      {
        "kodeKECAMATAN": 1808030,
        "kodeKABUPATEN": 1808,
        "namaKECAMATAN": "BANJAR AGUNG"
      },
      {
        "kodeKECAMATAN": 1808031,
        "kodeKABUPATEN": 1808,
        "namaKECAMATAN": "BANJAR MARGO"
      },
      {
        "kodeKECAMATAN": 1808032,
        "kodeKABUPATEN": 1808,
        "namaKECAMATAN": "BANJAR BARU"
      },
      {
        "kodeKECAMATAN": 1808040,
        "kodeKABUPATEN": 1808,
        "namaKECAMATAN": "GEDUNG AJI"
      },
      {
        "kodeKECAMATAN": 1808041,
        "kodeKABUPATEN": 1808,
        "namaKECAMATAN": "PENAWAR AJI"
      },
      {
        "kodeKECAMATAN": 1808042,
        "kodeKABUPATEN": 1808,
        "namaKECAMATAN": "MERAKSA AJI"
      },
      {
        "kodeKECAMATAN": 1808050,
        "kodeKABUPATEN": 1808,
        "namaKECAMATAN": "MENGGALA"
      },
      {
        "kodeKECAMATAN": 1808051,
        "kodeKABUPATEN": 1808,
        "namaKECAMATAN": "PENAWAR TAMA"
      },
      {
        "kodeKECAMATAN": 1808052,
        "kodeKABUPATEN": 1808,
        "namaKECAMATAN": "RAWAJITU SELATAN"
      },
      {
        "kodeKECAMATAN": 1808053,
        "kodeKABUPATEN": 1808,
        "namaKECAMATAN": "GEDUNG MENENG"
      },
      {
        "kodeKECAMATAN": 1808054,
        "kodeKABUPATEN": 1808,
        "namaKECAMATAN": "RAWAJITU TIMUR"
      },
      {
        "kodeKECAMATAN": 1808055,
        "kodeKABUPATEN": 1808,
        "namaKECAMATAN": "RAWA PITU"
      },
      {
        "kodeKECAMATAN": 1808056,
        "kodeKABUPATEN": 1808,
        "namaKECAMATAN": "GEDUNG AJI BARU"
      },
      {
        "kodeKECAMATAN": 1808057,
        "kodeKABUPATEN": 1808,
        "namaKECAMATAN": "DENTE TELADAS"
      },
      {
        "kodeKECAMATAN": 1808058,
        "kodeKABUPATEN": 1808,
        "namaKECAMATAN": "MENGGALA TIMUR"
      },
      {
        "kodeKECAMATAN": 1809010,
        "kodeKABUPATEN": 1809,
        "namaKECAMATAN": "PUNDUH PIDADA"
      },
      {
        "kodeKECAMATAN": 1809011,
        "kodeKABUPATEN": 1809,
        "namaKECAMATAN": "MARGA PUNDUH"
      },
      {
        "kodeKECAMATAN": 1809020,
        "kodeKABUPATEN": 1809,
        "namaKECAMATAN": "PADANG CERMIN"
      },
      {
        "kodeKECAMATAN": 1809021,
        "kodeKABUPATEN": 1809,
        "namaKECAMATAN": "TELUK PANDAN"
      },
      {
        "kodeKECAMATAN": 1809022,
        "kodeKABUPATEN": 1809,
        "namaKECAMATAN": "WAY RATAI"
      },
      {
        "kodeKECAMATAN": 1809030,
        "kodeKABUPATEN": 1809,
        "namaKECAMATAN": "KEDONDONG"
      },
      {
        "kodeKECAMATAN": 1809031,
        "kodeKABUPATEN": 1809,
        "namaKECAMATAN": "WAY KHILAU"
      },
      {
        "kodeKECAMATAN": 1809040,
        "kodeKABUPATEN": 1809,
        "namaKECAMATAN": "WAY LIMA"
      },
      {
        "kodeKECAMATAN": 1809050,
        "kodeKABUPATEN": 1809,
        "namaKECAMATAN": "GEDUNG TATAAN"
      },
      {
        "kodeKECAMATAN": 1809060,
        "kodeKABUPATEN": 1809,
        "namaKECAMATAN": "NEGERI KATON"
      },
      {
        "kodeKECAMATAN": 1809070,
        "kodeKABUPATEN": 1809,
        "namaKECAMATAN": "TEGINENENG"
      },
      {
        "kodeKECAMATAN": 1810010,
        "kodeKABUPATEN": 1810,
        "namaKECAMATAN": "PARDASUKA"
      },
      {
        "kodeKECAMATAN": 1810020,
        "kodeKABUPATEN": 1810,
        "namaKECAMATAN": "AMBARAWA"
      },
      {
        "kodeKECAMATAN": 1810030,
        "kodeKABUPATEN": 1810,
        "namaKECAMATAN": "PAGELARAN"
      },
      {
        "kodeKECAMATAN": 1810031,
        "kodeKABUPATEN": 1810,
        "namaKECAMATAN": "PAGELARAN UTARA"
      },
      {
        "kodeKECAMATAN": 1810040,
        "kodeKABUPATEN": 1810,
        "namaKECAMATAN": "PRINGSEWU"
      },
      {
        "kodeKECAMATAN": 1810050,
        "kodeKABUPATEN": 1810,
        "namaKECAMATAN": "GADING REJO"
      },
      {
        "kodeKECAMATAN": 1810060,
        "kodeKABUPATEN": 1810,
        "namaKECAMATAN": "SUKOHARJO"
      },
      {
        "kodeKECAMATAN": 1810070,
        "kodeKABUPATEN": 1810,
        "namaKECAMATAN": "BANYUMAS"
      },
      {
        "kodeKECAMATAN": 1810080,
        "kodeKABUPATEN": 1810,
        "namaKECAMATAN": "ADI LUWIH"
      },
      {
        "kodeKECAMATAN": 1811010,
        "kodeKABUPATEN": 1811,
        "namaKECAMATAN": "WAY SERDANG"
      },
      {
        "kodeKECAMATAN": 1811020,
        "kodeKABUPATEN": 1811,
        "namaKECAMATAN": "SIMPANG PEMATANG"
      },
      {
        "kodeKECAMATAN": 1811030,
        "kodeKABUPATEN": 1811,
        "namaKECAMATAN": "PANCA JAYA"
      },
      {
        "kodeKECAMATAN": 1811040,
        "kodeKABUPATEN": 1811,
        "namaKECAMATAN": "TANJUNG RAYA"
      },
      {
        "kodeKECAMATAN": 1811050,
        "kodeKABUPATEN": 1811,
        "namaKECAMATAN": "MESUJI"
      },
      {
        "kodeKECAMATAN": 1811060,
        "kodeKABUPATEN": 1811,
        "namaKECAMATAN": "MESUJI TIMUR"
      },
      {
        "kodeKECAMATAN": 1811070,
        "kodeKABUPATEN": 1811,
        "namaKECAMATAN": "RAWAJITU UTARA"
      },
      {
        "kodeKECAMATAN": 1812010,
        "kodeKABUPATEN": 1812,
        "namaKECAMATAN": "TULANG BAWANG UDIK"
      },
      {
        "kodeKECAMATAN": 1812020,
        "kodeKABUPATEN": 1812,
        "namaKECAMATAN": "TUMI JAJAR"
      },
      {
        "kodeKECAMATAN": 1812030,
        "kodeKABUPATEN": 1812,
        "namaKECAMATAN": "TULANG BAWANG TENGAH"
      },
      {
        "kodeKECAMATAN": 1812040,
        "kodeKABUPATEN": 1812,
        "namaKECAMATAN": "PAGAR DEWA"
      },
      {
        "kodeKECAMATAN": 1812050,
        "kodeKABUPATEN": 1812,
        "namaKECAMATAN": "LAMBU KIBANG"
      },
      {
        "kodeKECAMATAN": 1812060,
        "kodeKABUPATEN": 1812,
        "namaKECAMATAN": "GUNUNG TERANG"
      },
      {
        "kodeKECAMATAN": 1812070,
        "kodeKABUPATEN": 1812,
        "namaKECAMATAN": "GUNUNG AGUNG"
      },
      {
        "kodeKECAMATAN": 1812080,
        "kodeKABUPATEN": 1812,
        "namaKECAMATAN": "WAY KENANGA"
      },
      {
        "kodeKECAMATAN": 1813010,
        "kodeKABUPATEN": 1813,
        "namaKECAMATAN": "LEMONG"
      },
      {
        "kodeKECAMATAN": 1813020,
        "kodeKABUPATEN": 1813,
        "namaKECAMATAN": "PESISIR UTARA"
      },
      {
        "kodeKECAMATAN": 1813030,
        "kodeKABUPATEN": 1813,
        "namaKECAMATAN": "PULAU PISANG"
      },
      {
        "kodeKECAMATAN": 1813040,
        "kodeKABUPATEN": 1813,
        "namaKECAMATAN": "KARYA PENGGAWA"
      },
      {
        "kodeKECAMATAN": 1813050,
        "kodeKABUPATEN": 1813,
        "namaKECAMATAN": "WAY KRUI"
      },
      {
        "kodeKECAMATAN": 1813060,
        "kodeKABUPATEN": 1813,
        "namaKECAMATAN": "PESISIR TENGAH"
      },
      {
        "kodeKECAMATAN": 1813070,
        "kodeKABUPATEN": 1813,
        "namaKECAMATAN": "KRUI SELATAN"
      },
      {
        "kodeKECAMATAN": 1813080,
        "kodeKABUPATEN": 1813,
        "namaKECAMATAN": "PESISIR SELATAN"
      },
      {
        "kodeKECAMATAN": 1813090,
        "kodeKABUPATEN": 1813,
        "namaKECAMATAN": "NGAMBUR"
      },
      {
        "kodeKECAMATAN": 1813100,
        "kodeKABUPATEN": 1813,
        "namaKECAMATAN": "BENGKUNAT"
      },
      {
        "kodeKECAMATAN": 1813110,
        "kodeKABUPATEN": 1813,
        "namaKECAMATAN": "BENGKUNAT BELIMBING"
      },
      {
        "kodeKECAMATAN": 1871010,
        "kodeKABUPATEN": 1871,
        "namaKECAMATAN": "TELUK BETUNG BARAT"
      },
      {
        "kodeKECAMATAN": 1871011,
        "kodeKABUPATEN": 1871,
        "namaKECAMATAN": "TELUKBETUNG TIMUR"
      },
      {
        "kodeKECAMATAN": 1871020,
        "kodeKABUPATEN": 1871,
        "namaKECAMATAN": "TELUK BETUNG SELATAN"
      },
      {
        "kodeKECAMATAN": 1871021,
        "kodeKABUPATEN": 1871,
        "namaKECAMATAN": "BUMI WARAS"
      },
      {
        "kodeKECAMATAN": 1871030,
        "kodeKABUPATEN": 1871,
        "namaKECAMATAN": "PANJANG"
      },
      {
        "kodeKECAMATAN": 1871040,
        "kodeKABUPATEN": 1871,
        "namaKECAMATAN": "TANJUNG KARANG TIMUR"
      },
      {
        "kodeKECAMATAN": 1871041,
        "kodeKABUPATEN": 1871,
        "namaKECAMATAN": "KEDAMAIAN"
      },
      {
        "kodeKECAMATAN": 1871050,
        "kodeKABUPATEN": 1871,
        "namaKECAMATAN": "TELUK BETUNG UTARA"
      },
      {
        "kodeKECAMATAN": 1871060,
        "kodeKABUPATEN": 1871,
        "namaKECAMATAN": "TANJUNG KARANG PUSAT"
      },
      {
        "kodeKECAMATAN": 1871061,
        "kodeKABUPATEN": 1871,
        "namaKECAMATAN": "ENGGAL"
      },
      {
        "kodeKECAMATAN": 1871070,
        "kodeKABUPATEN": 1871,
        "namaKECAMATAN": "TANJUNG KARANG BARAT"
      },
      {
        "kodeKECAMATAN": 1871071,
        "kodeKABUPATEN": 1871,
        "namaKECAMATAN": "KEMILING"
      },
      {
        "kodeKECAMATAN": 1871072,
        "kodeKABUPATEN": 1871,
        "namaKECAMATAN": "LANGKAPURA"
      },
      {
        "kodeKECAMATAN": 1871080,
        "kodeKABUPATEN": 1871,
        "namaKECAMATAN": "KEDATON"
      },
      {
        "kodeKECAMATAN": 1871081,
        "kodeKABUPATEN": 1871,
        "namaKECAMATAN": "RAJABASA"
      },
      {
        "kodeKECAMATAN": 1871082,
        "kodeKABUPATEN": 1871,
        "namaKECAMATAN": "TANJUNG SENANG"
      },
      {
        "kodeKECAMATAN": 1871083,
        "kodeKABUPATEN": 1871,
        "namaKECAMATAN": "LABUHAN RATU"
      },
      {
        "kodeKECAMATAN": 1871090,
        "kodeKABUPATEN": 1871,
        "namaKECAMATAN": "SUKARAME"
      },
      {
        "kodeKECAMATAN": 1871091,
        "kodeKABUPATEN": 1871,
        "namaKECAMATAN": "SUKABUMI"
      },
      {
        "kodeKECAMATAN": 1871092,
        "kodeKABUPATEN": 1871,
        "namaKECAMATAN": "WAY HALIM"
      },
      {
        "kodeKECAMATAN": 1872011,
        "kodeKABUPATEN": 1872,
        "namaKECAMATAN": "METRO SELATAN"
      },
      {
        "kodeKECAMATAN": 1872012,
        "kodeKABUPATEN": 1872,
        "namaKECAMATAN": "METRO BARAT"
      },
      {
        "kodeKECAMATAN": 1872021,
        "kodeKABUPATEN": 1872,
        "namaKECAMATAN": "METRO TIMUR"
      },
      {
        "kodeKECAMATAN": 1872022,
        "kodeKABUPATEN": 1872,
        "namaKECAMATAN": "METRO PUSAT"
      },
      {
        "kodeKECAMATAN": 1872023,
        "kodeKABUPATEN": 1872,
        "namaKECAMATAN": "METRO UTARA"
      },
      {
        "kodeKECAMATAN": 1901070,
        "kodeKABUPATEN": 1901,
        "namaKECAMATAN": "MENDO BARAT"
      },
      {
        "kodeKECAMATAN": 1901080,
        "kodeKABUPATEN": 1901,
        "namaKECAMATAN": "MERAWANG"
      },
      {
        "kodeKECAMATAN": 1901081,
        "kodeKABUPATEN": 1901,
        "namaKECAMATAN": "PUDING BESAR"
      },
      {
        "kodeKECAMATAN": 1901090,
        "kodeKABUPATEN": 1901,
        "namaKECAMATAN": "SUNGAI LIAT"
      },
      {
        "kodeKECAMATAN": 1901091,
        "kodeKABUPATEN": 1901,
        "namaKECAMATAN": "PEMALI"
      },
      {
        "kodeKECAMATAN": 1901092,
        "kodeKABUPATEN": 1901,
        "namaKECAMATAN": "BAKAM"
      },
      {
        "kodeKECAMATAN": 1901130,
        "kodeKABUPATEN": 1901,
        "namaKECAMATAN": "BELINYU"
      },
      {
        "kodeKECAMATAN": 1901131,
        "kodeKABUPATEN": 1901,
        "namaKECAMATAN": "RIAU SILIP"
      },
      {
        "kodeKECAMATAN": 1902010,
        "kodeKABUPATEN": 1902,
        "namaKECAMATAN": "MEMBALONG"
      },
      {
        "kodeKECAMATAN": 1902060,
        "kodeKABUPATEN": 1902,
        "namaKECAMATAN": "TANJUNG PANDAN"
      },
      {
        "kodeKECAMATAN": 1902061,
        "kodeKABUPATEN": 1902,
        "namaKECAMATAN": "BADAU"
      },
      {
        "kodeKECAMATAN": 1902062,
        "kodeKABUPATEN": 1902,
        "namaKECAMATAN": "SIJUK"
      },
      {
        "kodeKECAMATAN": 1902063,
        "kodeKABUPATEN": 1902,
        "namaKECAMATAN": "SELAT NASIK"
      },
      {
        "kodeKECAMATAN": 1903010,
        "kodeKABUPATEN": 1903,
        "namaKECAMATAN": "KELAPA"
      },
      {
        "kodeKECAMATAN": 1903020,
        "kodeKABUPATEN": 1903,
        "namaKECAMATAN": "TEMPILANG"
      },
      {
        "kodeKECAMATAN": 1903030,
        "kodeKABUPATEN": 1903,
        "namaKECAMATAN": "MENTOK"
      },
      {
        "kodeKECAMATAN": 1903040,
        "kodeKABUPATEN": 1903,
        "namaKECAMATAN": "SIMPANG TERITIP"
      },
      {
        "kodeKECAMATAN": 1903050,
        "kodeKABUPATEN": 1903,
        "namaKECAMATAN": "JEBUS"
      },
      {
        "kodeKECAMATAN": 1903051,
        "kodeKABUPATEN": 1903,
        "namaKECAMATAN": "PARITTIGA"
      },
      {
        "kodeKECAMATAN": 1904010,
        "kodeKABUPATEN": 1904,
        "namaKECAMATAN": "KOBA"
      },
      {
        "kodeKECAMATAN": 1904011,
        "kodeKABUPATEN": 1904,
        "namaKECAMATAN": "LUBUK BESAR"
      },
      {
        "kodeKECAMATAN": 1904020,
        "kodeKABUPATEN": 1904,
        "namaKECAMATAN": "PANGKALAN BARU"
      },
      {
        "kodeKECAMATAN": 1904021,
        "kodeKABUPATEN": 1904,
        "namaKECAMATAN": "NAMANG"
      },
      {
        "kodeKECAMATAN": 1904030,
        "kodeKABUPATEN": 1904,
        "namaKECAMATAN": "SUNGAI SELAN"
      },
      {
        "kodeKECAMATAN": 1904040,
        "kodeKABUPATEN": 1904,
        "namaKECAMATAN": "SIMPANG KATIS"
      },
      {
        "kodeKECAMATAN": 1905010,
        "kodeKABUPATEN": 1905,
        "namaKECAMATAN": "PAYUNG"
      },
      {
        "kodeKECAMATAN": 1905011,
        "kodeKABUPATEN": 1905,
        "namaKECAMATAN": "PULAU BESAR"
      },
      {
        "kodeKECAMATAN": 1905020,
        "kodeKABUPATEN": 1905,
        "namaKECAMATAN": "SIMPANG RIMBA"
      },
      {
        "kodeKECAMATAN": 1905030,
        "kodeKABUPATEN": 1905,
        "namaKECAMATAN": "TOBOALI"
      },
      {
        "kodeKECAMATAN": 1905031,
        "kodeKABUPATEN": 1905,
        "namaKECAMATAN": "TUKAK SADAI"
      },
      {
        "kodeKECAMATAN": 1905040,
        "kodeKABUPATEN": 1905,
        "namaKECAMATAN": "AIR GEGAS"
      },
      {
        "kodeKECAMATAN": 1905050,
        "kodeKABUPATEN": 1905,
        "namaKECAMATAN": "LEPAR PONGOK"
      },
      {
        "kodeKECAMATAN": 1905051,
        "kodeKABUPATEN": 1905,
        "namaKECAMATAN": "KEPULAUAN PONGOK"
      },
      {
        "kodeKECAMATAN": 1906010,
        "kodeKABUPATEN": 1906,
        "namaKECAMATAN": "DENDANG"
      },
      {
        "kodeKECAMATAN": 1906011,
        "kodeKABUPATEN": 1906,
        "namaKECAMATAN": "SIMPANG PESAK"
      },
      {
        "kodeKECAMATAN": 1906020,
        "kodeKABUPATEN": 1906,
        "namaKECAMATAN": "GANTUNG"
      },
      {
        "kodeKECAMATAN": 1906021,
        "kodeKABUPATEN": 1906,
        "namaKECAMATAN": "SIMPANG RENGGIANG"
      },
      {
        "kodeKECAMATAN": 1906030,
        "kodeKABUPATEN": 1906,
        "namaKECAMATAN": "MANGGAR"
      },
      {
        "kodeKECAMATAN": 1906031,
        "kodeKABUPATEN": 1906,
        "namaKECAMATAN": "DAMAR"
      },
      {
        "kodeKECAMATAN": 1906040,
        "kodeKABUPATEN": 1906,
        "namaKECAMATAN": "KELAPA KAMPIT"
      },
      {
        "kodeKECAMATAN": 1971010,
        "kodeKABUPATEN": 1971,
        "namaKECAMATAN": "RANGKUI"
      },
      {
        "kodeKECAMATAN": 1971020,
        "kodeKABUPATEN": 1971,
        "namaKECAMATAN": "BUKIT INTAN"
      },
      {
        "kodeKECAMATAN": 1971021,
        "kodeKABUPATEN": 1971,
        "namaKECAMATAN": "GIRIMAYA"
      },
      {
        "kodeKECAMATAN": 1971030,
        "kodeKABUPATEN": 1971,
        "namaKECAMATAN": "PANGKAL BALAM"
      },
      {
        "kodeKECAMATAN": 1971031,
        "kodeKABUPATEN": 1971,
        "namaKECAMATAN": "GABEK"
      },
      {
        "kodeKECAMATAN": 1971040,
        "kodeKABUPATEN": 1971,
        "namaKECAMATAN": "TAMAN SARI"
      },
      {
        "kodeKECAMATAN": 1971041,
        "kodeKABUPATEN": 1971,
        "namaKECAMATAN": "GERUNGGANG"
      },
      {
        "kodeKECAMATAN": 2101010,
        "kodeKABUPATEN": 2101,
        "namaKECAMATAN": "MORO"
      },
      {
        "kodeKECAMATAN": 2101011,
        "kodeKABUPATEN": 2101,
        "namaKECAMATAN": "DURAI"
      },
      {
        "kodeKECAMATAN": 2101020,
        "kodeKABUPATEN": 2101,
        "namaKECAMATAN": "KUNDUR"
      },
      {
        "kodeKECAMATAN": 2101021,
        "kodeKABUPATEN": 2101,
        "namaKECAMATAN": "KUNDUR UTARA"
      },
      {
        "kodeKECAMATAN": 2101022,
        "kodeKABUPATEN": 2101,
        "namaKECAMATAN": "KUNDUR BARAT"
      },
      {
        "kodeKECAMATAN": 2101023,
        "kodeKABUPATEN": 2101,
        "namaKECAMATAN": "UNGAR"
      },
      {
        "kodeKECAMATAN": 2101024,
        "kodeKABUPATEN": 2101,
        "namaKECAMATAN": "BELAT"
      },
      {
        "kodeKECAMATAN": 2101030,
        "kodeKABUPATEN": 2101,
        "namaKECAMATAN": "KARIMUN"
      },
      {
        "kodeKECAMATAN": 2101031,
        "kodeKABUPATEN": 2101,
        "namaKECAMATAN": "BURU"
      },
      {
        "kodeKECAMATAN": 2101032,
        "kodeKABUPATEN": 2101,
        "namaKECAMATAN": "MERAL"
      },
      {
        "kodeKECAMATAN": 2101033,
        "kodeKABUPATEN": 2101,
        "namaKECAMATAN": "TEBING"
      },
      {
        "kodeKECAMATAN": 2101034,
        "kodeKABUPATEN": 2101,
        "namaKECAMATAN": "MERAL BARAT"
      },
      {
        "kodeKECAMATAN": 2102040,
        "kodeKABUPATEN": 2102,
        "namaKECAMATAN": "TELUK BINTAN"
      },
      {
        "kodeKECAMATAN": 2102050,
        "kodeKABUPATEN": 2102,
        "namaKECAMATAN": "BINTAN UTARA"
      },
      {
        "kodeKECAMATAN": 2102051,
        "kodeKABUPATEN": 2102,
        "namaKECAMATAN": "TELUK SEBONG"
      },
      {
        "kodeKECAMATAN": 2102052,
        "kodeKABUPATEN": 2102,
        "namaKECAMATAN": "SERI KUALA LOBAM"
      },
      {
        "kodeKECAMATAN": 2102060,
        "kodeKABUPATEN": 2102,
        "namaKECAMATAN": "BINTAN TIMUR"
      },
      {
        "kodeKECAMATAN": 2102061,
        "kodeKABUPATEN": 2102,
        "namaKECAMATAN": "GUNUNG KIJANG"
      },
      {
        "kodeKECAMATAN": 2102062,
        "kodeKABUPATEN": 2102,
        "namaKECAMATAN": "MANTANG"
      },
      {
        "kodeKECAMATAN": 2102063,
        "kodeKABUPATEN": 2102,
        "namaKECAMATAN": "BINTAN PESISIR"
      },
      {
        "kodeKECAMATAN": 2102064,
        "kodeKABUPATEN": 2102,
        "namaKECAMATAN": "TOAPAYA"
      },
      {
        "kodeKECAMATAN": 2102070,
        "kodeKABUPATEN": 2102,
        "namaKECAMATAN": "TAMBELAN"
      },
      {
        "kodeKECAMATAN": 2103030,
        "kodeKABUPATEN": 2103,
        "namaKECAMATAN": "MIDAI"
      },
      {
        "kodeKECAMATAN": 2103040,
        "kodeKABUPATEN": 2103,
        "namaKECAMATAN": "BUNGURAN BARAT"
      },
      {
        "kodeKECAMATAN": 2103041,
        "kodeKABUPATEN": 2103,
        "namaKECAMATAN": "BUNGURAN UTARA"
      },
      {
        "kodeKECAMATAN": 2103042,
        "kodeKABUPATEN": 2103,
        "namaKECAMATAN": "PULAU LAUT"
      },
      {
        "kodeKECAMATAN": 2103043,
        "kodeKABUPATEN": 2103,
        "namaKECAMATAN": "PULAU TIGA"
      },
      {
        "kodeKECAMATAN": 2103050,
        "kodeKABUPATEN": 2103,
        "namaKECAMATAN": "BUNGURAN TIMUR"
      },
      {
        "kodeKECAMATAN": 2103051,
        "kodeKABUPATEN": 2103,
        "namaKECAMATAN": "BUNGURAN TIMUR LAUT"
      },
      {
        "kodeKECAMATAN": 2103052,
        "kodeKABUPATEN": 2103,
        "namaKECAMATAN": "BUNGURAN TENGAH"
      },
      {
        "kodeKECAMATAN": 2103053,
        "kodeKABUPATEN": 2103,
        "namaKECAMATAN": "BUNGURAN SELATAN"
      },
      {
        "kodeKECAMATAN": 2103060,
        "kodeKABUPATEN": 2103,
        "namaKECAMATAN": "SERASAN"
      },
      {
        "kodeKECAMATAN": 2103061,
        "kodeKABUPATEN": 2103,
        "namaKECAMATAN": "SUBI"
      },
      {
        "kodeKECAMATAN": 2103062,
        "kodeKABUPATEN": 2103,
        "namaKECAMATAN": "SERASAN TIMUR"
      },
      {
        "kodeKECAMATAN": 2104010,
        "kodeKABUPATEN": 2104,
        "namaKECAMATAN": "SINGKEP BARAT"
      },
      {
        "kodeKECAMATAN": 2104020,
        "kodeKABUPATEN": 2104,
        "namaKECAMATAN": "SINGKEP"
      },
      {
        "kodeKECAMATAN": 2104021,
        "kodeKABUPATEN": 2104,
        "namaKECAMATAN": "SINGKEP SELATAN"
      },
      {
        "kodeKECAMATAN": 2104022,
        "kodeKABUPATEN": 2104,
        "namaKECAMATAN": "SINGKEP PESISIR"
      },
      {
        "kodeKECAMATAN": 2104030,
        "kodeKABUPATEN": 2104,
        "namaKECAMATAN": "LINGGA"
      },
      {
        "kodeKECAMATAN": 2104031,
        "kodeKABUPATEN": 2104,
        "namaKECAMATAN": "SELAYAR"
      },
      {
        "kodeKECAMATAN": 2104032,
        "kodeKABUPATEN": 2104,
        "namaKECAMATAN": "LINGGA TIMUR"
      },
      {
        "kodeKECAMATAN": 2104040,
        "kodeKABUPATEN": 2104,
        "namaKECAMATAN": "LINGGA UTARA"
      },
      {
        "kodeKECAMATAN": 2104050,
        "kodeKABUPATEN": 2104,
        "namaKECAMATAN": "SENAYANG"
      },
      {
        "kodeKECAMATAN": 2105010,
        "kodeKABUPATEN": 2105,
        "namaKECAMATAN": "JEMAJA"
      },
      {
        "kodeKECAMATAN": 2105020,
        "kodeKABUPATEN": 2105,
        "namaKECAMATAN": "JEMAJA TIMUR"
      },
      {
        "kodeKECAMATAN": 2105030,
        "kodeKABUPATEN": 2105,
        "namaKECAMATAN": "SIANTAN SELATAN"
      },
      {
        "kodeKECAMATAN": 2105040,
        "kodeKABUPATEN": 2105,
        "namaKECAMATAN": "SIANTAN"
      },
      {
        "kodeKECAMATAN": 2105050,
        "kodeKABUPATEN": 2105,
        "namaKECAMATAN": "SIANTAN TIMUR"
      },
      {
        "kodeKECAMATAN": 2105060,
        "kodeKABUPATEN": 2105,
        "namaKECAMATAN": "SIANTAN TENGAH"
      },
      {
        "kodeKECAMATAN": 2105070,
        "kodeKABUPATEN": 2105,
        "namaKECAMATAN": "PALMATAK"
      },
      {
        "kodeKECAMATAN": 2171010,
        "kodeKABUPATEN": 2171,
        "namaKECAMATAN": "BELAKANG PADANG"
      },
      {
        "kodeKECAMATAN": 2171020,
        "kodeKABUPATEN": 2171,
        "namaKECAMATAN": "BULANG"
      },
      {
        "kodeKECAMATAN": 2171030,
        "kodeKABUPATEN": 2171,
        "namaKECAMATAN": "GALANG"
      },
      {
        "kodeKECAMATAN": 2171040,
        "kodeKABUPATEN": 2171,
        "namaKECAMATAN": "SEI BEDUK"
      },
      {
        "kodeKECAMATAN": 2171041,
        "kodeKABUPATEN": 2171,
        "namaKECAMATAN": "SAGULUNG"
      },
      {
        "kodeKECAMATAN": 2171050,
        "kodeKABUPATEN": 2171,
        "namaKECAMATAN": "NONGSA"
      },
      {
        "kodeKECAMATAN": 2171051,
        "kodeKABUPATEN": 2171,
        "namaKECAMATAN": "BATAM KOTA"
      },
      {
        "kodeKECAMATAN": 2171060,
        "kodeKABUPATEN": 2171,
        "namaKECAMATAN": "SEKUPANG"
      },
      {
        "kodeKECAMATAN": 2171061,
        "kodeKABUPATEN": 2171,
        "namaKECAMATAN": "BATU AJI"
      },
      {
        "kodeKECAMATAN": 2171070,
        "kodeKABUPATEN": 2171,
        "namaKECAMATAN": "LUBUK BAJA"
      },
      {
        "kodeKECAMATAN": 2171080,
        "kodeKABUPATEN": 2171,
        "namaKECAMATAN": "BATU AMPAR"
      },
      {
        "kodeKECAMATAN": 2171081,
        "kodeKABUPATEN": 2171,
        "namaKECAMATAN": "BENGKONG"
      },
      {
        "kodeKECAMATAN": 2172010,
        "kodeKABUPATEN": 2172,
        "namaKECAMATAN": "BUKIT BESTARI"
      },
      {
        "kodeKECAMATAN": 2172020,
        "kodeKABUPATEN": 2172,
        "namaKECAMATAN": "TANJUNGPINANG TIMUR"
      },
      {
        "kodeKECAMATAN": 2172030,
        "kodeKABUPATEN": 2172,
        "namaKECAMATAN": "TANJUNGPINANG KOTA"
      },
      {
        "kodeKECAMATAN": 2172040,
        "kodeKABUPATEN": 2172,
        "namaKECAMATAN": "TANJUNGPINANG BARAT"
      },
      {
        "kodeKECAMATAN": 3101010,
        "kodeKABUPATEN": 3101,
        "namaKECAMATAN": "KEPULAUAN SERIBU SELATAN"
      },
      {
        "kodeKECAMATAN": 3101020,
        "kodeKABUPATEN": 3101,
        "namaKECAMATAN": "KEPULAUAN SERIBU UTARA"
      },
      {
        "kodeKECAMATAN": 3171010,
        "kodeKABUPATEN": 3171,
        "namaKECAMATAN": "JAGAKARSA"
      },
      {
        "kodeKECAMATAN": 3171020,
        "kodeKABUPATEN": 3171,
        "namaKECAMATAN": "PASAR MINGGU"
      },
      {
        "kodeKECAMATAN": 3171030,
        "kodeKABUPATEN": 3171,
        "namaKECAMATAN": "CILANDAK"
      },
      {
        "kodeKECAMATAN": 3171040,
        "kodeKABUPATEN": 3171,
        "namaKECAMATAN": "PESANGGRAHAN"
      },
      {
        "kodeKECAMATAN": 3171050,
        "kodeKABUPATEN": 3171,
        "namaKECAMATAN": "KEBAYORAN LAMA"
      },
      {
        "kodeKECAMATAN": 3171060,
        "kodeKABUPATEN": 3171,
        "namaKECAMATAN": "KEBAYORAN BARU"
      },
      {
        "kodeKECAMATAN": 3171070,
        "kodeKABUPATEN": 3171,
        "namaKECAMATAN": "MAMPANG PRAPATAN"
      },
      {
        "kodeKECAMATAN": 3171080,
        "kodeKABUPATEN": 3171,
        "namaKECAMATAN": "PANCORAN"
      },
      {
        "kodeKECAMATAN": 3171090,
        "kodeKABUPATEN": 3171,
        "namaKECAMATAN": "TEBET"
      },
      {
        "kodeKECAMATAN": 3171100,
        "kodeKABUPATEN": 3171,
        "namaKECAMATAN": "SETIA BUDI"
      },
      {
        "kodeKECAMATAN": 3172010,
        "kodeKABUPATEN": 3172,
        "namaKECAMATAN": "PASAR REBO"
      },
      {
        "kodeKECAMATAN": 3172020,
        "kodeKABUPATEN": 3172,
        "namaKECAMATAN": "CIRACAS"
      },
      {
        "kodeKECAMATAN": 3172030,
        "kodeKABUPATEN": 3172,
        "namaKECAMATAN": "CIPAYUNG"
      },
      {
        "kodeKECAMATAN": 3172040,
        "kodeKABUPATEN": 3172,
        "namaKECAMATAN": "MAKASAR"
      },
      {
        "kodeKECAMATAN": 3172050,
        "kodeKABUPATEN": 3172,
        "namaKECAMATAN": "KRAMAT JATI"
      },
      {
        "kodeKECAMATAN": 3172060,
        "kodeKABUPATEN": 3172,
        "namaKECAMATAN": "JATINEGARA"
      },
      {
        "kodeKECAMATAN": 3172070,
        "kodeKABUPATEN": 3172,
        "namaKECAMATAN": "DUREN SAWIT"
      },
      {
        "kodeKECAMATAN": 3172080,
        "kodeKABUPATEN": 3172,
        "namaKECAMATAN": "CAKUNG"
      },
      {
        "kodeKECAMATAN": 3172090,
        "kodeKABUPATEN": 3172,
        "namaKECAMATAN": "PULO GADUNG"
      },
      {
        "kodeKECAMATAN": 3172100,
        "kodeKABUPATEN": 3172,
        "namaKECAMATAN": "MATRAMAN"
      },
      {
        "kodeKECAMATAN": 3173010,
        "kodeKABUPATEN": 3173,
        "namaKECAMATAN": "TANAH ABANG"
      },
      {
        "kodeKECAMATAN": 3173020,
        "kodeKABUPATEN": 3173,
        "namaKECAMATAN": "MENTENG"
      },
      {
        "kodeKECAMATAN": 3173030,
        "kodeKABUPATEN": 3173,
        "namaKECAMATAN": "SENEN"
      },
      {
        "kodeKECAMATAN": 3173040,
        "kodeKABUPATEN": 3173,
        "namaKECAMATAN": "JOHAR BARU"
      },
      {
        "kodeKECAMATAN": 3173050,
        "kodeKABUPATEN": 3173,
        "namaKECAMATAN": "CEMPAKA PUTIH"
      },
      {
        "kodeKECAMATAN": 3173060,
        "kodeKABUPATEN": 3173,
        "namaKECAMATAN": "KEMAYORAN"
      },
      {
        "kodeKECAMATAN": 3173070,
        "kodeKABUPATEN": 3173,
        "namaKECAMATAN": "SAWAH BESAR"
      },
      {
        "kodeKECAMATAN": 3173080,
        "kodeKABUPATEN": 3173,
        "namaKECAMATAN": "GAMBIR"
      },
      {
        "kodeKECAMATAN": 3174010,
        "kodeKABUPATEN": 3174,
        "namaKECAMATAN": "KEMBANGAN"
      },
      {
        "kodeKECAMATAN": 3174020,
        "kodeKABUPATEN": 3174,
        "namaKECAMATAN": "KEBON JERUK"
      },
      {
        "kodeKECAMATAN": 3174030,
        "kodeKABUPATEN": 3174,
        "namaKECAMATAN": "PALMERAH"
      },
      {
        "kodeKECAMATAN": 3174040,
        "kodeKABUPATEN": 3174,
        "namaKECAMATAN": "GROGOL PETAMBURAN"
      },
      {
        "kodeKECAMATAN": 3174050,
        "kodeKABUPATEN": 3174,
        "namaKECAMATAN": "TAMBORA"
      },
      {
        "kodeKECAMATAN": 3174060,
        "kodeKABUPATEN": 3174,
        "namaKECAMATAN": "TAMAN SARI"
      },
      {
        "kodeKECAMATAN": 3174070,
        "kodeKABUPATEN": 3174,
        "namaKECAMATAN": "CENGKARENG"
      },
      {
        "kodeKECAMATAN": 3174080,
        "kodeKABUPATEN": 3174,
        "namaKECAMATAN": "KALI DERES"
      },
      {
        "kodeKECAMATAN": 3175010,
        "kodeKABUPATEN": 3175,
        "namaKECAMATAN": "PENJARINGAN"
      },
      {
        "kodeKECAMATAN": 3175020,
        "kodeKABUPATEN": 3175,
        "namaKECAMATAN": "PADEMANGAN"
      },
      {
        "kodeKECAMATAN": 3175030,
        "kodeKABUPATEN": 3175,
        "namaKECAMATAN": "TANJUNG PRIOK"
      },
      {
        "kodeKECAMATAN": 3175040,
        "kodeKABUPATEN": 3175,
        "namaKECAMATAN": "KOJA"
      },
      {
        "kodeKECAMATAN": 3175050,
        "kodeKABUPATEN": 3175,
        "namaKECAMATAN": "KELAPA GADING"
      },
      {
        "kodeKECAMATAN": 3175060,
        "kodeKABUPATEN": 3175,
        "namaKECAMATAN": "CILINCING"
      },
      {
        "kodeKECAMATAN": 3201010,
        "kodeKABUPATEN": 3201,
        "namaKECAMATAN": "NANGGUNG"
      },
      {
        "kodeKECAMATAN": 3201020,
        "kodeKABUPATEN": 3201,
        "namaKECAMATAN": "LEUWILIANG"
      },
      {
        "kodeKECAMATAN": 3201021,
        "kodeKABUPATEN": 3201,
        "namaKECAMATAN": "LEUWISADENG"
      },
      {
        "kodeKECAMATAN": 3201030,
        "kodeKABUPATEN": 3201,
        "namaKECAMATAN": "PAMIJAHAN"
      },
      {
        "kodeKECAMATAN": 3201040,
        "kodeKABUPATEN": 3201,
        "namaKECAMATAN": "CIBUNGBULANG"
      },
      {
        "kodeKECAMATAN": 3201050,
        "kodeKABUPATEN": 3201,
        "namaKECAMATAN": "CIAMPEA"
      },
      {
        "kodeKECAMATAN": 3201051,
        "kodeKABUPATEN": 3201,
        "namaKECAMATAN": "TENJOLAYA"
      },
      {
        "kodeKECAMATAN": 3201060,
        "kodeKABUPATEN": 3201,
        "namaKECAMATAN": "DRAMAGA"
      },
      {
        "kodeKECAMATAN": 3201070,
        "kodeKABUPATEN": 3201,
        "namaKECAMATAN": "CIOMAS"
      },
      {
        "kodeKECAMATAN": 3201071,
        "kodeKABUPATEN": 3201,
        "namaKECAMATAN": "TAMANSARI"
      },
      {
        "kodeKECAMATAN": 3201080,
        "kodeKABUPATEN": 3201,
        "namaKECAMATAN": "CIJERUK"
      },
      {
        "kodeKECAMATAN": 3201081,
        "kodeKABUPATEN": 3201,
        "namaKECAMATAN": "CIGOMBONG"
      },
      {
        "kodeKECAMATAN": 3201090,
        "kodeKABUPATEN": 3201,
        "namaKECAMATAN": "CARINGIN"
      },
      {
        "kodeKECAMATAN": 3201100,
        "kodeKABUPATEN": 3201,
        "namaKECAMATAN": "CIAWI"
      },
      {
        "kodeKECAMATAN": 3201110,
        "kodeKABUPATEN": 3201,
        "namaKECAMATAN": "CISARUA"
      },
      {
        "kodeKECAMATAN": 3201120,
        "kodeKABUPATEN": 3201,
        "namaKECAMATAN": "MEGAMENDUNG"
      },
      {
        "kodeKECAMATAN": 3201130,
        "kodeKABUPATEN": 3201,
        "namaKECAMATAN": "SUKARAJA"
      },
      {
        "kodeKECAMATAN": 3201140,
        "kodeKABUPATEN": 3201,
        "namaKECAMATAN": "BABAKAN MADANG"
      },
      {
        "kodeKECAMATAN": 3201150,
        "kodeKABUPATEN": 3201,
        "namaKECAMATAN": "SUKAMAKMUR"
      },
      {
        "kodeKECAMATAN": 3201160,
        "kodeKABUPATEN": 3201,
        "namaKECAMATAN": "CARIU"
      },
      {
        "kodeKECAMATAN": 3201161,
        "kodeKABUPATEN": 3201,
        "namaKECAMATAN": "TANJUNGSARI"
      },
      {
        "kodeKECAMATAN": 3201170,
        "kodeKABUPATEN": 3201,
        "namaKECAMATAN": "JONGGOL"
      },
      {
        "kodeKECAMATAN": 3201180,
        "kodeKABUPATEN": 3201,
        "namaKECAMATAN": "CILEUNGSI"
      },
      {
        "kodeKECAMATAN": 3201181,
        "kodeKABUPATEN": 3201,
        "namaKECAMATAN": "KELAPA NUNGGAL"
      },
      {
        "kodeKECAMATAN": 3201190,
        "kodeKABUPATEN": 3201,
        "namaKECAMATAN": "GUNUNG PUTRI"
      },
      {
        "kodeKECAMATAN": 3201200,
        "kodeKABUPATEN": 3201,
        "namaKECAMATAN": "CITEUREUP"
      },
      {
        "kodeKECAMATAN": 3201210,
        "kodeKABUPATEN": 3201,
        "namaKECAMATAN": "CIBINONG"
      },
      {
        "kodeKECAMATAN": 3201220,
        "kodeKABUPATEN": 3201,
        "namaKECAMATAN": "BOJONG GEDE"
      },
      {
        "kodeKECAMATAN": 3201221,
        "kodeKABUPATEN": 3201,
        "namaKECAMATAN": "TAJUR HALANG"
      },
      {
        "kodeKECAMATAN": 3201230,
        "kodeKABUPATEN": 3201,
        "namaKECAMATAN": "KEMANG"
      },
      {
        "kodeKECAMATAN": 3201231,
        "kodeKABUPATEN": 3201,
        "namaKECAMATAN": "RANCA BUNGUR"
      },
      {
        "kodeKECAMATAN": 3201240,
        "kodeKABUPATEN": 3201,
        "namaKECAMATAN": "PARUNG"
      },
      {
        "kodeKECAMATAN": 3201241,
        "kodeKABUPATEN": 3201,
        "namaKECAMATAN": "CISEENG"
      },
      {
        "kodeKECAMATAN": 3201250,
        "kodeKABUPATEN": 3201,
        "namaKECAMATAN": "GUNUNG SINDUR"
      },
      {
        "kodeKECAMATAN": 3201260,
        "kodeKABUPATEN": 3201,
        "namaKECAMATAN": "RUMPIN"
      },
      {
        "kodeKECAMATAN": 3201270,
        "kodeKABUPATEN": 3201,
        "namaKECAMATAN": "CIGUDEG"
      },
      {
        "kodeKECAMATAN": 3201271,
        "kodeKABUPATEN": 3201,
        "namaKECAMATAN": "SUKAJAYA"
      },
      {
        "kodeKECAMATAN": 3201280,
        "kodeKABUPATEN": 3201,
        "namaKECAMATAN": "JASINGA"
      },
      {
        "kodeKECAMATAN": 3201290,
        "kodeKABUPATEN": 3201,
        "namaKECAMATAN": "TENJO"
      },
      {
        "kodeKECAMATAN": 3201300,
        "kodeKABUPATEN": 3201,
        "namaKECAMATAN": "PARUNG PANJANG"
      },
      {
        "kodeKECAMATAN": 3202010,
        "kodeKABUPATEN": 3202,
        "namaKECAMATAN": "CIEMAS"
      },
      {
        "kodeKECAMATAN": 3202020,
        "kodeKABUPATEN": 3202,
        "namaKECAMATAN": "CIRACAP"
      },
      {
        "kodeKECAMATAN": 3202021,
        "kodeKABUPATEN": 3202,
        "namaKECAMATAN": "WALURAN"
      },
      {
        "kodeKECAMATAN": 3202030,
        "kodeKABUPATEN": 3202,
        "namaKECAMATAN": "SURADE"
      },
      {
        "kodeKECAMATAN": 3202031,
        "kodeKABUPATEN": 3202,
        "namaKECAMATAN": "CIBITUNG"
      },
      {
        "kodeKECAMATAN": 3202040,
        "kodeKABUPATEN": 3202,
        "namaKECAMATAN": "JAMPANG KULON"
      },
      {
        "kodeKECAMATAN": 3202041,
        "kodeKABUPATEN": 3202,
        "namaKECAMATAN": "CIMANGGU"
      },
      {
        "kodeKECAMATAN": 3202050,
        "kodeKABUPATEN": 3202,
        "namaKECAMATAN": "KALI BUNDER"
      },
      {
        "kodeKECAMATAN": 3202060,
        "kodeKABUPATEN": 3202,
        "namaKECAMATAN": "TEGAL BULEUD"
      },
      {
        "kodeKECAMATAN": 3202070,
        "kodeKABUPATEN": 3202,
        "namaKECAMATAN": "CIDOLOG"
      },
      {
        "kodeKECAMATAN": 3202080,
        "kodeKABUPATEN": 3202,
        "namaKECAMATAN": "SAGARANTEN"
      },
      {
        "kodeKECAMATAN": 3202081,
        "kodeKABUPATEN": 3202,
        "namaKECAMATAN": "CIDADAP"
      },
      {
        "kodeKECAMATAN": 3202082,
        "kodeKABUPATEN": 3202,
        "namaKECAMATAN": "CURUGKEMBAR"
      },
      {
        "kodeKECAMATAN": 3202090,
        "kodeKABUPATEN": 3202,
        "namaKECAMATAN": "PABUARAN"
      },
      {
        "kodeKECAMATAN": 3202100,
        "kodeKABUPATEN": 3202,
        "namaKECAMATAN": "LENGKONG"
      },
      {
        "kodeKECAMATAN": 3202110,
        "kodeKABUPATEN": 3202,
        "namaKECAMATAN": "PALABUHANRATU"
      },
      {
        "kodeKECAMATAN": 3202111,
        "kodeKABUPATEN": 3202,
        "namaKECAMATAN": "SIMPENAN"
      },
      {
        "kodeKECAMATAN": 3202120,
        "kodeKABUPATEN": 3202,
        "namaKECAMATAN": "WARUNG KIARA"
      },
      {
        "kodeKECAMATAN": 3202121,
        "kodeKABUPATEN": 3202,
        "namaKECAMATAN": "BANTARGADUNG"
      },
      {
        "kodeKECAMATAN": 3202130,
        "kodeKABUPATEN": 3202,
        "namaKECAMATAN": "JAMPANG TENGAH"
      },
      {
        "kodeKECAMATAN": 3202131,
        "kodeKABUPATEN": 3202,
        "namaKECAMATAN": "PURABAYA"
      },
      {
        "kodeKECAMATAN": 3202140,
        "kodeKABUPATEN": 3202,
        "namaKECAMATAN": "CIKEMBAR"
      },
      {
        "kodeKECAMATAN": 3202150,
        "kodeKABUPATEN": 3202,
        "namaKECAMATAN": "NYALINDUNG"
      },
      {
        "kodeKECAMATAN": 3202160,
        "kodeKABUPATEN": 3202,
        "namaKECAMATAN": "GEGER BITUNG"
      },
      {
        "kodeKECAMATAN": 3202170,
        "kodeKABUPATEN": 3202,
        "namaKECAMATAN": "SUKARAJA"
      },
      {
        "kodeKECAMATAN": 3202171,
        "kodeKABUPATEN": 3202,
        "namaKECAMATAN": "KEBONPEDES"
      },
      {
        "kodeKECAMATAN": 3202172,
        "kodeKABUPATEN": 3202,
        "namaKECAMATAN": "CIREUNGHAS"
      },
      {
        "kodeKECAMATAN": 3202173,
        "kodeKABUPATEN": 3202,
        "namaKECAMATAN": "SUKALARANG"
      },
      {
        "kodeKECAMATAN": 3202180,
        "kodeKABUPATEN": 3202,
        "namaKECAMATAN": "SUKABUMI"
      },
      {
        "kodeKECAMATAN": 3202190,
        "kodeKABUPATEN": 3202,
        "namaKECAMATAN": "KADUDAMPIT"
      },
      {
        "kodeKECAMATAN": 3202200,
        "kodeKABUPATEN": 3202,
        "namaKECAMATAN": "CISAAT"
      },
      {
        "kodeKECAMATAN": 3202201,
        "kodeKABUPATEN": 3202,
        "namaKECAMATAN": "GUNUNGGURUH"
      },
      {
        "kodeKECAMATAN": 3202210,
        "kodeKABUPATEN": 3202,
        "namaKECAMATAN": "CIBADAK"
      },
      {
        "kodeKECAMATAN": 3202211,
        "kodeKABUPATEN": 3202,
        "namaKECAMATAN": "CICANTAYAN"
      },
      {
        "kodeKECAMATAN": 3202212,
        "kodeKABUPATEN": 3202,
        "namaKECAMATAN": "CARINGIN"
      },
      {
        "kodeKECAMATAN": 3202220,
        "kodeKABUPATEN": 3202,
        "namaKECAMATAN": "NAGRAK"
      },
      {
        "kodeKECAMATAN": 3202221,
        "kodeKABUPATEN": 3202,
        "namaKECAMATAN": "CIAMBAR"
      },
      {
        "kodeKECAMATAN": 3202230,
        "kodeKABUPATEN": 3202,
        "namaKECAMATAN": "CICURUG"
      },
      {
        "kodeKECAMATAN": 3202240,
        "kodeKABUPATEN": 3202,
        "namaKECAMATAN": "CIDAHU"
      },
      {
        "kodeKECAMATAN": 3202250,
        "kodeKABUPATEN": 3202,
        "namaKECAMATAN": "PARAKAN SALAK"
      },
      {
        "kodeKECAMATAN": 3202260,
        "kodeKABUPATEN": 3202,
        "namaKECAMATAN": "PARUNG KUDA"
      },
      {
        "kodeKECAMATAN": 3202261,
        "kodeKABUPATEN": 3202,
        "namaKECAMATAN": "BOJONG GENTENG"
      },
      {
        "kodeKECAMATAN": 3202270,
        "kodeKABUPATEN": 3202,
        "namaKECAMATAN": "KALAPA NUNGGAL"
      },
      {
        "kodeKECAMATAN": 3202280,
        "kodeKABUPATEN": 3202,
        "namaKECAMATAN": "CIKIDANG"
      },
      {
        "kodeKECAMATAN": 3202290,
        "kodeKABUPATEN": 3202,
        "namaKECAMATAN": "CISOLOK"
      },
      {
        "kodeKECAMATAN": 3202291,
        "kodeKABUPATEN": 3202,
        "namaKECAMATAN": "CIKAKAK"
      },
      {
        "kodeKECAMATAN": 3202300,
        "kodeKABUPATEN": 3202,
        "namaKECAMATAN": "KABANDUNGAN"
      },
      {
        "kodeKECAMATAN": 3203010,
        "kodeKABUPATEN": 3203,
        "namaKECAMATAN": "AGRABINTA"
      },
      {
        "kodeKECAMATAN": 3203011,
        "kodeKABUPATEN": 3203,
        "namaKECAMATAN": "LELES"
      },
      {
        "kodeKECAMATAN": 3203020,
        "kodeKABUPATEN": 3203,
        "namaKECAMATAN": "SINDANGBARANG"
      },
      {
        "kodeKECAMATAN": 3203030,
        "kodeKABUPATEN": 3203,
        "namaKECAMATAN": "CIDAUN"
      },
      {
        "kodeKECAMATAN": 3203040,
        "kodeKABUPATEN": 3203,
        "namaKECAMATAN": "NARINGGUL"
      },
      {
        "kodeKECAMATAN": 3203050,
        "kodeKABUPATEN": 3203,
        "namaKECAMATAN": "CIBINONG"
      },
      {
        "kodeKECAMATAN": 3203051,
        "kodeKABUPATEN": 3203,
        "namaKECAMATAN": "CIKADU"
      },
      {
        "kodeKECAMATAN": 3203060,
        "kodeKABUPATEN": 3203,
        "namaKECAMATAN": "TANGGEUNG"
      },
      {
        "kodeKECAMATAN": 3203061,
        "kodeKABUPATEN": 3203,
        "namaKECAMATAN": "PASIRKUDA"
      },
      {
        "kodeKECAMATAN": 3203070,
        "kodeKABUPATEN": 3203,
        "namaKECAMATAN": "KADUPANDAK"
      },
      {
        "kodeKECAMATAN": 3203071,
        "kodeKABUPATEN": 3203,
        "namaKECAMATAN": "CIJATI"
      },
      {
        "kodeKECAMATAN": 3203080,
        "kodeKABUPATEN": 3203,
        "namaKECAMATAN": "TAKOKAK"
      },
      {
        "kodeKECAMATAN": 3203090,
        "kodeKABUPATEN": 3203,
        "namaKECAMATAN": "SUKANAGARA"
      },
      {
        "kodeKECAMATAN": 3203100,
        "kodeKABUPATEN": 3203,
        "namaKECAMATAN": "PAGELARAN"
      },
      {
        "kodeKECAMATAN": 3203110,
        "kodeKABUPATEN": 3203,
        "namaKECAMATAN": "CAMPAKA"
      },
      {
        "kodeKECAMATAN": 3203111,
        "kodeKABUPATEN": 3203,
        "namaKECAMATAN": "CAMPAKA MULYA"
      },
      {
        "kodeKECAMATAN": 3203120,
        "kodeKABUPATEN": 3203,
        "namaKECAMATAN": "CIBEBER"
      },
      {
        "kodeKECAMATAN": 3203130,
        "kodeKABUPATEN": 3203,
        "namaKECAMATAN": "WARUNGKONDANG"
      },
      {
        "kodeKECAMATAN": 3203131,
        "kodeKABUPATEN": 3203,
        "namaKECAMATAN": "GEKBRONG"
      },
      {
        "kodeKECAMATAN": 3203140,
        "kodeKABUPATEN": 3203,
        "namaKECAMATAN": "CILAKU"
      },
      {
        "kodeKECAMATAN": 3203150,
        "kodeKABUPATEN": 3203,
        "namaKECAMATAN": "SUKALUYU"
      },
      {
        "kodeKECAMATAN": 3203160,
        "kodeKABUPATEN": 3203,
        "namaKECAMATAN": "BOJONGPICUNG"
      },
      {
        "kodeKECAMATAN": 3203161,
        "kodeKABUPATEN": 3203,
        "namaKECAMATAN": "HAURWANGI"
      },
      {
        "kodeKECAMATAN": 3203170,
        "kodeKABUPATEN": 3203,
        "namaKECAMATAN": "CIRANJANG"
      },
      {
        "kodeKECAMATAN": 3203180,
        "kodeKABUPATEN": 3203,
        "namaKECAMATAN": "MANDE"
      },
      {
        "kodeKECAMATAN": 3203190,
        "kodeKABUPATEN": 3203,
        "namaKECAMATAN": "KARANGTENGAH"
      },
      {
        "kodeKECAMATAN": 3203200,
        "kodeKABUPATEN": 3203,
        "namaKECAMATAN": "CIANJUR"
      },
      {
        "kodeKECAMATAN": 3203210,
        "kodeKABUPATEN": 3203,
        "namaKECAMATAN": "CUGENANG"
      },
      {
        "kodeKECAMATAN": 3203220,
        "kodeKABUPATEN": 3203,
        "namaKECAMATAN": "PACET"
      },
      {
        "kodeKECAMATAN": 3203221,
        "kodeKABUPATEN": 3203,
        "namaKECAMATAN": "CIPANAS"
      },
      {
        "kodeKECAMATAN": 3203230,
        "kodeKABUPATEN": 3203,
        "namaKECAMATAN": "SUKARESMI"
      },
      {
        "kodeKECAMATAN": 3203240,
        "kodeKABUPATEN": 3203,
        "namaKECAMATAN": "CIKALONGKULON"
      },
      {
        "kodeKECAMATAN": 3204010,
        "kodeKABUPATEN": 3204,
        "namaKECAMATAN": "CIWIDEY"
      },
      {
        "kodeKECAMATAN": 3204011,
        "kodeKABUPATEN": 3204,
        "namaKECAMATAN": "RANCABALI"
      },
      {
        "kodeKECAMATAN": 3204020,
        "kodeKABUPATEN": 3204,
        "namaKECAMATAN": "PASIRJAMBU"
      },
      {
        "kodeKECAMATAN": 3204030,
        "kodeKABUPATEN": 3204,
        "namaKECAMATAN": "CIMAUNG"
      },
      {
        "kodeKECAMATAN": 3204040,
        "kodeKABUPATEN": 3204,
        "namaKECAMATAN": "PANGALENGAN"
      },
      {
        "kodeKECAMATAN": 3204050,
        "kodeKABUPATEN": 3204,
        "namaKECAMATAN": "KERTASARI"
      },
      {
        "kodeKECAMATAN": 3204060,
        "kodeKABUPATEN": 3204,
        "namaKECAMATAN": "PACET"
      },
      {
        "kodeKECAMATAN": 3204070,
        "kodeKABUPATEN": 3204,
        "namaKECAMATAN": "IBUN"
      },
      {
        "kodeKECAMATAN": 3204080,
        "kodeKABUPATEN": 3204,
        "namaKECAMATAN": "PASEH"
      },
      {
        "kodeKECAMATAN": 3204090,
        "kodeKABUPATEN": 3204,
        "namaKECAMATAN": "CIKANCUNG"
      },
      {
        "kodeKECAMATAN": 3204100,
        "kodeKABUPATEN": 3204,
        "namaKECAMATAN": "CICALENGKA"
      },
      {
        "kodeKECAMATAN": 3204101,
        "kodeKABUPATEN": 3204,
        "namaKECAMATAN": "NAGREG"
      },
      {
        "kodeKECAMATAN": 3204110,
        "kodeKABUPATEN": 3204,
        "namaKECAMATAN": "RANCAEKEK"
      },
      {
        "kodeKECAMATAN": 3204120,
        "kodeKABUPATEN": 3204,
        "namaKECAMATAN": "MAJALAYA"
      },
      {
        "kodeKECAMATAN": 3204121,
        "kodeKABUPATEN": 3204,
        "namaKECAMATAN": "SOLOKAN JERUK"
      },
      {
        "kodeKECAMATAN": 3204130,
        "kodeKABUPATEN": 3204,
        "namaKECAMATAN": "CIPARAY"
      },
      {
        "kodeKECAMATAN": 3204140,
        "kodeKABUPATEN": 3204,
        "namaKECAMATAN": "BALEENDAH"
      },
      {
        "kodeKECAMATAN": 3204150,
        "kodeKABUPATEN": 3204,
        "namaKECAMATAN": "ARJASARI"
      },
      {
        "kodeKECAMATAN": 3204160,
        "kodeKABUPATEN": 3204,
        "namaKECAMATAN": "BANJARAN"
      },
      {
        "kodeKECAMATAN": 3204161,
        "kodeKABUPATEN": 3204,
        "namaKECAMATAN": "CANGKUANG"
      },
      {
        "kodeKECAMATAN": 3204170,
        "kodeKABUPATEN": 3204,
        "namaKECAMATAN": "PAMEUNGPEUK"
      },
      {
        "kodeKECAMATAN": 3204180,
        "kodeKABUPATEN": 3204,
        "namaKECAMATAN": "KATAPANG"
      },
      {
        "kodeKECAMATAN": 3204190,
        "kodeKABUPATEN": 3204,
        "namaKECAMATAN": "SOREANG"
      },
      {
        "kodeKECAMATAN": 3204191,
        "kodeKABUPATEN": 3204,
        "namaKECAMATAN": "KUTAWARINGIN"
      },
      {
        "kodeKECAMATAN": 3204250,
        "kodeKABUPATEN": 3204,
        "namaKECAMATAN": "MARGAASIH"
      },
      {
        "kodeKECAMATAN": 3204260,
        "kodeKABUPATEN": 3204,
        "namaKECAMATAN": "MARGAHAYU"
      },
      {
        "kodeKECAMATAN": 3204270,
        "kodeKABUPATEN": 3204,
        "namaKECAMATAN": "DAYEUHKOLOT"
      },
      {
        "kodeKECAMATAN": 3204280,
        "kodeKABUPATEN": 3204,
        "namaKECAMATAN": "BOJONGSOANG"
      },
      {
        "kodeKECAMATAN": 3204290,
        "kodeKABUPATEN": 3204,
        "namaKECAMATAN": "CILEUNYI"
      },
      {
        "kodeKECAMATAN": 3204300,
        "kodeKABUPATEN": 3204,
        "namaKECAMATAN": "CILENGKRANG"
      },
      {
        "kodeKECAMATAN": 3204310,
        "kodeKABUPATEN": 3204,
        "namaKECAMATAN": "CIMENYAN"
      },
      {
        "kodeKECAMATAN": 3205010,
        "kodeKABUPATEN": 3205,
        "namaKECAMATAN": "CISEWU"
      },
      {
        "kodeKECAMATAN": 3205011,
        "kodeKABUPATEN": 3205,
        "namaKECAMATAN": "CARINGIN"
      },
      {
        "kodeKECAMATAN": 3205020,
        "kodeKABUPATEN": 3205,
        "namaKECAMATAN": "TALEGONG"
      },
      {
        "kodeKECAMATAN": 3205030,
        "kodeKABUPATEN": 3205,
        "namaKECAMATAN": "BUNGBULANG"
      },
      {
        "kodeKECAMATAN": 3205031,
        "kodeKABUPATEN": 3205,
        "namaKECAMATAN": "MEKARMUKTI"
      },
      {
        "kodeKECAMATAN": 3205040,
        "kodeKABUPATEN": 3205,
        "namaKECAMATAN": "PAMULIHAN"
      },
      {
        "kodeKECAMATAN": 3205050,
        "kodeKABUPATEN": 3205,
        "namaKECAMATAN": "PAKENJENG"
      },
      {
        "kodeKECAMATAN": 3205060,
        "kodeKABUPATEN": 3205,
        "namaKECAMATAN": "CIKELET"
      },
      {
        "kodeKECAMATAN": 3205070,
        "kodeKABUPATEN": 3205,
        "namaKECAMATAN": "PAMEUNGPEUK"
      },
      {
        "kodeKECAMATAN": 3205080,
        "kodeKABUPATEN": 3205,
        "namaKECAMATAN": "CIBALONG"
      },
      {
        "kodeKECAMATAN": 3205090,
        "kodeKABUPATEN": 3205,
        "namaKECAMATAN": "CISOMPET"
      },
      {
        "kodeKECAMATAN": 3205100,
        "kodeKABUPATEN": 3205,
        "namaKECAMATAN": "PEUNDEUY"
      },
      {
        "kodeKECAMATAN": 3205110,
        "kodeKABUPATEN": 3205,
        "namaKECAMATAN": "SINGAJAYA"
      },
      {
        "kodeKECAMATAN": 3205111,
        "kodeKABUPATEN": 3205,
        "namaKECAMATAN": "CIHURIP"
      },
      {
        "kodeKECAMATAN": 3205120,
        "kodeKABUPATEN": 3205,
        "namaKECAMATAN": "CIKAJANG"
      },
      {
        "kodeKECAMATAN": 3205130,
        "kodeKABUPATEN": 3205,
        "namaKECAMATAN": "BANJARWANGI"
      },
      {
        "kodeKECAMATAN": 3205140,
        "kodeKABUPATEN": 3205,
        "namaKECAMATAN": "CILAWU"
      },
      {
        "kodeKECAMATAN": 3205150,
        "kodeKABUPATEN": 3205,
        "namaKECAMATAN": "BAYONGBONG"
      },
      {
        "kodeKECAMATAN": 3205151,
        "kodeKABUPATEN": 3205,
        "namaKECAMATAN": "CIGEDUG"
      },
      {
        "kodeKECAMATAN": 3205160,
        "kodeKABUPATEN": 3205,
        "namaKECAMATAN": "CISURUPAN"
      },
      {
        "kodeKECAMATAN": 3205161,
        "kodeKABUPATEN": 3205,
        "namaKECAMATAN": "SUKARESMI"
      },
      {
        "kodeKECAMATAN": 3205170,
        "kodeKABUPATEN": 3205,
        "namaKECAMATAN": "SAMARANG"
      },
      {
        "kodeKECAMATAN": 3205171,
        "kodeKABUPATEN": 3205,
        "namaKECAMATAN": "PASIRWANGI"
      },
      {
        "kodeKECAMATAN": 3205181,
        "kodeKABUPATEN": 3205,
        "namaKECAMATAN": "TAROGONG KIDUL"
      },
      {
        "kodeKECAMATAN": 3205182,
        "kodeKABUPATEN": 3205,
        "namaKECAMATAN": "TAROGONG KALER"
      },
      {
        "kodeKECAMATAN": 3205190,
        "kodeKABUPATEN": 3205,
        "namaKECAMATAN": "GARUT KOTA"
      },
      {
        "kodeKECAMATAN": 3205200,
        "kodeKABUPATEN": 3205,
        "namaKECAMATAN": "KARANGPAWITAN"
      },
      {
        "kodeKECAMATAN": 3205210,
        "kodeKABUPATEN": 3205,
        "namaKECAMATAN": "WANARAJA"
      },
      {
        "kodeKECAMATAN": 3205211,
        "kodeKABUPATEN": 3205,
        "namaKECAMATAN": "SUCINARAJA"
      },
      {
        "kodeKECAMATAN": 3205212,
        "kodeKABUPATEN": 3205,
        "namaKECAMATAN": "PANGATIKAN"
      },
      {
        "kodeKECAMATAN": 3205220,
        "kodeKABUPATEN": 3205,
        "namaKECAMATAN": "SUKAWENING"
      },
      {
        "kodeKECAMATAN": 3205221,
        "kodeKABUPATEN": 3205,
        "namaKECAMATAN": "KARANGTENGAH"
      },
      {
        "kodeKECAMATAN": 3205230,
        "kodeKABUPATEN": 3205,
        "namaKECAMATAN": "BANYURESMI"
      },
      {
        "kodeKECAMATAN": 3205240,
        "kodeKABUPATEN": 3205,
        "namaKECAMATAN": "LELES"
      },
      {
        "kodeKECAMATAN": 3205250,
        "kodeKABUPATEN": 3205,
        "namaKECAMATAN": "LEUWIGOONG"
      },
      {
        "kodeKECAMATAN": 3205260,
        "kodeKABUPATEN": 3205,
        "namaKECAMATAN": "CIBATU"
      },
      {
        "kodeKECAMATAN": 3205261,
        "kodeKABUPATEN": 3205,
        "namaKECAMATAN": "KERSAMANAH"
      },
      {
        "kodeKECAMATAN": 3205270,
        "kodeKABUPATEN": 3205,
        "namaKECAMATAN": "CIBIUK"
      },
      {
        "kodeKECAMATAN": 3205280,
        "kodeKABUPATEN": 3205,
        "namaKECAMATAN": "KADUNGORA"
      },
      {
        "kodeKECAMATAN": 3205290,
        "kodeKABUPATEN": 3205,
        "namaKECAMATAN": "BLUBUR LIMBANGAN"
      },
      {
        "kodeKECAMATAN": 3205300,
        "kodeKABUPATEN": 3205,
        "namaKECAMATAN": "SELAAWI"
      },
      {
        "kodeKECAMATAN": 3205310,
        "kodeKABUPATEN": 3205,
        "namaKECAMATAN": "MALANGBONG"
      },
      {
        "kodeKECAMATAN": 3206010,
        "kodeKABUPATEN": 3206,
        "namaKECAMATAN": "CIPATUJAH"
      },
      {
        "kodeKECAMATAN": 3206020,
        "kodeKABUPATEN": 3206,
        "namaKECAMATAN": "KARANGNUNGGAL"
      },
      {
        "kodeKECAMATAN": 3206030,
        "kodeKABUPATEN": 3206,
        "namaKECAMATAN": "CIKALONG"
      },
      {
        "kodeKECAMATAN": 3206040,
        "kodeKABUPATEN": 3206,
        "namaKECAMATAN": "PANCATENGAH"
      },
      {
        "kodeKECAMATAN": 3206050,
        "kodeKABUPATEN": 3206,
        "namaKECAMATAN": "CIKATOMAS"
      },
      {
        "kodeKECAMATAN": 3206060,
        "kodeKABUPATEN": 3206,
        "namaKECAMATAN": "CIBALONG"
      },
      {
        "kodeKECAMATAN": 3206061,
        "kodeKABUPATEN": 3206,
        "namaKECAMATAN": "PARUNGPONTENG"
      },
      {
        "kodeKECAMATAN": 3206070,
        "kodeKABUPATEN": 3206,
        "namaKECAMATAN": "BANTARKALONG"
      },
      {
        "kodeKECAMATAN": 3206071,
        "kodeKABUPATEN": 3206,
        "namaKECAMATAN": "BOJONGASIH"
      },
      {
        "kodeKECAMATAN": 3206072,
        "kodeKABUPATEN": 3206,
        "namaKECAMATAN": "CULAMEGA"
      },
      {
        "kodeKECAMATAN": 3206080,
        "kodeKABUPATEN": 3206,
        "namaKECAMATAN": "BOJONGGAMBIR"
      },
      {
        "kodeKECAMATAN": 3206090,
        "kodeKABUPATEN": 3206,
        "namaKECAMATAN": "SODONGHILIR"
      },
      {
        "kodeKECAMATAN": 3206100,
        "kodeKABUPATEN": 3206,
        "namaKECAMATAN": "TARAJU"
      },
      {
        "kodeKECAMATAN": 3206110,
        "kodeKABUPATEN": 3206,
        "namaKECAMATAN": "SALAWU"
      },
      {
        "kodeKECAMATAN": 3206111,
        "kodeKABUPATEN": 3206,
        "namaKECAMATAN": "PUSPAHIANG"
      },
      {
        "kodeKECAMATAN": 3206120,
        "kodeKABUPATEN": 3206,
        "namaKECAMATAN": "TANJUNGJAYA"
      },
      {
        "kodeKECAMATAN": 3206130,
        "kodeKABUPATEN": 3206,
        "namaKECAMATAN": "SUKARAJA"
      },
      {
        "kodeKECAMATAN": 3206140,
        "kodeKABUPATEN": 3206,
        "namaKECAMATAN": "SALOPA"
      },
      {
        "kodeKECAMATAN": 3206141,
        "kodeKABUPATEN": 3206,
        "namaKECAMATAN": "JATIWARAS"
      },
      {
        "kodeKECAMATAN": 3206150,
        "kodeKABUPATEN": 3206,
        "namaKECAMATAN": "CINEAM"
      },
      {
        "kodeKECAMATAN": 3206151,
        "kodeKABUPATEN": 3206,
        "namaKECAMATAN": "KARANGJAYA"
      },
      {
        "kodeKECAMATAN": 3206160,
        "kodeKABUPATEN": 3206,
        "namaKECAMATAN": "MANONJAYA"
      },
      {
        "kodeKECAMATAN": 3206161,
        "kodeKABUPATEN": 3206,
        "namaKECAMATAN": "GUNUNGTANJUNG"
      },
      {
        "kodeKECAMATAN": 3206190,
        "kodeKABUPATEN": 3206,
        "namaKECAMATAN": "SINGAPARNA"
      },
      {
        "kodeKECAMATAN": 3206191,
        "kodeKABUPATEN": 3206,
        "namaKECAMATAN": "SUKARAME"
      },
      {
        "kodeKECAMATAN": 3206192,
        "kodeKABUPATEN": 3206,
        "namaKECAMATAN": "MANGUNREJA"
      },
      {
        "kodeKECAMATAN": 3206200,
        "kodeKABUPATEN": 3206,
        "namaKECAMATAN": "CIGALONTANG"
      },
      {
        "kodeKECAMATAN": 3206210,
        "kodeKABUPATEN": 3206,
        "namaKECAMATAN": "LEUWISARI"
      },
      {
        "kodeKECAMATAN": 3206211,
        "kodeKABUPATEN": 3206,
        "namaKECAMATAN": "SARIWANGI"
      },
      {
        "kodeKECAMATAN": 3206212,
        "kodeKABUPATEN": 3206,
        "namaKECAMATAN": "PADAKEMBANG"
      },
      {
        "kodeKECAMATAN": 3206221,
        "kodeKABUPATEN": 3206,
        "namaKECAMATAN": "SUKARATU"
      },
      {
        "kodeKECAMATAN": 3206230,
        "kodeKABUPATEN": 3206,
        "namaKECAMATAN": "CISAYONG"
      },
      {
        "kodeKECAMATAN": 3206231,
        "kodeKABUPATEN": 3206,
        "namaKECAMATAN": "SUKAHENING"
      },
      {
        "kodeKECAMATAN": 3206240,
        "kodeKABUPATEN": 3206,
        "namaKECAMATAN": "RAJAPOLAH"
      },
      {
        "kodeKECAMATAN": 3206250,
        "kodeKABUPATEN": 3206,
        "namaKECAMATAN": "JAMANIS"
      },
      {
        "kodeKECAMATAN": 3206260,
        "kodeKABUPATEN": 3206,
        "namaKECAMATAN": "CIAWI"
      },
      {
        "kodeKECAMATAN": 3206261,
        "kodeKABUPATEN": 3206,
        "namaKECAMATAN": "KADIPATEN"
      },
      {
        "kodeKECAMATAN": 3206270,
        "kodeKABUPATEN": 3206,
        "namaKECAMATAN": "PAGERAGEUNG"
      },
      {
        "kodeKECAMATAN": 3206271,
        "kodeKABUPATEN": 3206,
        "namaKECAMATAN": "SUKARESIK"
      },
      {
        "kodeKECAMATAN": 3207100,
        "kodeKABUPATEN": 3207,
        "namaKECAMATAN": "BANJARSARI"
      },
      {
        "kodeKECAMATAN": 3207110,
        "kodeKABUPATEN": 3207,
        "namaKECAMATAN": "LAKBOK"
      },
      {
        "kodeKECAMATAN": 3207111,
        "kodeKABUPATEN": 3207,
        "namaKECAMATAN": "PURWADADI"
      },
      {
        "kodeKECAMATAN": 3207120,
        "kodeKABUPATEN": 3207,
        "namaKECAMATAN": "PAMARICAN"
      },
      {
        "kodeKECAMATAN": 3207130,
        "kodeKABUPATEN": 3207,
        "namaKECAMATAN": "CIDOLOG"
      },
      {
        "kodeKECAMATAN": 3207140,
        "kodeKABUPATEN": 3207,
        "namaKECAMATAN": "CIMARAGAS"
      },
      {
        "kodeKECAMATAN": 3207150,
        "kodeKABUPATEN": 3207,
        "namaKECAMATAN": "CIJEUNGJING"
      },
      {
        "kodeKECAMATAN": 3207160,
        "kodeKABUPATEN": 3207,
        "namaKECAMATAN": "CISAGA"
      },
      {
        "kodeKECAMATAN": 3207170,
        "kodeKABUPATEN": 3207,
        "namaKECAMATAN": "TAMBAKSARI"
      },
      {
        "kodeKECAMATAN": 3207180,
        "kodeKABUPATEN": 3207,
        "namaKECAMATAN": "RANCAH"
      },
      {
        "kodeKECAMATAN": 3207190,
        "kodeKABUPATEN": 3207,
        "namaKECAMATAN": "RAJADESA"
      },
      {
        "kodeKECAMATAN": 3207200,
        "kodeKABUPATEN": 3207,
        "namaKECAMATAN": "SUKADANA"
      },
      {
        "kodeKECAMATAN": 3207210,
        "kodeKABUPATEN": 3207,
        "namaKECAMATAN": "CIAMIS"
      },
      {
        "kodeKECAMATAN": 3207211,
        "kodeKABUPATEN": 3207,
        "namaKECAMATAN": "BAREGBEG"
      },
      {
        "kodeKECAMATAN": 3207220,
        "kodeKABUPATEN": 3207,
        "namaKECAMATAN": "CIKONENG"
      },
      {
        "kodeKECAMATAN": 3207221,
        "kodeKABUPATEN": 3207,
        "namaKECAMATAN": "SINDANGKASIH"
      },
      {
        "kodeKECAMATAN": 3207230,
        "kodeKABUPATEN": 3207,
        "namaKECAMATAN": "CIHAURBEUTI"
      },
      {
        "kodeKECAMATAN": 3207240,
        "kodeKABUPATEN": 3207,
        "namaKECAMATAN": "SADANANYA"
      },
      {
        "kodeKECAMATAN": 3207250,
        "kodeKABUPATEN": 3207,
        "namaKECAMATAN": "CIPAKU"
      },
      {
        "kodeKECAMATAN": 3207260,
        "kodeKABUPATEN": 3207,
        "namaKECAMATAN": "JATINAGARA"
      },
      {
        "kodeKECAMATAN": 3207270,
        "kodeKABUPATEN": 3207,
        "namaKECAMATAN": "PANAWANGAN"
      },
      {
        "kodeKECAMATAN": 3207280,
        "kodeKABUPATEN": 3207,
        "namaKECAMATAN": "KAWALI"
      },
      {
        "kodeKECAMATAN": 3207281,
        "kodeKABUPATEN": 3207,
        "namaKECAMATAN": "LUMBUNG"
      },
      {
        "kodeKECAMATAN": 3207290,
        "kodeKABUPATEN": 3207,
        "namaKECAMATAN": "PANJALU"
      },
      {
        "kodeKECAMATAN": 3207291,
        "kodeKABUPATEN": 3207,
        "namaKECAMATAN": "SUKAMANTRI"
      },
      {
        "kodeKECAMATAN": 3207300,
        "kodeKABUPATEN": 3207,
        "namaKECAMATAN": "PANUMBANGAN"
      },
      {
        "kodeKECAMATAN": 3208010,
        "kodeKABUPATEN": 3208,
        "namaKECAMATAN": "DARMA"
      },
      {
        "kodeKECAMATAN": 3208020,
        "kodeKABUPATEN": 3208,
        "namaKECAMATAN": "KADUGEDE"
      },
      {
        "kodeKECAMATAN": 3208021,
        "kodeKABUPATEN": 3208,
        "namaKECAMATAN": "NUSAHERANG"
      },
      {
        "kodeKECAMATAN": 3208030,
        "kodeKABUPATEN": 3208,
        "namaKECAMATAN": "CINIRU"
      },
      {
        "kodeKECAMATAN": 3208031,
        "kodeKABUPATEN": 3208,
        "namaKECAMATAN": "HANTARA"
      },
      {
        "kodeKECAMATAN": 3208040,
        "kodeKABUPATEN": 3208,
        "namaKECAMATAN": "SELAJAMBE"
      },
      {
        "kodeKECAMATAN": 3208050,
        "kodeKABUPATEN": 3208,
        "namaKECAMATAN": "SUBANG"
      },
      {
        "kodeKECAMATAN": 3208051,
        "kodeKABUPATEN": 3208,
        "namaKECAMATAN": "CILEBAK"
      },
      {
        "kodeKECAMATAN": 3208060,
        "kodeKABUPATEN": 3208,
        "namaKECAMATAN": "CIWARU"
      },
      {
        "kodeKECAMATAN": 3208061,
        "kodeKABUPATEN": 3208,
        "namaKECAMATAN": "KARANGKANCANA"
      },
      {
        "kodeKECAMATAN": 3208070,
        "kodeKABUPATEN": 3208,
        "namaKECAMATAN": "CIBINGBIN"
      },
      {
        "kodeKECAMATAN": 3208071,
        "kodeKABUPATEN": 3208,
        "namaKECAMATAN": "CIBEUREUM"
      },
      {
        "kodeKECAMATAN": 3208080,
        "kodeKABUPATEN": 3208,
        "namaKECAMATAN": "LURAGUNG"
      },
      {
        "kodeKECAMATAN": 3208081,
        "kodeKABUPATEN": 3208,
        "namaKECAMATAN": "CIMAHI"
      },
      {
        "kodeKECAMATAN": 3208090,
        "kodeKABUPATEN": 3208,
        "namaKECAMATAN": "CIDAHU"
      },
      {
        "kodeKECAMATAN": 3208091,
        "kodeKABUPATEN": 3208,
        "namaKECAMATAN": "KALIMANGGIS"
      },
      {
        "kodeKECAMATAN": 3208100,
        "kodeKABUPATEN": 3208,
        "namaKECAMATAN": "CIAWIGEBANG"
      },
      {
        "kodeKECAMATAN": 3208101,
        "kodeKABUPATEN": 3208,
        "namaKECAMATAN": "CIPICUNG"
      },
      {
        "kodeKECAMATAN": 3208110,
        "kodeKABUPATEN": 3208,
        "namaKECAMATAN": "LEBAKWANGI"
      },
      {
        "kodeKECAMATAN": 3208111,
        "kodeKABUPATEN": 3208,
        "namaKECAMATAN": "MALEBER"
      },
      {
        "kodeKECAMATAN": 3208120,
        "kodeKABUPATEN": 3208,
        "namaKECAMATAN": "GARAWANGI"
      },
      {
        "kodeKECAMATAN": 3208121,
        "kodeKABUPATEN": 3208,
        "namaKECAMATAN": "SINDANGAGUNG"
      },
      {
        "kodeKECAMATAN": 3208130,
        "kodeKABUPATEN": 3208,
        "namaKECAMATAN": "KUNINGAN"
      },
      {
        "kodeKECAMATAN": 3208140,
        "kodeKABUPATEN": 3208,
        "namaKECAMATAN": "CIGUGUR"
      },
      {
        "kodeKECAMATAN": 3208150,
        "kodeKABUPATEN": 3208,
        "namaKECAMATAN": "KRAMATMULYA"
      },
      {
        "kodeKECAMATAN": 3208160,
        "kodeKABUPATEN": 3208,
        "namaKECAMATAN": "JALAKSANA"
      },
      {
        "kodeKECAMATAN": 3208161,
        "kodeKABUPATEN": 3208,
        "namaKECAMATAN": "JAPARA"
      },
      {
        "kodeKECAMATAN": 3208170,
        "kodeKABUPATEN": 3208,
        "namaKECAMATAN": "CILIMUS"
      },
      {
        "kodeKECAMATAN": 3208171,
        "kodeKABUPATEN": 3208,
        "namaKECAMATAN": "CIGANDAMEKAR"
      },
      {
        "kodeKECAMATAN": 3208180,
        "kodeKABUPATEN": 3208,
        "namaKECAMATAN": "MANDIRANCAN"
      },
      {
        "kodeKECAMATAN": 3208181,
        "kodeKABUPATEN": 3208,
        "namaKECAMATAN": "PANCALANG"
      },
      {
        "kodeKECAMATAN": 3208190,
        "kodeKABUPATEN": 3208,
        "namaKECAMATAN": "PASAWAHAN"
      },
      {
        "kodeKECAMATAN": 3209010,
        "kodeKABUPATEN": 3209,
        "namaKECAMATAN": "WALED"
      },
      {
        "kodeKECAMATAN": 3209011,
        "kodeKABUPATEN": 3209,
        "namaKECAMATAN": "PASALEMAN"
      },
      {
        "kodeKECAMATAN": 3209020,
        "kodeKABUPATEN": 3209,
        "namaKECAMATAN": "CILEDUG"
      },
      {
        "kodeKECAMATAN": 3209021,
        "kodeKABUPATEN": 3209,
        "namaKECAMATAN": "PABUARAN"
      },
      {
        "kodeKECAMATAN": 3209030,
        "kodeKABUPATEN": 3209,
        "namaKECAMATAN": "LOSARI"
      },
      {
        "kodeKECAMATAN": 3209031,
        "kodeKABUPATEN": 3209,
        "namaKECAMATAN": "PABEDILAN"
      },
      {
        "kodeKECAMATAN": 3209040,
        "kodeKABUPATEN": 3209,
        "namaKECAMATAN": "BABAKAN"
      },
      {
        "kodeKECAMATAN": 3209041,
        "kodeKABUPATEN": 3209,
        "namaKECAMATAN": "GEBANG"
      },
      {
        "kodeKECAMATAN": 3209050,
        "kodeKABUPATEN": 3209,
        "namaKECAMATAN": "KARANGSEMBUNG"
      },
      {
        "kodeKECAMATAN": 3209051,
        "kodeKABUPATEN": 3209,
        "namaKECAMATAN": "KARANGWARENG"
      },
      {
        "kodeKECAMATAN": 3209060,
        "kodeKABUPATEN": 3209,
        "namaKECAMATAN": "LEMAHABANG"
      },
      {
        "kodeKECAMATAN": 3209061,
        "kodeKABUPATEN": 3209,
        "namaKECAMATAN": "SUSUKANLEBAK"
      },
      {
        "kodeKECAMATAN": 3209070,
        "kodeKABUPATEN": 3209,
        "namaKECAMATAN": "SEDONG"
      },
      {
        "kodeKECAMATAN": 3209080,
        "kodeKABUPATEN": 3209,
        "namaKECAMATAN": "ASTANAJAPURA"
      },
      {
        "kodeKECAMATAN": 3209081,
        "kodeKABUPATEN": 3209,
        "namaKECAMATAN": "PANGENAN"
      },
      {
        "kodeKECAMATAN": 3209090,
        "kodeKABUPATEN": 3209,
        "namaKECAMATAN": "MUNDU"
      },
      {
        "kodeKECAMATAN": 3209100,
        "kodeKABUPATEN": 3209,
        "namaKECAMATAN": "BEBER"
      },
      {
        "kodeKECAMATAN": 3209101,
        "kodeKABUPATEN": 3209,
        "namaKECAMATAN": "GREGED"
      },
      {
        "kodeKECAMATAN": 3209111,
        "kodeKABUPATEN": 3209,
        "namaKECAMATAN": "TALUN"
      },
      {
        "kodeKECAMATAN": 3209120,
        "kodeKABUPATEN": 3209,
        "namaKECAMATAN": "SUMBER"
      },
      {
        "kodeKECAMATAN": 3209121,
        "kodeKABUPATEN": 3209,
        "namaKECAMATAN": "DUKUPUNTANG"
      },
      {
        "kodeKECAMATAN": 3209130,
        "kodeKABUPATEN": 3209,
        "namaKECAMATAN": "PALIMANAN"
      },
      {
        "kodeKECAMATAN": 3209140,
        "kodeKABUPATEN": 3209,
        "namaKECAMATAN": "PLUMBON"
      },
      {
        "kodeKECAMATAN": 3209141,
        "kodeKABUPATEN": 3209,
        "namaKECAMATAN": "DEPOK"
      },
      {
        "kodeKECAMATAN": 3209150,
        "kodeKABUPATEN": 3209,
        "namaKECAMATAN": "WERU"
      },
      {
        "kodeKECAMATAN": 3209151,
        "kodeKABUPATEN": 3209,
        "namaKECAMATAN": "PLERED"
      },
      {
        "kodeKECAMATAN": 3209161,
        "kodeKABUPATEN": 3209,
        "namaKECAMATAN": "TENGAH TANI"
      },
      {
        "kodeKECAMATAN": 3209162,
        "kodeKABUPATEN": 3209,
        "namaKECAMATAN": "KEDAWUNG"
      },
      {
        "kodeKECAMATAN": 3209171,
        "kodeKABUPATEN": 3209,
        "namaKECAMATAN": "GUNUNGJATI"
      },
      {
        "kodeKECAMATAN": 3209180,
        "kodeKABUPATEN": 3209,
        "namaKECAMATAN": "KAPETAKAN"
      },
      {
        "kodeKECAMATAN": 3209181,
        "kodeKABUPATEN": 3209,
        "namaKECAMATAN": "SURANENGGALA"
      },
      {
        "kodeKECAMATAN": 3209190,
        "kodeKABUPATEN": 3209,
        "namaKECAMATAN": "KLANGENAN"
      },
      {
        "kodeKECAMATAN": 3209191,
        "kodeKABUPATEN": 3209,
        "namaKECAMATAN": "JAMBLANG"
      },
      {
        "kodeKECAMATAN": 3209200,
        "kodeKABUPATEN": 3209,
        "namaKECAMATAN": "ARJAWINANGUN"
      },
      {
        "kodeKECAMATAN": 3209201,
        "kodeKABUPATEN": 3209,
        "namaKECAMATAN": "PANGURAGAN"
      },
      {
        "kodeKECAMATAN": 3209210,
        "kodeKABUPATEN": 3209,
        "namaKECAMATAN": "CIWARINGIN"
      },
      {
        "kodeKECAMATAN": 3209211,
        "kodeKABUPATEN": 3209,
        "namaKECAMATAN": "GEMPOL"
      },
      {
        "kodeKECAMATAN": 3209220,
        "kodeKABUPATEN": 3209,
        "namaKECAMATAN": "SUSUKAN"
      },
      {
        "kodeKECAMATAN": 3209230,
        "kodeKABUPATEN": 3209,
        "namaKECAMATAN": "GEGESIK"
      },
      {
        "kodeKECAMATAN": 3209231,
        "kodeKABUPATEN": 3209,
        "namaKECAMATAN": "KALIWEDI"
      },
      {
        "kodeKECAMATAN": 3210010,
        "kodeKABUPATEN": 3210,
        "namaKECAMATAN": "LEMAHSUGIH"
      },
      {
        "kodeKECAMATAN": 3210020,
        "kodeKABUPATEN": 3210,
        "namaKECAMATAN": "BANTARUJEG"
      },
      {
        "kodeKECAMATAN": 3210021,
        "kodeKABUPATEN": 3210,
        "namaKECAMATAN": "MALAUSMA"
      },
      {
        "kodeKECAMATAN": 3210030,
        "kodeKABUPATEN": 3210,
        "namaKECAMATAN": "CIKIJING"
      },
      {
        "kodeKECAMATAN": 3210031,
        "kodeKABUPATEN": 3210,
        "namaKECAMATAN": "CINGAMBUL"
      },
      {
        "kodeKECAMATAN": 3210040,
        "kodeKABUPATEN": 3210,
        "namaKECAMATAN": "TALAGA"
      },
      {
        "kodeKECAMATAN": 3210041,
        "kodeKABUPATEN": 3210,
        "namaKECAMATAN": "BANJARAN"
      },
      {
        "kodeKECAMATAN": 3210050,
        "kodeKABUPATEN": 3210,
        "namaKECAMATAN": "ARGAPURA"
      },
      {
        "kodeKECAMATAN": 3210060,
        "kodeKABUPATEN": 3210,
        "namaKECAMATAN": "MAJA"
      },
      {
        "kodeKECAMATAN": 3210070,
        "kodeKABUPATEN": 3210,
        "namaKECAMATAN": "MAJALENGKA"
      },
      {
        "kodeKECAMATAN": 3210080,
        "kodeKABUPATEN": 3210,
        "namaKECAMATAN": "CIGASONG"
      },
      {
        "kodeKECAMATAN": 3210090,
        "kodeKABUPATEN": 3210,
        "namaKECAMATAN": "SUKAHAJI"
      },
      {
        "kodeKECAMATAN": 3210091,
        "kodeKABUPATEN": 3210,
        "namaKECAMATAN": "SINDANG"
      },
      {
        "kodeKECAMATAN": 3210100,
        "kodeKABUPATEN": 3210,
        "namaKECAMATAN": "RAJAGALUH"
      },
      {
        "kodeKECAMATAN": 3210110,
        "kodeKABUPATEN": 3210,
        "namaKECAMATAN": "SINDANGWANGI"
      },
      {
        "kodeKECAMATAN": 3210120,
        "kodeKABUPATEN": 3210,
        "namaKECAMATAN": "LEUWIMUNDING"
      },
      {
        "kodeKECAMATAN": 3210130,
        "kodeKABUPATEN": 3210,
        "namaKECAMATAN": "PALASAH"
      },
      {
        "kodeKECAMATAN": 3210140,
        "kodeKABUPATEN": 3210,
        "namaKECAMATAN": "JATIWANGI"
      },
      {
        "kodeKECAMATAN": 3210150,
        "kodeKABUPATEN": 3210,
        "namaKECAMATAN": "DAWUAN"
      },
      {
        "kodeKECAMATAN": 3210151,
        "kodeKABUPATEN": 3210,
        "namaKECAMATAN": "KASOKANDEL"
      },
      {
        "kodeKECAMATAN": 3210160,
        "kodeKABUPATEN": 3210,
        "namaKECAMATAN": "PANYINGKIRAN"
      },
      {
        "kodeKECAMATAN": 3210170,
        "kodeKABUPATEN": 3210,
        "namaKECAMATAN": "KADIPATEN"
      },
      {
        "kodeKECAMATAN": 3210180,
        "kodeKABUPATEN": 3210,
        "namaKECAMATAN": "KERTAJATI"
      },
      {
        "kodeKECAMATAN": 3210190,
        "kodeKABUPATEN": 3210,
        "namaKECAMATAN": "JATITUJUH"
      },
      {
        "kodeKECAMATAN": 3210200,
        "kodeKABUPATEN": 3210,
        "namaKECAMATAN": "LIGUNG"
      },
      {
        "kodeKECAMATAN": 3210210,
        "kodeKABUPATEN": 3210,
        "namaKECAMATAN": "SUMBERJAYA"
      },
      {
        "kodeKECAMATAN": 3211010,
        "kodeKABUPATEN": 3211,
        "namaKECAMATAN": "JATINANGOR"
      },
      {
        "kodeKECAMATAN": 3211020,
        "kodeKABUPATEN": 3211,
        "namaKECAMATAN": "CIMANGGUNG"
      },
      {
        "kodeKECAMATAN": 3211030,
        "kodeKABUPATEN": 3211,
        "namaKECAMATAN": "TANJUNGSARI"
      },
      {
        "kodeKECAMATAN": 3211031,
        "kodeKABUPATEN": 3211,
        "namaKECAMATAN": "SUKASARI"
      },
      {
        "kodeKECAMATAN": 3211032,
        "kodeKABUPATEN": 3211,
        "namaKECAMATAN": "PAMULIHAN"
      },
      {
        "kodeKECAMATAN": 3211040,
        "kodeKABUPATEN": 3211,
        "namaKECAMATAN": "RANCAKALONG"
      },
      {
        "kodeKECAMATAN": 3211050,
        "kodeKABUPATEN": 3211,
        "namaKECAMATAN": "SUMEDANG SELATAN"
      },
      {
        "kodeKECAMATAN": 3211060,
        "kodeKABUPATEN": 3211,
        "namaKECAMATAN": "SUMEDANG UTARA"
      },
      {
        "kodeKECAMATAN": 3211061,
        "kodeKABUPATEN": 3211,
        "namaKECAMATAN": "GANEAS"
      },
      {
        "kodeKECAMATAN": 3211070,
        "kodeKABUPATEN": 3211,
        "namaKECAMATAN": "SITURAJA"
      },
      {
        "kodeKECAMATAN": 3211071,
        "kodeKABUPATEN": 3211,
        "namaKECAMATAN": "CISITU"
      },
      {
        "kodeKECAMATAN": 3211080,
        "kodeKABUPATEN": 3211,
        "namaKECAMATAN": "DARMARAJA"
      },
      {
        "kodeKECAMATAN": 3211090,
        "kodeKABUPATEN": 3211,
        "namaKECAMATAN": "CIBUGEL"
      },
      {
        "kodeKECAMATAN": 3211100,
        "kodeKABUPATEN": 3211,
        "namaKECAMATAN": "WADO"
      },
      {
        "kodeKECAMATAN": 3211101,
        "kodeKABUPATEN": 3211,
        "namaKECAMATAN": "JATINUNGGAL"
      },
      {
        "kodeKECAMATAN": 3211111,
        "kodeKABUPATEN": 3211,
        "namaKECAMATAN": "JATIGEDE"
      },
      {
        "kodeKECAMATAN": 3211120,
        "kodeKABUPATEN": 3211,
        "namaKECAMATAN": "TOMO"
      },
      {
        "kodeKECAMATAN": 3211130,
        "kodeKABUPATEN": 3211,
        "namaKECAMATAN": "UJUNG JAYA"
      },
      {
        "kodeKECAMATAN": 3211140,
        "kodeKABUPATEN": 3211,
        "namaKECAMATAN": "CONGGEANG"
      },
      {
        "kodeKECAMATAN": 3211150,
        "kodeKABUPATEN": 3211,
        "namaKECAMATAN": "PASEH"
      },
      {
        "kodeKECAMATAN": 3211160,
        "kodeKABUPATEN": 3211,
        "namaKECAMATAN": "CIMALAKA"
      },
      {
        "kodeKECAMATAN": 3211161,
        "kodeKABUPATEN": 3211,
        "namaKECAMATAN": "CISARUA"
      },
      {
        "kodeKECAMATAN": 3211170,
        "kodeKABUPATEN": 3211,
        "namaKECAMATAN": "TANJUNGKERTA"
      },
      {
        "kodeKECAMATAN": 3211171,
        "kodeKABUPATEN": 3211,
        "namaKECAMATAN": "TANJUNGMEDAR"
      },
      {
        "kodeKECAMATAN": 3211180,
        "kodeKABUPATEN": 3211,
        "namaKECAMATAN": "BUAHDUA"
      },
      {
        "kodeKECAMATAN": 3211181,
        "kodeKABUPATEN": 3211,
        "namaKECAMATAN": "SURIAN"
      },
      {
        "kodeKECAMATAN": 3212010,
        "kodeKABUPATEN": 3212,
        "namaKECAMATAN": "HAURGEULIS"
      },
      {
        "kodeKECAMATAN": 3212011,
        "kodeKABUPATEN": 3212,
        "namaKECAMATAN": "GANTAR"
      },
      {
        "kodeKECAMATAN": 3212020,
        "kodeKABUPATEN": 3212,
        "namaKECAMATAN": "KROYA"
      },
      {
        "kodeKECAMATAN": 3212030,
        "kodeKABUPATEN": 3212,
        "namaKECAMATAN": "GABUSWETAN"
      },
      {
        "kodeKECAMATAN": 3212040,
        "kodeKABUPATEN": 3212,
        "namaKECAMATAN": "CIKEDUNG"
      },
      {
        "kodeKECAMATAN": 3212041,
        "kodeKABUPATEN": 3212,
        "namaKECAMATAN": "TERISI"
      },
      {
        "kodeKECAMATAN": 3212050,
        "kodeKABUPATEN": 3212,
        "namaKECAMATAN": "LELEA"
      },
      {
        "kodeKECAMATAN": 3212060,
        "kodeKABUPATEN": 3212,
        "namaKECAMATAN": "BANGODUA"
      },
      {
        "kodeKECAMATAN": 3212061,
        "kodeKABUPATEN": 3212,
        "namaKECAMATAN": "TUKDANA"
      },
      {
        "kodeKECAMATAN": 3212070,
        "kodeKABUPATEN": 3212,
        "namaKECAMATAN": "WIDASARI"
      },
      {
        "kodeKECAMATAN": 3212080,
        "kodeKABUPATEN": 3212,
        "namaKECAMATAN": "KERTASEMAYA"
      },
      {
        "kodeKECAMATAN": 3212081,
        "kodeKABUPATEN": 3212,
        "namaKECAMATAN": "SUKAGUMIWANG"
      },
      {
        "kodeKECAMATAN": 3212090,
        "kodeKABUPATEN": 3212,
        "namaKECAMATAN": "KRANGKENG"
      },
      {
        "kodeKECAMATAN": 3212100,
        "kodeKABUPATEN": 3212,
        "namaKECAMATAN": "KARANGAMPEL"
      },
      {
        "kodeKECAMATAN": 3212101,
        "kodeKABUPATEN": 3212,
        "namaKECAMATAN": "KEDOKAN BUNDER"
      },
      {
        "kodeKECAMATAN": 3212110,
        "kodeKABUPATEN": 3212,
        "namaKECAMATAN": "JUNTINYUAT"
      },
      {
        "kodeKECAMATAN": 3212120,
        "kodeKABUPATEN": 3212,
        "namaKECAMATAN": "SLIYEG"
      },
      {
        "kodeKECAMATAN": 3212130,
        "kodeKABUPATEN": 3212,
        "namaKECAMATAN": "JATIBARANG"
      },
      {
        "kodeKECAMATAN": 3212140,
        "kodeKABUPATEN": 3212,
        "namaKECAMATAN": "BALONGAN"
      },
      {
        "kodeKECAMATAN": 3212150,
        "kodeKABUPATEN": 3212,
        "namaKECAMATAN": "INDRAMAYU"
      },
      {
        "kodeKECAMATAN": 3212160,
        "kodeKABUPATEN": 3212,
        "namaKECAMATAN": "SINDANG"
      },
      {
        "kodeKECAMATAN": 3212161,
        "kodeKABUPATEN": 3212,
        "namaKECAMATAN": "CANTIGI"
      },
      {
        "kodeKECAMATAN": 3212162,
        "kodeKABUPATEN": 3212,
        "namaKECAMATAN": "PASEKAN"
      },
      {
        "kodeKECAMATAN": 3212170,
        "kodeKABUPATEN": 3212,
        "namaKECAMATAN": "LOHBENER"
      },
      {
        "kodeKECAMATAN": 3212171,
        "kodeKABUPATEN": 3212,
        "namaKECAMATAN": "ARAHAN"
      },
      {
        "kodeKECAMATAN": 3212180,
        "kodeKABUPATEN": 3212,
        "namaKECAMATAN": "LOSARANG"
      },
      {
        "kodeKECAMATAN": 3212190,
        "kodeKABUPATEN": 3212,
        "namaKECAMATAN": "KANDANGHAUR"
      },
      {
        "kodeKECAMATAN": 3212200,
        "kodeKABUPATEN": 3212,
        "namaKECAMATAN": "BONGAS"
      },
      {
        "kodeKECAMATAN": 3212210,
        "kodeKABUPATEN": 3212,
        "namaKECAMATAN": "ANJATAN"
      },
      {
        "kodeKECAMATAN": 3212220,
        "kodeKABUPATEN": 3212,
        "namaKECAMATAN": "SUKRA"
      },
      {
        "kodeKECAMATAN": 3212221,
        "kodeKABUPATEN": 3212,
        "namaKECAMATAN": "PATROL"
      },
      {
        "kodeKECAMATAN": 3213010,
        "kodeKABUPATEN": 3213,
        "namaKECAMATAN": "SAGALAHERANG"
      },
      {
        "kodeKECAMATAN": 3213011,
        "kodeKABUPATEN": 3213,
        "namaKECAMATAN": "SERANGPANJANG"
      },
      {
        "kodeKECAMATAN": 3213020,
        "kodeKABUPATEN": 3213,
        "namaKECAMATAN": "JALANCAGAK"
      },
      {
        "kodeKECAMATAN": 3213021,
        "kodeKABUPATEN": 3213,
        "namaKECAMATAN": "CIATER"
      },
      {
        "kodeKECAMATAN": 3213030,
        "kodeKABUPATEN": 3213,
        "namaKECAMATAN": "CISALAK"
      },
      {
        "kodeKECAMATAN": 3213031,
        "kodeKABUPATEN": 3213,
        "namaKECAMATAN": "KASOMALANG"
      },
      {
        "kodeKECAMATAN": 3213040,
        "kodeKABUPATEN": 3213,
        "namaKECAMATAN": "TANJUNGSIANG"
      },
      {
        "kodeKECAMATAN": 3213050,
        "kodeKABUPATEN": 3213,
        "namaKECAMATAN": "CIJAMBE"
      },
      {
        "kodeKECAMATAN": 3213060,
        "kodeKABUPATEN": 3213,
        "namaKECAMATAN": "CIBOGO"
      },
      {
        "kodeKECAMATAN": 3213070,
        "kodeKABUPATEN": 3213,
        "namaKECAMATAN": "SUBANG"
      },
      {
        "kodeKECAMATAN": 3213080,
        "kodeKABUPATEN": 3213,
        "namaKECAMATAN": "KALIJATI"
      },
      {
        "kodeKECAMATAN": 3213081,
        "kodeKABUPATEN": 3213,
        "namaKECAMATAN": "DAWUAN"
      },
      {
        "kodeKECAMATAN": 3213090,
        "kodeKABUPATEN": 3213,
        "namaKECAMATAN": "CIPEUNDEUY"
      },
      {
        "kodeKECAMATAN": 3213100,
        "kodeKABUPATEN": 3213,
        "namaKECAMATAN": "PABUARAN"
      },
      {
        "kodeKECAMATAN": 3213110,
        "kodeKABUPATEN": 3213,
        "namaKECAMATAN": "PATOKBEUSI"
      },
      {
        "kodeKECAMATAN": 3213120,
        "kodeKABUPATEN": 3213,
        "namaKECAMATAN": "PURWADADI"
      },
      {
        "kodeKECAMATAN": 3213130,
        "kodeKABUPATEN": 3213,
        "namaKECAMATAN": "CIKAUM"
      },
      {
        "kodeKECAMATAN": 3213140,
        "kodeKABUPATEN": 3213,
        "namaKECAMATAN": "PAGADEN"
      },
      {
        "kodeKECAMATAN": 3213141,
        "kodeKABUPATEN": 3213,
        "namaKECAMATAN": "PAGADEN BARAT"
      },
      {
        "kodeKECAMATAN": 3213150,
        "kodeKABUPATEN": 3213,
        "namaKECAMATAN": "CIPUNAGARA"
      },
      {
        "kodeKECAMATAN": 3213160,
        "kodeKABUPATEN": 3213,
        "namaKECAMATAN": "COMPRENG"
      },
      {
        "kodeKECAMATAN": 3213170,
        "kodeKABUPATEN": 3213,
        "namaKECAMATAN": "BINONG"
      },
      {
        "kodeKECAMATAN": 3213171,
        "kodeKABUPATEN": 3213,
        "namaKECAMATAN": "TAMBAKDAHAN"
      },
      {
        "kodeKECAMATAN": 3213180,
        "kodeKABUPATEN": 3213,
        "namaKECAMATAN": "CIASEM"
      },
      {
        "kodeKECAMATAN": 3213190,
        "kodeKABUPATEN": 3213,
        "namaKECAMATAN": "PAMANUKAN"
      },
      {
        "kodeKECAMATAN": 3213191,
        "kodeKABUPATEN": 3213,
        "namaKECAMATAN": "SUKASARI"
      },
      {
        "kodeKECAMATAN": 3213200,
        "kodeKABUPATEN": 3213,
        "namaKECAMATAN": "PUSAKANAGARA"
      },
      {
        "kodeKECAMATAN": 3213201,
        "kodeKABUPATEN": 3213,
        "namaKECAMATAN": "PUSAKAJAYA"
      },
      {
        "kodeKECAMATAN": 3213210,
        "kodeKABUPATEN": 3213,
        "namaKECAMATAN": "LEGONKULON"
      },
      {
        "kodeKECAMATAN": 3213220,
        "kodeKABUPATEN": 3213,
        "namaKECAMATAN": "BLANAKAN"
      },
      {
        "kodeKECAMATAN": 3214010,
        "kodeKABUPATEN": 3214,
        "namaKECAMATAN": "JATILUHUR"
      },
      {
        "kodeKECAMATAN": 3214011,
        "kodeKABUPATEN": 3214,
        "namaKECAMATAN": "SUKASARI"
      },
      {
        "kodeKECAMATAN": 3214020,
        "kodeKABUPATEN": 3214,
        "namaKECAMATAN": "MANIIS"
      },
      {
        "kodeKECAMATAN": 3214030,
        "kodeKABUPATEN": 3214,
        "namaKECAMATAN": "TEGAL WARU"
      },
      {
        "kodeKECAMATAN": 3214040,
        "kodeKABUPATEN": 3214,
        "namaKECAMATAN": "PLERED"
      },
      {
        "kodeKECAMATAN": 3214050,
        "kodeKABUPATEN": 3214,
        "namaKECAMATAN": "SUKATANI"
      },
      {
        "kodeKECAMATAN": 3214060,
        "kodeKABUPATEN": 3214,
        "namaKECAMATAN": "DARANGDAN"
      },
      {
        "kodeKECAMATAN": 3214070,
        "kodeKABUPATEN": 3214,
        "namaKECAMATAN": "BOJONG"
      },
      {
        "kodeKECAMATAN": 3214080,
        "kodeKABUPATEN": 3214,
        "namaKECAMATAN": "WANAYASA"
      },
      {
        "kodeKECAMATAN": 3214081,
        "kodeKABUPATEN": 3214,
        "namaKECAMATAN": "KIARAPEDES"
      },
      {
        "kodeKECAMATAN": 3214090,
        "kodeKABUPATEN": 3214,
        "namaKECAMATAN": "PASAWAHAN"
      },
      {
        "kodeKECAMATAN": 3214091,
        "kodeKABUPATEN": 3214,
        "namaKECAMATAN": "PONDOK SALAM"
      },
      {
        "kodeKECAMATAN": 3214100,
        "kodeKABUPATEN": 3214,
        "namaKECAMATAN": "PURWAKARTA"
      },
      {
        "kodeKECAMATAN": 3214101,
        "kodeKABUPATEN": 3214,
        "namaKECAMATAN": "BABAKANCIKAO"
      },
      {
        "kodeKECAMATAN": 3214110,
        "kodeKABUPATEN": 3214,
        "namaKECAMATAN": "CAMPAKA"
      },
      {
        "kodeKECAMATAN": 3214111,
        "kodeKABUPATEN": 3214,
        "namaKECAMATAN": "CIBATU"
      },
      {
        "kodeKECAMATAN": 3214112,
        "kodeKABUPATEN": 3214,
        "namaKECAMATAN": "BUNGURSARI"
      },
      {
        "kodeKECAMATAN": 3215010,
        "kodeKABUPATEN": 3215,
        "namaKECAMATAN": "PANGKALAN"
      },
      {
        "kodeKECAMATAN": 3215011,
        "kodeKABUPATEN": 3215,
        "namaKECAMATAN": "TEGALWARU"
      },
      {
        "kodeKECAMATAN": 3215020,
        "kodeKABUPATEN": 3215,
        "namaKECAMATAN": "CIAMPEL"
      },
      {
        "kodeKECAMATAN": 3215031,
        "kodeKABUPATEN": 3215,
        "namaKECAMATAN": "TELUKJAMBE TIMUR"
      },
      {
        "kodeKECAMATAN": 3215032,
        "kodeKABUPATEN": 3215,
        "namaKECAMATAN": "TELUKJAMBE BARAT"
      },
      {
        "kodeKECAMATAN": 3215040,
        "kodeKABUPATEN": 3215,
        "namaKECAMATAN": "KLARI"
      },
      {
        "kodeKECAMATAN": 3215050,
        "kodeKABUPATEN": 3215,
        "namaKECAMATAN": "CIKAMPEK"
      },
      {
        "kodeKECAMATAN": 3215051,
        "kodeKABUPATEN": 3215,
        "namaKECAMATAN": "PURWASARI"
      },
      {
        "kodeKECAMATAN": 3215060,
        "kodeKABUPATEN": 3215,
        "namaKECAMATAN": "TIRTAMULYA"
      },
      {
        "kodeKECAMATAN": 3215070,
        "kodeKABUPATEN": 3215,
        "namaKECAMATAN": "JATISARI"
      },
      {
        "kodeKECAMATAN": 3215071,
        "kodeKABUPATEN": 3215,
        "namaKECAMATAN": "BANYUSARI"
      },
      {
        "kodeKECAMATAN": 3215072,
        "kodeKABUPATEN": 3215,
        "namaKECAMATAN": "KOTABARU"
      },
      {
        "kodeKECAMATAN": 3215081,
        "kodeKABUPATEN": 3215,
        "namaKECAMATAN": "CILAMAYA WETAN"
      },
      {
        "kodeKECAMATAN": 3215082,
        "kodeKABUPATEN": 3215,
        "namaKECAMATAN": "CILAMAYA KULON"
      },
      {
        "kodeKECAMATAN": 3215090,
        "kodeKABUPATEN": 3215,
        "namaKECAMATAN": "LEMAHABANG"
      },
      {
        "kodeKECAMATAN": 3215100,
        "kodeKABUPATEN": 3215,
        "namaKECAMATAN": "TALAGASARI"
      },
      {
        "kodeKECAMATAN": 3215111,
        "kodeKABUPATEN": 3215,
        "namaKECAMATAN": "MAJALAYA"
      },
      {
        "kodeKECAMATAN": 3215112,
        "kodeKABUPATEN": 3215,
        "namaKECAMATAN": "KARAWANG TIMUR"
      },
      {
        "kodeKECAMATAN": 3215113,
        "kodeKABUPATEN": 3215,
        "namaKECAMATAN": "KARAWANG BARAT"
      },
      {
        "kodeKECAMATAN": 3215120,
        "kodeKABUPATEN": 3215,
        "namaKECAMATAN": "RAWAMERTA"
      },
      {
        "kodeKECAMATAN": 3215130,
        "kodeKABUPATEN": 3215,
        "namaKECAMATAN": "TEMPURAN"
      },
      {
        "kodeKECAMATAN": 3215140,
        "kodeKABUPATEN": 3215,
        "namaKECAMATAN": "KUTAWALUYA"
      },
      {
        "kodeKECAMATAN": 3215150,
        "kodeKABUPATEN": 3215,
        "namaKECAMATAN": "RENGASDENGKLOK"
      },
      {
        "kodeKECAMATAN": 3215151,
        "kodeKABUPATEN": 3215,
        "namaKECAMATAN": "JAYAKERTA"
      },
      {
        "kodeKECAMATAN": 3215160,
        "kodeKABUPATEN": 3215,
        "namaKECAMATAN": "PEDES"
      },
      {
        "kodeKECAMATAN": 3215161,
        "kodeKABUPATEN": 3215,
        "namaKECAMATAN": "CILEBAR"
      },
      {
        "kodeKECAMATAN": 3215170,
        "kodeKABUPATEN": 3215,
        "namaKECAMATAN": "CIBUAYA"
      },
      {
        "kodeKECAMATAN": 3215180,
        "kodeKABUPATEN": 3215,
        "namaKECAMATAN": "TIRTAJAYA"
      },
      {
        "kodeKECAMATAN": 3215190,
        "kodeKABUPATEN": 3215,
        "namaKECAMATAN": "BATUJAYA"
      },
      {
        "kodeKECAMATAN": 3215200,
        "kodeKABUPATEN": 3215,
        "namaKECAMATAN": "PAKISJAYA"
      },
      {
        "kodeKECAMATAN": 3216010,
        "kodeKABUPATEN": 3216,
        "namaKECAMATAN": "SETU"
      },
      {
        "kodeKECAMATAN": 3216021,
        "kodeKABUPATEN": 3216,
        "namaKECAMATAN": "SERANG BARU"
      },
      {
        "kodeKECAMATAN": 3216022,
        "kodeKABUPATEN": 3216,
        "namaKECAMATAN": "CIKARANG PUSAT"
      },
      {
        "kodeKECAMATAN": 3216023,
        "kodeKABUPATEN": 3216,
        "namaKECAMATAN": "CIKARANG SELATAN"
      },
      {
        "kodeKECAMATAN": 3216030,
        "kodeKABUPATEN": 3216,
        "namaKECAMATAN": "CIBARUSAH"
      },
      {
        "kodeKECAMATAN": 3216031,
        "kodeKABUPATEN": 3216,
        "namaKECAMATAN": "BOJONGMANGU"
      },
      {
        "kodeKECAMATAN": 3216041,
        "kodeKABUPATEN": 3216,
        "namaKECAMATAN": "CIKARANG TIMUR"
      },
      {
        "kodeKECAMATAN": 3216050,
        "kodeKABUPATEN": 3216,
        "namaKECAMATAN": "KEDUNGWARINGIN"
      },
      {
        "kodeKECAMATAN": 3216061,
        "kodeKABUPATEN": 3216,
        "namaKECAMATAN": "CIKARANG UTARA"
      },
      {
        "kodeKECAMATAN": 3216062,
        "kodeKABUPATEN": 3216,
        "namaKECAMATAN": "KARANGBAHAGIA"
      },
      {
        "kodeKECAMATAN": 3216070,
        "kodeKABUPATEN": 3216,
        "namaKECAMATAN": "CIBITUNG"
      },
      {
        "kodeKECAMATAN": 3216071,
        "kodeKABUPATEN": 3216,
        "namaKECAMATAN": "CIKARANG BARAT"
      },
      {
        "kodeKECAMATAN": 3216081,
        "kodeKABUPATEN": 3216,
        "namaKECAMATAN": "TAMBUN SELATAN"
      },
      {
        "kodeKECAMATAN": 3216082,
        "kodeKABUPATEN": 3216,
        "namaKECAMATAN": "TAMBUN UTARA"
      },
      {
        "kodeKECAMATAN": 3216090,
        "kodeKABUPATEN": 3216,
        "namaKECAMATAN": "BABELAN"
      },
      {
        "kodeKECAMATAN": 3216100,
        "kodeKABUPATEN": 3216,
        "namaKECAMATAN": "TARUMAJAYA"
      },
      {
        "kodeKECAMATAN": 3216110,
        "kodeKABUPATEN": 3216,
        "namaKECAMATAN": "TAMBELANG"
      },
      {
        "kodeKECAMATAN": 3216111,
        "kodeKABUPATEN": 3216,
        "namaKECAMATAN": "SUKAWANGI"
      },
      {
        "kodeKECAMATAN": 3216120,
        "kodeKABUPATEN": 3216,
        "namaKECAMATAN": "SUKATANI"
      },
      {
        "kodeKECAMATAN": 3216121,
        "kodeKABUPATEN": 3216,
        "namaKECAMATAN": "SUKAKARYA"
      },
      {
        "kodeKECAMATAN": 3216130,
        "kodeKABUPATEN": 3216,
        "namaKECAMATAN": "PEBAYURAN"
      },
      {
        "kodeKECAMATAN": 3216140,
        "kodeKABUPATEN": 3216,
        "namaKECAMATAN": "CABANGBUNGIN"
      },
      {
        "kodeKECAMATAN": 3216150,
        "kodeKABUPATEN": 3216,
        "namaKECAMATAN": "MUARA GEMBONG"
      },
      {
        "kodeKECAMATAN": 3217010,
        "kodeKABUPATEN": 3217,
        "namaKECAMATAN": "RONGGA"
      },
      {
        "kodeKECAMATAN": 3217020,
        "kodeKABUPATEN": 3217,
        "namaKECAMATAN": "GUNUNGHALU"
      },
      {
        "kodeKECAMATAN": 3217030,
        "kodeKABUPATEN": 3217,
        "namaKECAMATAN": "SINDANGKERTA"
      },
      {
        "kodeKECAMATAN": 3217040,
        "kodeKABUPATEN": 3217,
        "namaKECAMATAN": "CILILIN"
      },
      {
        "kodeKECAMATAN": 3217050,
        "kodeKABUPATEN": 3217,
        "namaKECAMATAN": "CIHAMPELAS"
      },
      {
        "kodeKECAMATAN": 3217060,
        "kodeKABUPATEN": 3217,
        "namaKECAMATAN": "CIPONGKOR"
      },
      {
        "kodeKECAMATAN": 3217070,
        "kodeKABUPATEN": 3217,
        "namaKECAMATAN": "BATUJAJAR"
      },
      {
        "kodeKECAMATAN": 3217071,
        "kodeKABUPATEN": 3217,
        "namaKECAMATAN": "SAGULING"
      },
      {
        "kodeKECAMATAN": 3217080,
        "kodeKABUPATEN": 3217,
        "namaKECAMATAN": "CIPATAT"
      },
      {
        "kodeKECAMATAN": 3217090,
        "kodeKABUPATEN": 3217,
        "namaKECAMATAN": "PADALARANG"
      },
      {
        "kodeKECAMATAN": 3217100,
        "kodeKABUPATEN": 3217,
        "namaKECAMATAN": "NGAMPRAH"
      },
      {
        "kodeKECAMATAN": 3217110,
        "kodeKABUPATEN": 3217,
        "namaKECAMATAN": "PARONGPONG"
      },
      {
        "kodeKECAMATAN": 3217120,
        "kodeKABUPATEN": 3217,
        "namaKECAMATAN": "LEMBANG"
      },
      {
        "kodeKECAMATAN": 3217130,
        "kodeKABUPATEN": 3217,
        "namaKECAMATAN": "CISARUA"
      },
      {
        "kodeKECAMATAN": 3217140,
        "kodeKABUPATEN": 3217,
        "namaKECAMATAN": "CIKALONG WETAN"
      },
      {
        "kodeKECAMATAN": 3217150,
        "kodeKABUPATEN": 3217,
        "namaKECAMATAN": "CIPEUNDEUY"
      },
      {
        "kodeKECAMATAN": 3218010,
        "kodeKABUPATEN": 3218,
        "namaKECAMATAN": "CIMERAK"
      },
      {
        "kodeKECAMATAN": 3218020,
        "kodeKABUPATEN": 3218,
        "namaKECAMATAN": "CIJULANG"
      },
      {
        "kodeKECAMATAN": 3218030,
        "kodeKABUPATEN": 3218,
        "namaKECAMATAN": "CIGUGUR"
      },
      {
        "kodeKECAMATAN": 3218040,
        "kodeKABUPATEN": 3218,
        "namaKECAMATAN": "LANGKAPLANCAR"
      },
      {
        "kodeKECAMATAN": 3218050,
        "kodeKABUPATEN": 3218,
        "namaKECAMATAN": "PARIGI"
      },
      {
        "kodeKECAMATAN": 3218060,
        "kodeKABUPATEN": 3218,
        "namaKECAMATAN": "SIDAMULIH"
      },
      {
        "kodeKECAMATAN": 3218070,
        "kodeKABUPATEN": 3218,
        "namaKECAMATAN": "PANGANDARAN"
      },
      {
        "kodeKECAMATAN": 3218080,
        "kodeKABUPATEN": 3218,
        "namaKECAMATAN": "KALIPUCANG"
      },
      {
        "kodeKECAMATAN": 3218090,
        "kodeKABUPATEN": 3218,
        "namaKECAMATAN": "PADAHERANG"
      },
      {
        "kodeKECAMATAN": 3218100,
        "kodeKABUPATEN": 3218,
        "namaKECAMATAN": "MANGUNJAYA"
      },
      {
        "kodeKECAMATAN": 3271010,
        "kodeKABUPATEN": 3271,
        "namaKECAMATAN": "BOGOR SELATAN"
      },
      {
        "kodeKECAMATAN": 3271020,
        "kodeKABUPATEN": 3271,
        "namaKECAMATAN": "BOGOR TIMUR"
      },
      {
        "kodeKECAMATAN": 3271030,
        "kodeKABUPATEN": 3271,
        "namaKECAMATAN": "BOGOR UTARA"
      },
      {
        "kodeKECAMATAN": 3271040,
        "kodeKABUPATEN": 3271,
        "namaKECAMATAN": "BOGOR TENGAH"
      },
      {
        "kodeKECAMATAN": 3271050,
        "kodeKABUPATEN": 3271,
        "namaKECAMATAN": "BOGOR BARAT"
      },
      {
        "kodeKECAMATAN": 3271060,
        "kodeKABUPATEN": 3271,
        "namaKECAMATAN": "TANAH SEREAL"
      },
      {
        "kodeKECAMATAN": 3272010,
        "kodeKABUPATEN": 3272,
        "namaKECAMATAN": "BAROS"
      },
      {
        "kodeKECAMATAN": 3272011,
        "kodeKABUPATEN": 3272,
        "namaKECAMATAN": "LEMBURSITU"
      },
      {
        "kodeKECAMATAN": 3272012,
        "kodeKABUPATEN": 3272,
        "namaKECAMATAN": "CIBEUREUM"
      },
      {
        "kodeKECAMATAN": 3272020,
        "kodeKABUPATEN": 3272,
        "namaKECAMATAN": "CITAMIANG"
      },
      {
        "kodeKECAMATAN": 3272030,
        "kodeKABUPATEN": 3272,
        "namaKECAMATAN": "WARUDOYONG"
      },
      {
        "kodeKECAMATAN": 3272040,
        "kodeKABUPATEN": 3272,
        "namaKECAMATAN": "GUNUNG PUYUH"
      },
      {
        "kodeKECAMATAN": 3272050,
        "kodeKABUPATEN": 3272,
        "namaKECAMATAN": "CIKOLE"
      },
      {
        "kodeKECAMATAN": 3273010,
        "kodeKABUPATEN": 3273,
        "namaKECAMATAN": "BANDUNG KULON"
      },
      {
        "kodeKECAMATAN": 3273020,
        "kodeKABUPATEN": 3273,
        "namaKECAMATAN": "BABAKAN CIPARAY"
      },
      {
        "kodeKECAMATAN": 3273030,
        "kodeKABUPATEN": 3273,
        "namaKECAMATAN": "BOJONGLOA KALER"
      },
      {
        "kodeKECAMATAN": 3273040,
        "kodeKABUPATEN": 3273,
        "namaKECAMATAN": "BOJONGLOA KIDUL"
      },
      {
        "kodeKECAMATAN": 3273050,
        "kodeKABUPATEN": 3273,
        "namaKECAMATAN": "ASTANAANYAR"
      },
      {
        "kodeKECAMATAN": 3273060,
        "kodeKABUPATEN": 3273,
        "namaKECAMATAN": "REGOL"
      },
      {
        "kodeKECAMATAN": 3273070,
        "kodeKABUPATEN": 3273,
        "namaKECAMATAN": "LENGKONG"
      },
      {
        "kodeKECAMATAN": 3273080,
        "kodeKABUPATEN": 3273,
        "namaKECAMATAN": "BANDUNG KIDUL"
      },
      {
        "kodeKECAMATAN": 3273090,
        "kodeKABUPATEN": 3273,
        "namaKECAMATAN": "BUAHBATU"
      },
      {
        "kodeKECAMATAN": 3273100,
        "kodeKABUPATEN": 3273,
        "namaKECAMATAN": "RANCASARI"
      },
      {
        "kodeKECAMATAN": 3273101,
        "kodeKABUPATEN": 3273,
        "namaKECAMATAN": "GEDEBAGE"
      },
      {
        "kodeKECAMATAN": 3273110,
        "kodeKABUPATEN": 3273,
        "namaKECAMATAN": "CIBIRU"
      },
      {
        "kodeKECAMATAN": 3273111,
        "kodeKABUPATEN": 3273,
        "namaKECAMATAN": "PANYILEUKAN"
      },
      {
        "kodeKECAMATAN": 3273120,
        "kodeKABUPATEN": 3273,
        "namaKECAMATAN": "UJUNG BERUNG"
      },
      {
        "kodeKECAMATAN": 3273121,
        "kodeKABUPATEN": 3273,
        "namaKECAMATAN": "CINAMBO"
      },
      {
        "kodeKECAMATAN": 3273130,
        "kodeKABUPATEN": 3273,
        "namaKECAMATAN": "ARCAMANIK"
      },
      {
        "kodeKECAMATAN": 3273141,
        "kodeKABUPATEN": 3273,
        "namaKECAMATAN": "ANTAPANI"
      },
      {
        "kodeKECAMATAN": 3273142,
        "kodeKABUPATEN": 3273,
        "namaKECAMATAN": "MANDALAJATI"
      },
      {
        "kodeKECAMATAN": 3273150,
        "kodeKABUPATEN": 3273,
        "namaKECAMATAN": "KIARACONDONG"
      },
      {
        "kodeKECAMATAN": 3273160,
        "kodeKABUPATEN": 3273,
        "namaKECAMATAN": "BATUNUNGGAL"
      },
      {
        "kodeKECAMATAN": 3273170,
        "kodeKABUPATEN": 3273,
        "namaKECAMATAN": "SUMUR BANDUNG"
      },
      {
        "kodeKECAMATAN": 3273180,
        "kodeKABUPATEN": 3273,
        "namaKECAMATAN": "ANDIR"
      },
      {
        "kodeKECAMATAN": 3273190,
        "kodeKABUPATEN": 3273,
        "namaKECAMATAN": "CICENDO"
      },
      {
        "kodeKECAMATAN": 3273200,
        "kodeKABUPATEN": 3273,
        "namaKECAMATAN": "BANDUNG WETAN"
      },
      {
        "kodeKECAMATAN": 3273210,
        "kodeKABUPATEN": 3273,
        "namaKECAMATAN": "CIBEUNYING KIDUL"
      },
      {
        "kodeKECAMATAN": 3273220,
        "kodeKABUPATEN": 3273,
        "namaKECAMATAN": "CIBEUNYING KALER"
      },
      {
        "kodeKECAMATAN": 3273230,
        "kodeKABUPATEN": 3273,
        "namaKECAMATAN": "COBLONG"
      },
      {
        "kodeKECAMATAN": 3273240,
        "kodeKABUPATEN": 3273,
        "namaKECAMATAN": "SUKAJADI"
      },
      {
        "kodeKECAMATAN": 3273250,
        "kodeKABUPATEN": 3273,
        "namaKECAMATAN": "SUKASARI"
      },
      {
        "kodeKECAMATAN": 3273260,
        "kodeKABUPATEN": 3273,
        "namaKECAMATAN": "CIDADAP"
      },
      {
        "kodeKECAMATAN": 3274010,
        "kodeKABUPATEN": 3274,
        "namaKECAMATAN": "HARJAMUKTI"
      },
      {
        "kodeKECAMATAN": 3274020,
        "kodeKABUPATEN": 3274,
        "namaKECAMATAN": "LEMAHWUNGKUK"
      },
      {
        "kodeKECAMATAN": 3274030,
        "kodeKABUPATEN": 3274,
        "namaKECAMATAN": "PEKALIPAN"
      },
      {
        "kodeKECAMATAN": 3274040,
        "kodeKABUPATEN": 3274,
        "namaKECAMATAN": "KESAMBI"
      },
      {
        "kodeKECAMATAN": 3274050,
        "kodeKABUPATEN": 3274,
        "namaKECAMATAN": "KEJAKSAN"
      },
      {
        "kodeKECAMATAN": 3275010,
        "kodeKABUPATEN": 3275,
        "namaKECAMATAN": "PONDOKGEDE"
      },
      {
        "kodeKECAMATAN": 3275011,
        "kodeKABUPATEN": 3275,
        "namaKECAMATAN": "JATISAMPURNA"
      },
      {
        "kodeKECAMATAN": 3275012,
        "kodeKABUPATEN": 3275,
        "namaKECAMATAN": "PONDOKMELATI"
      },
      {
        "kodeKECAMATAN": 3275020,
        "kodeKABUPATEN": 3275,
        "namaKECAMATAN": "JATIASIH"
      },
      {
        "kodeKECAMATAN": 3275030,
        "kodeKABUPATEN": 3275,
        "namaKECAMATAN": "BANTARGEBANG"
      },
      {
        "kodeKECAMATAN": 3275031,
        "kodeKABUPATEN": 3275,
        "namaKECAMATAN": "MUSTIKAJAYA"
      },
      {
        "kodeKECAMATAN": 3275040,
        "kodeKABUPATEN": 3275,
        "namaKECAMATAN": "BEKASI TIMUR"
      },
      {
        "kodeKECAMATAN": 3275041,
        "kodeKABUPATEN": 3275,
        "namaKECAMATAN": "RAWALUMBU"
      },
      {
        "kodeKECAMATAN": 3275050,
        "kodeKABUPATEN": 3275,
        "namaKECAMATAN": "BEKASI SELATAN"
      },
      {
        "kodeKECAMATAN": 3275060,
        "kodeKABUPATEN": 3275,
        "namaKECAMATAN": "BEKASI BARAT"
      },
      {
        "kodeKECAMATAN": 3275061,
        "kodeKABUPATEN": 3275,
        "namaKECAMATAN": "MEDAN SATRIA"
      },
      {
        "kodeKECAMATAN": 3275070,
        "kodeKABUPATEN": 3275,
        "namaKECAMATAN": "BEKASI UTARA"
      },
      {
        "kodeKECAMATAN": 3276010,
        "kodeKABUPATEN": 3276,
        "namaKECAMATAN": "SAWANGAN"
      },
      {
        "kodeKECAMATAN": 3276011,
        "kodeKABUPATEN": 3276,
        "namaKECAMATAN": "BOJONGSARI"
      },
      {
        "kodeKECAMATAN": 3276020,
        "kodeKABUPATEN": 3276,
        "namaKECAMATAN": "PANCORAN MAS"
      },
      {
        "kodeKECAMATAN": 3276021,
        "kodeKABUPATEN": 3276,
        "namaKECAMATAN": "CIPAYUNG"
      },
      {
        "kodeKECAMATAN": 3276030,
        "kodeKABUPATEN": 3276,
        "namaKECAMATAN": "SUKMA JAYA"
      },
      {
        "kodeKECAMATAN": 3276031,
        "kodeKABUPATEN": 3276,
        "namaKECAMATAN": "CILODONG"
      },
      {
        "kodeKECAMATAN": 3276040,
        "kodeKABUPATEN": 3276,
        "namaKECAMATAN": "CIMANGGIS"
      },
      {
        "kodeKECAMATAN": 3276041,
        "kodeKABUPATEN": 3276,
        "namaKECAMATAN": "TAPOS"
      },
      {
        "kodeKECAMATAN": 3276050,
        "kodeKABUPATEN": 3276,
        "namaKECAMATAN": "BEJI"
      },
      {
        "kodeKECAMATAN": 3276060,
        "kodeKABUPATEN": 3276,
        "namaKECAMATAN": "LIMO"
      },
      {
        "kodeKECAMATAN": 3276061,
        "kodeKABUPATEN": 3276,
        "namaKECAMATAN": "CINERE"
      },
      {
        "kodeKECAMATAN": 3277010,
        "kodeKABUPATEN": 3277,
        "namaKECAMATAN": "CIMAHI SELATAN"
      },
      {
        "kodeKECAMATAN": 3277020,
        "kodeKABUPATEN": 3277,
        "namaKECAMATAN": "CIMAHI TENGAH"
      },
      {
        "kodeKECAMATAN": 3277030,
        "kodeKABUPATEN": 3277,
        "namaKECAMATAN": "CIMAHI UTARA"
      },
      {
        "kodeKECAMATAN": 3278010,
        "kodeKABUPATEN": 3278,
        "namaKECAMATAN": "KAWALU"
      },
      {
        "kodeKECAMATAN": 3278020,
        "kodeKABUPATEN": 3278,
        "namaKECAMATAN": "TAMANSARI"
      },
      {
        "kodeKECAMATAN": 3278030,
        "kodeKABUPATEN": 3278,
        "namaKECAMATAN": "CIBEUREUM"
      },
      {
        "kodeKECAMATAN": 3278031,
        "kodeKABUPATEN": 3278,
        "namaKECAMATAN": "PURBARATU"
      },
      {
        "kodeKECAMATAN": 3278040,
        "kodeKABUPATEN": 3278,
        "namaKECAMATAN": "TAWANG"
      },
      {
        "kodeKECAMATAN": 3278050,
        "kodeKABUPATEN": 3278,
        "namaKECAMATAN": "CIHIDEUNG"
      },
      {
        "kodeKECAMATAN": 3278060,
        "kodeKABUPATEN": 3278,
        "namaKECAMATAN": "MANGKUBUMI"
      },
      {
        "kodeKECAMATAN": 3278070,
        "kodeKABUPATEN": 3278,
        "namaKECAMATAN": "INDIHIANG"
      },
      {
        "kodeKECAMATAN": 3278071,
        "kodeKABUPATEN": 3278,
        "namaKECAMATAN": "BUNGURSARI"
      },
      {
        "kodeKECAMATAN": 3278080,
        "kodeKABUPATEN": 3278,
        "namaKECAMATAN": "CIPEDES"
      },
      {
        "kodeKECAMATAN": 3279010,
        "kodeKABUPATEN": 3279,
        "namaKECAMATAN": "BANJAR"
      },
      {
        "kodeKECAMATAN": 3279020,
        "kodeKABUPATEN": 3279,
        "namaKECAMATAN": "PURWAHARJA"
      },
      {
        "kodeKECAMATAN": 3279030,
        "kodeKABUPATEN": 3279,
        "namaKECAMATAN": "PATARUMAN"
      },
      {
        "kodeKECAMATAN": 3279040,
        "kodeKABUPATEN": 3279,
        "namaKECAMATAN": "LANGENSARI"
      },
      {
        "kodeKECAMATAN": 3301010,
        "kodeKABUPATEN": 3301,
        "namaKECAMATAN": "DAYEUHLUHUR"
      },
      {
        "kodeKECAMATAN": 3301020,
        "kodeKABUPATEN": 3301,
        "namaKECAMATAN": "WANAREJA"
      },
      {
        "kodeKECAMATAN": 3301030,
        "kodeKABUPATEN": 3301,
        "namaKECAMATAN": "MAJENANG"
      },
      {
        "kodeKECAMATAN": 3301040,
        "kodeKABUPATEN": 3301,
        "namaKECAMATAN": "CIMANGGU"
      },
      {
        "kodeKECAMATAN": 3301050,
        "kodeKABUPATEN": 3301,
        "namaKECAMATAN": "KARANGPUCUNG"
      },
      {
        "kodeKECAMATAN": 3301060,
        "kodeKABUPATEN": 3301,
        "namaKECAMATAN": "CIPARI"
      },
      {
        "kodeKECAMATAN": 3301070,
        "kodeKABUPATEN": 3301,
        "namaKECAMATAN": "SIDAREJA"
      },
      {
        "kodeKECAMATAN": 3301080,
        "kodeKABUPATEN": 3301,
        "namaKECAMATAN": "KEDUNGREJA"
      },
      {
        "kodeKECAMATAN": 3301090,
        "kodeKABUPATEN": 3301,
        "namaKECAMATAN": "PATIMUAN"
      },
      {
        "kodeKECAMATAN": 3301100,
        "kodeKABUPATEN": 3301,
        "namaKECAMATAN": "GANDRUNGMANGU"
      },
      {
        "kodeKECAMATAN": 3301110,
        "kodeKABUPATEN": 3301,
        "namaKECAMATAN": "BANTARSARI"
      },
      {
        "kodeKECAMATAN": 3301120,
        "kodeKABUPATEN": 3301,
        "namaKECAMATAN": "KAWUNGANTEN"
      },
      {
        "kodeKECAMATAN": 3301121,
        "kodeKABUPATEN": 3301,
        "namaKECAMATAN": "KAMPUNG LAUT"
      },
      {
        "kodeKECAMATAN": 3301130,
        "kodeKABUPATEN": 3301,
        "namaKECAMATAN": "JERUKLEGI"
      },
      {
        "kodeKECAMATAN": 3301140,
        "kodeKABUPATEN": 3301,
        "namaKECAMATAN": "KESUGIHAN"
      },
      {
        "kodeKECAMATAN": 3301150,
        "kodeKABUPATEN": 3301,
        "namaKECAMATAN": "ADIPALA"
      },
      {
        "kodeKECAMATAN": 3301160,
        "kodeKABUPATEN": 3301,
        "namaKECAMATAN": "MAOS"
      },
      {
        "kodeKECAMATAN": 3301170,
        "kodeKABUPATEN": 3301,
        "namaKECAMATAN": "SAMPANG"
      },
      {
        "kodeKECAMATAN": 3301180,
        "kodeKABUPATEN": 3301,
        "namaKECAMATAN": "KROYA"
      },
      {
        "kodeKECAMATAN": 3301190,
        "kodeKABUPATEN": 3301,
        "namaKECAMATAN": "BINANGUN"
      },
      {
        "kodeKECAMATAN": 3301200,
        "kodeKABUPATEN": 3301,
        "namaKECAMATAN": "NUSAWUNGU"
      },
      {
        "kodeKECAMATAN": 3301710,
        "kodeKABUPATEN": 3301,
        "namaKECAMATAN": "CILACAP SELATAN"
      },
      {
        "kodeKECAMATAN": 3301720,
        "kodeKABUPATEN": 3301,
        "namaKECAMATAN": "CILACAP TENGAH"
      },
      {
        "kodeKECAMATAN": 3301730,
        "kodeKABUPATEN": 3301,
        "namaKECAMATAN": "CILACAP UTARA"
      },
      {
        "kodeKECAMATAN": 3302010,
        "kodeKABUPATEN": 3302,
        "namaKECAMATAN": "LUMBIR"
      },
      {
        "kodeKECAMATAN": 3302020,
        "kodeKABUPATEN": 3302,
        "namaKECAMATAN": "WANGON"
      },
      {
        "kodeKECAMATAN": 3302030,
        "kodeKABUPATEN": 3302,
        "namaKECAMATAN": "JATILAWANG"
      },
      {
        "kodeKECAMATAN": 3302040,
        "kodeKABUPATEN": 3302,
        "namaKECAMATAN": "RAWALO"
      },
      {
        "kodeKECAMATAN": 3302050,
        "kodeKABUPATEN": 3302,
        "namaKECAMATAN": "KEBASEN"
      },
      {
        "kodeKECAMATAN": 3302060,
        "kodeKABUPATEN": 3302,
        "namaKECAMATAN": "KEMRANJEN"
      },
      {
        "kodeKECAMATAN": 3302070,
        "kodeKABUPATEN": 3302,
        "namaKECAMATAN": "SUMPIUH"
      },
      {
        "kodeKECAMATAN": 3302080,
        "kodeKABUPATEN": 3302,
        "namaKECAMATAN": "TAMBAK"
      },
      {
        "kodeKECAMATAN": 3302090,
        "kodeKABUPATEN": 3302,
        "namaKECAMATAN": "SOMAGEDE"
      },
      {
        "kodeKECAMATAN": 3302100,
        "kodeKABUPATEN": 3302,
        "namaKECAMATAN": "KALIBAGOR"
      },
      {
        "kodeKECAMATAN": 3302110,
        "kodeKABUPATEN": 3302,
        "namaKECAMATAN": "BANYUMAS"
      },
      {
        "kodeKECAMATAN": 3302120,
        "kodeKABUPATEN": 3302,
        "namaKECAMATAN": "PATIKRAJA"
      },
      {
        "kodeKECAMATAN": 3302130,
        "kodeKABUPATEN": 3302,
        "namaKECAMATAN": "PURWOJATI"
      },
      {
        "kodeKECAMATAN": 3302140,
        "kodeKABUPATEN": 3302,
        "namaKECAMATAN": "AJIBARANG"
      },
      {
        "kodeKECAMATAN": 3302150,
        "kodeKABUPATEN": 3302,
        "namaKECAMATAN": "GUMELAR"
      },
      {
        "kodeKECAMATAN": 3302160,
        "kodeKABUPATEN": 3302,
        "namaKECAMATAN": "PEKUNCEN"
      },
      {
        "kodeKECAMATAN": 3302170,
        "kodeKABUPATEN": 3302,
        "namaKECAMATAN": "CILONGOK"
      },
      {
        "kodeKECAMATAN": 3302180,
        "kodeKABUPATEN": 3302,
        "namaKECAMATAN": "KARANGLEWAS"
      },
      {
        "kodeKECAMATAN": 3302190,
        "kodeKABUPATEN": 3302,
        "namaKECAMATAN": "KEDUNG BANTENG"
      },
      {
        "kodeKECAMATAN": 3302200,
        "kodeKABUPATEN": 3302,
        "namaKECAMATAN": "BATURRADEN"
      },
      {
        "kodeKECAMATAN": 3302210,
        "kodeKABUPATEN": 3302,
        "namaKECAMATAN": "SUMBANG"
      },
      {
        "kodeKECAMATAN": 3302220,
        "kodeKABUPATEN": 3302,
        "namaKECAMATAN": "KEMBARAN"
      },
      {
        "kodeKECAMATAN": 3302230,
        "kodeKABUPATEN": 3302,
        "namaKECAMATAN": "SOKARAJA"
      },
      {
        "kodeKECAMATAN": 3302710,
        "kodeKABUPATEN": 3302,
        "namaKECAMATAN": "PURWOKERTO SELATAN"
      },
      {
        "kodeKECAMATAN": 3302720,
        "kodeKABUPATEN": 3302,
        "namaKECAMATAN": "PURWOKERTO BARAT"
      },
      {
        "kodeKECAMATAN": 3302730,
        "kodeKABUPATEN": 3302,
        "namaKECAMATAN": "PURWOKERTO TIMUR"
      },
      {
        "kodeKECAMATAN": 3302740,
        "kodeKABUPATEN": 3302,
        "namaKECAMATAN": "PURWOKERTO UTARA"
      },
      {
        "kodeKECAMATAN": 3303010,
        "kodeKABUPATEN": 3303,
        "namaKECAMATAN": "KEMANGKON"
      },
      {
        "kodeKECAMATAN": 3303020,
        "kodeKABUPATEN": 3303,
        "namaKECAMATAN": "BUKATEJA"
      },
      {
        "kodeKECAMATAN": 3303030,
        "kodeKABUPATEN": 3303,
        "namaKECAMATAN": "KEJOBONG"
      },
      {
        "kodeKECAMATAN": 3303040,
        "kodeKABUPATEN": 3303,
        "namaKECAMATAN": "PENGADEGAN"
      },
      {
        "kodeKECAMATAN": 3303050,
        "kodeKABUPATEN": 3303,
        "namaKECAMATAN": "KALIGONDANG"
      },
      {
        "kodeKECAMATAN": 3303060,
        "kodeKABUPATEN": 3303,
        "namaKECAMATAN": "PURBALINGGA"
      },
      {
        "kodeKECAMATAN": 3303070,
        "kodeKABUPATEN": 3303,
        "namaKECAMATAN": "KALIMANAH"
      },
      {
        "kodeKECAMATAN": 3303080,
        "kodeKABUPATEN": 3303,
        "namaKECAMATAN": "PADAMARA"
      },
      {
        "kodeKECAMATAN": 3303090,
        "kodeKABUPATEN": 3303,
        "namaKECAMATAN": "KUTASARI"
      },
      {
        "kodeKECAMATAN": 3303100,
        "kodeKABUPATEN": 3303,
        "namaKECAMATAN": "BOJONGSARI"
      },
      {
        "kodeKECAMATAN": 3303110,
        "kodeKABUPATEN": 3303,
        "namaKECAMATAN": "MREBET"
      },
      {
        "kodeKECAMATAN": 3303120,
        "kodeKABUPATEN": 3303,
        "namaKECAMATAN": "BOBOTSARI"
      },
      {
        "kodeKECAMATAN": 3303130,
        "kodeKABUPATEN": 3303,
        "namaKECAMATAN": "KARANGREJA"
      },
      {
        "kodeKECAMATAN": 3303131,
        "kodeKABUPATEN": 3303,
        "namaKECAMATAN": "KARANGJAMBU"
      },
      {
        "kodeKECAMATAN": 3303140,
        "kodeKABUPATEN": 3303,
        "namaKECAMATAN": "KARANGANYAR"
      },
      {
        "kodeKECAMATAN": 3303141,
        "kodeKABUPATEN": 3303,
        "namaKECAMATAN": "KERTANEGARA"
      },
      {
        "kodeKECAMATAN": 3303150,
        "kodeKABUPATEN": 3303,
        "namaKECAMATAN": "KARANGMONCOL"
      },
      {
        "kodeKECAMATAN": 3303160,
        "kodeKABUPATEN": 3303,
        "namaKECAMATAN": "REMBANG"
      },
      {
        "kodeKECAMATAN": 3304010,
        "kodeKABUPATEN": 3304,
        "namaKECAMATAN": "SUSUKAN"
      },
      {
        "kodeKECAMATAN": 3304020,
        "kodeKABUPATEN": 3304,
        "namaKECAMATAN": "PURWAREJA KLAMPOK"
      },
      {
        "kodeKECAMATAN": 3304030,
        "kodeKABUPATEN": 3304,
        "namaKECAMATAN": "MANDIRAJA"
      },
      {
        "kodeKECAMATAN": 3304040,
        "kodeKABUPATEN": 3304,
        "namaKECAMATAN": "PURWANEGARA"
      },
      {
        "kodeKECAMATAN": 3304050,
        "kodeKABUPATEN": 3304,
        "namaKECAMATAN": "BAWANG"
      },
      {
        "kodeKECAMATAN": 3304060,
        "kodeKABUPATEN": 3304,
        "namaKECAMATAN": "BANJARNEGARA"
      },
      {
        "kodeKECAMATAN": 3304061,
        "kodeKABUPATEN": 3304,
        "namaKECAMATAN": "PAGEDONGAN"
      },
      {
        "kodeKECAMATAN": 3304070,
        "kodeKABUPATEN": 3304,
        "namaKECAMATAN": "SIGALUH"
      },
      {
        "kodeKECAMATAN": 3304080,
        "kodeKABUPATEN": 3304,
        "namaKECAMATAN": "MADUKARA"
      },
      {
        "kodeKECAMATAN": 3304090,
        "kodeKABUPATEN": 3304,
        "namaKECAMATAN": "BANJARMANGU"
      },
      {
        "kodeKECAMATAN": 3304100,
        "kodeKABUPATEN": 3304,
        "namaKECAMATAN": "WANADADI"
      },
      {
        "kodeKECAMATAN": 3304110,
        "kodeKABUPATEN": 3304,
        "namaKECAMATAN": "RAKIT"
      },
      {
        "kodeKECAMATAN": 3304120,
        "kodeKABUPATEN": 3304,
        "namaKECAMATAN": "PUNGGELAN"
      },
      {
        "kodeKECAMATAN": 3304130,
        "kodeKABUPATEN": 3304,
        "namaKECAMATAN": "KARANGKOBAR"
      },
      {
        "kodeKECAMATAN": 3304140,
        "kodeKABUPATEN": 3304,
        "namaKECAMATAN": "PAGENTAN"
      },
      {
        "kodeKECAMATAN": 3304150,
        "kodeKABUPATEN": 3304,
        "namaKECAMATAN": "PEJAWARAN"
      },
      {
        "kodeKECAMATAN": 3304160,
        "kodeKABUPATEN": 3304,
        "namaKECAMATAN": "BATUR"
      },
      {
        "kodeKECAMATAN": 3304170,
        "kodeKABUPATEN": 3304,
        "namaKECAMATAN": "WANAYASA"
      },
      {
        "kodeKECAMATAN": 3304180,
        "kodeKABUPATEN": 3304,
        "namaKECAMATAN": "KALIBENING"
      },
      {
        "kodeKECAMATAN": 3304181,
        "kodeKABUPATEN": 3304,
        "namaKECAMATAN": "PANDANARUM"
      },
      {
        "kodeKECAMATAN": 3305010,
        "kodeKABUPATEN": 3305,
        "namaKECAMATAN": "AYAH"
      },
      {
        "kodeKECAMATAN": 3305020,
        "kodeKABUPATEN": 3305,
        "namaKECAMATAN": "BUAYAN"
      },
      {
        "kodeKECAMATAN": 3305030,
        "kodeKABUPATEN": 3305,
        "namaKECAMATAN": "PURING"
      },
      {
        "kodeKECAMATAN": 3305040,
        "kodeKABUPATEN": 3305,
        "namaKECAMATAN": "PETANAHAN"
      },
      {
        "kodeKECAMATAN": 3305050,
        "kodeKABUPATEN": 3305,
        "namaKECAMATAN": "KLIRONG"
      },
      {
        "kodeKECAMATAN": 3305060,
        "kodeKABUPATEN": 3305,
        "namaKECAMATAN": "BULUSPESANTREN"
      },
      {
        "kodeKECAMATAN": 3305070,
        "kodeKABUPATEN": 3305,
        "namaKECAMATAN": "AMBAL"
      },
      {
        "kodeKECAMATAN": 3305080,
        "kodeKABUPATEN": 3305,
        "namaKECAMATAN": "MIRIT"
      },
      {
        "kodeKECAMATAN": 3305081,
        "kodeKABUPATEN": 3305,
        "namaKECAMATAN": "BONOROWO"
      },
      {
        "kodeKECAMATAN": 3305090,
        "kodeKABUPATEN": 3305,
        "namaKECAMATAN": "PREMBUN"
      },
      {
        "kodeKECAMATAN": 3305091,
        "kodeKABUPATEN": 3305,
        "namaKECAMATAN": "PADURESO"
      },
      {
        "kodeKECAMATAN": 3305100,
        "kodeKABUPATEN": 3305,
        "namaKECAMATAN": "KUTOWINANGUN"
      },
      {
        "kodeKECAMATAN": 3305110,
        "kodeKABUPATEN": 3305,
        "namaKECAMATAN": "ALIAN"
      },
      {
        "kodeKECAMATAN": 3305111,
        "kodeKABUPATEN": 3305,
        "namaKECAMATAN": "PONCOWARNO"
      },
      {
        "kodeKECAMATAN": 3305120,
        "kodeKABUPATEN": 3305,
        "namaKECAMATAN": "KEBUMEN"
      },
      {
        "kodeKECAMATAN": 3305130,
        "kodeKABUPATEN": 3305,
        "namaKECAMATAN": "PEJAGOAN"
      },
      {
        "kodeKECAMATAN": 3305140,
        "kodeKABUPATEN": 3305,
        "namaKECAMATAN": "SRUWENG"
      },
      {
        "kodeKECAMATAN": 3305150,
        "kodeKABUPATEN": 3305,
        "namaKECAMATAN": "ADIMULYO"
      },
      {
        "kodeKECAMATAN": 3305160,
        "kodeKABUPATEN": 3305,
        "namaKECAMATAN": "KUWARASAN"
      },
      {
        "kodeKECAMATAN": 3305170,
        "kodeKABUPATEN": 3305,
        "namaKECAMATAN": "ROWOKELE"
      },
      {
        "kodeKECAMATAN": 3305180,
        "kodeKABUPATEN": 3305,
        "namaKECAMATAN": "SEMPOR"
      },
      {
        "kodeKECAMATAN": 3305190,
        "kodeKABUPATEN": 3305,
        "namaKECAMATAN": "GOMBONG"
      },
      {
        "kodeKECAMATAN": 3305200,
        "kodeKABUPATEN": 3305,
        "namaKECAMATAN": "KARANGANYAR"
      },
      {
        "kodeKECAMATAN": 3305210,
        "kodeKABUPATEN": 3305,
        "namaKECAMATAN": "KARANGGAYAM"
      },
      {
        "kodeKECAMATAN": 3305220,
        "kodeKABUPATEN": 3305,
        "namaKECAMATAN": "SADANG"
      },
      {
        "kodeKECAMATAN": 3305221,
        "kodeKABUPATEN": 3305,
        "namaKECAMATAN": "KARANGSAMBUNG"
      },
      {
        "kodeKECAMATAN": 3306010,
        "kodeKABUPATEN": 3306,
        "namaKECAMATAN": "GRABAG"
      },
      {
        "kodeKECAMATAN": 3306020,
        "kodeKABUPATEN": 3306,
        "namaKECAMATAN": "NGOMBOL"
      },
      {
        "kodeKECAMATAN": 3306030,
        "kodeKABUPATEN": 3306,
        "namaKECAMATAN": "PURWODADI"
      },
      {
        "kodeKECAMATAN": 3306040,
        "kodeKABUPATEN": 3306,
        "namaKECAMATAN": "BAGELEN"
      },
      {
        "kodeKECAMATAN": 3306050,
        "kodeKABUPATEN": 3306,
        "namaKECAMATAN": "KALIGESING"
      },
      {
        "kodeKECAMATAN": 3306060,
        "kodeKABUPATEN": 3306,
        "namaKECAMATAN": "PURWOREJO"
      },
      {
        "kodeKECAMATAN": 3306070,
        "kodeKABUPATEN": 3306,
        "namaKECAMATAN": "BANYU URIP"
      },
      {
        "kodeKECAMATAN": 3306080,
        "kodeKABUPATEN": 3306,
        "namaKECAMATAN": "BAYAN"
      },
      {
        "kodeKECAMATAN": 3306090,
        "kodeKABUPATEN": 3306,
        "namaKECAMATAN": "KUTOARJO"
      },
      {
        "kodeKECAMATAN": 3306100,
        "kodeKABUPATEN": 3306,
        "namaKECAMATAN": "BUTUH"
      },
      {
        "kodeKECAMATAN": 3306110,
        "kodeKABUPATEN": 3306,
        "namaKECAMATAN": "PITURUH"
      },
      {
        "kodeKECAMATAN": 3306120,
        "kodeKABUPATEN": 3306,
        "namaKECAMATAN": "KEMIRI"
      },
      {
        "kodeKECAMATAN": 3306130,
        "kodeKABUPATEN": 3306,
        "namaKECAMATAN": "BRUNO"
      },
      {
        "kodeKECAMATAN": 3306140,
        "kodeKABUPATEN": 3306,
        "namaKECAMATAN": "GEBANG"
      },
      {
        "kodeKECAMATAN": 3306150,
        "kodeKABUPATEN": 3306,
        "namaKECAMATAN": "LOANO"
      },
      {
        "kodeKECAMATAN": 3306160,
        "kodeKABUPATEN": 3306,
        "namaKECAMATAN": "BENER"
      },
      {
        "kodeKECAMATAN": 3307010,
        "kodeKABUPATEN": 3307,
        "namaKECAMATAN": "WADASLINTANG"
      },
      {
        "kodeKECAMATAN": 3307020,
        "kodeKABUPATEN": 3307,
        "namaKECAMATAN": "KEPIL"
      },
      {
        "kodeKECAMATAN": 3307030,
        "kodeKABUPATEN": 3307,
        "namaKECAMATAN": "SAPURAN"
      },
      {
        "kodeKECAMATAN": 3307031,
        "kodeKABUPATEN": 3307,
        "namaKECAMATAN": "KALIBAWANG"
      },
      {
        "kodeKECAMATAN": 3307040,
        "kodeKABUPATEN": 3307,
        "namaKECAMATAN": "KALIWIRO"
      },
      {
        "kodeKECAMATAN": 3307050,
        "kodeKABUPATEN": 3307,
        "namaKECAMATAN": "LEKSONO"
      },
      {
        "kodeKECAMATAN": 3307051,
        "kodeKABUPATEN": 3307,
        "namaKECAMATAN": "SUKOHARJO"
      },
      {
        "kodeKECAMATAN": 3307060,
        "kodeKABUPATEN": 3307,
        "namaKECAMATAN": "SELOMERTO"
      },
      {
        "kodeKECAMATAN": 3307070,
        "kodeKABUPATEN": 3307,
        "namaKECAMATAN": "KALIKAJAR"
      },
      {
        "kodeKECAMATAN": 3307080,
        "kodeKABUPATEN": 3307,
        "namaKECAMATAN": "KERTEK"
      },
      {
        "kodeKECAMATAN": 3307090,
        "kodeKABUPATEN": 3307,
        "namaKECAMATAN": "WONOSOBO"
      },
      {
        "kodeKECAMATAN": 3307100,
        "kodeKABUPATEN": 3307,
        "namaKECAMATAN": "WATUMALANG"
      },
      {
        "kodeKECAMATAN": 3307110,
        "kodeKABUPATEN": 3307,
        "namaKECAMATAN": "MOJOTENGAH"
      },
      {
        "kodeKECAMATAN": 3307120,
        "kodeKABUPATEN": 3307,
        "namaKECAMATAN": "GARUNG"
      },
      {
        "kodeKECAMATAN": 3307130,
        "kodeKABUPATEN": 3307,
        "namaKECAMATAN": "KEJAJAR"
      },
      {
        "kodeKECAMATAN": 3308010,
        "kodeKABUPATEN": 3308,
        "namaKECAMATAN": "SALAMAN"
      },
      {
        "kodeKECAMATAN": 3308020,
        "kodeKABUPATEN": 3308,
        "namaKECAMATAN": "BOROBUDUR"
      },
      {
        "kodeKECAMATAN": 3308030,
        "kodeKABUPATEN": 3308,
        "namaKECAMATAN": "NGLUWAR"
      },
      {
        "kodeKECAMATAN": 3308040,
        "kodeKABUPATEN": 3308,
        "namaKECAMATAN": "SALAM"
      },
      {
        "kodeKECAMATAN": 3308050,
        "kodeKABUPATEN": 3308,
        "namaKECAMATAN": "SRUMBUNG"
      },
      {
        "kodeKECAMATAN": 3308060,
        "kodeKABUPATEN": 3308,
        "namaKECAMATAN": "DUKUN"
      },
      {
        "kodeKECAMATAN": 3308070,
        "kodeKABUPATEN": 3308,
        "namaKECAMATAN": "MUNTILAN"
      },
      {
        "kodeKECAMATAN": 3308080,
        "kodeKABUPATEN": 3308,
        "namaKECAMATAN": "MUNGKID"
      },
      {
        "kodeKECAMATAN": 3308090,
        "kodeKABUPATEN": 3308,
        "namaKECAMATAN": "SAWANGAN"
      },
      {
        "kodeKECAMATAN": 3308100,
        "kodeKABUPATEN": 3308,
        "namaKECAMATAN": "CANDIMULYO"
      },
      {
        "kodeKECAMATAN": 3308110,
        "kodeKABUPATEN": 3308,
        "namaKECAMATAN": "MERTOYUDAN"
      },
      {
        "kodeKECAMATAN": 3308120,
        "kodeKABUPATEN": 3308,
        "namaKECAMATAN": "TEMPURAN"
      },
      {
        "kodeKECAMATAN": 3308130,
        "kodeKABUPATEN": 3308,
        "namaKECAMATAN": "KAJORAN"
      },
      {
        "kodeKECAMATAN": 3308140,
        "kodeKABUPATEN": 3308,
        "namaKECAMATAN": "KALIANGKRIK"
      },
      {
        "kodeKECAMATAN": 3308150,
        "kodeKABUPATEN": 3308,
        "namaKECAMATAN": "BANDONGAN"
      },
      {
        "kodeKECAMATAN": 3308160,
        "kodeKABUPATEN": 3308,
        "namaKECAMATAN": "WINDUSARI"
      },
      {
        "kodeKECAMATAN": 3308170,
        "kodeKABUPATEN": 3308,
        "namaKECAMATAN": "SECANG"
      },
      {
        "kodeKECAMATAN": 3308180,
        "kodeKABUPATEN": 3308,
        "namaKECAMATAN": "TEGALREJO"
      },
      {
        "kodeKECAMATAN": 3308190,
        "kodeKABUPATEN": 3308,
        "namaKECAMATAN": "PAKIS"
      },
      {
        "kodeKECAMATAN": 3308200,
        "kodeKABUPATEN": 3308,
        "namaKECAMATAN": "GRABAG"
      },
      {
        "kodeKECAMATAN": 3308210,
        "kodeKABUPATEN": 3308,
        "namaKECAMATAN": "NGABLAK"
      },
      {
        "kodeKECAMATAN": 3309010,
        "kodeKABUPATEN": 3309,
        "namaKECAMATAN": "SELO"
      },
      {
        "kodeKECAMATAN": 3309020,
        "kodeKABUPATEN": 3309,
        "namaKECAMATAN": "AMPEL"
      },
      {
        "kodeKECAMATAN": 3309030,
        "kodeKABUPATEN": 3309,
        "namaKECAMATAN": "CEPOGO"
      },
      {
        "kodeKECAMATAN": 3309040,
        "kodeKABUPATEN": 3309,
        "namaKECAMATAN": "MUSUK"
      },
      {
        "kodeKECAMATAN": 3309050,
        "kodeKABUPATEN": 3309,
        "namaKECAMATAN": "BOYOLALI"
      },
      {
        "kodeKECAMATAN": 3309060,
        "kodeKABUPATEN": 3309,
        "namaKECAMATAN": "MOJOSONGO"
      },
      {
        "kodeKECAMATAN": 3309070,
        "kodeKABUPATEN": 3309,
        "namaKECAMATAN": "TERAS"
      },
      {
        "kodeKECAMATAN": 3309080,
        "kodeKABUPATEN": 3309,
        "namaKECAMATAN": "SAWIT"
      },
      {
        "kodeKECAMATAN": 3309090,
        "kodeKABUPATEN": 3309,
        "namaKECAMATAN": "BANYUDONO"
      },
      {
        "kodeKECAMATAN": 3309100,
        "kodeKABUPATEN": 3309,
        "namaKECAMATAN": "SAMBI"
      },
      {
        "kodeKECAMATAN": 3309110,
        "kodeKABUPATEN": 3309,
        "namaKECAMATAN": "NGEMPLAK"
      },
      {
        "kodeKECAMATAN": 3309120,
        "kodeKABUPATEN": 3309,
        "namaKECAMATAN": "NOGOSARI"
      },
      {
        "kodeKECAMATAN": 3309130,
        "kodeKABUPATEN": 3309,
        "namaKECAMATAN": "SIMO"
      },
      {
        "kodeKECAMATAN": 3309140,
        "kodeKABUPATEN": 3309,
        "namaKECAMATAN": "KARANGGEDE"
      },
      {
        "kodeKECAMATAN": 3309150,
        "kodeKABUPATEN": 3309,
        "namaKECAMATAN": "KLEGO"
      },
      {
        "kodeKECAMATAN": 3309160,
        "kodeKABUPATEN": 3309,
        "namaKECAMATAN": "ANDONG"
      },
      {
        "kodeKECAMATAN": 3309170,
        "kodeKABUPATEN": 3309,
        "namaKECAMATAN": "KEMUSU"
      },
      {
        "kodeKECAMATAN": 3309180,
        "kodeKABUPATEN": 3309,
        "namaKECAMATAN": "WONOSEGORO"
      },
      {
        "kodeKECAMATAN": 3309190,
        "kodeKABUPATEN": 3309,
        "namaKECAMATAN": "JUWANGI"
      },
      {
        "kodeKECAMATAN": 3310010,
        "kodeKABUPATEN": 3310,
        "namaKECAMATAN": "PRAMBANAN"
      },
      {
        "kodeKECAMATAN": 3310020,
        "kodeKABUPATEN": 3310,
        "namaKECAMATAN": "GANTIWARNO"
      },
      {
        "kodeKECAMATAN": 3310030,
        "kodeKABUPATEN": 3310,
        "namaKECAMATAN": "WEDI"
      },
      {
        "kodeKECAMATAN": 3310040,
        "kodeKABUPATEN": 3310,
        "namaKECAMATAN": "BAYAT"
      },
      {
        "kodeKECAMATAN": 3310050,
        "kodeKABUPATEN": 3310,
        "namaKECAMATAN": "CAWAS"
      },
      {
        "kodeKECAMATAN": 3310060,
        "kodeKABUPATEN": 3310,
        "namaKECAMATAN": "TRUCUK"
      },
      {
        "kodeKECAMATAN": 3310070,
        "kodeKABUPATEN": 3310,
        "namaKECAMATAN": "KALIKOTES"
      },
      {
        "kodeKECAMATAN": 3310080,
        "kodeKABUPATEN": 3310,
        "namaKECAMATAN": "KEBONARUM"
      },
      {
        "kodeKECAMATAN": 3310090,
        "kodeKABUPATEN": 3310,
        "namaKECAMATAN": "JOGONALAN"
      },
      {
        "kodeKECAMATAN": 3310100,
        "kodeKABUPATEN": 3310,
        "namaKECAMATAN": "MANISRENGGO"
      },
      {
        "kodeKECAMATAN": 3310110,
        "kodeKABUPATEN": 3310,
        "namaKECAMATAN": "KARANGNONGKO"
      },
      {
        "kodeKECAMATAN": 3310120,
        "kodeKABUPATEN": 3310,
        "namaKECAMATAN": "NGAWEN"
      },
      {
        "kodeKECAMATAN": 3310130,
        "kodeKABUPATEN": 3310,
        "namaKECAMATAN": "CEPER"
      },
      {
        "kodeKECAMATAN": 3310140,
        "kodeKABUPATEN": 3310,
        "namaKECAMATAN": "PEDAN"
      },
      {
        "kodeKECAMATAN": 3310150,
        "kodeKABUPATEN": 3310,
        "namaKECAMATAN": "KARANGDOWO"
      },
      {
        "kodeKECAMATAN": 3310160,
        "kodeKABUPATEN": 3310,
        "namaKECAMATAN": "JUWIRING"
      },
      {
        "kodeKECAMATAN": 3310170,
        "kodeKABUPATEN": 3310,
        "namaKECAMATAN": "WONOSARI"
      },
      {
        "kodeKECAMATAN": 3310180,
        "kodeKABUPATEN": 3310,
        "namaKECAMATAN": "DELANGGU"
      },
      {
        "kodeKECAMATAN": 3310190,
        "kodeKABUPATEN": 3310,
        "namaKECAMATAN": "POLANHARJO"
      },
      {
        "kodeKECAMATAN": 3310200,
        "kodeKABUPATEN": 3310,
        "namaKECAMATAN": "KARANGANOM"
      },
      {
        "kodeKECAMATAN": 3310210,
        "kodeKABUPATEN": 3310,
        "namaKECAMATAN": "TULUNG"
      },
      {
        "kodeKECAMATAN": 3310220,
        "kodeKABUPATEN": 3310,
        "namaKECAMATAN": "JATINOM"
      },
      {
        "kodeKECAMATAN": 3310230,
        "kodeKABUPATEN": 3310,
        "namaKECAMATAN": "KEMALANG"
      },
      {
        "kodeKECAMATAN": 3310710,
        "kodeKABUPATEN": 3310,
        "namaKECAMATAN": "KLATEN SELATAN"
      },
      {
        "kodeKECAMATAN": 3310720,
        "kodeKABUPATEN": 3310,
        "namaKECAMATAN": "KLATEN TENGAH"
      },
      {
        "kodeKECAMATAN": 3310730,
        "kodeKABUPATEN": 3310,
        "namaKECAMATAN": "KLATEN UTARA"
      },
      {
        "kodeKECAMATAN": 3311010,
        "kodeKABUPATEN": 3311,
        "namaKECAMATAN": "WERU"
      },
      {
        "kodeKECAMATAN": 3311020,
        "kodeKABUPATEN": 3311,
        "namaKECAMATAN": "BULU"
      },
      {
        "kodeKECAMATAN": 3311030,
        "kodeKABUPATEN": 3311,
        "namaKECAMATAN": "TAWANGSARI"
      },
      {
        "kodeKECAMATAN": 3311040,
        "kodeKABUPATEN": 3311,
        "namaKECAMATAN": "SUKOHARJO"
      },
      {
        "kodeKECAMATAN": 3311050,
        "kodeKABUPATEN": 3311,
        "namaKECAMATAN": "NGUTER"
      },
      {
        "kodeKECAMATAN": 3311060,
        "kodeKABUPATEN": 3311,
        "namaKECAMATAN": "BENDOSARI"
      },
      {
        "kodeKECAMATAN": 3311070,
        "kodeKABUPATEN": 3311,
        "namaKECAMATAN": "POLOKARTO"
      },
      {
        "kodeKECAMATAN": 3311080,
        "kodeKABUPATEN": 3311,
        "namaKECAMATAN": "MOJOLABAN"
      },
      {
        "kodeKECAMATAN": 3311090,
        "kodeKABUPATEN": 3311,
        "namaKECAMATAN": "GROGOL"
      },
      {
        "kodeKECAMATAN": 3311100,
        "kodeKABUPATEN": 3311,
        "namaKECAMATAN": "BAKI"
      },
      {
        "kodeKECAMATAN": 3311110,
        "kodeKABUPATEN": 3311,
        "namaKECAMATAN": "GATAK"
      },
      {
        "kodeKECAMATAN": 3311120,
        "kodeKABUPATEN": 3311,
        "namaKECAMATAN": "KARTASURA"
      },
      {
        "kodeKECAMATAN": 3312010,
        "kodeKABUPATEN": 3312,
        "namaKECAMATAN": "PRACIMANTORO"
      },
      {
        "kodeKECAMATAN": 3312020,
        "kodeKABUPATEN": 3312,
        "namaKECAMATAN": "PARANGGUPITO"
      },
      {
        "kodeKECAMATAN": 3312030,
        "kodeKABUPATEN": 3312,
        "namaKECAMATAN": "GIRITONTRO"
      },
      {
        "kodeKECAMATAN": 3312040,
        "kodeKABUPATEN": 3312,
        "namaKECAMATAN": "GIRIWOYO"
      },
      {
        "kodeKECAMATAN": 3312050,
        "kodeKABUPATEN": 3312,
        "namaKECAMATAN": "BATUWARNO"
      },
      {
        "kodeKECAMATAN": 3312060,
        "kodeKABUPATEN": 3312,
        "namaKECAMATAN": "KARANGTENGAH"
      },
      {
        "kodeKECAMATAN": 3312070,
        "kodeKABUPATEN": 3312,
        "namaKECAMATAN": "TIRTOMOYO"
      },
      {
        "kodeKECAMATAN": 3312080,
        "kodeKABUPATEN": 3312,
        "namaKECAMATAN": "NGUNTORONADI"
      },
      {
        "kodeKECAMATAN": 3312090,
        "kodeKABUPATEN": 3312,
        "namaKECAMATAN": "BATURETNO"
      },
      {
        "kodeKECAMATAN": 3312100,
        "kodeKABUPATEN": 3312,
        "namaKECAMATAN": "EROMOKO"
      },
      {
        "kodeKECAMATAN": 3312110,
        "kodeKABUPATEN": 3312,
        "namaKECAMATAN": "WURYANTORO"
      },
      {
        "kodeKECAMATAN": 3312120,
        "kodeKABUPATEN": 3312,
        "namaKECAMATAN": "MANYARAN"
      },
      {
        "kodeKECAMATAN": 3312130,
        "kodeKABUPATEN": 3312,
        "namaKECAMATAN": "SELOGIRI"
      },
      {
        "kodeKECAMATAN": 3312140,
        "kodeKABUPATEN": 3312,
        "namaKECAMATAN": "WONOGIRI"
      },
      {
        "kodeKECAMATAN": 3312150,
        "kodeKABUPATEN": 3312,
        "namaKECAMATAN": "NGADIROJO"
      },
      {
        "kodeKECAMATAN": 3312160,
        "kodeKABUPATEN": 3312,
        "namaKECAMATAN": "SIDOHARJO"
      },
      {
        "kodeKECAMATAN": 3312170,
        "kodeKABUPATEN": 3312,
        "namaKECAMATAN": "JATIROTO"
      },
      {
        "kodeKECAMATAN": 3312180,
        "kodeKABUPATEN": 3312,
        "namaKECAMATAN": "KISMANTORO"
      },
      {
        "kodeKECAMATAN": 3312190,
        "kodeKABUPATEN": 3312,
        "namaKECAMATAN": "PURWANTORO"
      },
      {
        "kodeKECAMATAN": 3312200,
        "kodeKABUPATEN": 3312,
        "namaKECAMATAN": "BULUKERTO"
      },
      {
        "kodeKECAMATAN": 3312201,
        "kodeKABUPATEN": 3312,
        "namaKECAMATAN": "PUHPELEM"
      },
      {
        "kodeKECAMATAN": 3312210,
        "kodeKABUPATEN": 3312,
        "namaKECAMATAN": "SLOGOHIMO"
      },
      {
        "kodeKECAMATAN": 3312220,
        "kodeKABUPATEN": 3312,
        "namaKECAMATAN": "JATISRONO"
      },
      {
        "kodeKECAMATAN": 3312230,
        "kodeKABUPATEN": 3312,
        "namaKECAMATAN": "JATIPURNO"
      },
      {
        "kodeKECAMATAN": 3312240,
        "kodeKABUPATEN": 3312,
        "namaKECAMATAN": "GIRIMARTO"
      },
      {
        "kodeKECAMATAN": 3313010,
        "kodeKABUPATEN": 3313,
        "namaKECAMATAN": "JATIPURO"
      },
      {
        "kodeKECAMATAN": 3313020,
        "kodeKABUPATEN": 3313,
        "namaKECAMATAN": "JATIYOSO"
      },
      {
        "kodeKECAMATAN": 3313030,
        "kodeKABUPATEN": 3313,
        "namaKECAMATAN": "JUMAPOLO"
      },
      {
        "kodeKECAMATAN": 3313040,
        "kodeKABUPATEN": 3313,
        "namaKECAMATAN": "JUMANTONO"
      },
      {
        "kodeKECAMATAN": 3313050,
        "kodeKABUPATEN": 3313,
        "namaKECAMATAN": "MATESIH"
      },
      {
        "kodeKECAMATAN": 3313060,
        "kodeKABUPATEN": 3313,
        "namaKECAMATAN": "TAWANGMANGU"
      },
      {
        "kodeKECAMATAN": 3313070,
        "kodeKABUPATEN": 3313,
        "namaKECAMATAN": "NGARGOYOSO"
      },
      {
        "kodeKECAMATAN": 3313080,
        "kodeKABUPATEN": 3313,
        "namaKECAMATAN": "KARANGPANDAN"
      },
      {
        "kodeKECAMATAN": 3313090,
        "kodeKABUPATEN": 3313,
        "namaKECAMATAN": "KARANGANYAR"
      },
      {
        "kodeKECAMATAN": 3313100,
        "kodeKABUPATEN": 3313,
        "namaKECAMATAN": "TASIKMADU"
      },
      {
        "kodeKECAMATAN": 3313110,
        "kodeKABUPATEN": 3313,
        "namaKECAMATAN": "JATEN"
      },
      {
        "kodeKECAMATAN": 3313120,
        "kodeKABUPATEN": 3313,
        "namaKECAMATAN": "COLOMADU"
      },
      {
        "kodeKECAMATAN": 3313130,
        "kodeKABUPATEN": 3313,
        "namaKECAMATAN": "GONDANGREJO"
      },
      {
        "kodeKECAMATAN": 3313140,
        "kodeKABUPATEN": 3313,
        "namaKECAMATAN": "KEBAKKRAMAT"
      },
      {
        "kodeKECAMATAN": 3313150,
        "kodeKABUPATEN": 3313,
        "namaKECAMATAN": "MOJOGEDANG"
      },
      {
        "kodeKECAMATAN": 3313160,
        "kodeKABUPATEN": 3313,
        "namaKECAMATAN": "KERJO"
      },
      {
        "kodeKECAMATAN": 3313170,
        "kodeKABUPATEN": 3313,
        "namaKECAMATAN": "JENAWI"
      },
      {
        "kodeKECAMATAN": 3314010,
        "kodeKABUPATEN": 3314,
        "namaKECAMATAN": "KALIJAMBE"
      },
      {
        "kodeKECAMATAN": 3314020,
        "kodeKABUPATEN": 3314,
        "namaKECAMATAN": "PLUPUH"
      },
      {
        "kodeKECAMATAN": 3314030,
        "kodeKABUPATEN": 3314,
        "namaKECAMATAN": "MASARAN"
      },
      {
        "kodeKECAMATAN": 3314040,
        "kodeKABUPATEN": 3314,
        "namaKECAMATAN": "KEDAWUNG"
      },
      {
        "kodeKECAMATAN": 3314050,
        "kodeKABUPATEN": 3314,
        "namaKECAMATAN": "SAMBIREJO"
      },
      {
        "kodeKECAMATAN": 3314060,
        "kodeKABUPATEN": 3314,
        "namaKECAMATAN": "GONDANG"
      },
      {
        "kodeKECAMATAN": 3314070,
        "kodeKABUPATEN": 3314,
        "namaKECAMATAN": "SAMBUNG MACAN"
      },
      {
        "kodeKECAMATAN": 3314080,
        "kodeKABUPATEN": 3314,
        "namaKECAMATAN": "NGRAMPAL"
      },
      {
        "kodeKECAMATAN": 3314090,
        "kodeKABUPATEN": 3314,
        "namaKECAMATAN": "KARANGMALANG"
      },
      {
        "kodeKECAMATAN": 3314100,
        "kodeKABUPATEN": 3314,
        "namaKECAMATAN": "SRAGEN"
      },
      {
        "kodeKECAMATAN": 3314110,
        "kodeKABUPATEN": 3314,
        "namaKECAMATAN": "SIDOHARJO"
      },
      {
        "kodeKECAMATAN": 3314120,
        "kodeKABUPATEN": 3314,
        "namaKECAMATAN": "TANON"
      },
      {
        "kodeKECAMATAN": 3314130,
        "kodeKABUPATEN": 3314,
        "namaKECAMATAN": "GEMOLONG"
      },
      {
        "kodeKECAMATAN": 3314140,
        "kodeKABUPATEN": 3314,
        "namaKECAMATAN": "MIRI"
      },
      {
        "kodeKECAMATAN": 3314150,
        "kodeKABUPATEN": 3314,
        "namaKECAMATAN": "SUMBERLAWANG"
      },
      {
        "kodeKECAMATAN": 3314160,
        "kodeKABUPATEN": 3314,
        "namaKECAMATAN": "MONDOKAN"
      },
      {
        "kodeKECAMATAN": 3314170,
        "kodeKABUPATEN": 3314,
        "namaKECAMATAN": "SUKODONO"
      },
      {
        "kodeKECAMATAN": 3314180,
        "kodeKABUPATEN": 3314,
        "namaKECAMATAN": "GESI"
      },
      {
        "kodeKECAMATAN": 3314190,
        "kodeKABUPATEN": 3314,
        "namaKECAMATAN": "TANGEN"
      },
      {
        "kodeKECAMATAN": 3314200,
        "kodeKABUPATEN": 3314,
        "namaKECAMATAN": "JENAR"
      },
      {
        "kodeKECAMATAN": 3315010,
        "kodeKABUPATEN": 3315,
        "namaKECAMATAN": "KEDUNGJATI"
      },
      {
        "kodeKECAMATAN": 3315020,
        "kodeKABUPATEN": 3315,
        "namaKECAMATAN": "KARANGRAYUNG"
      },
      {
        "kodeKECAMATAN": 3315030,
        "kodeKABUPATEN": 3315,
        "namaKECAMATAN": "PENAWANGAN"
      },
      {
        "kodeKECAMATAN": 3315040,
        "kodeKABUPATEN": 3315,
        "namaKECAMATAN": "TOROH"
      },
      {
        "kodeKECAMATAN": 3315050,
        "kodeKABUPATEN": 3315,
        "namaKECAMATAN": "GEYER"
      },
      {
        "kodeKECAMATAN": 3315060,
        "kodeKABUPATEN": 3315,
        "namaKECAMATAN": "PULOKULON"
      },
      {
        "kodeKECAMATAN": 3315070,
        "kodeKABUPATEN": 3315,
        "namaKECAMATAN": "KRADENAN"
      },
      {
        "kodeKECAMATAN": 3315080,
        "kodeKABUPATEN": 3315,
        "namaKECAMATAN": "GABUS"
      },
      {
        "kodeKECAMATAN": 3315090,
        "kodeKABUPATEN": 3315,
        "namaKECAMATAN": "NGARINGAN"
      },
      {
        "kodeKECAMATAN": 3315100,
        "kodeKABUPATEN": 3315,
        "namaKECAMATAN": "WIROSARI"
      },
      {
        "kodeKECAMATAN": 3315110,
        "kodeKABUPATEN": 3315,
        "namaKECAMATAN": "TAWANGHARJO"
      },
      {
        "kodeKECAMATAN": 3315120,
        "kodeKABUPATEN": 3315,
        "namaKECAMATAN": "GROBOGAN"
      },
      {
        "kodeKECAMATAN": 3315130,
        "kodeKABUPATEN": 3315,
        "namaKECAMATAN": "PURWODADI"
      },
      {
        "kodeKECAMATAN": 3315140,
        "kodeKABUPATEN": 3315,
        "namaKECAMATAN": "BRATI"
      },
      {
        "kodeKECAMATAN": 3315150,
        "kodeKABUPATEN": 3315,
        "namaKECAMATAN": "KLAMBU"
      },
      {
        "kodeKECAMATAN": 3315160,
        "kodeKABUPATEN": 3315,
        "namaKECAMATAN": "GODONG"
      },
      {
        "kodeKECAMATAN": 3315170,
        "kodeKABUPATEN": 3315,
        "namaKECAMATAN": "GUBUG"
      },
      {
        "kodeKECAMATAN": 3315180,
        "kodeKABUPATEN": 3315,
        "namaKECAMATAN": "TEGOWANU"
      },
      {
        "kodeKECAMATAN": 3315190,
        "kodeKABUPATEN": 3315,
        "namaKECAMATAN": "TANGGUNGHARJO"
      },
      {
        "kodeKECAMATAN": 3316010,
        "kodeKABUPATEN": 3316,
        "namaKECAMATAN": "JATI"
      },
      {
        "kodeKECAMATAN": 3316020,
        "kodeKABUPATEN": 3316,
        "namaKECAMATAN": "RANDUBLATUNG"
      },
      {
        "kodeKECAMATAN": 3316030,
        "kodeKABUPATEN": 3316,
        "namaKECAMATAN": "KRADENAN"
      },
      {
        "kodeKECAMATAN": 3316040,
        "kodeKABUPATEN": 3316,
        "namaKECAMATAN": "KEDUNGTUBAN"
      },
      {
        "kodeKECAMATAN": 3316050,
        "kodeKABUPATEN": 3316,
        "namaKECAMATAN": "CEPU"
      },
      {
        "kodeKECAMATAN": 3316060,
        "kodeKABUPATEN": 3316,
        "namaKECAMATAN": "SAMBONG"
      },
      {
        "kodeKECAMATAN": 3316070,
        "kodeKABUPATEN": 3316,
        "namaKECAMATAN": "JIKEN"
      },
      {
        "kodeKECAMATAN": 3316080,
        "kodeKABUPATEN": 3316,
        "namaKECAMATAN": "BOGOREJO"
      },
      {
        "kodeKECAMATAN": 3316090,
        "kodeKABUPATEN": 3316,
        "namaKECAMATAN": "JEPON"
      },
      {
        "kodeKECAMATAN": 3316100,
        "kodeKABUPATEN": 3316,
        "namaKECAMATAN": "KOTA BLORA"
      },
      {
        "kodeKECAMATAN": 3316110,
        "kodeKABUPATEN": 3316,
        "namaKECAMATAN": "BANJAREJO"
      },
      {
        "kodeKECAMATAN": 3316120,
        "kodeKABUPATEN": 3316,
        "namaKECAMATAN": "TUNJUNGAN"
      },
      {
        "kodeKECAMATAN": 3316130,
        "kodeKABUPATEN": 3316,
        "namaKECAMATAN": "JAPAH"
      },
      {
        "kodeKECAMATAN": 3316140,
        "kodeKABUPATEN": 3316,
        "namaKECAMATAN": "NGAWEN"
      },
      {
        "kodeKECAMATAN": 3316150,
        "kodeKABUPATEN": 3316,
        "namaKECAMATAN": "KUNDURAN"
      },
      {
        "kodeKECAMATAN": 3316160,
        "kodeKABUPATEN": 3316,
        "namaKECAMATAN": "TODANAN"
      },
      {
        "kodeKECAMATAN": 3317010,
        "kodeKABUPATEN": 3317,
        "namaKECAMATAN": "SUMBER"
      },
      {
        "kodeKECAMATAN": 3317020,
        "kodeKABUPATEN": 3317,
        "namaKECAMATAN": "BULU"
      },
      {
        "kodeKECAMATAN": 3317030,
        "kodeKABUPATEN": 3317,
        "namaKECAMATAN": "GUNEM"
      },
      {
        "kodeKECAMATAN": 3317040,
        "kodeKABUPATEN": 3317,
        "namaKECAMATAN": "SALE"
      },
      {
        "kodeKECAMATAN": 3317050,
        "kodeKABUPATEN": 3317,
        "namaKECAMATAN": "SARANG"
      },
      {
        "kodeKECAMATAN": 3317060,
        "kodeKABUPATEN": 3317,
        "namaKECAMATAN": "SEDAN"
      },
      {
        "kodeKECAMATAN": 3317070,
        "kodeKABUPATEN": 3317,
        "namaKECAMATAN": "PAMOTAN"
      },
      {
        "kodeKECAMATAN": 3317080,
        "kodeKABUPATEN": 3317,
        "namaKECAMATAN": "SULANG"
      },
      {
        "kodeKECAMATAN": 3317090,
        "kodeKABUPATEN": 3317,
        "namaKECAMATAN": "KALIORI"
      },
      {
        "kodeKECAMATAN": 3317100,
        "kodeKABUPATEN": 3317,
        "namaKECAMATAN": "REMBANG"
      },
      {
        "kodeKECAMATAN": 3317110,
        "kodeKABUPATEN": 3317,
        "namaKECAMATAN": "PANCUR"
      },
      {
        "kodeKECAMATAN": 3317120,
        "kodeKABUPATEN": 3317,
        "namaKECAMATAN": "KRAGAN"
      },
      {
        "kodeKECAMATAN": 3317130,
        "kodeKABUPATEN": 3317,
        "namaKECAMATAN": "SLUKE"
      },
      {
        "kodeKECAMATAN": 3317140,
        "kodeKABUPATEN": 3317,
        "namaKECAMATAN": "LASEM"
      },
      {
        "kodeKECAMATAN": 3318010,
        "kodeKABUPATEN": 3318,
        "namaKECAMATAN": "SUKOLILO"
      },
      {
        "kodeKECAMATAN": 3318020,
        "kodeKABUPATEN": 3318,
        "namaKECAMATAN": "KAYEN"
      },
      {
        "kodeKECAMATAN": 3318030,
        "kodeKABUPATEN": 3318,
        "namaKECAMATAN": "TAMBAKROMO"
      },
      {
        "kodeKECAMATAN": 3318040,
        "kodeKABUPATEN": 3318,
        "namaKECAMATAN": "WINONG"
      },
      {
        "kodeKECAMATAN": 3318050,
        "kodeKABUPATEN": 3318,
        "namaKECAMATAN": "PUCAKWANGI"
      },
      {
        "kodeKECAMATAN": 3318060,
        "kodeKABUPATEN": 3318,
        "namaKECAMATAN": "JAKEN"
      },
      {
        "kodeKECAMATAN": 3318070,
        "kodeKABUPATEN": 3318,
        "namaKECAMATAN": "BATANGAN"
      },
      {
        "kodeKECAMATAN": 3318080,
        "kodeKABUPATEN": 3318,
        "namaKECAMATAN": "JUWANA"
      },
      {
        "kodeKECAMATAN": 3318090,
        "kodeKABUPATEN": 3318,
        "namaKECAMATAN": "JAKENAN"
      },
      {
        "kodeKECAMATAN": 3318100,
        "kodeKABUPATEN": 3318,
        "namaKECAMATAN": "PATI"
      },
      {
        "kodeKECAMATAN": 3318110,
        "kodeKABUPATEN": 3318,
        "namaKECAMATAN": "GABUS"
      },
      {
        "kodeKECAMATAN": 3318120,
        "kodeKABUPATEN": 3318,
        "namaKECAMATAN": "MARGOREJO"
      },
      {
        "kodeKECAMATAN": 3318130,
        "kodeKABUPATEN": 3318,
        "namaKECAMATAN": "GEMBONG"
      },
      {
        "kodeKECAMATAN": 3318140,
        "kodeKABUPATEN": 3318,
        "namaKECAMATAN": "TLOGOWUNGU"
      },
      {
        "kodeKECAMATAN": 3318150,
        "kodeKABUPATEN": 3318,
        "namaKECAMATAN": "WEDARIJAKSA"
      },
      {
        "kodeKECAMATAN": 3318160,
        "kodeKABUPATEN": 3318,
        "namaKECAMATAN": "TRANGKIL"
      },
      {
        "kodeKECAMATAN": 3318170,
        "kodeKABUPATEN": 3318,
        "namaKECAMATAN": "MARGOYOSO"
      },
      {
        "kodeKECAMATAN": 3318180,
        "kodeKABUPATEN": 3318,
        "namaKECAMATAN": "GUNUNG WUNGKAL"
      },
      {
        "kodeKECAMATAN": 3318190,
        "kodeKABUPATEN": 3318,
        "namaKECAMATAN": "CLUWAK"
      },
      {
        "kodeKECAMATAN": 3318200,
        "kodeKABUPATEN": 3318,
        "namaKECAMATAN": "TAYU"
      },
      {
        "kodeKECAMATAN": 3318210,
        "kodeKABUPATEN": 3318,
        "namaKECAMATAN": "DUKUHSETI"
      },
      {
        "kodeKECAMATAN": 3319010,
        "kodeKABUPATEN": 3319,
        "namaKECAMATAN": "KALIWUNGU"
      },
      {
        "kodeKECAMATAN": 3319020,
        "kodeKABUPATEN": 3319,
        "namaKECAMATAN": "KOTA KUDUS"
      },
      {
        "kodeKECAMATAN": 3319030,
        "kodeKABUPATEN": 3319,
        "namaKECAMATAN": "JATI"
      },
      {
        "kodeKECAMATAN": 3319040,
        "kodeKABUPATEN": 3319,
        "namaKECAMATAN": "UNDAAN"
      },
      {
        "kodeKECAMATAN": 3319050,
        "kodeKABUPATEN": 3319,
        "namaKECAMATAN": "MEJOBO"
      },
      {
        "kodeKECAMATAN": 3319060,
        "kodeKABUPATEN": 3319,
        "namaKECAMATAN": "JEKULO"
      },
      {
        "kodeKECAMATAN": 3319070,
        "kodeKABUPATEN": 3319,
        "namaKECAMATAN": "BAE"
      },
      {
        "kodeKECAMATAN": 3319080,
        "kodeKABUPATEN": 3319,
        "namaKECAMATAN": "GEBOG"
      },
      {
        "kodeKECAMATAN": 3319090,
        "kodeKABUPATEN": 3319,
        "namaKECAMATAN": "DAWE"
      },
      {
        "kodeKECAMATAN": 3320010,
        "kodeKABUPATEN": 3320,
        "namaKECAMATAN": "KEDUNG"
      },
      {
        "kodeKECAMATAN": 3320020,
        "kodeKABUPATEN": 3320,
        "namaKECAMATAN": "PECANGAAN"
      },
      {
        "kodeKECAMATAN": 3320021,
        "kodeKABUPATEN": 3320,
        "namaKECAMATAN": "KALINYAMATAN"
      },
      {
        "kodeKECAMATAN": 3320030,
        "kodeKABUPATEN": 3320,
        "namaKECAMATAN": "WELAHAN"
      },
      {
        "kodeKECAMATAN": 3320040,
        "kodeKABUPATEN": 3320,
        "namaKECAMATAN": "MAYONG"
      },
      {
        "kodeKECAMATAN": 3320050,
        "kodeKABUPATEN": 3320,
        "namaKECAMATAN": "NALUMSARI"
      },
      {
        "kodeKECAMATAN": 3320060,
        "kodeKABUPATEN": 3320,
        "namaKECAMATAN": "BATEALIT"
      },
      {
        "kodeKECAMATAN": 3320070,
        "kodeKABUPATEN": 3320,
        "namaKECAMATAN": "TAHUNAN"
      },
      {
        "kodeKECAMATAN": 3320080,
        "kodeKABUPATEN": 3320,
        "namaKECAMATAN": "JEPARA"
      },
      {
        "kodeKECAMATAN": 3320090,
        "kodeKABUPATEN": 3320,
        "namaKECAMATAN": "MLONGGO"
      },
      {
        "kodeKECAMATAN": 3320091,
        "kodeKABUPATEN": 3320,
        "namaKECAMATAN": "PAKIS AJI"
      },
      {
        "kodeKECAMATAN": 3320100,
        "kodeKABUPATEN": 3320,
        "namaKECAMATAN": "BANGSRI"
      },
      {
        "kodeKECAMATAN": 3320101,
        "kodeKABUPATEN": 3320,
        "namaKECAMATAN": "KEMBANG"
      },
      {
        "kodeKECAMATAN": 3320110,
        "kodeKABUPATEN": 3320,
        "namaKECAMATAN": "KELING"
      },
      {
        "kodeKECAMATAN": 3320111,
        "kodeKABUPATEN": 3320,
        "namaKECAMATAN": "DONOROJO"
      },
      {
        "kodeKECAMATAN": 3320120,
        "kodeKABUPATEN": 3320,
        "namaKECAMATAN": "KARIMUNJAWA"
      },
      {
        "kodeKECAMATAN": 3321010,
        "kodeKABUPATEN": 3321,
        "namaKECAMATAN": "MRANGGEN"
      },
      {
        "kodeKECAMATAN": 3321020,
        "kodeKABUPATEN": 3321,
        "namaKECAMATAN": "KARANGAWEN"
      },
      {
        "kodeKECAMATAN": 3321030,
        "kodeKABUPATEN": 3321,
        "namaKECAMATAN": "GUNTUR"
      },
      {
        "kodeKECAMATAN": 3321040,
        "kodeKABUPATEN": 3321,
        "namaKECAMATAN": "SAYUNG"
      },
      {
        "kodeKECAMATAN": 3321050,
        "kodeKABUPATEN": 3321,
        "namaKECAMATAN": "KARANG TENGAH"
      },
      {
        "kodeKECAMATAN": 3321060,
        "kodeKABUPATEN": 3321,
        "namaKECAMATAN": "BONANG"
      },
      {
        "kodeKECAMATAN": 3321070,
        "kodeKABUPATEN": 3321,
        "namaKECAMATAN": "DEMAK"
      },
      {
        "kodeKECAMATAN": 3321080,
        "kodeKABUPATEN": 3321,
        "namaKECAMATAN": "WONOSALAM"
      },
      {
        "kodeKECAMATAN": 3321090,
        "kodeKABUPATEN": 3321,
        "namaKECAMATAN": "DEMPET"
      },
      {
        "kodeKECAMATAN": 3321091,
        "kodeKABUPATEN": 3321,
        "namaKECAMATAN": "KEBONAGUNG"
      },
      {
        "kodeKECAMATAN": 3321100,
        "kodeKABUPATEN": 3321,
        "namaKECAMATAN": "GAJAH"
      },
      {
        "kodeKECAMATAN": 3321110,
        "kodeKABUPATEN": 3321,
        "namaKECAMATAN": "KARANGANYAR"
      },
      {
        "kodeKECAMATAN": 3321120,
        "kodeKABUPATEN": 3321,
        "namaKECAMATAN": "MIJEN"
      },
      {
        "kodeKECAMATAN": 3321130,
        "kodeKABUPATEN": 3321,
        "namaKECAMATAN": "WEDUNG"
      },
      {
        "kodeKECAMATAN": 3322010,
        "kodeKABUPATEN": 3322,
        "namaKECAMATAN": "GETASAN"
      },
      {
        "kodeKECAMATAN": 3322020,
        "kodeKABUPATEN": 3322,
        "namaKECAMATAN": "TENGARAN"
      },
      {
        "kodeKECAMATAN": 3322030,
        "kodeKABUPATEN": 3322,
        "namaKECAMATAN": "SUSUKAN"
      },
      {
        "kodeKECAMATAN": 3322031,
        "kodeKABUPATEN": 3322,
        "namaKECAMATAN": "KALIWUNGU"
      },
      {
        "kodeKECAMATAN": 3322040,
        "kodeKABUPATEN": 3322,
        "namaKECAMATAN": "SURUH"
      },
      {
        "kodeKECAMATAN": 3322050,
        "kodeKABUPATEN": 3322,
        "namaKECAMATAN": "PABELAN"
      },
      {
        "kodeKECAMATAN": 3322060,
        "kodeKABUPATEN": 3322,
        "namaKECAMATAN": "TUNTANG"
      },
      {
        "kodeKECAMATAN": 3322070,
        "kodeKABUPATEN": 3322,
        "namaKECAMATAN": "BANYUBIRU"
      },
      {
        "kodeKECAMATAN": 3322080,
        "kodeKABUPATEN": 3322,
        "namaKECAMATAN": "JAMBU"
      },
      {
        "kodeKECAMATAN": 3322090,
        "kodeKABUPATEN": 3322,
        "namaKECAMATAN": "SUMOWONO"
      },
      {
        "kodeKECAMATAN": 3322100,
        "kodeKABUPATEN": 3322,
        "namaKECAMATAN": "AMBARAWA"
      },
      {
        "kodeKECAMATAN": 3322101,
        "kodeKABUPATEN": 3322,
        "namaKECAMATAN": "BANDUNGAN"
      },
      {
        "kodeKECAMATAN": 3322110,
        "kodeKABUPATEN": 3322,
        "namaKECAMATAN": "BAWEN"
      },
      {
        "kodeKECAMATAN": 3322120,
        "kodeKABUPATEN": 3322,
        "namaKECAMATAN": "BRINGIN"
      },
      {
        "kodeKECAMATAN": 3322121,
        "kodeKABUPATEN": 3322,
        "namaKECAMATAN": "BANCAK"
      },
      {
        "kodeKECAMATAN": 3322130,
        "kodeKABUPATEN": 3322,
        "namaKECAMATAN": "PRINGAPUS"
      },
      {
        "kodeKECAMATAN": 3322140,
        "kodeKABUPATEN": 3322,
        "namaKECAMATAN": "BERGAS"
      },
      {
        "kodeKECAMATAN": 3322151,
        "kodeKABUPATEN": 3322,
        "namaKECAMATAN": "UNGARAN BARAT"
      },
      {
        "kodeKECAMATAN": 3322152,
        "kodeKABUPATEN": 3322,
        "namaKECAMATAN": "UNGARAN TIMUR"
      },
      {
        "kodeKECAMATAN": 3323010,
        "kodeKABUPATEN": 3323,
        "namaKECAMATAN": "PARAKAN"
      },
      {
        "kodeKECAMATAN": 3323011,
        "kodeKABUPATEN": 3323,
        "namaKECAMATAN": "KLEDUNG"
      },
      {
        "kodeKECAMATAN": 3323012,
        "kodeKABUPATEN": 3323,
        "namaKECAMATAN": "BANSARI"
      },
      {
        "kodeKECAMATAN": 3323020,
        "kodeKABUPATEN": 3323,
        "namaKECAMATAN": "BULU"
      },
      {
        "kodeKECAMATAN": 3323030,
        "kodeKABUPATEN": 3323,
        "namaKECAMATAN": "TEMANGGUNG"
      },
      {
        "kodeKECAMATAN": 3323031,
        "kodeKABUPATEN": 3323,
        "namaKECAMATAN": "TLOGOMULYO"
      },
      {
        "kodeKECAMATAN": 3323040,
        "kodeKABUPATEN": 3323,
        "namaKECAMATAN": "TEMBARAK"
      },
      {
        "kodeKECAMATAN": 3323041,
        "kodeKABUPATEN": 3323,
        "namaKECAMATAN": "SELOPAMPANG"
      },
      {
        "kodeKECAMATAN": 3323050,
        "kodeKABUPATEN": 3323,
        "namaKECAMATAN": "KRANGGAN"
      },
      {
        "kodeKECAMATAN": 3323060,
        "kodeKABUPATEN": 3323,
        "namaKECAMATAN": "PRINGSURAT"
      },
      {
        "kodeKECAMATAN": 3323070,
        "kodeKABUPATEN": 3323,
        "namaKECAMATAN": "KALORAN"
      },
      {
        "kodeKECAMATAN": 3323080,
        "kodeKABUPATEN": 3323,
        "namaKECAMATAN": "KANDANGAN"
      },
      {
        "kodeKECAMATAN": 3323090,
        "kodeKABUPATEN": 3323,
        "namaKECAMATAN": "KEDU"
      },
      {
        "kodeKECAMATAN": 3323100,
        "kodeKABUPATEN": 3323,
        "namaKECAMATAN": "NGADIREJO"
      },
      {
        "kodeKECAMATAN": 3323110,
        "kodeKABUPATEN": 3323,
        "namaKECAMATAN": "JUMO"
      },
      {
        "kodeKECAMATAN": 3323111,
        "kodeKABUPATEN": 3323,
        "namaKECAMATAN": "GEMAWANG"
      },
      {
        "kodeKECAMATAN": 3323120,
        "kodeKABUPATEN": 3323,
        "namaKECAMATAN": "CANDIROTO"
      },
      {
        "kodeKECAMATAN": 3323121,
        "kodeKABUPATEN": 3323,
        "namaKECAMATAN": "BEJEN"
      },
      {
        "kodeKECAMATAN": 3323130,
        "kodeKABUPATEN": 3323,
        "namaKECAMATAN": "TRETEP"
      },
      {
        "kodeKECAMATAN": 3323131,
        "kodeKABUPATEN": 3323,
        "namaKECAMATAN": "WONOBOYO"
      },
      {
        "kodeKECAMATAN": 3324010,
        "kodeKABUPATEN": 3324,
        "namaKECAMATAN": "PLANTUNGAN"
      },
      {
        "kodeKECAMATAN": 3324020,
        "kodeKABUPATEN": 3324,
        "namaKECAMATAN": "SUKOREJO"
      },
      {
        "kodeKECAMATAN": 3324030,
        "kodeKABUPATEN": 3324,
        "namaKECAMATAN": "PAGERRUYUNG"
      },
      {
        "kodeKECAMATAN": 3324040,
        "kodeKABUPATEN": 3324,
        "namaKECAMATAN": "PATEAN"
      },
      {
        "kodeKECAMATAN": 3324050,
        "kodeKABUPATEN": 3324,
        "namaKECAMATAN": "SINGOROJO"
      },
      {
        "kodeKECAMATAN": 3324060,
        "kodeKABUPATEN": 3324,
        "namaKECAMATAN": "LIMBANGAN"
      },
      {
        "kodeKECAMATAN": 3324070,
        "kodeKABUPATEN": 3324,
        "namaKECAMATAN": "BOJA"
      },
      {
        "kodeKECAMATAN": 3324080,
        "kodeKABUPATEN": 3324,
        "namaKECAMATAN": "KALIWUNGU"
      },
      {
        "kodeKECAMATAN": 3324081,
        "kodeKABUPATEN": 3324,
        "namaKECAMATAN": "KALIWUNGU SELATAN"
      },
      {
        "kodeKECAMATAN": 3324090,
        "kodeKABUPATEN": 3324,
        "namaKECAMATAN": "BRANGSONG"
      },
      {
        "kodeKECAMATAN": 3324100,
        "kodeKABUPATEN": 3324,
        "namaKECAMATAN": "PEGANDON"
      },
      {
        "kodeKECAMATAN": 3324101,
        "kodeKABUPATEN": 3324,
        "namaKECAMATAN": "NGAMPEL"
      },
      {
        "kodeKECAMATAN": 3324110,
        "kodeKABUPATEN": 3324,
        "namaKECAMATAN": "GEMUH"
      },
      {
        "kodeKECAMATAN": 3324111,
        "kodeKABUPATEN": 3324,
        "namaKECAMATAN": "RINGINARUM"
      },
      {
        "kodeKECAMATAN": 3324120,
        "kodeKABUPATEN": 3324,
        "namaKECAMATAN": "WELERI"
      },
      {
        "kodeKECAMATAN": 3324130,
        "kodeKABUPATEN": 3324,
        "namaKECAMATAN": "ROWOSARI"
      },
      {
        "kodeKECAMATAN": 3324140,
        "kodeKABUPATEN": 3324,
        "namaKECAMATAN": "KANGKUNG"
      },
      {
        "kodeKECAMATAN": 3324150,
        "kodeKABUPATEN": 3324,
        "namaKECAMATAN": "CEPIRING"
      },
      {
        "kodeKECAMATAN": 3324160,
        "kodeKABUPATEN": 3324,
        "namaKECAMATAN": "PATEBON"
      },
      {
        "kodeKECAMATAN": 3324170,
        "kodeKABUPATEN": 3324,
        "namaKECAMATAN": "KOTA KENDAL"
      },
      {
        "kodeKECAMATAN": 3325010,
        "kodeKABUPATEN": 3325,
        "namaKECAMATAN": "WONOTUNGGAL"
      },
      {
        "kodeKECAMATAN": 3325020,
        "kodeKABUPATEN": 3325,
        "namaKECAMATAN": "BANDAR"
      },
      {
        "kodeKECAMATAN": 3325030,
        "kodeKABUPATEN": 3325,
        "namaKECAMATAN": "BLADO"
      },
      {
        "kodeKECAMATAN": 3325040,
        "kodeKABUPATEN": 3325,
        "namaKECAMATAN": "REBAN"
      },
      {
        "kodeKECAMATAN": 3325050,
        "kodeKABUPATEN": 3325,
        "namaKECAMATAN": "BAWANG"
      },
      {
        "kodeKECAMATAN": 3325060,
        "kodeKABUPATEN": 3325,
        "namaKECAMATAN": "TERSONO"
      },
      {
        "kodeKECAMATAN": 3325070,
        "kodeKABUPATEN": 3325,
        "namaKECAMATAN": "GRINGSING"
      },
      {
        "kodeKECAMATAN": 3325080,
        "kodeKABUPATEN": 3325,
        "namaKECAMATAN": "LIMPUNG"
      },
      {
        "kodeKECAMATAN": 3325081,
        "kodeKABUPATEN": 3325,
        "namaKECAMATAN": "BANYUPUTIH"
      },
      {
        "kodeKECAMATAN": 3325090,
        "kodeKABUPATEN": 3325,
        "namaKECAMATAN": "SUBAH"
      },
      {
        "kodeKECAMATAN": 3325091,
        "kodeKABUPATEN": 3325,
        "namaKECAMATAN": "PECALUNGAN"
      },
      {
        "kodeKECAMATAN": 3325100,
        "kodeKABUPATEN": 3325,
        "namaKECAMATAN": "TULIS"
      },
      {
        "kodeKECAMATAN": 3325101,
        "kodeKABUPATEN": 3325,
        "namaKECAMATAN": "KANDEMAN"
      },
      {
        "kodeKECAMATAN": 3325110,
        "kodeKABUPATEN": 3325,
        "namaKECAMATAN": "BATANG"
      },
      {
        "kodeKECAMATAN": 3325120,
        "kodeKABUPATEN": 3325,
        "namaKECAMATAN": "WARUNG ASEM"
      },
      {
        "kodeKECAMATAN": 3326010,
        "kodeKABUPATEN": 3326,
        "namaKECAMATAN": "KANDANGSERANG"
      },
      {
        "kodeKECAMATAN": 3326020,
        "kodeKABUPATEN": 3326,
        "namaKECAMATAN": "PANINGGARAN"
      },
      {
        "kodeKECAMATAN": 3326030,
        "kodeKABUPATEN": 3326,
        "namaKECAMATAN": "LEBAKBARANG"
      },
      {
        "kodeKECAMATAN": 3326040,
        "kodeKABUPATEN": 3326,
        "namaKECAMATAN": "PETUNGKRIONO"
      },
      {
        "kodeKECAMATAN": 3326050,
        "kodeKABUPATEN": 3326,
        "namaKECAMATAN": "TALUN"
      },
      {
        "kodeKECAMATAN": 3326060,
        "kodeKABUPATEN": 3326,
        "namaKECAMATAN": "DORO"
      },
      {
        "kodeKECAMATAN": 3326070,
        "kodeKABUPATEN": 3326,
        "namaKECAMATAN": "KARANGANYAR"
      },
      {
        "kodeKECAMATAN": 3326080,
        "kodeKABUPATEN": 3326,
        "namaKECAMATAN": "KAJEN"
      },
      {
        "kodeKECAMATAN": 3326090,
        "kodeKABUPATEN": 3326,
        "namaKECAMATAN": "KESESI"
      },
      {
        "kodeKECAMATAN": 3326100,
        "kodeKABUPATEN": 3326,
        "namaKECAMATAN": "SRAGI"
      },
      {
        "kodeKECAMATAN": 3326101,
        "kodeKABUPATEN": 3326,
        "namaKECAMATAN": "SIWALAN"
      },
      {
        "kodeKECAMATAN": 3326110,
        "kodeKABUPATEN": 3326,
        "namaKECAMATAN": "BOJONG"
      },
      {
        "kodeKECAMATAN": 3326120,
        "kodeKABUPATEN": 3326,
        "namaKECAMATAN": "WONOPRINGGO"
      },
      {
        "kodeKECAMATAN": 3326130,
        "kodeKABUPATEN": 3326,
        "namaKECAMATAN": "KEDUNGWUNI"
      },
      {
        "kodeKECAMATAN": 3326131,
        "kodeKABUPATEN": 3326,
        "namaKECAMATAN": "KARANGDADAP"
      },
      {
        "kodeKECAMATAN": 3326140,
        "kodeKABUPATEN": 3326,
        "namaKECAMATAN": "BUARAN"
      },
      {
        "kodeKECAMATAN": 3326150,
        "kodeKABUPATEN": 3326,
        "namaKECAMATAN": "TIRTO"
      },
      {
        "kodeKECAMATAN": 3326160,
        "kodeKABUPATEN": 3326,
        "namaKECAMATAN": "WIRADESA"
      },
      {
        "kodeKECAMATAN": 3326161,
        "kodeKABUPATEN": 3326,
        "namaKECAMATAN": "WONOKERTO"
      },
      {
        "kodeKECAMATAN": 3327010,
        "kodeKABUPATEN": 3327,
        "namaKECAMATAN": "MOGA"
      },
      {
        "kodeKECAMATAN": 3327011,
        "kodeKABUPATEN": 3327,
        "namaKECAMATAN": "WARUNGPRING"
      },
      {
        "kodeKECAMATAN": 3327020,
        "kodeKABUPATEN": 3327,
        "namaKECAMATAN": "PULOSARI"
      },
      {
        "kodeKECAMATAN": 3327030,
        "kodeKABUPATEN": 3327,
        "namaKECAMATAN": "BELIK"
      },
      {
        "kodeKECAMATAN": 3327040,
        "kodeKABUPATEN": 3327,
        "namaKECAMATAN": "WATUKUMPUL"
      },
      {
        "kodeKECAMATAN": 3327050,
        "kodeKABUPATEN": 3327,
        "namaKECAMATAN": "BODEH"
      },
      {
        "kodeKECAMATAN": 3327060,
        "kodeKABUPATEN": 3327,
        "namaKECAMATAN": "BANTARBOLANG"
      },
      {
        "kodeKECAMATAN": 3327070,
        "kodeKABUPATEN": 3327,
        "namaKECAMATAN": "RANDUDONGKAL"
      },
      {
        "kodeKECAMATAN": 3327080,
        "kodeKABUPATEN": 3327,
        "namaKECAMATAN": "PEMALANG"
      },
      {
        "kodeKECAMATAN": 3327090,
        "kodeKABUPATEN": 3327,
        "namaKECAMATAN": "TAMAN"
      },
      {
        "kodeKECAMATAN": 3327100,
        "kodeKABUPATEN": 3327,
        "namaKECAMATAN": "PETARUKAN"
      },
      {
        "kodeKECAMATAN": 3327110,
        "kodeKABUPATEN": 3327,
        "namaKECAMATAN": "AMPELGADING"
      },
      {
        "kodeKECAMATAN": 3327120,
        "kodeKABUPATEN": 3327,
        "namaKECAMATAN": "COMAL"
      },
      {
        "kodeKECAMATAN": 3327130,
        "kodeKABUPATEN": 3327,
        "namaKECAMATAN": "ULUJAMI"
      },
      {
        "kodeKECAMATAN": 3328010,
        "kodeKABUPATEN": 3328,
        "namaKECAMATAN": "MARGASARI"
      },
      {
        "kodeKECAMATAN": 3328020,
        "kodeKABUPATEN": 3328,
        "namaKECAMATAN": "BUMIJAWA"
      },
      {
        "kodeKECAMATAN": 3328030,
        "kodeKABUPATEN": 3328,
        "namaKECAMATAN": "BOJONG"
      },
      {
        "kodeKECAMATAN": 3328040,
        "kodeKABUPATEN": 3328,
        "namaKECAMATAN": "BALAPULANG"
      },
      {
        "kodeKECAMATAN": 3328050,
        "kodeKABUPATEN": 3328,
        "namaKECAMATAN": "PAGERBARANG"
      },
      {
        "kodeKECAMATAN": 3328060,
        "kodeKABUPATEN": 3328,
        "namaKECAMATAN": "LEBAKSIU"
      },
      {
        "kodeKECAMATAN": 3328070,
        "kodeKABUPATEN": 3328,
        "namaKECAMATAN": "JATINEGARA"
      },
      {
        "kodeKECAMATAN": 3328080,
        "kodeKABUPATEN": 3328,
        "namaKECAMATAN": "KEDUNG BANTENG"
      },
      {
        "kodeKECAMATAN": 3328090,
        "kodeKABUPATEN": 3328,
        "namaKECAMATAN": "PANGKAH"
      },
      {
        "kodeKECAMATAN": 3328100,
        "kodeKABUPATEN": 3328,
        "namaKECAMATAN": "SLAWI"
      },
      {
        "kodeKECAMATAN": 3328110,
        "kodeKABUPATEN": 3328,
        "namaKECAMATAN": "DUKUHWARU"
      },
      {
        "kodeKECAMATAN": 3328120,
        "kodeKABUPATEN": 3328,
        "namaKECAMATAN": "ADIWERNA"
      },
      {
        "kodeKECAMATAN": 3328130,
        "kodeKABUPATEN": 3328,
        "namaKECAMATAN": "DUKUHTURI"
      },
      {
        "kodeKECAMATAN": 3328140,
        "kodeKABUPATEN": 3328,
        "namaKECAMATAN": "TALANG"
      },
      {
        "kodeKECAMATAN": 3328150,
        "kodeKABUPATEN": 3328,
        "namaKECAMATAN": "TARUB"
      },
      {
        "kodeKECAMATAN": 3328160,
        "kodeKABUPATEN": 3328,
        "namaKECAMATAN": "KRAMAT"
      },
      {
        "kodeKECAMATAN": 3328170,
        "kodeKABUPATEN": 3328,
        "namaKECAMATAN": "SURADADI"
      },
      {
        "kodeKECAMATAN": 3328180,
        "kodeKABUPATEN": 3328,
        "namaKECAMATAN": "WARUREJA"
      },
      {
        "kodeKECAMATAN": 3329010,
        "kodeKABUPATEN": 3329,
        "namaKECAMATAN": "SALEM"
      },
      {
        "kodeKECAMATAN": 3329020,
        "kodeKABUPATEN": 3329,
        "namaKECAMATAN": "BANTARKAWUNG"
      },
      {
        "kodeKECAMATAN": 3329030,
        "kodeKABUPATEN": 3329,
        "namaKECAMATAN": "BUMIAYU"
      },
      {
        "kodeKECAMATAN": 3329040,
        "kodeKABUPATEN": 3329,
        "namaKECAMATAN": "PAGUYANGAN"
      },
      {
        "kodeKECAMATAN": 3329050,
        "kodeKABUPATEN": 3329,
        "namaKECAMATAN": "SIRAMPOG"
      },
      {
        "kodeKECAMATAN": 3329060,
        "kodeKABUPATEN": 3329,
        "namaKECAMATAN": "TONJONG"
      },
      {
        "kodeKECAMATAN": 3329070,
        "kodeKABUPATEN": 3329,
        "namaKECAMATAN": "LARANGAN"
      },
      {
        "kodeKECAMATAN": 3329080,
        "kodeKABUPATEN": 3329,
        "namaKECAMATAN": "KETANGGUNGAN"
      },
      {
        "kodeKECAMATAN": 3329090,
        "kodeKABUPATEN": 3329,
        "namaKECAMATAN": "BANJARHARJO"
      },
      {
        "kodeKECAMATAN": 3329100,
        "kodeKABUPATEN": 3329,
        "namaKECAMATAN": "LOSARI"
      },
      {
        "kodeKECAMATAN": 3329110,
        "kodeKABUPATEN": 3329,
        "namaKECAMATAN": "TANJUNG"
      },
      {
        "kodeKECAMATAN": 3329120,
        "kodeKABUPATEN": 3329,
        "namaKECAMATAN": "KERSANA"
      },
      {
        "kodeKECAMATAN": 3329130,
        "kodeKABUPATEN": 3329,
        "namaKECAMATAN": "BULAKAMBA"
      },
      {
        "kodeKECAMATAN": 3329140,
        "kodeKABUPATEN": 3329,
        "namaKECAMATAN": "WANASARI"
      },
      {
        "kodeKECAMATAN": 3329150,
        "kodeKABUPATEN": 3329,
        "namaKECAMATAN": "SONGGOM"
      },
      {
        "kodeKECAMATAN": 3329160,
        "kodeKABUPATEN": 3329,
        "namaKECAMATAN": "JATIBARANG"
      },
      {
        "kodeKECAMATAN": 3329170,
        "kodeKABUPATEN": 3329,
        "namaKECAMATAN": "BREBES"
      },
      {
        "kodeKECAMATAN": 3371010,
        "kodeKABUPATEN": 3371,
        "namaKECAMATAN": "MAGELANG SELATAN"
      },
      {
        "kodeKECAMATAN": 3371011,
        "kodeKABUPATEN": 3371,
        "namaKECAMATAN": "MAGELANG TENGAH"
      },
      {
        "kodeKECAMATAN": 3371020,
        "kodeKABUPATEN": 3371,
        "namaKECAMATAN": "MAGELANG UTARA"
      },
      {
        "kodeKECAMATAN": 3372010,
        "kodeKABUPATEN": 3372,
        "namaKECAMATAN": "LAWEYAN"
      },
      {
        "kodeKECAMATAN": 3372020,
        "kodeKABUPATEN": 3372,
        "namaKECAMATAN": "SERENGAN"
      },
      {
        "kodeKECAMATAN": 3372030,
        "kodeKABUPATEN": 3372,
        "namaKECAMATAN": "PASAR KLIWON"
      },
      {
        "kodeKECAMATAN": 3372040,
        "kodeKABUPATEN": 3372,
        "namaKECAMATAN": "JEBRES"
      },
      {
        "kodeKECAMATAN": 3372050,
        "kodeKABUPATEN": 3372,
        "namaKECAMATAN": "BANJARSARI"
      },
      {
        "kodeKECAMATAN": 3373010,
        "kodeKABUPATEN": 3373,
        "namaKECAMATAN": "ARGOMULYO"
      },
      {
        "kodeKECAMATAN": 3373020,
        "kodeKABUPATEN": 3373,
        "namaKECAMATAN": "TINGKIR"
      },
      {
        "kodeKECAMATAN": 3373030,
        "kodeKABUPATEN": 3373,
        "namaKECAMATAN": "SIDOMUKTI"
      },
      {
        "kodeKECAMATAN": 3373040,
        "kodeKABUPATEN": 3373,
        "namaKECAMATAN": "SIDOREJO"
      },
      {
        "kodeKECAMATAN": 3374010,
        "kodeKABUPATEN": 3374,
        "namaKECAMATAN": "MIJEN"
      },
      {
        "kodeKECAMATAN": 3374020,
        "kodeKABUPATEN": 3374,
        "namaKECAMATAN": "GUNUNG PATI"
      },
      {
        "kodeKECAMATAN": 3374030,
        "kodeKABUPATEN": 3374,
        "namaKECAMATAN": "BANYUMANIK"
      },
      {
        "kodeKECAMATAN": 3374040,
        "kodeKABUPATEN": 3374,
        "namaKECAMATAN": "GAJAH MUNGKUR"
      },
      {
        "kodeKECAMATAN": 3374050,
        "kodeKABUPATEN": 3374,
        "namaKECAMATAN": "SEMARANG SELATAN"
      },
      {
        "kodeKECAMATAN": 3374060,
        "kodeKABUPATEN": 3374,
        "namaKECAMATAN": "CANDISARI"
      },
      {
        "kodeKECAMATAN": 3374070,
        "kodeKABUPATEN": 3374,
        "namaKECAMATAN": "TEMBALANG"
      },
      {
        "kodeKECAMATAN": 3374080,
        "kodeKABUPATEN": 3374,
        "namaKECAMATAN": "PEDURUNGAN"
      },
      {
        "kodeKECAMATAN": 3374090,
        "kodeKABUPATEN": 3374,
        "namaKECAMATAN": "GENUK"
      },
      {
        "kodeKECAMATAN": 3374100,
        "kodeKABUPATEN": 3374,
        "namaKECAMATAN": "GAYAMSARI"
      },
      {
        "kodeKECAMATAN": 3374110,
        "kodeKABUPATEN": 3374,
        "namaKECAMATAN": "SEMARANG TIMUR"
      },
      {
        "kodeKECAMATAN": 3374120,
        "kodeKABUPATEN": 3374,
        "namaKECAMATAN": "SEMARANG UTARA"
      },
      {
        "kodeKECAMATAN": 3374130,
        "kodeKABUPATEN": 3374,
        "namaKECAMATAN": "SEMARANG TENGAH"
      },
      {
        "kodeKECAMATAN": 3374140,
        "kodeKABUPATEN": 3374,
        "namaKECAMATAN": "SEMARANG BARAT"
      },
      {
        "kodeKECAMATAN": 3374150,
        "kodeKABUPATEN": 3374,
        "namaKECAMATAN": "TUGU"
      },
      {
        "kodeKECAMATAN": 3374160,
        "kodeKABUPATEN": 3374,
        "namaKECAMATAN": "NGALIYAN"
      },
      {
        "kodeKECAMATAN": 3375010,
        "kodeKABUPATEN": 3375,
        "namaKECAMATAN": "PEKALONGAN BARAT"
      },
      {
        "kodeKECAMATAN": 3375020,
        "kodeKABUPATEN": 3375,
        "namaKECAMATAN": "PEKALONGAN TIMUR"
      },
      {
        "kodeKECAMATAN": 3375030,
        "kodeKABUPATEN": 3375,
        "namaKECAMATAN": "PEKALONGAN SELATAN"
      },
      {
        "kodeKECAMATAN": 3375040,
        "kodeKABUPATEN": 3375,
        "namaKECAMATAN": "PEKALONGAN UTARA"
      },
      {
        "kodeKECAMATAN": 3376010,
        "kodeKABUPATEN": 3376,
        "namaKECAMATAN": "TEGAL SELATAN"
      },
      {
        "kodeKECAMATAN": 3376020,
        "kodeKABUPATEN": 3376,
        "namaKECAMATAN": "TEGAL TIMUR"
      },
      {
        "kodeKECAMATAN": 3376030,
        "kodeKABUPATEN": 3376,
        "namaKECAMATAN": "TEGAL BARAT"
      },
      {
        "kodeKECAMATAN": 3376040,
        "kodeKABUPATEN": 3376,
        "namaKECAMATAN": "MARGADANA"
      },
      {
        "kodeKECAMATAN": 3401010,
        "kodeKABUPATEN": 3401,
        "namaKECAMATAN": "TEMON"
      },
      {
        "kodeKECAMATAN": 3401020,
        "kodeKABUPATEN": 3401,
        "namaKECAMATAN": "WATES"
      },
      {
        "kodeKECAMATAN": 3401030,
        "kodeKABUPATEN": 3401,
        "namaKECAMATAN": "PANJATAN"
      },
      {
        "kodeKECAMATAN": 3401040,
        "kodeKABUPATEN": 3401,
        "namaKECAMATAN": "GALUR"
      },
      {
        "kodeKECAMATAN": 3401050,
        "kodeKABUPATEN": 3401,
        "namaKECAMATAN": "LENDAH"
      },
      {
        "kodeKECAMATAN": 3401060,
        "kodeKABUPATEN": 3401,
        "namaKECAMATAN": "SENTOLO"
      },
      {
        "kodeKECAMATAN": 3401070,
        "kodeKABUPATEN": 3401,
        "namaKECAMATAN": "PENGASIH"
      },
      {
        "kodeKECAMATAN": 3401080,
        "kodeKABUPATEN": 3401,
        "namaKECAMATAN": "KOKAP"
      },
      {
        "kodeKECAMATAN": 3401090,
        "kodeKABUPATEN": 3401,
        "namaKECAMATAN": "GIRIMULYO"
      },
      {
        "kodeKECAMATAN": 3401100,
        "kodeKABUPATEN": 3401,
        "namaKECAMATAN": "NANGGULAN"
      },
      {
        "kodeKECAMATAN": 3401110,
        "kodeKABUPATEN": 3401,
        "namaKECAMATAN": "KALIBAWANG"
      },
      {
        "kodeKECAMATAN": 3401120,
        "kodeKABUPATEN": 3401,
        "namaKECAMATAN": "SAMIGALUH"
      },
      {
        "kodeKECAMATAN": 3402010,
        "kodeKABUPATEN": 3402,
        "namaKECAMATAN": "SRANDAKAN"
      },
      {
        "kodeKECAMATAN": 3402020,
        "kodeKABUPATEN": 3402,
        "namaKECAMATAN": "SANDEN"
      },
      {
        "kodeKECAMATAN": 3402030,
        "kodeKABUPATEN": 3402,
        "namaKECAMATAN": "KRETEK"
      },
      {
        "kodeKECAMATAN": 3402040,
        "kodeKABUPATEN": 3402,
        "namaKECAMATAN": "PUNDONG"
      },
      {
        "kodeKECAMATAN": 3402050,
        "kodeKABUPATEN": 3402,
        "namaKECAMATAN": "BAMBANG LIPURO"
      },
      {
        "kodeKECAMATAN": 3402060,
        "kodeKABUPATEN": 3402,
        "namaKECAMATAN": "PANDAK"
      },
      {
        "kodeKECAMATAN": 3402070,
        "kodeKABUPATEN": 3402,
        "namaKECAMATAN": "BANTUL"
      },
      {
        "kodeKECAMATAN": 3402080,
        "kodeKABUPATEN": 3402,
        "namaKECAMATAN": "JETIS"
      },
      {
        "kodeKECAMATAN": 3402090,
        "kodeKABUPATEN": 3402,
        "namaKECAMATAN": "IMOGIRI"
      },
      {
        "kodeKECAMATAN": 3402100,
        "kodeKABUPATEN": 3402,
        "namaKECAMATAN": "DLINGO"
      },
      {
        "kodeKECAMATAN": 3402110,
        "kodeKABUPATEN": 3402,
        "namaKECAMATAN": "PLERET"
      },
      {
        "kodeKECAMATAN": 3402120,
        "kodeKABUPATEN": 3402,
        "namaKECAMATAN": "PIYUNGAN"
      },
      {
        "kodeKECAMATAN": 3402130,
        "kodeKABUPATEN": 3402,
        "namaKECAMATAN": "BANGUNTAPAN"
      },
      {
        "kodeKECAMATAN": 3402140,
        "kodeKABUPATEN": 3402,
        "namaKECAMATAN": "SEWON"
      },
      {
        "kodeKECAMATAN": 3402150,
        "kodeKABUPATEN": 3402,
        "namaKECAMATAN": "KASIHAN"
      },
      {
        "kodeKECAMATAN": 3402160,
        "kodeKABUPATEN": 3402,
        "namaKECAMATAN": "PAJANGAN"
      },
      {
        "kodeKECAMATAN": 3402170,
        "kodeKABUPATEN": 3402,
        "namaKECAMATAN": "SEDAYU"
      },
      {
        "kodeKECAMATAN": 3403010,
        "kodeKABUPATEN": 3403,
        "namaKECAMATAN": "PANGGANG"
      },
      {
        "kodeKECAMATAN": 3403011,
        "kodeKABUPATEN": 3403,
        "namaKECAMATAN": "PURWOSARI"
      },
      {
        "kodeKECAMATAN": 3403020,
        "kodeKABUPATEN": 3403,
        "namaKECAMATAN": "PALIYAN"
      },
      {
        "kodeKECAMATAN": 3403030,
        "kodeKABUPATEN": 3403,
        "namaKECAMATAN": "SAPTO SARI"
      },
      {
        "kodeKECAMATAN": 3403040,
        "kodeKABUPATEN": 3403,
        "namaKECAMATAN": "TEPUS"
      },
      {
        "kodeKECAMATAN": 3403041,
        "kodeKABUPATEN": 3403,
        "namaKECAMATAN": "TANJUNGSARI"
      },
      {
        "kodeKECAMATAN": 3403050,
        "kodeKABUPATEN": 3403,
        "namaKECAMATAN": "RONGKOP"
      },
      {
        "kodeKECAMATAN": 3403051,
        "kodeKABUPATEN": 3403,
        "namaKECAMATAN": "GIRISUBO"
      },
      {
        "kodeKECAMATAN": 3403060,
        "kodeKABUPATEN": 3403,
        "namaKECAMATAN": "SEMANU"
      },
      {
        "kodeKECAMATAN": 3403070,
        "kodeKABUPATEN": 3403,
        "namaKECAMATAN": "PONJONG"
      },
      {
        "kodeKECAMATAN": 3403080,
        "kodeKABUPATEN": 3403,
        "namaKECAMATAN": "KARANGMOJO"
      },
      {
        "kodeKECAMATAN": 3403090,
        "kodeKABUPATEN": 3403,
        "namaKECAMATAN": "WONOSARI"
      },
      {
        "kodeKECAMATAN": 3403100,
        "kodeKABUPATEN": 3403,
        "namaKECAMATAN": "PLAYEN"
      },
      {
        "kodeKECAMATAN": 3403110,
        "kodeKABUPATEN": 3403,
        "namaKECAMATAN": "PATUK"
      },
      {
        "kodeKECAMATAN": 3403120,
        "kodeKABUPATEN": 3403,
        "namaKECAMATAN": "GEDANG SARI"
      },
      {
        "kodeKECAMATAN": 3403130,
        "kodeKABUPATEN": 3403,
        "namaKECAMATAN": "NGLIPAR"
      },
      {
        "kodeKECAMATAN": 3403140,
        "kodeKABUPATEN": 3403,
        "namaKECAMATAN": "NGAWEN"
      },
      {
        "kodeKECAMATAN": 3403150,
        "kodeKABUPATEN": 3403,
        "namaKECAMATAN": "SEMIN"
      },
      {
        "kodeKECAMATAN": 3404010,
        "kodeKABUPATEN": 3404,
        "namaKECAMATAN": "MOYUDAN"
      },
      {
        "kodeKECAMATAN": 3404020,
        "kodeKABUPATEN": 3404,
        "namaKECAMATAN": "MINGGIR"
      },
      {
        "kodeKECAMATAN": 3404030,
        "kodeKABUPATEN": 3404,
        "namaKECAMATAN": "SEYEGAN"
      },
      {
        "kodeKECAMATAN": 3404040,
        "kodeKABUPATEN": 3404,
        "namaKECAMATAN": "GODEAN"
      },
      {
        "kodeKECAMATAN": 3404050,
        "kodeKABUPATEN": 3404,
        "namaKECAMATAN": "GAMPING"
      },
      {
        "kodeKECAMATAN": 3404060,
        "kodeKABUPATEN": 3404,
        "namaKECAMATAN": "MLATI"
      },
      {
        "kodeKECAMATAN": 3404070,
        "kodeKABUPATEN": 3404,
        "namaKECAMATAN": "DEPOK"
      },
      {
        "kodeKECAMATAN": 3404080,
        "kodeKABUPATEN": 3404,
        "namaKECAMATAN": "BERBAH"
      },
      {
        "kodeKECAMATAN": 3404090,
        "kodeKABUPATEN": 3404,
        "namaKECAMATAN": "PRAMBANAN"
      },
      {
        "kodeKECAMATAN": 3404100,
        "kodeKABUPATEN": 3404,
        "namaKECAMATAN": "KALASAN"
      },
      {
        "kodeKECAMATAN": 3404110,
        "kodeKABUPATEN": 3404,
        "namaKECAMATAN": "NGEMPLAK"
      },
      {
        "kodeKECAMATAN": 3404120,
        "kodeKABUPATEN": 3404,
        "namaKECAMATAN": "NGAGLIK"
      },
      {
        "kodeKECAMATAN": 3404130,
        "kodeKABUPATEN": 3404,
        "namaKECAMATAN": "SLEMAN"
      },
      {
        "kodeKECAMATAN": 3404140,
        "kodeKABUPATEN": 3404,
        "namaKECAMATAN": "TEMPEL"
      },
      {
        "kodeKECAMATAN": 3404150,
        "kodeKABUPATEN": 3404,
        "namaKECAMATAN": "TURI"
      },
      {
        "kodeKECAMATAN": 3404160,
        "kodeKABUPATEN": 3404,
        "namaKECAMATAN": "PAKEM"
      },
      {
        "kodeKECAMATAN": 3404170,
        "kodeKABUPATEN": 3404,
        "namaKECAMATAN": "CANGKRINGAN"
      },
      {
        "kodeKECAMATAN": 3471010,
        "kodeKABUPATEN": 3471,
        "namaKECAMATAN": "MANTRIJERON"
      },
      {
        "kodeKECAMATAN": 3471020,
        "kodeKABUPATEN": 3471,
        "namaKECAMATAN": "KRATON"
      },
      {
        "kodeKECAMATAN": 3471030,
        "kodeKABUPATEN": 3471,
        "namaKECAMATAN": "MERGANGSAN"
      },
      {
        "kodeKECAMATAN": 3471040,
        "kodeKABUPATEN": 3471,
        "namaKECAMATAN": "UMBULHARJO"
      },
      {
        "kodeKECAMATAN": 3471050,
        "kodeKABUPATEN": 3471,
        "namaKECAMATAN": "KOTAGEDE"
      },
      {
        "kodeKECAMATAN": 3471060,
        "kodeKABUPATEN": 3471,
        "namaKECAMATAN": "GONDOKUSUMAN"
      },
      {
        "kodeKECAMATAN": 3471070,
        "kodeKABUPATEN": 3471,
        "namaKECAMATAN": "DANUREJAN"
      },
      {
        "kodeKECAMATAN": 3471080,
        "kodeKABUPATEN": 3471,
        "namaKECAMATAN": "PAKUALAMAN"
      },
      {
        "kodeKECAMATAN": 3471090,
        "kodeKABUPATEN": 3471,
        "namaKECAMATAN": "GONDOMANAN"
      },
      {
        "kodeKECAMATAN": 3471100,
        "kodeKABUPATEN": 3471,
        "namaKECAMATAN": "NGAMPILAN"
      },
      {
        "kodeKECAMATAN": 3471110,
        "kodeKABUPATEN": 3471,
        "namaKECAMATAN": "WIROBRAJAN"
      },
      {
        "kodeKECAMATAN": 3471120,
        "kodeKABUPATEN": 3471,
        "namaKECAMATAN": "GEDONG TENGEN"
      },
      {
        "kodeKECAMATAN": 3471130,
        "kodeKABUPATEN": 3471,
        "namaKECAMATAN": "JETIS"
      },
      {
        "kodeKECAMATAN": 3471140,
        "kodeKABUPATEN": 3471,
        "namaKECAMATAN": "TEGALREJO"
      },
      {
        "kodeKECAMATAN": 3501010,
        "kodeKABUPATEN": 3501,
        "namaKECAMATAN": "DONOROJO"
      },
      {
        "kodeKECAMATAN": 3501020,
        "kodeKABUPATEN": 3501,
        "namaKECAMATAN": "PUNUNG"
      },
      {
        "kodeKECAMATAN": 3501030,
        "kodeKABUPATEN": 3501,
        "namaKECAMATAN": "PRINGKUKU"
      },
      {
        "kodeKECAMATAN": 3501040,
        "kodeKABUPATEN": 3501,
        "namaKECAMATAN": "PACITAN"
      },
      {
        "kodeKECAMATAN": 3501050,
        "kodeKABUPATEN": 3501,
        "namaKECAMATAN": "KEBONAGUNG"
      },
      {
        "kodeKECAMATAN": 3501060,
        "kodeKABUPATEN": 3501,
        "namaKECAMATAN": "ARJOSARI"
      },
      {
        "kodeKECAMATAN": 3501070,
        "kodeKABUPATEN": 3501,
        "namaKECAMATAN": "NAWANGAN"
      },
      {
        "kodeKECAMATAN": 3501080,
        "kodeKABUPATEN": 3501,
        "namaKECAMATAN": "BANDAR"
      },
      {
        "kodeKECAMATAN": 3501090,
        "kodeKABUPATEN": 3501,
        "namaKECAMATAN": "TEGALOMBO"
      },
      {
        "kodeKECAMATAN": 3501100,
        "kodeKABUPATEN": 3501,
        "namaKECAMATAN": "TULAKAN"
      },
      {
        "kodeKECAMATAN": 3501110,
        "kodeKABUPATEN": 3501,
        "namaKECAMATAN": "NGADIROJO"
      },
      {
        "kodeKECAMATAN": 3501120,
        "kodeKABUPATEN": 3501,
        "namaKECAMATAN": "SUDIMORO"
      },
      {
        "kodeKECAMATAN": 3502010,
        "kodeKABUPATEN": 3502,
        "namaKECAMATAN": "NGRAYUN"
      },
      {
        "kodeKECAMATAN": 3502020,
        "kodeKABUPATEN": 3502,
        "namaKECAMATAN": "SLAHUNG"
      },
      {
        "kodeKECAMATAN": 3502030,
        "kodeKABUPATEN": 3502,
        "namaKECAMATAN": "BUNGKAL"
      },
      {
        "kodeKECAMATAN": 3502040,
        "kodeKABUPATEN": 3502,
        "namaKECAMATAN": "SAMBIT"
      },
      {
        "kodeKECAMATAN": 3502050,
        "kodeKABUPATEN": 3502,
        "namaKECAMATAN": "SAWOO"
      },
      {
        "kodeKECAMATAN": 3502060,
        "kodeKABUPATEN": 3502,
        "namaKECAMATAN": "SOOKO"
      },
      {
        "kodeKECAMATAN": 3502061,
        "kodeKABUPATEN": 3502,
        "namaKECAMATAN": "PUDAK"
      },
      {
        "kodeKECAMATAN": 3502070,
        "kodeKABUPATEN": 3502,
        "namaKECAMATAN": "PULUNG"
      },
      {
        "kodeKECAMATAN": 3502080,
        "kodeKABUPATEN": 3502,
        "namaKECAMATAN": "MLARAK"
      },
      {
        "kodeKECAMATAN": 3502090,
        "kodeKABUPATEN": 3502,
        "namaKECAMATAN": "SIMAN"
      },
      {
        "kodeKECAMATAN": 3502100,
        "kodeKABUPATEN": 3502,
        "namaKECAMATAN": "JETIS"
      },
      {
        "kodeKECAMATAN": 3502110,
        "kodeKABUPATEN": 3502,
        "namaKECAMATAN": "BALONG"
      },
      {
        "kodeKECAMATAN": 3502120,
        "kodeKABUPATEN": 3502,
        "namaKECAMATAN": "KAUMAN"
      },
      {
        "kodeKECAMATAN": 3502130,
        "kodeKABUPATEN": 3502,
        "namaKECAMATAN": "JAMBON"
      },
      {
        "kodeKECAMATAN": 3502140,
        "kodeKABUPATEN": 3502,
        "namaKECAMATAN": "BADEGAN"
      },
      {
        "kodeKECAMATAN": 3502150,
        "kodeKABUPATEN": 3502,
        "namaKECAMATAN": "SAMPUNG"
      },
      {
        "kodeKECAMATAN": 3502160,
        "kodeKABUPATEN": 3502,
        "namaKECAMATAN": "SUKOREJO"
      },
      {
        "kodeKECAMATAN": 3502170,
        "kodeKABUPATEN": 3502,
        "namaKECAMATAN": "PONOROGO"
      },
      {
        "kodeKECAMATAN": 3502180,
        "kodeKABUPATEN": 3502,
        "namaKECAMATAN": "BABADAN"
      },
      {
        "kodeKECAMATAN": 3502190,
        "kodeKABUPATEN": 3502,
        "namaKECAMATAN": "JENANGAN"
      },
      {
        "kodeKECAMATAN": 3502200,
        "kodeKABUPATEN": 3502,
        "namaKECAMATAN": "NGEBEL"
      },
      {
        "kodeKECAMATAN": 3503010,
        "kodeKABUPATEN": 3503,
        "namaKECAMATAN": "PANGGUL"
      },
      {
        "kodeKECAMATAN": 3503020,
        "kodeKABUPATEN": 3503,
        "namaKECAMATAN": "MUNJUNGAN"
      },
      {
        "kodeKECAMATAN": 3503030,
        "kodeKABUPATEN": 3503,
        "namaKECAMATAN": "WATULIMO"
      },
      {
        "kodeKECAMATAN": 3503040,
        "kodeKABUPATEN": 3503,
        "namaKECAMATAN": "KAMPAK"
      },
      {
        "kodeKECAMATAN": 3503050,
        "kodeKABUPATEN": 3503,
        "namaKECAMATAN": "DONGKO"
      },
      {
        "kodeKECAMATAN": 3503060,
        "kodeKABUPATEN": 3503,
        "namaKECAMATAN": "PULE"
      },
      {
        "kodeKECAMATAN": 3503070,
        "kodeKABUPATEN": 3503,
        "namaKECAMATAN": "KARANGAN"
      },
      {
        "kodeKECAMATAN": 3503071,
        "kodeKABUPATEN": 3503,
        "namaKECAMATAN": "SURUH"
      },
      {
        "kodeKECAMATAN": 3503080,
        "kodeKABUPATEN": 3503,
        "namaKECAMATAN": "GANDUSARI"
      },
      {
        "kodeKECAMATAN": 3503090,
        "kodeKABUPATEN": 3503,
        "namaKECAMATAN": "DURENAN"
      },
      {
        "kodeKECAMATAN": 3503100,
        "kodeKABUPATEN": 3503,
        "namaKECAMATAN": "POGALAN"
      },
      {
        "kodeKECAMATAN": 3503110,
        "kodeKABUPATEN": 3503,
        "namaKECAMATAN": "TRENGGALEK"
      },
      {
        "kodeKECAMATAN": 3503120,
        "kodeKABUPATEN": 3503,
        "namaKECAMATAN": "TUGU"
      },
      {
        "kodeKECAMATAN": 3503130,
        "kodeKABUPATEN": 3503,
        "namaKECAMATAN": "BENDUNGAN"
      },
      {
        "kodeKECAMATAN": 3504010,
        "kodeKABUPATEN": 3504,
        "namaKECAMATAN": "BESUKI"
      },
      {
        "kodeKECAMATAN": 3504020,
        "kodeKABUPATEN": 3504,
        "namaKECAMATAN": "BANDUNG"
      },
      {
        "kodeKECAMATAN": 3504030,
        "kodeKABUPATEN": 3504,
        "namaKECAMATAN": "PAKEL"
      },
      {
        "kodeKECAMATAN": 3504040,
        "kodeKABUPATEN": 3504,
        "namaKECAMATAN": "CAMPUR DARAT"
      },
      {
        "kodeKECAMATAN": 3504050,
        "kodeKABUPATEN": 3504,
        "namaKECAMATAN": "TANGGUNG GUNUNG"
      },
      {
        "kodeKECAMATAN": 3504060,
        "kodeKABUPATEN": 3504,
        "namaKECAMATAN": "KALIDAWIR"
      },
      {
        "kodeKECAMATAN": 3504070,
        "kodeKABUPATEN": 3504,
        "namaKECAMATAN": "PUCANG LABAN"
      },
      {
        "kodeKECAMATAN": 3504080,
        "kodeKABUPATEN": 3504,
        "namaKECAMATAN": "REJOTANGAN"
      },
      {
        "kodeKECAMATAN": 3504090,
        "kodeKABUPATEN": 3504,
        "namaKECAMATAN": "NGUNUT"
      },
      {
        "kodeKECAMATAN": 3504100,
        "kodeKABUPATEN": 3504,
        "namaKECAMATAN": "SUMBERGEMPOL"
      },
      {
        "kodeKECAMATAN": 3504110,
        "kodeKABUPATEN": 3504,
        "namaKECAMATAN": "BOYOLANGU"
      },
      {
        "kodeKECAMATAN": 3504120,
        "kodeKABUPATEN": 3504,
        "namaKECAMATAN": "TULUNGAGUNG"
      },
      {
        "kodeKECAMATAN": 3504130,
        "kodeKABUPATEN": 3504,
        "namaKECAMATAN": "KEDUNGWARU"
      },
      {
        "kodeKECAMATAN": 3504140,
        "kodeKABUPATEN": 3504,
        "namaKECAMATAN": "NGANTRU"
      },
      {
        "kodeKECAMATAN": 3504150,
        "kodeKABUPATEN": 3504,
        "namaKECAMATAN": "KARANGREJO"
      },
      {
        "kodeKECAMATAN": 3504160,
        "kodeKABUPATEN": 3504,
        "namaKECAMATAN": "KAUMAN"
      },
      {
        "kodeKECAMATAN": 3504170,
        "kodeKABUPATEN": 3504,
        "namaKECAMATAN": "GONDANG"
      },
      {
        "kodeKECAMATAN": 3504180,
        "kodeKABUPATEN": 3504,
        "namaKECAMATAN": "PAGER WOJO"
      },
      {
        "kodeKECAMATAN": 3504190,
        "kodeKABUPATEN": 3504,
        "namaKECAMATAN": "SENDANG"
      },
      {
        "kodeKECAMATAN": 3505010,
        "kodeKABUPATEN": 3505,
        "namaKECAMATAN": "BAKUNG"
      },
      {
        "kodeKECAMATAN": 3505020,
        "kodeKABUPATEN": 3505,
        "namaKECAMATAN": "WONOTIRTO"
      },
      {
        "kodeKECAMATAN": 3505030,
        "kodeKABUPATEN": 3505,
        "namaKECAMATAN": "PANGGUNGREJO"
      },
      {
        "kodeKECAMATAN": 3505040,
        "kodeKABUPATEN": 3505,
        "namaKECAMATAN": "WATES"
      },
      {
        "kodeKECAMATAN": 3505050,
        "kodeKABUPATEN": 3505,
        "namaKECAMATAN": "BINANGUN"
      },
      {
        "kodeKECAMATAN": 3505060,
        "kodeKABUPATEN": 3505,
        "namaKECAMATAN": "SUTOJAYAN"
      },
      {
        "kodeKECAMATAN": 3505070,
        "kodeKABUPATEN": 3505,
        "namaKECAMATAN": "KADEMANGAN"
      },
      {
        "kodeKECAMATAN": 3505080,
        "kodeKABUPATEN": 3505,
        "namaKECAMATAN": "KANIGORO"
      },
      {
        "kodeKECAMATAN": 3505090,
        "kodeKABUPATEN": 3505,
        "namaKECAMATAN": "TALUN"
      },
      {
        "kodeKECAMATAN": 3505100,
        "kodeKABUPATEN": 3505,
        "namaKECAMATAN": "SELOPURO"
      },
      {
        "kodeKECAMATAN": 3505110,
        "kodeKABUPATEN": 3505,
        "namaKECAMATAN": "KESAMBEN"
      },
      {
        "kodeKECAMATAN": 3505120,
        "kodeKABUPATEN": 3505,
        "namaKECAMATAN": "SELOREJO"
      },
      {
        "kodeKECAMATAN": 3505130,
        "kodeKABUPATEN": 3505,
        "namaKECAMATAN": "DOKO"
      },
      {
        "kodeKECAMATAN": 3505140,
        "kodeKABUPATEN": 3505,
        "namaKECAMATAN": "WLINGI"
      },
      {
        "kodeKECAMATAN": 3505150,
        "kodeKABUPATEN": 3505,
        "namaKECAMATAN": "GANDUSARI"
      },
      {
        "kodeKECAMATAN": 3505160,
        "kodeKABUPATEN": 3505,
        "namaKECAMATAN": "GARUM"
      },
      {
        "kodeKECAMATAN": 3505170,
        "kodeKABUPATEN": 3505,
        "namaKECAMATAN": "NGLEGOK"
      },
      {
        "kodeKECAMATAN": 3505180,
        "kodeKABUPATEN": 3505,
        "namaKECAMATAN": "SANANKULON"
      },
      {
        "kodeKECAMATAN": 3505190,
        "kodeKABUPATEN": 3505,
        "namaKECAMATAN": "PONGGOK"
      },
      {
        "kodeKECAMATAN": 3505200,
        "kodeKABUPATEN": 3505,
        "namaKECAMATAN": "SRENGAT"
      },
      {
        "kodeKECAMATAN": 3505210,
        "kodeKABUPATEN": 3505,
        "namaKECAMATAN": "WONODADI"
      },
      {
        "kodeKECAMATAN": 3505220,
        "kodeKABUPATEN": 3505,
        "namaKECAMATAN": "UDANAWU"
      },
      {
        "kodeKECAMATAN": 3506010,
        "kodeKABUPATEN": 3506,
        "namaKECAMATAN": "MOJO"
      },
      {
        "kodeKECAMATAN": 3506020,
        "kodeKABUPATEN": 3506,
        "namaKECAMATAN": "SEMEN"
      },
      {
        "kodeKECAMATAN": 3506030,
        "kodeKABUPATEN": 3506,
        "namaKECAMATAN": "NGADILUWIH"
      },
      {
        "kodeKECAMATAN": 3506040,
        "kodeKABUPATEN": 3506,
        "namaKECAMATAN": "KRAS"
      },
      {
        "kodeKECAMATAN": 3506050,
        "kodeKABUPATEN": 3506,
        "namaKECAMATAN": "RINGINREJO"
      },
      {
        "kodeKECAMATAN": 3506060,
        "kodeKABUPATEN": 3506,
        "namaKECAMATAN": "KANDAT"
      },
      {
        "kodeKECAMATAN": 3506070,
        "kodeKABUPATEN": 3506,
        "namaKECAMATAN": "WATES"
      },
      {
        "kodeKECAMATAN": 3506080,
        "kodeKABUPATEN": 3506,
        "namaKECAMATAN": "NGANCAR"
      },
      {
        "kodeKECAMATAN": 3506090,
        "kodeKABUPATEN": 3506,
        "namaKECAMATAN": "PLOSOKLATEN"
      },
      {
        "kodeKECAMATAN": 3506100,
        "kodeKABUPATEN": 3506,
        "namaKECAMATAN": "GURAH"
      },
      {
        "kodeKECAMATAN": 3506110,
        "kodeKABUPATEN": 3506,
        "namaKECAMATAN": "PUNCU"
      },
      {
        "kodeKECAMATAN": 3506120,
        "kodeKABUPATEN": 3506,
        "namaKECAMATAN": "KEPUNG"
      },
      {
        "kodeKECAMATAN": 3506130,
        "kodeKABUPATEN": 3506,
        "namaKECAMATAN": "KANDANGAN"
      },
      {
        "kodeKECAMATAN": 3506140,
        "kodeKABUPATEN": 3506,
        "namaKECAMATAN": "PARE"
      },
      {
        "kodeKECAMATAN": 3506141,
        "kodeKABUPATEN": 3506,
        "namaKECAMATAN": "BADAS"
      },
      {
        "kodeKECAMATAN": 3506150,
        "kodeKABUPATEN": 3506,
        "namaKECAMATAN": "KUNJANG"
      },
      {
        "kodeKECAMATAN": 3506160,
        "kodeKABUPATEN": 3506,
        "namaKECAMATAN": "PLEMAHAN"
      },
      {
        "kodeKECAMATAN": 3506170,
        "kodeKABUPATEN": 3506,
        "namaKECAMATAN": "PURWOASRI"
      },
      {
        "kodeKECAMATAN": 3506180,
        "kodeKABUPATEN": 3506,
        "namaKECAMATAN": "PAPAR"
      },
      {
        "kodeKECAMATAN": 3506190,
        "kodeKABUPATEN": 3506,
        "namaKECAMATAN": "PAGU"
      },
      {
        "kodeKECAMATAN": 3506191,
        "kodeKABUPATEN": 3506,
        "namaKECAMATAN": "KAYEN KIDUL"
      },
      {
        "kodeKECAMATAN": 3506200,
        "kodeKABUPATEN": 3506,
        "namaKECAMATAN": "GAMPENGREJO"
      },
      {
        "kodeKECAMATAN": 3506201,
        "kodeKABUPATEN": 3506,
        "namaKECAMATAN": "NGASEM"
      },
      {
        "kodeKECAMATAN": 3506210,
        "kodeKABUPATEN": 3506,
        "namaKECAMATAN": "BANYAKAN"
      },
      {
        "kodeKECAMATAN": 3506220,
        "kodeKABUPATEN": 3506,
        "namaKECAMATAN": "GROGOL"
      },
      {
        "kodeKECAMATAN": 3506230,
        "kodeKABUPATEN": 3506,
        "namaKECAMATAN": "TAROKAN"
      },
      {
        "kodeKECAMATAN": 3507010,
        "kodeKABUPATEN": 3507,
        "namaKECAMATAN": "DONOMULYO"
      },
      {
        "kodeKECAMATAN": 3507020,
        "kodeKABUPATEN": 3507,
        "namaKECAMATAN": "KALIPARE"
      },
      {
        "kodeKECAMATAN": 3507030,
        "kodeKABUPATEN": 3507,
        "namaKECAMATAN": "PAGAK"
      },
      {
        "kodeKECAMATAN": 3507040,
        "kodeKABUPATEN": 3507,
        "namaKECAMATAN": "BANTUR"
      },
      {
        "kodeKECAMATAN": 3507050,
        "kodeKABUPATEN": 3507,
        "namaKECAMATAN": "GEDANGAN"
      },
      {
        "kodeKECAMATAN": 3507060,
        "kodeKABUPATEN": 3507,
        "namaKECAMATAN": "SUMBERMANJING"
      },
      {
        "kodeKECAMATAN": 3507070,
        "kodeKABUPATEN": 3507,
        "namaKECAMATAN": "DAMPIT"
      },
      {
        "kodeKECAMATAN": 3507080,
        "kodeKABUPATEN": 3507,
        "namaKECAMATAN": "TIRTO YUDO"
      },
      {
        "kodeKECAMATAN": 3507090,
        "kodeKABUPATEN": 3507,
        "namaKECAMATAN": "AMPELGADING"
      },
      {
        "kodeKECAMATAN": 3507100,
        "kodeKABUPATEN": 3507,
        "namaKECAMATAN": "PONCOKUSUMO"
      },
      {
        "kodeKECAMATAN": 3507110,
        "kodeKABUPATEN": 3507,
        "namaKECAMATAN": "WAJAK"
      },
      {
        "kodeKECAMATAN": 3507120,
        "kodeKABUPATEN": 3507,
        "namaKECAMATAN": "TUREN"
      },
      {
        "kodeKECAMATAN": 3507130,
        "kodeKABUPATEN": 3507,
        "namaKECAMATAN": "BULULAWANG"
      },
      {
        "kodeKECAMATAN": 3507140,
        "kodeKABUPATEN": 3507,
        "namaKECAMATAN": "GONDANGLEGI"
      },
      {
        "kodeKECAMATAN": 3507150,
        "kodeKABUPATEN": 3507,
        "namaKECAMATAN": "PAGELARAN"
      },
      {
        "kodeKECAMATAN": 3507160,
        "kodeKABUPATEN": 3507,
        "namaKECAMATAN": "KEPANJEN"
      },
      {
        "kodeKECAMATAN": 3507170,
        "kodeKABUPATEN": 3507,
        "namaKECAMATAN": "SUMBER PUCUNG"
      },
      {
        "kodeKECAMATAN": 3507180,
        "kodeKABUPATEN": 3507,
        "namaKECAMATAN": "KROMENGAN"
      },
      {
        "kodeKECAMATAN": 3507190,
        "kodeKABUPATEN": 3507,
        "namaKECAMATAN": "NGAJUM"
      },
      {
        "kodeKECAMATAN": 3507200,
        "kodeKABUPATEN": 3507,
        "namaKECAMATAN": "WONOSARI"
      },
      {
        "kodeKECAMATAN": 3507210,
        "kodeKABUPATEN": 3507,
        "namaKECAMATAN": "WAGIR"
      },
      {
        "kodeKECAMATAN": 3507220,
        "kodeKABUPATEN": 3507,
        "namaKECAMATAN": "PAKISAJI"
      },
      {
        "kodeKECAMATAN": 3507230,
        "kodeKABUPATEN": 3507,
        "namaKECAMATAN": "TAJINAN"
      },
      {
        "kodeKECAMATAN": 3507240,
        "kodeKABUPATEN": 3507,
        "namaKECAMATAN": "TUMPANG"
      },
      {
        "kodeKECAMATAN": 3507250,
        "kodeKABUPATEN": 3507,
        "namaKECAMATAN": "PAKIS"
      },
      {
        "kodeKECAMATAN": 3507260,
        "kodeKABUPATEN": 3507,
        "namaKECAMATAN": "JABUNG"
      },
      {
        "kodeKECAMATAN": 3507270,
        "kodeKABUPATEN": 3507,
        "namaKECAMATAN": "LAWANG"
      },
      {
        "kodeKECAMATAN": 3507280,
        "kodeKABUPATEN": 3507,
        "namaKECAMATAN": "SINGOSARI"
      },
      {
        "kodeKECAMATAN": 3507290,
        "kodeKABUPATEN": 3507,
        "namaKECAMATAN": "KARANGPLOSO"
      },
      {
        "kodeKECAMATAN": 3507300,
        "kodeKABUPATEN": 3507,
        "namaKECAMATAN": "DAU"
      },
      {
        "kodeKECAMATAN": 3507310,
        "kodeKABUPATEN": 3507,
        "namaKECAMATAN": "PUJON"
      },
      {
        "kodeKECAMATAN": 3507320,
        "kodeKABUPATEN": 3507,
        "namaKECAMATAN": "NGANTANG"
      },
      {
        "kodeKECAMATAN": 3507330,
        "kodeKABUPATEN": 3507,
        "namaKECAMATAN": "KASEMBON"
      },
      {
        "kodeKECAMATAN": 3508010,
        "kodeKABUPATEN": 3508,
        "namaKECAMATAN": "TEMPURSARI"
      },
      {
        "kodeKECAMATAN": 3508020,
        "kodeKABUPATEN": 3508,
        "namaKECAMATAN": "PRONOJIWO"
      },
      {
        "kodeKECAMATAN": 3508030,
        "kodeKABUPATEN": 3508,
        "namaKECAMATAN": "CANDIPURO"
      },
      {
        "kodeKECAMATAN": 3508040,
        "kodeKABUPATEN": 3508,
        "namaKECAMATAN": "PASIRIAN"
      },
      {
        "kodeKECAMATAN": 3508050,
        "kodeKABUPATEN": 3508,
        "namaKECAMATAN": "TEMPEH"
      },
      {
        "kodeKECAMATAN": 3508060,
        "kodeKABUPATEN": 3508,
        "namaKECAMATAN": "LUMAJANG"
      },
      {
        "kodeKECAMATAN": 3508061,
        "kodeKABUPATEN": 3508,
        "namaKECAMATAN": "SUMBERSUKO"
      },
      {
        "kodeKECAMATAN": 3508070,
        "kodeKABUPATEN": 3508,
        "namaKECAMATAN": "TEKUNG"
      },
      {
        "kodeKECAMATAN": 3508080,
        "kodeKABUPATEN": 3508,
        "namaKECAMATAN": "KUNIR"
      },
      {
        "kodeKECAMATAN": 3508090,
        "kodeKABUPATEN": 3508,
        "namaKECAMATAN": "YOSOWILANGUN"
      },
      {
        "kodeKECAMATAN": 3508100,
        "kodeKABUPATEN": 3508,
        "namaKECAMATAN": "ROWOKANGKUNG"
      },
      {
        "kodeKECAMATAN": 3508110,
        "kodeKABUPATEN": 3508,
        "namaKECAMATAN": "JATIROTO"
      },
      {
        "kodeKECAMATAN": 3508120,
        "kodeKABUPATEN": 3508,
        "namaKECAMATAN": "RANDUAGUNG"
      },
      {
        "kodeKECAMATAN": 3508130,
        "kodeKABUPATEN": 3508,
        "namaKECAMATAN": "SUKODONO"
      },
      {
        "kodeKECAMATAN": 3508140,
        "kodeKABUPATEN": 3508,
        "namaKECAMATAN": "PADANG"
      },
      {
        "kodeKECAMATAN": 3508150,
        "kodeKABUPATEN": 3508,
        "namaKECAMATAN": "PASRUJAMBE"
      },
      {
        "kodeKECAMATAN": 3508160,
        "kodeKABUPATEN": 3508,
        "namaKECAMATAN": "SENDURO"
      },
      {
        "kodeKECAMATAN": 3508170,
        "kodeKABUPATEN": 3508,
        "namaKECAMATAN": "GUCIALIT"
      },
      {
        "kodeKECAMATAN": 3508180,
        "kodeKABUPATEN": 3508,
        "namaKECAMATAN": "KEDUNGJAJANG"
      },
      {
        "kodeKECAMATAN": 3508190,
        "kodeKABUPATEN": 3508,
        "namaKECAMATAN": "KLAKAH"
      },
      {
        "kodeKECAMATAN": 3508200,
        "kodeKABUPATEN": 3508,
        "namaKECAMATAN": "RANUYOSO"
      },
      {
        "kodeKECAMATAN": 3509010,
        "kodeKABUPATEN": 3509,
        "namaKECAMATAN": "KENCONG"
      },
      {
        "kodeKECAMATAN": 3509020,
        "kodeKABUPATEN": 3509,
        "namaKECAMATAN": "GUMUK MAS"
      },
      {
        "kodeKECAMATAN": 3509030,
        "kodeKABUPATEN": 3509,
        "namaKECAMATAN": "PUGER"
      },
      {
        "kodeKECAMATAN": 3509040,
        "kodeKABUPATEN": 3509,
        "namaKECAMATAN": "WULUHAN"
      },
      {
        "kodeKECAMATAN": 3509050,
        "kodeKABUPATEN": 3509,
        "namaKECAMATAN": "AMBULU"
      },
      {
        "kodeKECAMATAN": 3509060,
        "kodeKABUPATEN": 3509,
        "namaKECAMATAN": "TEMPUREJO"
      },
      {
        "kodeKECAMATAN": 3509070,
        "kodeKABUPATEN": 3509,
        "namaKECAMATAN": "SILO"
      },
      {
        "kodeKECAMATAN": 3509080,
        "kodeKABUPATEN": 3509,
        "namaKECAMATAN": "MAYANG"
      },
      {
        "kodeKECAMATAN": 3509090,
        "kodeKABUPATEN": 3509,
        "namaKECAMATAN": "MUMBULSARI"
      },
      {
        "kodeKECAMATAN": 3509100,
        "kodeKABUPATEN": 3509,
        "namaKECAMATAN": "JENGGAWAH"
      },
      {
        "kodeKECAMATAN": 3509110,
        "kodeKABUPATEN": 3509,
        "namaKECAMATAN": "AJUNG"
      },
      {
        "kodeKECAMATAN": 3509120,
        "kodeKABUPATEN": 3509,
        "namaKECAMATAN": "RAMBIPUJI"
      },
      {
        "kodeKECAMATAN": 3509130,
        "kodeKABUPATEN": 3509,
        "namaKECAMATAN": "BALUNG"
      },
      {
        "kodeKECAMATAN": 3509140,
        "kodeKABUPATEN": 3509,
        "namaKECAMATAN": "UMBULSARI"
      },
      {
        "kodeKECAMATAN": 3509150,
        "kodeKABUPATEN": 3509,
        "namaKECAMATAN": "SEMBORO"
      },
      {
        "kodeKECAMATAN": 3509160,
        "kodeKABUPATEN": 3509,
        "namaKECAMATAN": "JOMBANG"
      },
      {
        "kodeKECAMATAN": 3509170,
        "kodeKABUPATEN": 3509,
        "namaKECAMATAN": "SUMBER BARU"
      },
      {
        "kodeKECAMATAN": 3509180,
        "kodeKABUPATEN": 3509,
        "namaKECAMATAN": "TANGGUL"
      },
      {
        "kodeKECAMATAN": 3509190,
        "kodeKABUPATEN": 3509,
        "namaKECAMATAN": "BANGSALSARI"
      },
      {
        "kodeKECAMATAN": 3509200,
        "kodeKABUPATEN": 3509,
        "namaKECAMATAN": "PANTI"
      },
      {
        "kodeKECAMATAN": 3509210,
        "kodeKABUPATEN": 3509,
        "namaKECAMATAN": "SUKORAMBI"
      },
      {
        "kodeKECAMATAN": 3509220,
        "kodeKABUPATEN": 3509,
        "namaKECAMATAN": "ARJASA"
      },
      {
        "kodeKECAMATAN": 3509230,
        "kodeKABUPATEN": 3509,
        "namaKECAMATAN": "PAKUSARI"
      },
      {
        "kodeKECAMATAN": 3509240,
        "kodeKABUPATEN": 3509,
        "namaKECAMATAN": "KALISAT"
      },
      {
        "kodeKECAMATAN": 3509250,
        "kodeKABUPATEN": 3509,
        "namaKECAMATAN": "LEDOKOMBO"
      },
      {
        "kodeKECAMATAN": 3509260,
        "kodeKABUPATEN": 3509,
        "namaKECAMATAN": "SUMBERJAMBE"
      },
      {
        "kodeKECAMATAN": 3509270,
        "kodeKABUPATEN": 3509,
        "namaKECAMATAN": "SUKOWONO"
      },
      {
        "kodeKECAMATAN": 3509280,
        "kodeKABUPATEN": 3509,
        "namaKECAMATAN": "JELBUK"
      },
      {
        "kodeKECAMATAN": 3509710,
        "kodeKABUPATEN": 3509,
        "namaKECAMATAN": "KALIWATES"
      },
      {
        "kodeKECAMATAN": 3509720,
        "kodeKABUPATEN": 3509,
        "namaKECAMATAN": "SUMBERSARI"
      },
      {
        "kodeKECAMATAN": 3509730,
        "kodeKABUPATEN": 3509,
        "namaKECAMATAN": "PATRANG"
      },
      {
        "kodeKECAMATAN": 3510010,
        "kodeKABUPATEN": 3510,
        "namaKECAMATAN": "PESANGGARAN"
      },
      {
        "kodeKECAMATAN": 3510011,
        "kodeKABUPATEN": 3510,
        "namaKECAMATAN": "SILIRAGUNG"
      },
      {
        "kodeKECAMATAN": 3510020,
        "kodeKABUPATEN": 3510,
        "namaKECAMATAN": "BANGOREJO"
      },
      {
        "kodeKECAMATAN": 3510030,
        "kodeKABUPATEN": 3510,
        "namaKECAMATAN": "PURWOHARJO"
      },
      {
        "kodeKECAMATAN": 3510040,
        "kodeKABUPATEN": 3510,
        "namaKECAMATAN": "TEGALDLIMO"
      },
      {
        "kodeKECAMATAN": 3510050,
        "kodeKABUPATEN": 3510,
        "namaKECAMATAN": "MUNCAR"
      },
      {
        "kodeKECAMATAN": 3510060,
        "kodeKABUPATEN": 3510,
        "namaKECAMATAN": "CLURING"
      },
      {
        "kodeKECAMATAN": 3510070,
        "kodeKABUPATEN": 3510,
        "namaKECAMATAN": "GAMBIRAN"
      },
      {
        "kodeKECAMATAN": 3510071,
        "kodeKABUPATEN": 3510,
        "namaKECAMATAN": "TEGALSARI"
      },
      {
        "kodeKECAMATAN": 3510080,
        "kodeKABUPATEN": 3510,
        "namaKECAMATAN": "GLENMORE"
      },
      {
        "kodeKECAMATAN": 3510090,
        "kodeKABUPATEN": 3510,
        "namaKECAMATAN": "KALIBARU"
      },
      {
        "kodeKECAMATAN": 3510100,
        "kodeKABUPATEN": 3510,
        "namaKECAMATAN": "GENTENG"
      },
      {
        "kodeKECAMATAN": 3510110,
        "kodeKABUPATEN": 3510,
        "namaKECAMATAN": "SRONO"
      },
      {
        "kodeKECAMATAN": 3510120,
        "kodeKABUPATEN": 3510,
        "namaKECAMATAN": "ROGOJAMPI"
      },
      {
        "kodeKECAMATAN": 3510130,
        "kodeKABUPATEN": 3510,
        "namaKECAMATAN": "KABAT"
      },
      {
        "kodeKECAMATAN": 3510140,
        "kodeKABUPATEN": 3510,
        "namaKECAMATAN": "SINGOJURUH"
      },
      {
        "kodeKECAMATAN": 3510150,
        "kodeKABUPATEN": 3510,
        "namaKECAMATAN": "SEMPU"
      },
      {
        "kodeKECAMATAN": 3510160,
        "kodeKABUPATEN": 3510,
        "namaKECAMATAN": "SONGGON"
      },
      {
        "kodeKECAMATAN": 3510170,
        "kodeKABUPATEN": 3510,
        "namaKECAMATAN": "GLAGAH"
      },
      {
        "kodeKECAMATAN": 3510171,
        "kodeKABUPATEN": 3510,
        "namaKECAMATAN": "LICIN"
      },
      {
        "kodeKECAMATAN": 3510180,
        "kodeKABUPATEN": 3510,
        "namaKECAMATAN": "BANYUWANGI"
      },
      {
        "kodeKECAMATAN": 3510190,
        "kodeKABUPATEN": 3510,
        "namaKECAMATAN": "GIRI"
      },
      {
        "kodeKECAMATAN": 3510200,
        "kodeKABUPATEN": 3510,
        "namaKECAMATAN": "KALIPURO"
      },
      {
        "kodeKECAMATAN": 3510210,
        "kodeKABUPATEN": 3510,
        "namaKECAMATAN": "WONGSOREJO"
      },
      {
        "kodeKECAMATAN": 3511010,
        "kodeKABUPATEN": 3511,
        "namaKECAMATAN": "MAESAN"
      },
      {
        "kodeKECAMATAN": 3511020,
        "kodeKABUPATEN": 3511,
        "namaKECAMATAN": "GRUJUGAN"
      },
      {
        "kodeKECAMATAN": 3511030,
        "kodeKABUPATEN": 3511,
        "namaKECAMATAN": "TAMANAN"
      },
      {
        "kodeKECAMATAN": 3511031,
        "kodeKABUPATEN": 3511,
        "namaKECAMATAN": "JAMBESARI DARUS SHOLAH"
      },
      {
        "kodeKECAMATAN": 3511040,
        "kodeKABUPATEN": 3511,
        "namaKECAMATAN": "PUJER"
      },
      {
        "kodeKECAMATAN": 3511050,
        "kodeKABUPATEN": 3511,
        "namaKECAMATAN": "TLOGOSARI"
      },
      {
        "kodeKECAMATAN": 3511060,
        "kodeKABUPATEN": 3511,
        "namaKECAMATAN": "SUKOSARI"
      },
      {
        "kodeKECAMATAN": 3511061,
        "kodeKABUPATEN": 3511,
        "namaKECAMATAN": "SUMBER WRINGIN"
      },
      {
        "kodeKECAMATAN": 3511070,
        "kodeKABUPATEN": 3511,
        "namaKECAMATAN": "TAPEN"
      },
      {
        "kodeKECAMATAN": 3511080,
        "kodeKABUPATEN": 3511,
        "namaKECAMATAN": "WONOSARI"
      },
      {
        "kodeKECAMATAN": 3511090,
        "kodeKABUPATEN": 3511,
        "namaKECAMATAN": "TENGGARANG"
      },
      {
        "kodeKECAMATAN": 3511100,
        "kodeKABUPATEN": 3511,
        "namaKECAMATAN": "BONDOWOSO"
      },
      {
        "kodeKECAMATAN": 3511110,
        "kodeKABUPATEN": 3511,
        "namaKECAMATAN": "CURAH DAMI"
      },
      {
        "kodeKECAMATAN": 3511111,
        "kodeKABUPATEN": 3511,
        "namaKECAMATAN": "BINAKAL"
      },
      {
        "kodeKECAMATAN": 3511120,
        "kodeKABUPATEN": 3511,
        "namaKECAMATAN": "PAKEM"
      },
      {
        "kodeKECAMATAN": 3511130,
        "kodeKABUPATEN": 3511,
        "namaKECAMATAN": "WRINGIN"
      },
      {
        "kodeKECAMATAN": 3511140,
        "kodeKABUPATEN": 3511,
        "namaKECAMATAN": "TEGALAMPEL"
      },
      {
        "kodeKECAMATAN": 3511141,
        "kodeKABUPATEN": 3511,
        "namaKECAMATAN": "TAMAN KROCOK"
      },
      {
        "kodeKECAMATAN": 3511150,
        "kodeKABUPATEN": 3511,
        "namaKECAMATAN": "KLABANG"
      },
      {
        "kodeKECAMATAN": 3511151,
        "kodeKABUPATEN": 3511,
        "namaKECAMATAN": "SEMPOL"
      },
      {
        "kodeKECAMATAN": 3511152,
        "kodeKABUPATEN": 3511,
        "namaKECAMATAN": "BOTOLINGGO"
      },
      {
        "kodeKECAMATAN": 3511160,
        "kodeKABUPATEN": 3511,
        "namaKECAMATAN": "PRAJEKAN"
      },
      {
        "kodeKECAMATAN": 3511170,
        "kodeKABUPATEN": 3511,
        "namaKECAMATAN": "CERMEE"
      },
      {
        "kodeKECAMATAN": 3512010,
        "kodeKABUPATEN": 3512,
        "namaKECAMATAN": "SUMBERMALANG"
      },
      {
        "kodeKECAMATAN": 3512020,
        "kodeKABUPATEN": 3512,
        "namaKECAMATAN": "JATIBANTENG"
      },
      {
        "kodeKECAMATAN": 3512030,
        "kodeKABUPATEN": 3512,
        "namaKECAMATAN": "BANYUGLUGUR"
      },
      {
        "kodeKECAMATAN": 3512040,
        "kodeKABUPATEN": 3512,
        "namaKECAMATAN": "BESUKI"
      },
      {
        "kodeKECAMATAN": 3512050,
        "kodeKABUPATEN": 3512,
        "namaKECAMATAN": "SUBOH"
      },
      {
        "kodeKECAMATAN": 3512060,
        "kodeKABUPATEN": 3512,
        "namaKECAMATAN": "MLANDINGAN"
      },
      {
        "kodeKECAMATAN": 3512070,
        "kodeKABUPATEN": 3512,
        "namaKECAMATAN": "BUNGATAN"
      },
      {
        "kodeKECAMATAN": 3512080,
        "kodeKABUPATEN": 3512,
        "namaKECAMATAN": "KENDIT"
      },
      {
        "kodeKECAMATAN": 3512090,
        "kodeKABUPATEN": 3512,
        "namaKECAMATAN": "PANARUKAN"
      },
      {
        "kodeKECAMATAN": 3512100,
        "kodeKABUPATEN": 3512,
        "namaKECAMATAN": "SITUBONDO"
      },
      {
        "kodeKECAMATAN": 3512110,
        "kodeKABUPATEN": 3512,
        "namaKECAMATAN": "MANGARAN"
      },
      {
        "kodeKECAMATAN": 3512120,
        "kodeKABUPATEN": 3512,
        "namaKECAMATAN": "PANJI"
      },
      {
        "kodeKECAMATAN": 3512130,
        "kodeKABUPATEN": 3512,
        "namaKECAMATAN": "KAPONGAN"
      },
      {
        "kodeKECAMATAN": 3512140,
        "kodeKABUPATEN": 3512,
        "namaKECAMATAN": "ARJASA"
      },
      {
        "kodeKECAMATAN": 3512150,
        "kodeKABUPATEN": 3512,
        "namaKECAMATAN": "JANGKAR"
      },
      {
        "kodeKECAMATAN": 3512160,
        "kodeKABUPATEN": 3512,
        "namaKECAMATAN": "ASEMBAGUS"
      },
      {
        "kodeKECAMATAN": 3512170,
        "kodeKABUPATEN": 3512,
        "namaKECAMATAN": "BANYUPUTIH"
      },
      {
        "kodeKECAMATAN": 3513010,
        "kodeKABUPATEN": 3513,
        "namaKECAMATAN": "SUKAPURA"
      },
      {
        "kodeKECAMATAN": 3513020,
        "kodeKABUPATEN": 3513,
        "namaKECAMATAN": "SUMBER"
      },
      {
        "kodeKECAMATAN": 3513030,
        "kodeKABUPATEN": 3513,
        "namaKECAMATAN": "KURIPAN"
      },
      {
        "kodeKECAMATAN": 3513040,
        "kodeKABUPATEN": 3513,
        "namaKECAMATAN": "BANTARAN"
      },
      {
        "kodeKECAMATAN": 3513050,
        "kodeKABUPATEN": 3513,
        "namaKECAMATAN": "LECES"
      },
      {
        "kodeKECAMATAN": 3513060,
        "kodeKABUPATEN": 3513,
        "namaKECAMATAN": "TEGALSIWALAN"
      },
      {
        "kodeKECAMATAN": 3513070,
        "kodeKABUPATEN": 3513,
        "namaKECAMATAN": "BANYUANYAR"
      },
      {
        "kodeKECAMATAN": 3513080,
        "kodeKABUPATEN": 3513,
        "namaKECAMATAN": "TIRIS"
      },
      {
        "kodeKECAMATAN": 3513090,
        "kodeKABUPATEN": 3513,
        "namaKECAMATAN": "KRUCIL"
      },
      {
        "kodeKECAMATAN": 3513100,
        "kodeKABUPATEN": 3513,
        "namaKECAMATAN": "GADING"
      },
      {
        "kodeKECAMATAN": 3513110,
        "kodeKABUPATEN": 3513,
        "namaKECAMATAN": "PAKUNIRAN"
      },
      {
        "kodeKECAMATAN": 3513120,
        "kodeKABUPATEN": 3513,
        "namaKECAMATAN": "KOTAANYAR"
      },
      {
        "kodeKECAMATAN": 3513130,
        "kodeKABUPATEN": 3513,
        "namaKECAMATAN": "PAITON"
      },
      {
        "kodeKECAMATAN": 3513140,
        "kodeKABUPATEN": 3513,
        "namaKECAMATAN": "BESUK"
      },
      {
        "kodeKECAMATAN": 3513150,
        "kodeKABUPATEN": 3513,
        "namaKECAMATAN": "KRAKSAAN"
      },
      {
        "kodeKECAMATAN": 3513160,
        "kodeKABUPATEN": 3513,
        "namaKECAMATAN": "KREJENGAN"
      },
      {
        "kodeKECAMATAN": 3513170,
        "kodeKABUPATEN": 3513,
        "namaKECAMATAN": "PAJARAKAN"
      },
      {
        "kodeKECAMATAN": 3513180,
        "kodeKABUPATEN": 3513,
        "namaKECAMATAN": "MARON"
      },
      {
        "kodeKECAMATAN": 3513190,
        "kodeKABUPATEN": 3513,
        "namaKECAMATAN": "GENDING"
      },
      {
        "kodeKECAMATAN": 3513200,
        "kodeKABUPATEN": 3513,
        "namaKECAMATAN": "DRINGU"
      },
      {
        "kodeKECAMATAN": 3513210,
        "kodeKABUPATEN": 3513,
        "namaKECAMATAN": "WONOMERTO"
      },
      {
        "kodeKECAMATAN": 3513220,
        "kodeKABUPATEN": 3513,
        "namaKECAMATAN": "LUMBANG"
      },
      {
        "kodeKECAMATAN": 3513230,
        "kodeKABUPATEN": 3513,
        "namaKECAMATAN": "TONGAS"
      },
      {
        "kodeKECAMATAN": 3513240,
        "kodeKABUPATEN": 3513,
        "namaKECAMATAN": "SUMBERASIH"
      },
      {
        "kodeKECAMATAN": 3514010,
        "kodeKABUPATEN": 3514,
        "namaKECAMATAN": "PURWODADI"
      },
      {
        "kodeKECAMATAN": 3514020,
        "kodeKABUPATEN": 3514,
        "namaKECAMATAN": "TUTUR"
      },
      {
        "kodeKECAMATAN": 3514030,
        "kodeKABUPATEN": 3514,
        "namaKECAMATAN": "PUSPO"
      },
      {
        "kodeKECAMATAN": 3514040,
        "kodeKABUPATEN": 3514,
        "namaKECAMATAN": "TOSARI"
      },
      {
        "kodeKECAMATAN": 3514050,
        "kodeKABUPATEN": 3514,
        "namaKECAMATAN": "LUMBANG"
      },
      {
        "kodeKECAMATAN": 3514060,
        "kodeKABUPATEN": 3514,
        "namaKECAMATAN": "PASREPAN"
      },
      {
        "kodeKECAMATAN": 3514070,
        "kodeKABUPATEN": 3514,
        "namaKECAMATAN": "KEJAYAN"
      },
      {
        "kodeKECAMATAN": 3514080,
        "kodeKABUPATEN": 3514,
        "namaKECAMATAN": "WONOREJO"
      },
      {
        "kodeKECAMATAN": 3514090,
        "kodeKABUPATEN": 3514,
        "namaKECAMATAN": "PURWOSARI"
      },
      {
        "kodeKECAMATAN": 3514100,
        "kodeKABUPATEN": 3514,
        "namaKECAMATAN": "PRIGEN"
      },
      {
        "kodeKECAMATAN": 3514110,
        "kodeKABUPATEN": 3514,
        "namaKECAMATAN": "SUKOREJO"
      },
      {
        "kodeKECAMATAN": 3514120,
        "kodeKABUPATEN": 3514,
        "namaKECAMATAN": "PANDAAN"
      },
      {
        "kodeKECAMATAN": 3514130,
        "kodeKABUPATEN": 3514,
        "namaKECAMATAN": "GEMPOL"
      },
      {
        "kodeKECAMATAN": 3514140,
        "kodeKABUPATEN": 3514,
        "namaKECAMATAN": "BEJI"
      },
      {
        "kodeKECAMATAN": 3514150,
        "kodeKABUPATEN": 3514,
        "namaKECAMATAN": "BANGIL"
      },
      {
        "kodeKECAMATAN": 3514160,
        "kodeKABUPATEN": 3514,
        "namaKECAMATAN": "REMBANG"
      },
      {
        "kodeKECAMATAN": 3514170,
        "kodeKABUPATEN": 3514,
        "namaKECAMATAN": "KRATON"
      },
      {
        "kodeKECAMATAN": 3514180,
        "kodeKABUPATEN": 3514,
        "namaKECAMATAN": "POHJENTREK"
      },
      {
        "kodeKECAMATAN": 3514190,
        "kodeKABUPATEN": 3514,
        "namaKECAMATAN": "GONDANG WETAN"
      },
      {
        "kodeKECAMATAN": 3514200,
        "kodeKABUPATEN": 3514,
        "namaKECAMATAN": "REJOSO"
      },
      {
        "kodeKECAMATAN": 3514210,
        "kodeKABUPATEN": 3514,
        "namaKECAMATAN": "WINONGAN"
      },
      {
        "kodeKECAMATAN": 3514220,
        "kodeKABUPATEN": 3514,
        "namaKECAMATAN": "GRATI"
      },
      {
        "kodeKECAMATAN": 3514230,
        "kodeKABUPATEN": 3514,
        "namaKECAMATAN": "LEKOK"
      },
      {
        "kodeKECAMATAN": 3514240,
        "kodeKABUPATEN": 3514,
        "namaKECAMATAN": "NGULING"
      },
      {
        "kodeKECAMATAN": 3515010,
        "kodeKABUPATEN": 3515,
        "namaKECAMATAN": "TARIK"
      },
      {
        "kodeKECAMATAN": 3515020,
        "kodeKABUPATEN": 3515,
        "namaKECAMATAN": "PRAMBON"
      },
      {
        "kodeKECAMATAN": 3515030,
        "kodeKABUPATEN": 3515,
        "namaKECAMATAN": "KREMBUNG"
      },
      {
        "kodeKECAMATAN": 3515040,
        "kodeKABUPATEN": 3515,
        "namaKECAMATAN": "PORONG"
      },
      {
        "kodeKECAMATAN": 3515050,
        "kodeKABUPATEN": 3515,
        "namaKECAMATAN": "JABON"
      },
      {
        "kodeKECAMATAN": 3515060,
        "kodeKABUPATEN": 3515,
        "namaKECAMATAN": "TANGGULANGIN"
      },
      {
        "kodeKECAMATAN": 3515070,
        "kodeKABUPATEN": 3515,
        "namaKECAMATAN": "CANDI"
      },
      {
        "kodeKECAMATAN": 3515080,
        "kodeKABUPATEN": 3515,
        "namaKECAMATAN": "TULANGAN"
      },
      {
        "kodeKECAMATAN": 3515090,
        "kodeKABUPATEN": 3515,
        "namaKECAMATAN": "WONOAYU"
      },
      {
        "kodeKECAMATAN": 3515100,
        "kodeKABUPATEN": 3515,
        "namaKECAMATAN": "SUKODONO"
      },
      {
        "kodeKECAMATAN": 3515110,
        "kodeKABUPATEN": 3515,
        "namaKECAMATAN": "SIDOARJO"
      },
      {
        "kodeKECAMATAN": 3515120,
        "kodeKABUPATEN": 3515,
        "namaKECAMATAN": "BUDURAN"
      },
      {
        "kodeKECAMATAN": 3515130,
        "kodeKABUPATEN": 3515,
        "namaKECAMATAN": "SEDATI"
      },
      {
        "kodeKECAMATAN": 3515140,
        "kodeKABUPATEN": 3515,
        "namaKECAMATAN": "WARU"
      },
      {
        "kodeKECAMATAN": 3515150,
        "kodeKABUPATEN": 3515,
        "namaKECAMATAN": "GEDANGAN"
      },
      {
        "kodeKECAMATAN": 3515160,
        "kodeKABUPATEN": 3515,
        "namaKECAMATAN": "TAMAN"
      },
      {
        "kodeKECAMATAN": 3515170,
        "kodeKABUPATEN": 3515,
        "namaKECAMATAN": "KRIAN"
      },
      {
        "kodeKECAMATAN": 3515180,
        "kodeKABUPATEN": 3515,
        "namaKECAMATAN": "BALONG BENDO"
      },
      {
        "kodeKECAMATAN": 3516010,
        "kodeKABUPATEN": 3516,
        "namaKECAMATAN": "JATIREJO"
      },
      {
        "kodeKECAMATAN": 3516020,
        "kodeKABUPATEN": 3516,
        "namaKECAMATAN": "GONDANG"
      },
      {
        "kodeKECAMATAN": 3516030,
        "kodeKABUPATEN": 3516,
        "namaKECAMATAN": "PACET"
      },
      {
        "kodeKECAMATAN": 3516040,
        "kodeKABUPATEN": 3516,
        "namaKECAMATAN": "TRAWAS"
      },
      {
        "kodeKECAMATAN": 3516050,
        "kodeKABUPATEN": 3516,
        "namaKECAMATAN": "NGORO"
      },
      {
        "kodeKECAMATAN": 3516060,
        "kodeKABUPATEN": 3516,
        "namaKECAMATAN": "PUNGGING"
      },
      {
        "kodeKECAMATAN": 3516070,
        "kodeKABUPATEN": 3516,
        "namaKECAMATAN": "KUTOREJO"
      },
      {
        "kodeKECAMATAN": 3516080,
        "kodeKABUPATEN": 3516,
        "namaKECAMATAN": "MOJOSARI"
      },
      {
        "kodeKECAMATAN": 3516090,
        "kodeKABUPATEN": 3516,
        "namaKECAMATAN": "BANGSAL"
      },
      {
        "kodeKECAMATAN": 3516091,
        "kodeKABUPATEN": 3516,
        "namaKECAMATAN": "MOJOANYAR"
      },
      {
        "kodeKECAMATAN": 3516100,
        "kodeKABUPATEN": 3516,
        "namaKECAMATAN": "DLANGGU"
      },
      {
        "kodeKECAMATAN": 3516110,
        "kodeKABUPATEN": 3516,
        "namaKECAMATAN": "PURI"
      },
      {
        "kodeKECAMATAN": 3516120,
        "kodeKABUPATEN": 3516,
        "namaKECAMATAN": "TROWULAN"
      },
      {
        "kodeKECAMATAN": 3516130,
        "kodeKABUPATEN": 3516,
        "namaKECAMATAN": "SOOKO"
      },
      {
        "kodeKECAMATAN": 3516140,
        "kodeKABUPATEN": 3516,
        "namaKECAMATAN": "GEDEK"
      },
      {
        "kodeKECAMATAN": 3516150,
        "kodeKABUPATEN": 3516,
        "namaKECAMATAN": "KEMLAGI"
      },
      {
        "kodeKECAMATAN": 3516160,
        "kodeKABUPATEN": 3516,
        "namaKECAMATAN": "JETIS"
      },
      {
        "kodeKECAMATAN": 3516170,
        "kodeKABUPATEN": 3516,
        "namaKECAMATAN": "DAWAR BLANDONG"
      },
      {
        "kodeKECAMATAN": 3517010,
        "kodeKABUPATEN": 3517,
        "namaKECAMATAN": "BANDAR KEDUNG MULYO"
      },
      {
        "kodeKECAMATAN": 3517020,
        "kodeKABUPATEN": 3517,
        "namaKECAMATAN": "PERAK"
      },
      {
        "kodeKECAMATAN": 3517030,
        "kodeKABUPATEN": 3517,
        "namaKECAMATAN": "GUDO"
      },
      {
        "kodeKECAMATAN": 3517040,
        "kodeKABUPATEN": 3517,
        "namaKECAMATAN": "DIWEK"
      },
      {
        "kodeKECAMATAN": 3517050,
        "kodeKABUPATEN": 3517,
        "namaKECAMATAN": "NGORO"
      },
      {
        "kodeKECAMATAN": 3517060,
        "kodeKABUPATEN": 3517,
        "namaKECAMATAN": "MOJOWARNO"
      },
      {
        "kodeKECAMATAN": 3517070,
        "kodeKABUPATEN": 3517,
        "namaKECAMATAN": "BARENG"
      },
      {
        "kodeKECAMATAN": 3517080,
        "kodeKABUPATEN": 3517,
        "namaKECAMATAN": "WONOSALAM"
      },
      {
        "kodeKECAMATAN": 3517090,
        "kodeKABUPATEN": 3517,
        "namaKECAMATAN": "MOJOAGUNG"
      },
      {
        "kodeKECAMATAN": 3517100,
        "kodeKABUPATEN": 3517,
        "namaKECAMATAN": "SUMOBITO"
      },
      {
        "kodeKECAMATAN": 3517110,
        "kodeKABUPATEN": 3517,
        "namaKECAMATAN": "JOGO ROTO"
      },
      {
        "kodeKECAMATAN": 3517120,
        "kodeKABUPATEN": 3517,
        "namaKECAMATAN": "PETERONGAN"
      },
      {
        "kodeKECAMATAN": 3517130,
        "kodeKABUPATEN": 3517,
        "namaKECAMATAN": "JOMBANG"
      },
      {
        "kodeKECAMATAN": 3517140,
        "kodeKABUPATEN": 3517,
        "namaKECAMATAN": "MEGALUH"
      },
      {
        "kodeKECAMATAN": 3517150,
        "kodeKABUPATEN": 3517,
        "namaKECAMATAN": "TEMBELANG"
      },
      {
        "kodeKECAMATAN": 3517160,
        "kodeKABUPATEN": 3517,
        "namaKECAMATAN": "KESAMBEN"
      },
      {
        "kodeKECAMATAN": 3517170,
        "kodeKABUPATEN": 3517,
        "namaKECAMATAN": "KUDU"
      },
      {
        "kodeKECAMATAN": 3517171,
        "kodeKABUPATEN": 3517,
        "namaKECAMATAN": "NGUSIKAN"
      },
      {
        "kodeKECAMATAN": 3517180,
        "kodeKABUPATEN": 3517,
        "namaKECAMATAN": "PLOSO"
      },
      {
        "kodeKECAMATAN": 3517190,
        "kodeKABUPATEN": 3517,
        "namaKECAMATAN": "KABUH"
      },
      {
        "kodeKECAMATAN": 3517200,
        "kodeKABUPATEN": 3517,
        "namaKECAMATAN": "PLANDAAN"
      },
      {
        "kodeKECAMATAN": 3518010,
        "kodeKABUPATEN": 3518,
        "namaKECAMATAN": "SAWAHAN"
      },
      {
        "kodeKECAMATAN": 3518020,
        "kodeKABUPATEN": 3518,
        "namaKECAMATAN": "NGETOS"
      },
      {
        "kodeKECAMATAN": 3518030,
        "kodeKABUPATEN": 3518,
        "namaKECAMATAN": "BERBEK"
      },
      {
        "kodeKECAMATAN": 3518040,
        "kodeKABUPATEN": 3518,
        "namaKECAMATAN": "LOCERET"
      },
      {
        "kodeKECAMATAN": 3518050,
        "kodeKABUPATEN": 3518,
        "namaKECAMATAN": "PACE"
      },
      {
        "kodeKECAMATAN": 3518060,
        "kodeKABUPATEN": 3518,
        "namaKECAMATAN": "TANJUNGANOM"
      },
      {
        "kodeKECAMATAN": 3518070,
        "kodeKABUPATEN": 3518,
        "namaKECAMATAN": "PRAMBON"
      },
      {
        "kodeKECAMATAN": 3518080,
        "kodeKABUPATEN": 3518,
        "namaKECAMATAN": "NGRONGGOT"
      },
      {
        "kodeKECAMATAN": 3518090,
        "kodeKABUPATEN": 3518,
        "namaKECAMATAN": "KERTOSONO"
      },
      {
        "kodeKECAMATAN": 3518100,
        "kodeKABUPATEN": 3518,
        "namaKECAMATAN": "PATIANROWO"
      },
      {
        "kodeKECAMATAN": 3518110,
        "kodeKABUPATEN": 3518,
        "namaKECAMATAN": "BARON"
      },
      {
        "kodeKECAMATAN": 3518120,
        "kodeKABUPATEN": 3518,
        "namaKECAMATAN": "GONDANG"
      },
      {
        "kodeKECAMATAN": 3518130,
        "kodeKABUPATEN": 3518,
        "namaKECAMATAN": "SUKOMORO"
      },
      {
        "kodeKECAMATAN": 3518140,
        "kodeKABUPATEN": 3518,
        "namaKECAMATAN": "NGANJUK"
      },
      {
        "kodeKECAMATAN": 3518150,
        "kodeKABUPATEN": 3518,
        "namaKECAMATAN": "BAGOR"
      },
      {
        "kodeKECAMATAN": 3518160,
        "kodeKABUPATEN": 3518,
        "namaKECAMATAN": "WILANGAN"
      },
      {
        "kodeKECAMATAN": 3518170,
        "kodeKABUPATEN": 3518,
        "namaKECAMATAN": "REJOSO"
      },
      {
        "kodeKECAMATAN": 3518180,
        "kodeKABUPATEN": 3518,
        "namaKECAMATAN": "NGLUYU"
      },
      {
        "kodeKECAMATAN": 3518190,
        "kodeKABUPATEN": 3518,
        "namaKECAMATAN": "LENGKONG"
      },
      {
        "kodeKECAMATAN": 3518200,
        "kodeKABUPATEN": 3518,
        "namaKECAMATAN": "JATIKALEN"
      },
      {
        "kodeKECAMATAN": 3519010,
        "kodeKABUPATEN": 3519,
        "namaKECAMATAN": "KEBONSARI"
      },
      {
        "kodeKECAMATAN": 3519020,
        "kodeKABUPATEN": 3519,
        "namaKECAMATAN": "GEGER"
      },
      {
        "kodeKECAMATAN": 3519030,
        "kodeKABUPATEN": 3519,
        "namaKECAMATAN": "DOLOPO"
      },
      {
        "kodeKECAMATAN": 3519040,
        "kodeKABUPATEN": 3519,
        "namaKECAMATAN": "DAGANGAN"
      },
      {
        "kodeKECAMATAN": 3519050,
        "kodeKABUPATEN": 3519,
        "namaKECAMATAN": "WUNGU"
      },
      {
        "kodeKECAMATAN": 3519060,
        "kodeKABUPATEN": 3519,
        "namaKECAMATAN": "KARE"
      },
      {
        "kodeKECAMATAN": 3519070,
        "kodeKABUPATEN": 3519,
        "namaKECAMATAN": "GEMARANG"
      },
      {
        "kodeKECAMATAN": 3519080,
        "kodeKABUPATEN": 3519,
        "namaKECAMATAN": "SARADAN"
      },
      {
        "kodeKECAMATAN": 3519090,
        "kodeKABUPATEN": 3519,
        "namaKECAMATAN": "PILANGKENCENG"
      },
      {
        "kodeKECAMATAN": 3519100,
        "kodeKABUPATEN": 3519,
        "namaKECAMATAN": "MEJAYAN"
      },
      {
        "kodeKECAMATAN": 3519110,
        "kodeKABUPATEN": 3519,
        "namaKECAMATAN": "WONOASRI"
      },
      {
        "kodeKECAMATAN": 3519120,
        "kodeKABUPATEN": 3519,
        "namaKECAMATAN": "BALEREJO"
      },
      {
        "kodeKECAMATAN": 3519130,
        "kodeKABUPATEN": 3519,
        "namaKECAMATAN": "MADIUN"
      },
      {
        "kodeKECAMATAN": 3519140,
        "kodeKABUPATEN": 3519,
        "namaKECAMATAN": "SAWAHAN"
      },
      {
        "kodeKECAMATAN": 3519150,
        "kodeKABUPATEN": 3519,
        "namaKECAMATAN": "JIWAN"
      },
      {
        "kodeKECAMATAN": 3520010,
        "kodeKABUPATEN": 3520,
        "namaKECAMATAN": "PONCOL"
      },
      {
        "kodeKECAMATAN": 3520020,
        "kodeKABUPATEN": 3520,
        "namaKECAMATAN": "PARANG"
      },
      {
        "kodeKECAMATAN": 3520030,
        "kodeKABUPATEN": 3520,
        "namaKECAMATAN": "LEMBEYAN"
      },
      {
        "kodeKECAMATAN": 3520040,
        "kodeKABUPATEN": 3520,
        "namaKECAMATAN": "TAKERAN"
      },
      {
        "kodeKECAMATAN": 3520041,
        "kodeKABUPATEN": 3520,
        "namaKECAMATAN": "NGUNTORONADI"
      },
      {
        "kodeKECAMATAN": 3520050,
        "kodeKABUPATEN": 3520,
        "namaKECAMATAN": "KAWEDANAN"
      },
      {
        "kodeKECAMATAN": 3520060,
        "kodeKABUPATEN": 3520,
        "namaKECAMATAN": "MAGETAN"
      },
      {
        "kodeKECAMATAN": 3520061,
        "kodeKABUPATEN": 3520,
        "namaKECAMATAN": "NGARIBOYO"
      },
      {
        "kodeKECAMATAN": 3520070,
        "kodeKABUPATEN": 3520,
        "namaKECAMATAN": "PLAOSAN"
      },
      {
        "kodeKECAMATAN": 3520071,
        "kodeKABUPATEN": 3520,
        "namaKECAMATAN": "SIDOREJO"
      },
      {
        "kodeKECAMATAN": 3520080,
        "kodeKABUPATEN": 3520,
        "namaKECAMATAN": "PANEKAN"
      },
      {
        "kodeKECAMATAN": 3520090,
        "kodeKABUPATEN": 3520,
        "namaKECAMATAN": "SUKOMORO"
      },
      {
        "kodeKECAMATAN": 3520100,
        "kodeKABUPATEN": 3520,
        "namaKECAMATAN": "BENDO"
      },
      {
        "kodeKECAMATAN": 3520110,
        "kodeKABUPATEN": 3520,
        "namaKECAMATAN": "MAOSPATI"
      },
      {
        "kodeKECAMATAN": 3520120,
        "kodeKABUPATEN": 3520,
        "namaKECAMATAN": "KARANGREJO"
      },
      {
        "kodeKECAMATAN": 3520121,
        "kodeKABUPATEN": 3520,
        "namaKECAMATAN": "KARAS"
      },
      {
        "kodeKECAMATAN": 3520130,
        "kodeKABUPATEN": 3520,
        "namaKECAMATAN": "BARAT"
      },
      {
        "kodeKECAMATAN": 3520131,
        "kodeKABUPATEN": 3520,
        "namaKECAMATAN": "KARTOHARJO"
      },
      {
        "kodeKECAMATAN": 3521010,
        "kodeKABUPATEN": 3521,
        "namaKECAMATAN": "SINE"
      },
      {
        "kodeKECAMATAN": 3521020,
        "kodeKABUPATEN": 3521,
        "namaKECAMATAN": "NGRAMBE"
      },
      {
        "kodeKECAMATAN": 3521030,
        "kodeKABUPATEN": 3521,
        "namaKECAMATAN": "JOGOROGO"
      },
      {
        "kodeKECAMATAN": 3521040,
        "kodeKABUPATEN": 3521,
        "namaKECAMATAN": "KENDAL"
      },
      {
        "kodeKECAMATAN": 3521050,
        "kodeKABUPATEN": 3521,
        "namaKECAMATAN": "GENENG"
      },
      {
        "kodeKECAMATAN": 3521051,
        "kodeKABUPATEN": 3521,
        "namaKECAMATAN": "GERIH"
      },
      {
        "kodeKECAMATAN": 3521060,
        "kodeKABUPATEN": 3521,
        "namaKECAMATAN": "KWADUNGAN"
      },
      {
        "kodeKECAMATAN": 3521070,
        "kodeKABUPATEN": 3521,
        "namaKECAMATAN": "PANGKUR"
      },
      {
        "kodeKECAMATAN": 3521080,
        "kodeKABUPATEN": 3521,
        "namaKECAMATAN": "KARANGJATI"
      },
      {
        "kodeKECAMATAN": 3521090,
        "kodeKABUPATEN": 3521,
        "namaKECAMATAN": "BRINGIN"
      },
      {
        "kodeKECAMATAN": 3521100,
        "kodeKABUPATEN": 3521,
        "namaKECAMATAN": "PADAS"
      },
      {
        "kodeKECAMATAN": 3521101,
        "kodeKABUPATEN": 3521,
        "namaKECAMATAN": "KASREMAN"
      },
      {
        "kodeKECAMATAN": 3521110,
        "kodeKABUPATEN": 3521,
        "namaKECAMATAN": "NGAWI"
      },
      {
        "kodeKECAMATAN": 3521120,
        "kodeKABUPATEN": 3521,
        "namaKECAMATAN": "PARON"
      },
      {
        "kodeKECAMATAN": 3521130,
        "kodeKABUPATEN": 3521,
        "namaKECAMATAN": "KEDUNGGALAR"
      },
      {
        "kodeKECAMATAN": 3521140,
        "kodeKABUPATEN": 3521,
        "namaKECAMATAN": "PITU"
      },
      {
        "kodeKECAMATAN": 3521150,
        "kodeKABUPATEN": 3521,
        "namaKECAMATAN": "WIDODAREN"
      },
      {
        "kodeKECAMATAN": 3521160,
        "kodeKABUPATEN": 3521,
        "namaKECAMATAN": "MANTINGAN"
      },
      {
        "kodeKECAMATAN": 3521170,
        "kodeKABUPATEN": 3521,
        "namaKECAMATAN": "KARANGANYAR"
      },
      {
        "kodeKECAMATAN": 3522010,
        "kodeKABUPATEN": 3522,
        "namaKECAMATAN": "MARGOMULYO"
      },
      {
        "kodeKECAMATAN": 3522020,
        "kodeKABUPATEN": 3522,
        "namaKECAMATAN": "NGRAHO"
      },
      {
        "kodeKECAMATAN": 3522030,
        "kodeKABUPATEN": 3522,
        "namaKECAMATAN": "TAMBAKREJO"
      },
      {
        "kodeKECAMATAN": 3522040,
        "kodeKABUPATEN": 3522,
        "namaKECAMATAN": "NGAMBON"
      },
      {
        "kodeKECAMATAN": 3522041,
        "kodeKABUPATEN": 3522,
        "namaKECAMATAN": "SEKAR"
      },
      {
        "kodeKECAMATAN": 3522050,
        "kodeKABUPATEN": 3522,
        "namaKECAMATAN": "BUBULAN"
      },
      {
        "kodeKECAMATAN": 3522051,
        "kodeKABUPATEN": 3522,
        "namaKECAMATAN": "GONDANG"
      },
      {
        "kodeKECAMATAN": 3522060,
        "kodeKABUPATEN": 3522,
        "namaKECAMATAN": "TEMAYANG"
      },
      {
        "kodeKECAMATAN": 3522070,
        "kodeKABUPATEN": 3522,
        "namaKECAMATAN": "SUGIHWARAS"
      },
      {
        "kodeKECAMATAN": 3522080,
        "kodeKABUPATEN": 3522,
        "namaKECAMATAN": "KEDUNGADEM"
      },
      {
        "kodeKECAMATAN": 3522090,
        "kodeKABUPATEN": 3522,
        "namaKECAMATAN": "KEPOH BARU"
      },
      {
        "kodeKECAMATAN": 3522100,
        "kodeKABUPATEN": 3522,
        "namaKECAMATAN": "BAURENO"
      },
      {
        "kodeKECAMATAN": 3522110,
        "kodeKABUPATEN": 3522,
        "namaKECAMATAN": "KANOR"
      },
      {
        "kodeKECAMATAN": 3522120,
        "kodeKABUPATEN": 3522,
        "namaKECAMATAN": "SUMBEREJO"
      },
      {
        "kodeKECAMATAN": 3522130,
        "kodeKABUPATEN": 3522,
        "namaKECAMATAN": "BALEN"
      },
      {
        "kodeKECAMATAN": 3522140,
        "kodeKABUPATEN": 3522,
        "namaKECAMATAN": "SUKOSEWU"
      },
      {
        "kodeKECAMATAN": 3522150,
        "kodeKABUPATEN": 3522,
        "namaKECAMATAN": "KAPAS"
      },
      {
        "kodeKECAMATAN": 3522160,
        "kodeKABUPATEN": 3522,
        "namaKECAMATAN": "BOJONEGORO"
      },
      {
        "kodeKECAMATAN": 3522170,
        "kodeKABUPATEN": 3522,
        "namaKECAMATAN": "TRUCUK"
      },
      {
        "kodeKECAMATAN": 3522180,
        "kodeKABUPATEN": 3522,
        "namaKECAMATAN": "DANDER"
      },
      {
        "kodeKECAMATAN": 3522190,
        "kodeKABUPATEN": 3522,
        "namaKECAMATAN": "NGASEM"
      },
      {
        "kodeKECAMATAN": 3522191,
        "kodeKABUPATEN": 3522,
        "namaKECAMATAN": "GAYAM"
      },
      {
        "kodeKECAMATAN": 3522200,
        "kodeKABUPATEN": 3522,
        "namaKECAMATAN": "KALITIDU"
      },
      {
        "kodeKECAMATAN": 3522210,
        "kodeKABUPATEN": 3522,
        "namaKECAMATAN": "MALO"
      },
      {
        "kodeKECAMATAN": 3522220,
        "kodeKABUPATEN": 3522,
        "namaKECAMATAN": "PURWOSARI"
      },
      {
        "kodeKECAMATAN": 3522230,
        "kodeKABUPATEN": 3522,
        "namaKECAMATAN": "PADANGAN"
      },
      {
        "kodeKECAMATAN": 3522240,
        "kodeKABUPATEN": 3522,
        "namaKECAMATAN": "KASIMAN"
      },
      {
        "kodeKECAMATAN": 3522241,
        "kodeKABUPATEN": 3522,
        "namaKECAMATAN": "KEDEWAN"
      },
      {
        "kodeKECAMATAN": 3523010,
        "kodeKABUPATEN": 3523,
        "namaKECAMATAN": "KENDURUAN"
      },
      {
        "kodeKECAMATAN": 3523020,
        "kodeKABUPATEN": 3523,
        "namaKECAMATAN": "BANGILAN"
      },
      {
        "kodeKECAMATAN": 3523030,
        "kodeKABUPATEN": 3523,
        "namaKECAMATAN": "SENORI"
      },
      {
        "kodeKECAMATAN": 3523040,
        "kodeKABUPATEN": 3523,
        "namaKECAMATAN": "SINGGAHAN"
      },
      {
        "kodeKECAMATAN": 3523050,
        "kodeKABUPATEN": 3523,
        "namaKECAMATAN": "MONTONG"
      },
      {
        "kodeKECAMATAN": 3523060,
        "kodeKABUPATEN": 3523,
        "namaKECAMATAN": "PARENGAN"
      },
      {
        "kodeKECAMATAN": 3523070,
        "kodeKABUPATEN": 3523,
        "namaKECAMATAN": "SOKO"
      },
      {
        "kodeKECAMATAN": 3523080,
        "kodeKABUPATEN": 3523,
        "namaKECAMATAN": "RENGEL"
      },
      {
        "kodeKECAMATAN": 3523081,
        "kodeKABUPATEN": 3523,
        "namaKECAMATAN": "GRABAGAN"
      },
      {
        "kodeKECAMATAN": 3523090,
        "kodeKABUPATEN": 3523,
        "namaKECAMATAN": "PLUMPANG"
      },
      {
        "kodeKECAMATAN": 3523100,
        "kodeKABUPATEN": 3523,
        "namaKECAMATAN": "WIDANG"
      },
      {
        "kodeKECAMATAN": 3523110,
        "kodeKABUPATEN": 3523,
        "namaKECAMATAN": "PALANG"
      },
      {
        "kodeKECAMATAN": 3523120,
        "kodeKABUPATEN": 3523,
        "namaKECAMATAN": "SEMANDING"
      },
      {
        "kodeKECAMATAN": 3523130,
        "kodeKABUPATEN": 3523,
        "namaKECAMATAN": "TUBAN"
      },
      {
        "kodeKECAMATAN": 3523140,
        "kodeKABUPATEN": 3523,
        "namaKECAMATAN": "JENU"
      },
      {
        "kodeKECAMATAN": 3523150,
        "kodeKABUPATEN": 3523,
        "namaKECAMATAN": "MERAKURAK"
      },
      {
        "kodeKECAMATAN": 3523160,
        "kodeKABUPATEN": 3523,
        "namaKECAMATAN": "KEREK"
      },
      {
        "kodeKECAMATAN": 3523170,
        "kodeKABUPATEN": 3523,
        "namaKECAMATAN": "TAMBAKBOYO"
      },
      {
        "kodeKECAMATAN": 3523180,
        "kodeKABUPATEN": 3523,
        "namaKECAMATAN": "JATIROGO"
      },
      {
        "kodeKECAMATAN": 3523190,
        "kodeKABUPATEN": 3523,
        "namaKECAMATAN": "BANCAR"
      },
      {
        "kodeKECAMATAN": 3524010,
        "kodeKABUPATEN": 3524,
        "namaKECAMATAN": "SUKORAME"
      },
      {
        "kodeKECAMATAN": 3524020,
        "kodeKABUPATEN": 3524,
        "namaKECAMATAN": "BLULUK"
      },
      {
        "kodeKECAMATAN": 3524030,
        "kodeKABUPATEN": 3524,
        "namaKECAMATAN": "NGIMBANG"
      },
      {
        "kodeKECAMATAN": 3524040,
        "kodeKABUPATEN": 3524,
        "namaKECAMATAN": "SAMBENG"
      },
      {
        "kodeKECAMATAN": 3524050,
        "kodeKABUPATEN": 3524,
        "namaKECAMATAN": "MANTUP"
      },
      {
        "kodeKECAMATAN": 3524060,
        "kodeKABUPATEN": 3524,
        "namaKECAMATAN": "KEMBANGBAHU"
      },
      {
        "kodeKECAMATAN": 3524070,
        "kodeKABUPATEN": 3524,
        "namaKECAMATAN": "SUGIO"
      },
      {
        "kodeKECAMATAN": 3524080,
        "kodeKABUPATEN": 3524,
        "namaKECAMATAN": "KEDUNGPRING"
      },
      {
        "kodeKECAMATAN": 3524090,
        "kodeKABUPATEN": 3524,
        "namaKECAMATAN": "MODO"
      },
      {
        "kodeKECAMATAN": 3524100,
        "kodeKABUPATEN": 3524,
        "namaKECAMATAN": "BABAT"
      },
      {
        "kodeKECAMATAN": 3524110,
        "kodeKABUPATEN": 3524,
        "namaKECAMATAN": "PUCUK"
      },
      {
        "kodeKECAMATAN": 3524120,
        "kodeKABUPATEN": 3524,
        "namaKECAMATAN": "SUKODADI"
      },
      {
        "kodeKECAMATAN": 3524130,
        "kodeKABUPATEN": 3524,
        "namaKECAMATAN": "LAMONGAN"
      },
      {
        "kodeKECAMATAN": 3524140,
        "kodeKABUPATEN": 3524,
        "namaKECAMATAN": "TIKUNG"
      },
      {
        "kodeKECAMATAN": 3524141,
        "kodeKABUPATEN": 3524,
        "namaKECAMATAN": "SARIREJO"
      },
      {
        "kodeKECAMATAN": 3524150,
        "kodeKABUPATEN": 3524,
        "namaKECAMATAN": "DEKET"
      },
      {
        "kodeKECAMATAN": 3524160,
        "kodeKABUPATEN": 3524,
        "namaKECAMATAN": "GLAGAH"
      },
      {
        "kodeKECAMATAN": 3524170,
        "kodeKABUPATEN": 3524,
        "namaKECAMATAN": "KARANGBINANGUN"
      },
      {
        "kodeKECAMATAN": 3524180,
        "kodeKABUPATEN": 3524,
        "namaKECAMATAN": "TURI"
      },
      {
        "kodeKECAMATAN": 3524190,
        "kodeKABUPATEN": 3524,
        "namaKECAMATAN": "KALITENGAH"
      },
      {
        "kodeKECAMATAN": 3524200,
        "kodeKABUPATEN": 3524,
        "namaKECAMATAN": "KARANG GENENG"
      },
      {
        "kodeKECAMATAN": 3524210,
        "kodeKABUPATEN": 3524,
        "namaKECAMATAN": "SEKARAN"
      },
      {
        "kodeKECAMATAN": 3524220,
        "kodeKABUPATEN": 3524,
        "namaKECAMATAN": "MADURAN"
      },
      {
        "kodeKECAMATAN": 3524230,
        "kodeKABUPATEN": 3524,
        "namaKECAMATAN": "LAREN"
      },
      {
        "kodeKECAMATAN": 3524240,
        "kodeKABUPATEN": 3524,
        "namaKECAMATAN": "SOLOKURO"
      },
      {
        "kodeKECAMATAN": 3524250,
        "kodeKABUPATEN": 3524,
        "namaKECAMATAN": "PACIRAN"
      },
      {
        "kodeKECAMATAN": 3524260,
        "kodeKABUPATEN": 3524,
        "namaKECAMATAN": "BRONDONG"
      },
      {
        "kodeKECAMATAN": 3525010,
        "kodeKABUPATEN": 3525,
        "namaKECAMATAN": "WRINGINANOM"
      },
      {
        "kodeKECAMATAN": 3525020,
        "kodeKABUPATEN": 3525,
        "namaKECAMATAN": "DRIYOREJO"
      },
      {
        "kodeKECAMATAN": 3525030,
        "kodeKABUPATEN": 3525,
        "namaKECAMATAN": "KEDAMEAN"
      },
      {
        "kodeKECAMATAN": 3525040,
        "kodeKABUPATEN": 3525,
        "namaKECAMATAN": "MENGANTI"
      },
      {
        "kodeKECAMATAN": 3525050,
        "kodeKABUPATEN": 3525,
        "namaKECAMATAN": "CERME"
      },
      {
        "kodeKECAMATAN": 3525060,
        "kodeKABUPATEN": 3525,
        "namaKECAMATAN": "BENJENG"
      },
      {
        "kodeKECAMATAN": 3525070,
        "kodeKABUPATEN": 3525,
        "namaKECAMATAN": "BALONGPANGGANG"
      },
      {
        "kodeKECAMATAN": 3525080,
        "kodeKABUPATEN": 3525,
        "namaKECAMATAN": "DUDUKSAMPEYAN"
      },
      {
        "kodeKECAMATAN": 3525090,
        "kodeKABUPATEN": 3525,
        "namaKECAMATAN": "KEBOMAS"
      },
      {
        "kodeKECAMATAN": 3525100,
        "kodeKABUPATEN": 3525,
        "namaKECAMATAN": "GRESIK"
      },
      {
        "kodeKECAMATAN": 3525110,
        "kodeKABUPATEN": 3525,
        "namaKECAMATAN": "MANYAR"
      },
      {
        "kodeKECAMATAN": 3525120,
        "kodeKABUPATEN": 3525,
        "namaKECAMATAN": "BUNGAH"
      },
      {
        "kodeKECAMATAN": 3525130,
        "kodeKABUPATEN": 3525,
        "namaKECAMATAN": "SIDAYU"
      },
      {
        "kodeKECAMATAN": 3525140,
        "kodeKABUPATEN": 3525,
        "namaKECAMATAN": "DUKUN"
      },
      {
        "kodeKECAMATAN": 3525150,
        "kodeKABUPATEN": 3525,
        "namaKECAMATAN": "PANCENG"
      },
      {
        "kodeKECAMATAN": 3525160,
        "kodeKABUPATEN": 3525,
        "namaKECAMATAN": "UJUNGPANGKAH"
      },
      {
        "kodeKECAMATAN": 3525170,
        "kodeKABUPATEN": 3525,
        "namaKECAMATAN": "SANGKAPURA"
      },
      {
        "kodeKECAMATAN": 3525180,
        "kodeKABUPATEN": 3525,
        "namaKECAMATAN": "TAMBAK"
      },
      {
        "kodeKECAMATAN": 3526010,
        "kodeKABUPATEN": 3526,
        "namaKECAMATAN": "KAMAL"
      },
      {
        "kodeKECAMATAN": 3526020,
        "kodeKABUPATEN": 3526,
        "namaKECAMATAN": "LABANG"
      },
      {
        "kodeKECAMATAN": 3526030,
        "kodeKABUPATEN": 3526,
        "namaKECAMATAN": "KWANYAR"
      },
      {
        "kodeKECAMATAN": 3526040,
        "kodeKABUPATEN": 3526,
        "namaKECAMATAN": "MODUNG"
      },
      {
        "kodeKECAMATAN": 3526050,
        "kodeKABUPATEN": 3526,
        "namaKECAMATAN": "BLEGA"
      },
      {
        "kodeKECAMATAN": 3526060,
        "kodeKABUPATEN": 3526,
        "namaKECAMATAN": "KONANG"
      },
      {
        "kodeKECAMATAN": 3526070,
        "kodeKABUPATEN": 3526,
        "namaKECAMATAN": "GALIS"
      },
      {
        "kodeKECAMATAN": 3526080,
        "kodeKABUPATEN": 3526,
        "namaKECAMATAN": "TANAH MERAH"
      },
      {
        "kodeKECAMATAN": 3526090,
        "kodeKABUPATEN": 3526,
        "namaKECAMATAN": "TRAGAH"
      },
      {
        "kodeKECAMATAN": 3526100,
        "kodeKABUPATEN": 3526,
        "namaKECAMATAN": "SOCAH"
      },
      {
        "kodeKECAMATAN": 3526110,
        "kodeKABUPATEN": 3526,
        "namaKECAMATAN": "BANGKALAN"
      },
      {
        "kodeKECAMATAN": 3526120,
        "kodeKABUPATEN": 3526,
        "namaKECAMATAN": "BURNEH"
      },
      {
        "kodeKECAMATAN": 3526130,
        "kodeKABUPATEN": 3526,
        "namaKECAMATAN": "AROSBAYA"
      },
      {
        "kodeKECAMATAN": 3526140,
        "kodeKABUPATEN": 3526,
        "namaKECAMATAN": "GEGER"
      },
      {
        "kodeKECAMATAN": 3526150,
        "kodeKABUPATEN": 3526,
        "namaKECAMATAN": "KOKOP"
      },
      {
        "kodeKECAMATAN": 3526160,
        "kodeKABUPATEN": 3526,
        "namaKECAMATAN": "TANJUNGBUMI"
      },
      {
        "kodeKECAMATAN": 3526170,
        "kodeKABUPATEN": 3526,
        "namaKECAMATAN": "SEPULU"
      },
      {
        "kodeKECAMATAN": 3526180,
        "kodeKABUPATEN": 3526,
        "namaKECAMATAN": "KLAMPIS"
      },
      {
        "kodeKECAMATAN": 3527010,
        "kodeKABUPATEN": 3527,
        "namaKECAMATAN": "SRESEH"
      },
      {
        "kodeKECAMATAN": 3527020,
        "kodeKABUPATEN": 3527,
        "namaKECAMATAN": "TORJUN"
      },
      {
        "kodeKECAMATAN": 3527021,
        "kodeKABUPATEN": 3527,
        "namaKECAMATAN": "PANGARENGAN"
      },
      {
        "kodeKECAMATAN": 3527030,
        "kodeKABUPATEN": 3527,
        "namaKECAMATAN": "SAMPANG"
      },
      {
        "kodeKECAMATAN": 3527040,
        "kodeKABUPATEN": 3527,
        "namaKECAMATAN": "CAMPLONG"
      },
      {
        "kodeKECAMATAN": 3527050,
        "kodeKABUPATEN": 3527,
        "namaKECAMATAN": "OMBEN"
      },
      {
        "kodeKECAMATAN": 3527060,
        "kodeKABUPATEN": 3527,
        "namaKECAMATAN": "KEDUNGDUNG"
      },
      {
        "kodeKECAMATAN": 3527070,
        "kodeKABUPATEN": 3527,
        "namaKECAMATAN": "JRENGIK"
      },
      {
        "kodeKECAMATAN": 3527080,
        "kodeKABUPATEN": 3527,
        "namaKECAMATAN": "TAMBELANGAN"
      },
      {
        "kodeKECAMATAN": 3527090,
        "kodeKABUPATEN": 3527,
        "namaKECAMATAN": "BANYUATES"
      },
      {
        "kodeKECAMATAN": 3527100,
        "kodeKABUPATEN": 3527,
        "namaKECAMATAN": "ROBATAL"
      },
      {
        "kodeKECAMATAN": 3527101,
        "kodeKABUPATEN": 3527,
        "namaKECAMATAN": "KARANG PENANG"
      },
      {
        "kodeKECAMATAN": 3527110,
        "kodeKABUPATEN": 3527,
        "namaKECAMATAN": "KETAPANG"
      },
      {
        "kodeKECAMATAN": 3527120,
        "kodeKABUPATEN": 3527,
        "namaKECAMATAN": "SOKOBANAH"
      },
      {
        "kodeKECAMATAN": 3528010,
        "kodeKABUPATEN": 3528,
        "namaKECAMATAN": "TLANAKAN"
      },
      {
        "kodeKECAMATAN": 3528020,
        "kodeKABUPATEN": 3528,
        "namaKECAMATAN": "PADEMAWU"
      },
      {
        "kodeKECAMATAN": 3528030,
        "kodeKABUPATEN": 3528,
        "namaKECAMATAN": "GALIS"
      },
      {
        "kodeKECAMATAN": 3528040,
        "kodeKABUPATEN": 3528,
        "namaKECAMATAN": "LARANGAN"
      },
      {
        "kodeKECAMATAN": 3528050,
        "kodeKABUPATEN": 3528,
        "namaKECAMATAN": "PAMEKASAN"
      },
      {
        "kodeKECAMATAN": 3528060,
        "kodeKABUPATEN": 3528,
        "namaKECAMATAN": "PROPPO"
      },
      {
        "kodeKECAMATAN": 3528070,
        "kodeKABUPATEN": 3528,
        "namaKECAMATAN": "PALENGAAN"
      },
      {
        "kodeKECAMATAN": 3528080,
        "kodeKABUPATEN": 3528,
        "namaKECAMATAN": "PEGANTENAN"
      },
      {
        "kodeKECAMATAN": 3528090,
        "kodeKABUPATEN": 3528,
        "namaKECAMATAN": "KADUR"
      },
      {
        "kodeKECAMATAN": 3528100,
        "kodeKABUPATEN": 3528,
        "namaKECAMATAN": "PAKONG"
      },
      {
        "kodeKECAMATAN": 3528110,
        "kodeKABUPATEN": 3528,
        "namaKECAMATAN": "WARU"
      },
      {
        "kodeKECAMATAN": 3528120,
        "kodeKABUPATEN": 3528,
        "namaKECAMATAN": "BATU MARMAR"
      },
      {
        "kodeKECAMATAN": 3528130,
        "kodeKABUPATEN": 3528,
        "namaKECAMATAN": "PASEAN"
      },
      {
        "kodeKECAMATAN": 3529010,
        "kodeKABUPATEN": 3529,
        "namaKECAMATAN": "PRAGAAN"
      },
      {
        "kodeKECAMATAN": 3529020,
        "kodeKABUPATEN": 3529,
        "namaKECAMATAN": "BLUTO"
      },
      {
        "kodeKECAMATAN": 3529030,
        "kodeKABUPATEN": 3529,
        "namaKECAMATAN": "SARONGGI"
      },
      {
        "kodeKECAMATAN": 3529040,
        "kodeKABUPATEN": 3529,
        "namaKECAMATAN": "GILIGENTENG"
      },
      {
        "kodeKECAMATAN": 3529050,
        "kodeKABUPATEN": 3529,
        "namaKECAMATAN": "TALANGO"
      },
      {
        "kodeKECAMATAN": 3529060,
        "kodeKABUPATEN": 3529,
        "namaKECAMATAN": "KALIANGET"
      },
      {
        "kodeKECAMATAN": 3529070,
        "kodeKABUPATEN": 3529,
        "namaKECAMATAN": "KOTA SUMENEP"
      },
      {
        "kodeKECAMATAN": 3529071,
        "kodeKABUPATEN": 3529,
        "namaKECAMATAN": "BATUAN"
      },
      {
        "kodeKECAMATAN": 3529080,
        "kodeKABUPATEN": 3529,
        "namaKECAMATAN": "LENTENG"
      },
      {
        "kodeKECAMATAN": 3529090,
        "kodeKABUPATEN": 3529,
        "namaKECAMATAN": "GANDING"
      },
      {
        "kodeKECAMATAN": 3529100,
        "kodeKABUPATEN": 3529,
        "namaKECAMATAN": "GULUK GULUK"
      },
      {
        "kodeKECAMATAN": 3529110,
        "kodeKABUPATEN": 3529,
        "namaKECAMATAN": "PASONGSONGAN"
      },
      {
        "kodeKECAMATAN": 3529120,
        "kodeKABUPATEN": 3529,
        "namaKECAMATAN": "AMBUNTEN"
      },
      {
        "kodeKECAMATAN": 3529130,
        "kodeKABUPATEN": 3529,
        "namaKECAMATAN": "RUBARU"
      },
      {
        "kodeKECAMATAN": 3529140,
        "kodeKABUPATEN": 3529,
        "namaKECAMATAN": "DASUK"
      },
      {
        "kodeKECAMATAN": 3529150,
        "kodeKABUPATEN": 3529,
        "namaKECAMATAN": "MANDING"
      },
      {
        "kodeKECAMATAN": 3529160,
        "kodeKABUPATEN": 3529,
        "namaKECAMATAN": "BATUPUTIH"
      },
      {
        "kodeKECAMATAN": 3529170,
        "kodeKABUPATEN": 3529,
        "namaKECAMATAN": "GAPURA"
      },
      {
        "kodeKECAMATAN": 3529180,
        "kodeKABUPATEN": 3529,
        "namaKECAMATAN": "BATANG BATANG"
      },
      {
        "kodeKECAMATAN": 3529190,
        "kodeKABUPATEN": 3529,
        "namaKECAMATAN": "DUNGKEK"
      },
      {
        "kodeKECAMATAN": 3529200,
        "kodeKABUPATEN": 3529,
        "namaKECAMATAN": "NONGGUNONG"
      },
      {
        "kodeKECAMATAN": 3529210,
        "kodeKABUPATEN": 3529,
        "namaKECAMATAN": "GAYAM"
      },
      {
        "kodeKECAMATAN": 3529220,
        "kodeKABUPATEN": 3529,
        "namaKECAMATAN": "RAAS"
      },
      {
        "kodeKECAMATAN": 3529230,
        "kodeKABUPATEN": 3529,
        "namaKECAMATAN": "SAPEKEN"
      },
      {
        "kodeKECAMATAN": 3529240,
        "kodeKABUPATEN": 3529,
        "namaKECAMATAN": "ARJASA"
      },
      {
        "kodeKECAMATAN": 3529241,
        "kodeKABUPATEN": 3529,
        "namaKECAMATAN": "KANGAYAN"
      },
      {
        "kodeKECAMATAN": 3529250,
        "kodeKABUPATEN": 3529,
        "namaKECAMATAN": "MASALEMBU"
      },
      {
        "kodeKECAMATAN": 3571010,
        "kodeKABUPATEN": 3571,
        "namaKECAMATAN": "MOJOROTO"
      },
      {
        "kodeKECAMATAN": 3571020,
        "kodeKABUPATEN": 3571,
        "namaKECAMATAN": "KOTA KEDIRI"
      },
      {
        "kodeKECAMATAN": 3571030,
        "kodeKABUPATEN": 3571,
        "namaKECAMATAN": "PESANTREN"
      },
      {
        "kodeKECAMATAN": 3572010,
        "kodeKABUPATEN": 3572,
        "namaKECAMATAN": "SUKOREJO"
      },
      {
        "kodeKECAMATAN": 3572020,
        "kodeKABUPATEN": 3572,
        "namaKECAMATAN": "KEPANJENKIDUL"
      },
      {
        "kodeKECAMATAN": 3572030,
        "kodeKABUPATEN": 3572,
        "namaKECAMATAN": "SANANWETAN"
      },
      {
        "kodeKECAMATAN": 3573010,
        "kodeKABUPATEN": 3573,
        "namaKECAMATAN": "KEDUNGKANDANG"
      },
      {
        "kodeKECAMATAN": 3573020,
        "kodeKABUPATEN": 3573,
        "namaKECAMATAN": "SUKUN"
      },
      {
        "kodeKECAMATAN": 3573030,
        "kodeKABUPATEN": 3573,
        "namaKECAMATAN": "KLOJEN"
      },
      {
        "kodeKECAMATAN": 3573040,
        "kodeKABUPATEN": 3573,
        "namaKECAMATAN": "BLIMBING"
      },
      {
        "kodeKECAMATAN": 3573050,
        "kodeKABUPATEN": 3573,
        "namaKECAMATAN": "LOWOKWARU"
      },
      {
        "kodeKECAMATAN": 3574010,
        "kodeKABUPATEN": 3574,
        "namaKECAMATAN": "KADEMANGAN"
      },
      {
        "kodeKECAMATAN": 3574011,
        "kodeKABUPATEN": 3574,
        "namaKECAMATAN": "KEDOPOK"
      },
      {
        "kodeKECAMATAN": 3574020,
        "kodeKABUPATEN": 3574,
        "namaKECAMATAN": "WONOASIH"
      },
      {
        "kodeKECAMATAN": 3574030,
        "kodeKABUPATEN": 3574,
        "namaKECAMATAN": "MAYANGAN"
      },
      {
        "kodeKECAMATAN": 3574031,
        "kodeKABUPATEN": 3574,
        "namaKECAMATAN": "KANIGARAN"
      },
      {
        "kodeKECAMATAN": 3575010,
        "kodeKABUPATEN": 3575,
        "namaKECAMATAN": "GADINGREJO"
      },
      {
        "kodeKECAMATAN": 3575020,
        "kodeKABUPATEN": 3575,
        "namaKECAMATAN": "PURWOREJO"
      },
      {
        "kodeKECAMATAN": 3575030,
        "kodeKABUPATEN": 3575,
        "namaKECAMATAN": "BUGULKIDUL"
      },
      {
        "kodeKECAMATAN": 3575031,
        "kodeKABUPATEN": 3575,
        "namaKECAMATAN": "PANGGUNGREJO"
      },
      {
        "kodeKECAMATAN": 3576010,
        "kodeKABUPATEN": 3576,
        "namaKECAMATAN": "PRAJURIT KULON"
      },
      {
        "kodeKECAMATAN": 3576020,
        "kodeKABUPATEN": 3576,
        "namaKECAMATAN": "MAGERSARI"
      },
      {
        "kodeKECAMATAN": 3577010,
        "kodeKABUPATEN": 3577,
        "namaKECAMATAN": "MANGU HARJO"
      },
      {
        "kodeKECAMATAN": 3577020,
        "kodeKABUPATEN": 3577,
        "namaKECAMATAN": "TAMAN"
      },
      {
        "kodeKECAMATAN": 3577030,
        "kodeKABUPATEN": 3577,
        "namaKECAMATAN": "KARTOHARJO"
      },
      {
        "kodeKECAMATAN": 3578010,
        "kodeKABUPATEN": 3578,
        "namaKECAMATAN": "KARANG PILANG"
      },
      {
        "kodeKECAMATAN": 3578020,
        "kodeKABUPATEN": 3578,
        "namaKECAMATAN": "JAMBANGAN"
      },
      {
        "kodeKECAMATAN": 3578030,
        "kodeKABUPATEN": 3578,
        "namaKECAMATAN": "GAYUNGAN"
      },
      {
        "kodeKECAMATAN": 3578040,
        "kodeKABUPATEN": 3578,
        "namaKECAMATAN": "WONOCOLO"
      },
      {
        "kodeKECAMATAN": 3578050,
        "kodeKABUPATEN": 3578,
        "namaKECAMATAN": "TENGGILIS MEJOYO"
      },
      {
        "kodeKECAMATAN": 3578060,
        "kodeKABUPATEN": 3578,
        "namaKECAMATAN": "GUNUNG ANYAR"
      },
      {
        "kodeKECAMATAN": 3578070,
        "kodeKABUPATEN": 3578,
        "namaKECAMATAN": "RUNGKUT"
      },
      {
        "kodeKECAMATAN": 3578080,
        "kodeKABUPATEN": 3578,
        "namaKECAMATAN": "SUKOLILO"
      },
      {
        "kodeKECAMATAN": 3578090,
        "kodeKABUPATEN": 3578,
        "namaKECAMATAN": "MULYOREJO"
      },
      {
        "kodeKECAMATAN": 3578100,
        "kodeKABUPATEN": 3578,
        "namaKECAMATAN": "GUBENG"
      },
      {
        "kodeKECAMATAN": 3578110,
        "kodeKABUPATEN": 3578,
        "namaKECAMATAN": "WONOKROMO"
      },
      {
        "kodeKECAMATAN": 3578120,
        "kodeKABUPATEN": 3578,
        "namaKECAMATAN": "DUKUH PAKIS"
      },
      {
        "kodeKECAMATAN": 3578130,
        "kodeKABUPATEN": 3578,
        "namaKECAMATAN": "WIYUNG"
      },
      {
        "kodeKECAMATAN": 3578140,
        "kodeKABUPATEN": 3578,
        "namaKECAMATAN": "LAKARSANTRI"
      },
      {
        "kodeKECAMATAN": 3578141,
        "kodeKABUPATEN": 3578,
        "namaKECAMATAN": "SAMBIKEREP"
      },
      {
        "kodeKECAMATAN": 3578150,
        "kodeKABUPATEN": 3578,
        "namaKECAMATAN": "TANDES"
      },
      {
        "kodeKECAMATAN": 3578160,
        "kodeKABUPATEN": 3578,
        "namaKECAMATAN": "SUKO MANUNGGAL"
      },
      {
        "kodeKECAMATAN": 3578170,
        "kodeKABUPATEN": 3578,
        "namaKECAMATAN": "SAWAHAN"
      },
      {
        "kodeKECAMATAN": 3578180,
        "kodeKABUPATEN": 3578,
        "namaKECAMATAN": "TEGALSARI"
      },
      {
        "kodeKECAMATAN": 3578190,
        "kodeKABUPATEN": 3578,
        "namaKECAMATAN": "GENTENG"
      },
      {
        "kodeKECAMATAN": 3578200,
        "kodeKABUPATEN": 3578,
        "namaKECAMATAN": "TAMBAKSARI"
      },
      {
        "kodeKECAMATAN": 3578210,
        "kodeKABUPATEN": 3578,
        "namaKECAMATAN": "KENJERAN"
      },
      {
        "kodeKECAMATAN": 3578211,
        "kodeKABUPATEN": 3578,
        "namaKECAMATAN": "BULAK"
      },
      {
        "kodeKECAMATAN": 3578220,
        "kodeKABUPATEN": 3578,
        "namaKECAMATAN": "SIMOKERTO"
      },
      {
        "kodeKECAMATAN": 3578230,
        "kodeKABUPATEN": 3578,
        "namaKECAMATAN": "SEMAMPIR"
      },
      {
        "kodeKECAMATAN": 3578240,
        "kodeKABUPATEN": 3578,
        "namaKECAMATAN": "PABEAN CANTIAN"
      },
      {
        "kodeKECAMATAN": 3578250,
        "kodeKABUPATEN": 3578,
        "namaKECAMATAN": "BUBUTAN"
      },
      {
        "kodeKECAMATAN": 3578260,
        "kodeKABUPATEN": 3578,
        "namaKECAMATAN": "KREMBANGAN"
      },
      {
        "kodeKECAMATAN": 3578270,
        "kodeKABUPATEN": 3578,
        "namaKECAMATAN": "ASEMROWO"
      },
      {
        "kodeKECAMATAN": 3578280,
        "kodeKABUPATEN": 3578,
        "namaKECAMATAN": "BENOWO"
      },
      {
        "kodeKECAMATAN": 3578281,
        "kodeKABUPATEN": 3578,
        "namaKECAMATAN": "PAKAL"
      },
      {
        "kodeKECAMATAN": 3579010,
        "kodeKABUPATEN": 3579,
        "namaKECAMATAN": "BATU"
      },
      {
        "kodeKECAMATAN": 3579020,
        "kodeKABUPATEN": 3579,
        "namaKECAMATAN": "JUNREJO"
      },
      {
        "kodeKECAMATAN": 3579030,
        "kodeKABUPATEN": 3579,
        "namaKECAMATAN": "BUMIAJI"
      },
      {
        "kodeKECAMATAN": 3601010,
        "kodeKABUPATEN": 3601,
        "namaKECAMATAN": "SUMUR"
      },
      {
        "kodeKECAMATAN": 3601020,
        "kodeKABUPATEN": 3601,
        "namaKECAMATAN": "CIMANGGU"
      },
      {
        "kodeKECAMATAN": 3601030,
        "kodeKABUPATEN": 3601,
        "namaKECAMATAN": "CIBALIUNG"
      },
      {
        "kodeKECAMATAN": 3601031,
        "kodeKABUPATEN": 3601,
        "namaKECAMATAN": "CIBITUNG"
      },
      {
        "kodeKECAMATAN": 3601040,
        "kodeKABUPATEN": 3601,
        "namaKECAMATAN": "CIKEUSIK"
      },
      {
        "kodeKECAMATAN": 3601050,
        "kodeKABUPATEN": 3601,
        "namaKECAMATAN": "CIGEULIS"
      },
      {
        "kodeKECAMATAN": 3601060,
        "kodeKABUPATEN": 3601,
        "namaKECAMATAN": "PANIMBANG"
      },
      {
        "kodeKECAMATAN": 3601061,
        "kodeKABUPATEN": 3601,
        "namaKECAMATAN": "SOBANG"
      },
      {
        "kodeKECAMATAN": 3601070,
        "kodeKABUPATEN": 3601,
        "namaKECAMATAN": "MUNJUL"
      },
      {
        "kodeKECAMATAN": 3601071,
        "kodeKABUPATEN": 3601,
        "namaKECAMATAN": "ANGSANA"
      },
      {
        "kodeKECAMATAN": 3601072,
        "kodeKABUPATEN": 3601,
        "namaKECAMATAN": "SINDANGRESMI"
      },
      {
        "kodeKECAMATAN": 3601080,
        "kodeKABUPATEN": 3601,
        "namaKECAMATAN": "PICUNG"
      },
      {
        "kodeKECAMATAN": 3601090,
        "kodeKABUPATEN": 3601,
        "namaKECAMATAN": "BOJONG"
      },
      {
        "kodeKECAMATAN": 3601100,
        "kodeKABUPATEN": 3601,
        "namaKECAMATAN": "SAKETI"
      },
      {
        "kodeKECAMATAN": 3601101,
        "kodeKABUPATEN": 3601,
        "namaKECAMATAN": "CISATA"
      },
      {
        "kodeKECAMATAN": 3601110,
        "kodeKABUPATEN": 3601,
        "namaKECAMATAN": "PAGELARAN"
      },
      {
        "kodeKECAMATAN": 3601111,
        "kodeKABUPATEN": 3601,
        "namaKECAMATAN": "PATIA"
      },
      {
        "kodeKECAMATAN": 3601112,
        "kodeKABUPATEN": 3601,
        "namaKECAMATAN": "SUKARESMI"
      },
      {
        "kodeKECAMATAN": 3601120,
        "kodeKABUPATEN": 3601,
        "namaKECAMATAN": "LABUAN"
      },
      {
        "kodeKECAMATAN": 3601121,
        "kodeKABUPATEN": 3601,
        "namaKECAMATAN": "CARITA"
      },
      {
        "kodeKECAMATAN": 3601130,
        "kodeKABUPATEN": 3601,
        "namaKECAMATAN": "JIPUT"
      },
      {
        "kodeKECAMATAN": 3601131,
        "kodeKABUPATEN": 3601,
        "namaKECAMATAN": "CIKEDAL"
      },
      {
        "kodeKECAMATAN": 3601140,
        "kodeKABUPATEN": 3601,
        "namaKECAMATAN": "MENES"
      },
      {
        "kodeKECAMATAN": 3601141,
        "kodeKABUPATEN": 3601,
        "namaKECAMATAN": "PULOSARI"
      },
      {
        "kodeKECAMATAN": 3601150,
        "kodeKABUPATEN": 3601,
        "namaKECAMATAN": "MANDALAWANGI"
      },
      {
        "kodeKECAMATAN": 3601160,
        "kodeKABUPATEN": 3601,
        "namaKECAMATAN": "CIMANUK"
      },
      {
        "kodeKECAMATAN": 3601161,
        "kodeKABUPATEN": 3601,
        "namaKECAMATAN": "CIPEUCANG"
      },
      {
        "kodeKECAMATAN": 3601170,
        "kodeKABUPATEN": 3601,
        "namaKECAMATAN": "BANJAR"
      },
      {
        "kodeKECAMATAN": 3601171,
        "kodeKABUPATEN": 3601,
        "namaKECAMATAN": "KADUHEJO"
      },
      {
        "kodeKECAMATAN": 3601172,
        "kodeKABUPATEN": 3601,
        "namaKECAMATAN": "MEKARJAYA"
      },
      {
        "kodeKECAMATAN": 3601180,
        "kodeKABUPATEN": 3601,
        "namaKECAMATAN": "PANDEGLANG"
      },
      {
        "kodeKECAMATAN": 3601181,
        "kodeKABUPATEN": 3601,
        "namaKECAMATAN": "MAJASARI"
      },
      {
        "kodeKECAMATAN": 3601190,
        "kodeKABUPATEN": 3601,
        "namaKECAMATAN": "CADASARI"
      },
      {
        "kodeKECAMATAN": 3601191,
        "kodeKABUPATEN": 3601,
        "namaKECAMATAN": "KARANGTANJUNG"
      },
      {
        "kodeKECAMATAN": 3601192,
        "kodeKABUPATEN": 3601,
        "namaKECAMATAN": "KORONCONG"
      },
      {
        "kodeKECAMATAN": 3602010,
        "kodeKABUPATEN": 3602,
        "namaKECAMATAN": "MALINGPING"
      },
      {
        "kodeKECAMATAN": 3602011,
        "kodeKABUPATEN": 3602,
        "namaKECAMATAN": "WANASALAM"
      },
      {
        "kodeKECAMATAN": 3602020,
        "kodeKABUPATEN": 3602,
        "namaKECAMATAN": "PANGGARANGAN"
      },
      {
        "kodeKECAMATAN": 3602021,
        "kodeKABUPATEN": 3602,
        "namaKECAMATAN": "CIHARA"
      },
      {
        "kodeKECAMATAN": 3602030,
        "kodeKABUPATEN": 3602,
        "namaKECAMATAN": "BAYAH"
      },
      {
        "kodeKECAMATAN": 3602031,
        "kodeKABUPATEN": 3602,
        "namaKECAMATAN": "CILOGRANG"
      },
      {
        "kodeKECAMATAN": 3602040,
        "kodeKABUPATEN": 3602,
        "namaKECAMATAN": "CIBEBER"
      },
      {
        "kodeKECAMATAN": 3602050,
        "kodeKABUPATEN": 3602,
        "namaKECAMATAN": "CIJAKU"
      },
      {
        "kodeKECAMATAN": 3602051,
        "kodeKABUPATEN": 3602,
        "namaKECAMATAN": "CIGEMBLONG"
      },
      {
        "kodeKECAMATAN": 3602060,
        "kodeKABUPATEN": 3602,
        "namaKECAMATAN": "BANJARSARI"
      },
      {
        "kodeKECAMATAN": 3602070,
        "kodeKABUPATEN": 3602,
        "namaKECAMATAN": "CILELES"
      },
      {
        "kodeKECAMATAN": 3602080,
        "kodeKABUPATEN": 3602,
        "namaKECAMATAN": "GUNUNG KENCANA"
      },
      {
        "kodeKECAMATAN": 3602090,
        "kodeKABUPATEN": 3602,
        "namaKECAMATAN": "BOJONGMANIK"
      },
      {
        "kodeKECAMATAN": 3602091,
        "kodeKABUPATEN": 3602,
        "namaKECAMATAN": "CIRINTEN"
      },
      {
        "kodeKECAMATAN": 3602100,
        "kodeKABUPATEN": 3602,
        "namaKECAMATAN": "LEUWIDAMAR"
      },
      {
        "kodeKECAMATAN": 3602110,
        "kodeKABUPATEN": 3602,
        "namaKECAMATAN": "MUNCANG"
      },
      {
        "kodeKECAMATAN": 3602111,
        "kodeKABUPATEN": 3602,
        "namaKECAMATAN": "SOBANG"
      },
      {
        "kodeKECAMATAN": 3602120,
        "kodeKABUPATEN": 3602,
        "namaKECAMATAN": "CIPANAS"
      },
      {
        "kodeKECAMATAN": 3602121,
        "kodeKABUPATEN": 3602,
        "namaKECAMATAN": "LEBAKGEDONG"
      },
      {
        "kodeKECAMATAN": 3602130,
        "kodeKABUPATEN": 3602,
        "namaKECAMATAN": "SAJIRA"
      },
      {
        "kodeKECAMATAN": 3602140,
        "kodeKABUPATEN": 3602,
        "namaKECAMATAN": "CIMARGA"
      },
      {
        "kodeKECAMATAN": 3602150,
        "kodeKABUPATEN": 3602,
        "namaKECAMATAN": "CIKULUR"
      },
      {
        "kodeKECAMATAN": 3602160,
        "kodeKABUPATEN": 3602,
        "namaKECAMATAN": "WARUNGGUNUNG"
      },
      {
        "kodeKECAMATAN": 3602170,
        "kodeKABUPATEN": 3602,
        "namaKECAMATAN": "CIBADAK"
      },
      {
        "kodeKECAMATAN": 3602180,
        "kodeKABUPATEN": 3602,
        "namaKECAMATAN": "RANGKASBITUNG"
      },
      {
        "kodeKECAMATAN": 3602181,
        "kodeKABUPATEN": 3602,
        "namaKECAMATAN": "KALANGANYAR"
      },
      {
        "kodeKECAMATAN": 3602190,
        "kodeKABUPATEN": 3602,
        "namaKECAMATAN": "MAJA"
      },
      {
        "kodeKECAMATAN": 3602191,
        "kodeKABUPATEN": 3602,
        "namaKECAMATAN": "CURUGBITUNG"
      },
      {
        "kodeKECAMATAN": 3603010,
        "kodeKABUPATEN": 3603,
        "namaKECAMATAN": "CISOKA"
      },
      {
        "kodeKECAMATAN": 3603011,
        "kodeKABUPATEN": 3603,
        "namaKECAMATAN": "SOLEAR"
      },
      {
        "kodeKECAMATAN": 3603020,
        "kodeKABUPATEN": 3603,
        "namaKECAMATAN": "TIGARAKSA"
      },
      {
        "kodeKECAMATAN": 3603021,
        "kodeKABUPATEN": 3603,
        "namaKECAMATAN": "JAMBE"
      },
      {
        "kodeKECAMATAN": 3603030,
        "kodeKABUPATEN": 3603,
        "namaKECAMATAN": "CIKUPA"
      },
      {
        "kodeKECAMATAN": 3603040,
        "kodeKABUPATEN": 3603,
        "namaKECAMATAN": "PANONGAN"
      },
      {
        "kodeKECAMATAN": 3603050,
        "kodeKABUPATEN": 3603,
        "namaKECAMATAN": "CURUG"
      },
      {
        "kodeKECAMATAN": 3603051,
        "kodeKABUPATEN": 3603,
        "namaKECAMATAN": "KELAPA DUA"
      },
      {
        "kodeKECAMATAN": 3603060,
        "kodeKABUPATEN": 3603,
        "namaKECAMATAN": "LEGOK"
      },
      {
        "kodeKECAMATAN": 3603070,
        "kodeKABUPATEN": 3603,
        "namaKECAMATAN": "PAGEDANGAN"
      },
      {
        "kodeKECAMATAN": 3603081,
        "kodeKABUPATEN": 3603,
        "namaKECAMATAN": "CISAUK"
      },
      {
        "kodeKECAMATAN": 3603120,
        "kodeKABUPATEN": 3603,
        "namaKECAMATAN": "PASARKEMIS"
      },
      {
        "kodeKECAMATAN": 3603121,
        "kodeKABUPATEN": 3603,
        "namaKECAMATAN": "SINDANG JAYA"
      },
      {
        "kodeKECAMATAN": 3603130,
        "kodeKABUPATEN": 3603,
        "namaKECAMATAN": "BALARAJA"
      },
      {
        "kodeKECAMATAN": 3603131,
        "kodeKABUPATEN": 3603,
        "namaKECAMATAN": "JAYANTI"
      },
      {
        "kodeKECAMATAN": 3603132,
        "kodeKABUPATEN": 3603,
        "namaKECAMATAN": "SUKAMULYA"
      },
      {
        "kodeKECAMATAN": 3603140,
        "kodeKABUPATEN": 3603,
        "namaKECAMATAN": "KRESEK"
      },
      {
        "kodeKECAMATAN": 3603141,
        "kodeKABUPATEN": 3603,
        "namaKECAMATAN": "GUNUNG KALER"
      },
      {
        "kodeKECAMATAN": 3603150,
        "kodeKABUPATEN": 3603,
        "namaKECAMATAN": "KRONJO"
      },
      {
        "kodeKECAMATAN": 3603151,
        "kodeKABUPATEN": 3603,
        "namaKECAMATAN": "MEKAR BARU"
      },
      {
        "kodeKECAMATAN": 3603160,
        "kodeKABUPATEN": 3603,
        "namaKECAMATAN": "MAUK"
      },
      {
        "kodeKECAMATAN": 3603161,
        "kodeKABUPATEN": 3603,
        "namaKECAMATAN": "KEMIRI"
      },
      {
        "kodeKECAMATAN": 3603162,
        "kodeKABUPATEN": 3603,
        "namaKECAMATAN": "SUKADIRI"
      },
      {
        "kodeKECAMATAN": 3603170,
        "kodeKABUPATEN": 3603,
        "namaKECAMATAN": "RAJEG"
      },
      {
        "kodeKECAMATAN": 3603180,
        "kodeKABUPATEN": 3603,
        "namaKECAMATAN": "SEPATAN"
      },
      {
        "kodeKECAMATAN": 3603181,
        "kodeKABUPATEN": 3603,
        "namaKECAMATAN": "SEPATAN TIMUR"
      },
      {
        "kodeKECAMATAN": 3603190,
        "kodeKABUPATEN": 3603,
        "namaKECAMATAN": "PAKUHAJI"
      },
      {
        "kodeKECAMATAN": 3603200,
        "kodeKABUPATEN": 3603,
        "namaKECAMATAN": "TELUKNAGA"
      },
      {
        "kodeKECAMATAN": 3603210,
        "kodeKABUPATEN": 3603,
        "namaKECAMATAN": "KOSAMBI"
      },
      {
        "kodeKECAMATAN": 3604010,
        "kodeKABUPATEN": 3604,
        "namaKECAMATAN": "CINANGKA"
      },
      {
        "kodeKECAMATAN": 3604020,
        "kodeKABUPATEN": 3604,
        "namaKECAMATAN": "PADARINCANG"
      },
      {
        "kodeKECAMATAN": 3604030,
        "kodeKABUPATEN": 3604,
        "namaKECAMATAN": "CIOMAS"
      },
      {
        "kodeKECAMATAN": 3604040,
        "kodeKABUPATEN": 3604,
        "namaKECAMATAN": "PABUARAN"
      },
      {
        "kodeKECAMATAN": 3604041,
        "kodeKABUPATEN": 3604,
        "namaKECAMATAN": "GUNUNG SARI"
      },
      {
        "kodeKECAMATAN": 3604050,
        "kodeKABUPATEN": 3604,
        "namaKECAMATAN": "BAROS"
      },
      {
        "kodeKECAMATAN": 3604060,
        "kodeKABUPATEN": 3604,
        "namaKECAMATAN": "PETIR"
      },
      {
        "kodeKECAMATAN": 3604061,
        "kodeKABUPATEN": 3604,
        "namaKECAMATAN": "TUNJUNG TEJA"
      },
      {
        "kodeKECAMATAN": 3604080,
        "kodeKABUPATEN": 3604,
        "namaKECAMATAN": "CIKEUSAL"
      },
      {
        "kodeKECAMATAN": 3604090,
        "kodeKABUPATEN": 3604,
        "namaKECAMATAN": "PAMARAYAN"
      },
      {
        "kodeKECAMATAN": 3604091,
        "kodeKABUPATEN": 3604,
        "namaKECAMATAN": "BANDUNG"
      },
      {
        "kodeKECAMATAN": 3604100,
        "kodeKABUPATEN": 3604,
        "namaKECAMATAN": "JAWILAN"
      },
      {
        "kodeKECAMATAN": 3604110,
        "kodeKABUPATEN": 3604,
        "namaKECAMATAN": "KOPO"
      },
      {
        "kodeKECAMATAN": 3604120,
        "kodeKABUPATEN": 3604,
        "namaKECAMATAN": "CIKANDE"
      },
      {
        "kodeKECAMATAN": 3604121,
        "kodeKABUPATEN": 3604,
        "namaKECAMATAN": "KIBIN"
      },
      {
        "kodeKECAMATAN": 3604130,
        "kodeKABUPATEN": 3604,
        "namaKECAMATAN": "KRAGILAN"
      },
      {
        "kodeKECAMATAN": 3604180,
        "kodeKABUPATEN": 3604,
        "namaKECAMATAN": "WARINGINKURUNG"
      },
      {
        "kodeKECAMATAN": 3604190,
        "kodeKABUPATEN": 3604,
        "namaKECAMATAN": "MANCAK"
      },
      {
        "kodeKECAMATAN": 3604200,
        "kodeKABUPATEN": 3604,
        "namaKECAMATAN": "ANYAR"
      },
      {
        "kodeKECAMATAN": 3604210,
        "kodeKABUPATEN": 3604,
        "namaKECAMATAN": "BOJONEGARA"
      },
      {
        "kodeKECAMATAN": 3604211,
        "kodeKABUPATEN": 3604,
        "namaKECAMATAN": "PULO AMPEL"
      },
      {
        "kodeKECAMATAN": 3604220,
        "kodeKABUPATEN": 3604,
        "namaKECAMATAN": "KRAMATWATU"
      },
      {
        "kodeKECAMATAN": 3604240,
        "kodeKABUPATEN": 3604,
        "namaKECAMATAN": "CIRUAS"
      },
      {
        "kodeKECAMATAN": 3604250,
        "kodeKABUPATEN": 3604,
        "namaKECAMATAN": "PONTANG"
      },
      {
        "kodeKECAMATAN": 3604251,
        "kodeKABUPATEN": 3604,
        "namaKECAMATAN": "LEBAK WANGI"
      },
      {
        "kodeKECAMATAN": 3604260,
        "kodeKABUPATEN": 3604,
        "namaKECAMATAN": "CARENANG"
      },
      {
        "kodeKECAMATAN": 3604261,
        "kodeKABUPATEN": 3604,
        "namaKECAMATAN": "BINUANG"
      },
      {
        "kodeKECAMATAN": 3604270,
        "kodeKABUPATEN": 3604,
        "namaKECAMATAN": "TIRTAYASA"
      },
      {
        "kodeKECAMATAN": 3604271,
        "kodeKABUPATEN": 3604,
        "namaKECAMATAN": "TANARA"
      },
      {
        "kodeKECAMATAN": 3671010,
        "kodeKABUPATEN": 3671,
        "namaKECAMATAN": "CILEDUG"
      },
      {
        "kodeKECAMATAN": 3671011,
        "kodeKABUPATEN": 3671,
        "namaKECAMATAN": "LARANGAN"
      },
      {
        "kodeKECAMATAN": 3671012,
        "kodeKABUPATEN": 3671,
        "namaKECAMATAN": "KARANG TENGAH"
      },
      {
        "kodeKECAMATAN": 3671020,
        "kodeKABUPATEN": 3671,
        "namaKECAMATAN": "CIPONDOH"
      },
      {
        "kodeKECAMATAN": 3671021,
        "kodeKABUPATEN": 3671,
        "namaKECAMATAN": "PINANG"
      },
      {
        "kodeKECAMATAN": 3671030,
        "kodeKABUPATEN": 3671,
        "namaKECAMATAN": "TANGERANG"
      },
      {
        "kodeKECAMATAN": 3671031,
        "kodeKABUPATEN": 3671,
        "namaKECAMATAN": "KARAWACI"
      },
      {
        "kodeKECAMATAN": 3671040,
        "kodeKABUPATEN": 3671,
        "namaKECAMATAN": "JATI UWUNG"
      },
      {
        "kodeKECAMATAN": 3671041,
        "kodeKABUPATEN": 3671,
        "namaKECAMATAN": "CIBODAS"
      },
      {
        "kodeKECAMATAN": 3671042,
        "kodeKABUPATEN": 3671,
        "namaKECAMATAN": "PERIUK"
      },
      {
        "kodeKECAMATAN": 3671050,
        "kodeKABUPATEN": 3671,
        "namaKECAMATAN": "BATUCEPER"
      },
      {
        "kodeKECAMATAN": 3671051,
        "kodeKABUPATEN": 3671,
        "namaKECAMATAN": "NEGLASARI"
      },
      {
        "kodeKECAMATAN": 3671060,
        "kodeKABUPATEN": 3671,
        "namaKECAMATAN": "BENDA"
      },
      {
        "kodeKECAMATAN": 3672010,
        "kodeKABUPATEN": 3672,
        "namaKECAMATAN": "CIWANDAN"
      },
      {
        "kodeKECAMATAN": 3672011,
        "kodeKABUPATEN": 3672,
        "namaKECAMATAN": "CITANGKIL"
      },
      {
        "kodeKECAMATAN": 3672020,
        "kodeKABUPATEN": 3672,
        "namaKECAMATAN": "PULOMERAK"
      },
      {
        "kodeKECAMATAN": 3672021,
        "kodeKABUPATEN": 3672,
        "namaKECAMATAN": "PURWAKARTA"
      },
      {
        "kodeKECAMATAN": 3672022,
        "kodeKABUPATEN": 3672,
        "namaKECAMATAN": "GROGOL"
      },
      {
        "kodeKECAMATAN": 3672030,
        "kodeKABUPATEN": 3672,
        "namaKECAMATAN": "CILEGON"
      },
      {
        "kodeKECAMATAN": 3672031,
        "kodeKABUPATEN": 3672,
        "namaKECAMATAN": "JOMBANG"
      },
      {
        "kodeKECAMATAN": 3672040,
        "kodeKABUPATEN": 3672,
        "namaKECAMATAN": "CIBEBER"
      },
      {
        "kodeKECAMATAN": 3673010,
        "kodeKABUPATEN": 3673,
        "namaKECAMATAN": "CURUG"
      },
      {
        "kodeKECAMATAN": 3673020,
        "kodeKABUPATEN": 3673,
        "namaKECAMATAN": "WALANTAKA"
      },
      {
        "kodeKECAMATAN": 3673030,
        "kodeKABUPATEN": 3673,
        "namaKECAMATAN": "CIPOCOK JAYA"
      },
      {
        "kodeKECAMATAN": 3673040,
        "kodeKABUPATEN": 3673,
        "namaKECAMATAN": "SERANG"
      },
      {
        "kodeKECAMATAN": 3673050,
        "kodeKABUPATEN": 3673,
        "namaKECAMATAN": "TAKTAKAN"
      },
      {
        "kodeKECAMATAN": 3673060,
        "kodeKABUPATEN": 3673,
        "namaKECAMATAN": "KASEMEN"
      },
      {
        "kodeKECAMATAN": 3674010,
        "kodeKABUPATEN": 3674,
        "namaKECAMATAN": "SETU"
      },
      {
        "kodeKECAMATAN": 3674020,
        "kodeKABUPATEN": 3674,
        "namaKECAMATAN": "SERPONG"
      },
      {
        "kodeKECAMATAN": 3674030,
        "kodeKABUPATEN": 3674,
        "namaKECAMATAN": "PAMULANG"
      },
      {
        "kodeKECAMATAN": 3674040,
        "kodeKABUPATEN": 3674,
        "namaKECAMATAN": "CIPUTAT"
      },
      {
        "kodeKECAMATAN": 3674050,
        "kodeKABUPATEN": 3674,
        "namaKECAMATAN": "CIPUTAT TIMUR"
      },
      {
        "kodeKECAMATAN": 3674060,
        "kodeKABUPATEN": 3674,
        "namaKECAMATAN": "PONDOK AREN"
      },
      {
        "kodeKECAMATAN": 3674070,
        "kodeKABUPATEN": 3674,
        "namaKECAMATAN": "SERPONG UTARA"
      },
      {
        "kodeKECAMATAN": 5101010,
        "kodeKABUPATEN": 5101,
        "namaKECAMATAN": "MELAYA"
      },
      {
        "kodeKECAMATAN": 5101020,
        "kodeKABUPATEN": 5101,
        "namaKECAMATAN": "NEGARA"
      },
      {
        "kodeKECAMATAN": 5101021,
        "kodeKABUPATEN": 5101,
        "namaKECAMATAN": "JEMBRANA"
      },
      {
        "kodeKECAMATAN": 5101030,
        "kodeKABUPATEN": 5101,
        "namaKECAMATAN": "MENDOYO"
      },
      {
        "kodeKECAMATAN": 5101040,
        "kodeKABUPATEN": 5101,
        "namaKECAMATAN": "PEKUTATAN"
      },
      {
        "kodeKECAMATAN": 5102010,
        "kodeKABUPATEN": 5102,
        "namaKECAMATAN": "SELEMADEG"
      },
      {
        "kodeKECAMATAN": 5102011,
        "kodeKABUPATEN": 5102,
        "namaKECAMATAN": "SELEMADEG TIMUR"
      },
      {
        "kodeKECAMATAN": 5102012,
        "kodeKABUPATEN": 5102,
        "namaKECAMATAN": "SELEMADEG BARAT"
      },
      {
        "kodeKECAMATAN": 5102020,
        "kodeKABUPATEN": 5102,
        "namaKECAMATAN": "KERAMBITAN"
      },
      {
        "kodeKECAMATAN": 5102030,
        "kodeKABUPATEN": 5102,
        "namaKECAMATAN": "TABANAN"
      },
      {
        "kodeKECAMATAN": 5102040,
        "kodeKABUPATEN": 5102,
        "namaKECAMATAN": "KEDIRI"
      },
      {
        "kodeKECAMATAN": 5102050,
        "kodeKABUPATEN": 5102,
        "namaKECAMATAN": "MARGA"
      },
      {
        "kodeKECAMATAN": 5102060,
        "kodeKABUPATEN": 5102,
        "namaKECAMATAN": "BATURITI"
      },
      {
        "kodeKECAMATAN": 5102070,
        "kodeKABUPATEN": 5102,
        "namaKECAMATAN": "PENEBEL"
      },
      {
        "kodeKECAMATAN": 5102080,
        "kodeKABUPATEN": 5102,
        "namaKECAMATAN": "PUPUAN"
      },
      {
        "kodeKECAMATAN": 5103010,
        "kodeKABUPATEN": 5103,
        "namaKECAMATAN": "KUTA SELATAN"
      },
      {
        "kodeKECAMATAN": 5103020,
        "kodeKABUPATEN": 5103,
        "namaKECAMATAN": "KUTA"
      },
      {
        "kodeKECAMATAN": 5103030,
        "kodeKABUPATEN": 5103,
        "namaKECAMATAN": "KUTA UTARA"
      },
      {
        "kodeKECAMATAN": 5103040,
        "kodeKABUPATEN": 5103,
        "namaKECAMATAN": "MENGWI"
      },
      {
        "kodeKECAMATAN": 5103050,
        "kodeKABUPATEN": 5103,
        "namaKECAMATAN": "ABIANSEMAL"
      },
      {
        "kodeKECAMATAN": 5103060,
        "kodeKABUPATEN": 5103,
        "namaKECAMATAN": "PETANG"
      },
      {
        "kodeKECAMATAN": 5104010,
        "kodeKABUPATEN": 5104,
        "namaKECAMATAN": "SUKAWATI"
      },
      {
        "kodeKECAMATAN": 5104020,
        "kodeKABUPATEN": 5104,
        "namaKECAMATAN": "BLAHBATUH"
      },
      {
        "kodeKECAMATAN": 5104030,
        "kodeKABUPATEN": 5104,
        "namaKECAMATAN": "GIANYAR"
      },
      {
        "kodeKECAMATAN": 5104040,
        "kodeKABUPATEN": 5104,
        "namaKECAMATAN": "TAMPAKSIRING"
      },
      {
        "kodeKECAMATAN": 5104050,
        "kodeKABUPATEN": 5104,
        "namaKECAMATAN": "UBUD"
      },
      {
        "kodeKECAMATAN": 5104060,
        "kodeKABUPATEN": 5104,
        "namaKECAMATAN": "TEGALLALANG"
      },
      {
        "kodeKECAMATAN": 5104070,
        "kodeKABUPATEN": 5104,
        "namaKECAMATAN": "PAYANGAN"
      },
      {
        "kodeKECAMATAN": 5105010,
        "kodeKABUPATEN": 5105,
        "namaKECAMATAN": "NUSAPENIDA"
      },
      {
        "kodeKECAMATAN": 5105020,
        "kodeKABUPATEN": 5105,
        "namaKECAMATAN": "BANJARANGKAN"
      },
      {
        "kodeKECAMATAN": 5105030,
        "kodeKABUPATEN": 5105,
        "namaKECAMATAN": "KLUNGKUNG"
      },
      {
        "kodeKECAMATAN": 5105040,
        "kodeKABUPATEN": 5105,
        "namaKECAMATAN": "DAWAN"
      },
      {
        "kodeKECAMATAN": 5106010,
        "kodeKABUPATEN": 5106,
        "namaKECAMATAN": "SUSUT"
      },
      {
        "kodeKECAMATAN": 5106020,
        "kodeKABUPATEN": 5106,
        "namaKECAMATAN": "BANGLI"
      },
      {
        "kodeKECAMATAN": 5106030,
        "kodeKABUPATEN": 5106,
        "namaKECAMATAN": "TEMBUKU"
      },
      {
        "kodeKECAMATAN": 5106040,
        "kodeKABUPATEN": 5106,
        "namaKECAMATAN": "KINTAMANI"
      },
      {
        "kodeKECAMATAN": 5107010,
        "kodeKABUPATEN": 5107,
        "namaKECAMATAN": "RENDANG"
      },
      {
        "kodeKECAMATAN": 5107020,
        "kodeKABUPATEN": 5107,
        "namaKECAMATAN": "SIDEMEN"
      },
      {
        "kodeKECAMATAN": 5107030,
        "kodeKABUPATEN": 5107,
        "namaKECAMATAN": "MANGGIS"
      },
      {
        "kodeKECAMATAN": 5107040,
        "kodeKABUPATEN": 5107,
        "namaKECAMATAN": "KARANGASEM"
      },
      {
        "kodeKECAMATAN": 5107050,
        "kodeKABUPATEN": 5107,
        "namaKECAMATAN": "ABANG"
      },
      {
        "kodeKECAMATAN": 5107060,
        "kodeKABUPATEN": 5107,
        "namaKECAMATAN": "BEBANDEM"
      },
      {
        "kodeKECAMATAN": 5107070,
        "kodeKABUPATEN": 5107,
        "namaKECAMATAN": "SELAT"
      },
      {
        "kodeKECAMATAN": 5107080,
        "kodeKABUPATEN": 5107,
        "namaKECAMATAN": "KUBU"
      },
      {
        "kodeKECAMATAN": 5108010,
        "kodeKABUPATEN": 5108,
        "namaKECAMATAN": "GEROKGAK"
      },
      {
        "kodeKECAMATAN": 5108020,
        "kodeKABUPATEN": 5108,
        "namaKECAMATAN": "SERIRIT"
      },
      {
        "kodeKECAMATAN": 5108030,
        "kodeKABUPATEN": 5108,
        "namaKECAMATAN": "BUSUNGBIU"
      },
      {
        "kodeKECAMATAN": 5108040,
        "kodeKABUPATEN": 5108,
        "namaKECAMATAN": "BANJAR"
      },
      {
        "kodeKECAMATAN": 5108050,
        "kodeKABUPATEN": 5108,
        "namaKECAMATAN": "SUKASADA"
      },
      {
        "kodeKECAMATAN": 5108060,
        "kodeKABUPATEN": 5108,
        "namaKECAMATAN": "BULELENG"
      },
      {
        "kodeKECAMATAN": 5108070,
        "kodeKABUPATEN": 5108,
        "namaKECAMATAN": "SAWAN"
      },
      {
        "kodeKECAMATAN": 5108080,
        "kodeKABUPATEN": 5108,
        "namaKECAMATAN": "KUBUTAMBAHAN"
      },
      {
        "kodeKECAMATAN": 5108090,
        "kodeKABUPATEN": 5108,
        "namaKECAMATAN": "TEJAKULA"
      },
      {
        "kodeKECAMATAN": 5171010,
        "kodeKABUPATEN": 5171,
        "namaKECAMATAN": "DENPASAR SELATAN"
      },
      {
        "kodeKECAMATAN": 5171020,
        "kodeKABUPATEN": 5171,
        "namaKECAMATAN": "DENPASAR TIMUR"
      },
      {
        "kodeKECAMATAN": 5171030,
        "kodeKABUPATEN": 5171,
        "namaKECAMATAN": "DENPASAR BARAT"
      },
      {
        "kodeKECAMATAN": 5171031,
        "kodeKABUPATEN": 5171,
        "namaKECAMATAN": "DENPASAR UTARA"
      },
      {
        "kodeKECAMATAN": 5201010,
        "kodeKABUPATEN": 5201,
        "namaKECAMATAN": "SEKOTONG"
      },
      {
        "kodeKECAMATAN": 5201011,
        "kodeKABUPATEN": 5201,
        "namaKECAMATAN": "LEMBAR"
      },
      {
        "kodeKECAMATAN": 5201020,
        "kodeKABUPATEN": 5201,
        "namaKECAMATAN": "GERUNG"
      },
      {
        "kodeKECAMATAN": 5201030,
        "kodeKABUPATEN": 5201,
        "namaKECAMATAN": "LABU API"
      },
      {
        "kodeKECAMATAN": 5201040,
        "kodeKABUPATEN": 5201,
        "namaKECAMATAN": "KEDIRI"
      },
      {
        "kodeKECAMATAN": 5201041,
        "kodeKABUPATEN": 5201,
        "namaKECAMATAN": "KURIPAN"
      },
      {
        "kodeKECAMATAN": 5201050,
        "kodeKABUPATEN": 5201,
        "namaKECAMATAN": "NARMADA"
      },
      {
        "kodeKECAMATAN": 5201051,
        "kodeKABUPATEN": 5201,
        "namaKECAMATAN": "LINGSAR"
      },
      {
        "kodeKECAMATAN": 5201060,
        "kodeKABUPATEN": 5201,
        "namaKECAMATAN": "GUNUNG SARI"
      },
      {
        "kodeKECAMATAN": 5201061,
        "kodeKABUPATEN": 5201,
        "namaKECAMATAN": "BATU LAYAR"
      },
      {
        "kodeKECAMATAN": 5202010,
        "kodeKABUPATEN": 5202,
        "namaKECAMATAN": "PRAYA BARAT"
      },
      {
        "kodeKECAMATAN": 5202011,
        "kodeKABUPATEN": 5202,
        "namaKECAMATAN": "PRAYA BARAT DAYA"
      },
      {
        "kodeKECAMATAN": 5202020,
        "kodeKABUPATEN": 5202,
        "namaKECAMATAN": "PUJUT"
      },
      {
        "kodeKECAMATAN": 5202030,
        "kodeKABUPATEN": 5202,
        "namaKECAMATAN": "PRAYA TIMUR"
      },
      {
        "kodeKECAMATAN": 5202040,
        "kodeKABUPATEN": 5202,
        "namaKECAMATAN": "JANAPRIA"
      },
      {
        "kodeKECAMATAN": 5202050,
        "kodeKABUPATEN": 5202,
        "namaKECAMATAN": "KOPANG"
      },
      {
        "kodeKECAMATAN": 5202060,
        "kodeKABUPATEN": 5202,
        "namaKECAMATAN": "PRAYA"
      },
      {
        "kodeKECAMATAN": 5202061,
        "kodeKABUPATEN": 5202,
        "namaKECAMATAN": "PRAYA TENGAH"
      },
      {
        "kodeKECAMATAN": 5202070,
        "kodeKABUPATEN": 5202,
        "namaKECAMATAN": "JONGGAT"
      },
      {
        "kodeKECAMATAN": 5202080,
        "kodeKABUPATEN": 5202,
        "namaKECAMATAN": "PRINGGARATA"
      },
      {
        "kodeKECAMATAN": 5202090,
        "kodeKABUPATEN": 5202,
        "namaKECAMATAN": "BATUKLIANG"
      },
      {
        "kodeKECAMATAN": 5202091,
        "kodeKABUPATEN": 5202,
        "namaKECAMATAN": "BATUKLIANG UTARA"
      },
      {
        "kodeKECAMATAN": 5203010,
        "kodeKABUPATEN": 5203,
        "namaKECAMATAN": "KERUAK"
      },
      {
        "kodeKECAMATAN": 5203011,
        "kodeKABUPATEN": 5203,
        "namaKECAMATAN": "JEROWARU"
      },
      {
        "kodeKECAMATAN": 5203020,
        "kodeKABUPATEN": 5203,
        "namaKECAMATAN": "SAKRA"
      },
      {
        "kodeKECAMATAN": 5203021,
        "kodeKABUPATEN": 5203,
        "namaKECAMATAN": "SAKRA BARAT"
      },
      {
        "kodeKECAMATAN": 5203022,
        "kodeKABUPATEN": 5203,
        "namaKECAMATAN": "SAKRA TIMUR"
      },
      {
        "kodeKECAMATAN": 5203030,
        "kodeKABUPATEN": 5203,
        "namaKECAMATAN": "TERARA"
      },
      {
        "kodeKECAMATAN": 5203031,
        "kodeKABUPATEN": 5203,
        "namaKECAMATAN": "MONTONG GADING"
      },
      {
        "kodeKECAMATAN": 5203040,
        "kodeKABUPATEN": 5203,
        "namaKECAMATAN": "SIKUR"
      },
      {
        "kodeKECAMATAN": 5203050,
        "kodeKABUPATEN": 5203,
        "namaKECAMATAN": "MASBAGIK"
      },
      {
        "kodeKECAMATAN": 5203051,
        "kodeKABUPATEN": 5203,
        "namaKECAMATAN": "PRINGGASELA"
      },
      {
        "kodeKECAMATAN": 5203060,
        "kodeKABUPATEN": 5203,
        "namaKECAMATAN": "SUKAMULIA"
      },
      {
        "kodeKECAMATAN": 5203061,
        "kodeKABUPATEN": 5203,
        "namaKECAMATAN": "SURALAGA"
      },
      {
        "kodeKECAMATAN": 5203070,
        "kodeKABUPATEN": 5203,
        "namaKECAMATAN": "SELONG"
      },
      {
        "kodeKECAMATAN": 5203071,
        "kodeKABUPATEN": 5203,
        "namaKECAMATAN": "LABUHAN HAJI"
      },
      {
        "kodeKECAMATAN": 5203080,
        "kodeKABUPATEN": 5203,
        "namaKECAMATAN": "PRINGGABAYA"
      },
      {
        "kodeKECAMATAN": 5203081,
        "kodeKABUPATEN": 5203,
        "namaKECAMATAN": "SUELA"
      },
      {
        "kodeKECAMATAN": 5203090,
        "kodeKABUPATEN": 5203,
        "namaKECAMATAN": "AIKMEL"
      },
      {
        "kodeKECAMATAN": 5203091,
        "kodeKABUPATEN": 5203,
        "namaKECAMATAN": "WANASABA"
      },
      {
        "kodeKECAMATAN": 5203092,
        "kodeKABUPATEN": 5203,
        "namaKECAMATAN": "SEMBALUN"
      },
      {
        "kodeKECAMATAN": 5203100,
        "kodeKABUPATEN": 5203,
        "namaKECAMATAN": "SAMBELIA"
      },
      {
        "kodeKECAMATAN": 5204020,
        "kodeKABUPATEN": 5204,
        "namaKECAMATAN": "LUNYUK"
      },
      {
        "kodeKECAMATAN": 5204021,
        "kodeKABUPATEN": 5204,
        "namaKECAMATAN": "ORONG TELU"
      },
      {
        "kodeKECAMATAN": 5204050,
        "kodeKABUPATEN": 5204,
        "namaKECAMATAN": "ALAS"
      },
      {
        "kodeKECAMATAN": 5204051,
        "kodeKABUPATEN": 5204,
        "namaKECAMATAN": "ALAS BARAT"
      },
      {
        "kodeKECAMATAN": 5204052,
        "kodeKABUPATEN": 5204,
        "namaKECAMATAN": "BUER"
      },
      {
        "kodeKECAMATAN": 5204061,
        "kodeKABUPATEN": 5204,
        "namaKECAMATAN": "UTAN"
      },
      {
        "kodeKECAMATAN": 5204062,
        "kodeKABUPATEN": 5204,
        "namaKECAMATAN": "RHEE"
      },
      {
        "kodeKECAMATAN": 5204070,
        "kodeKABUPATEN": 5204,
        "namaKECAMATAN": "BATULANTEH"
      },
      {
        "kodeKECAMATAN": 5204080,
        "kodeKABUPATEN": 5204,
        "namaKECAMATAN": "SUMBAWA"
      },
      {
        "kodeKECAMATAN": 5204081,
        "kodeKABUPATEN": 5204,
        "namaKECAMATAN": "LABUHAN BADAS"
      },
      {
        "kodeKECAMATAN": 5204082,
        "kodeKABUPATEN": 5204,
        "namaKECAMATAN": "UNTER IWES"
      },
      {
        "kodeKECAMATAN": 5204090,
        "kodeKABUPATEN": 5204,
        "namaKECAMATAN": "MOYOHILIR"
      },
      {
        "kodeKECAMATAN": 5204091,
        "kodeKABUPATEN": 5204,
        "namaKECAMATAN": "MOYO UTARA"
      },
      {
        "kodeKECAMATAN": 5204100,
        "kodeKABUPATEN": 5204,
        "namaKECAMATAN": "MOYOHULU"
      },
      {
        "kodeKECAMATAN": 5204110,
        "kodeKABUPATEN": 5204,
        "namaKECAMATAN": "ROPANG"
      },
      {
        "kodeKECAMATAN": 5204111,
        "kodeKABUPATEN": 5204,
        "namaKECAMATAN": "LENANGGUAR"
      },
      {
        "kodeKECAMATAN": 5204112,
        "kodeKABUPATEN": 5204,
        "namaKECAMATAN": "LANTUNG"
      },
      {
        "kodeKECAMATAN": 5204121,
        "kodeKABUPATEN": 5204,
        "namaKECAMATAN": "LAPE"
      },
      {
        "kodeKECAMATAN": 5204122,
        "kodeKABUPATEN": 5204,
        "namaKECAMATAN": "LOPOK"
      },
      {
        "kodeKECAMATAN": 5204130,
        "kodeKABUPATEN": 5204,
        "namaKECAMATAN": "PLAMPANG"
      },
      {
        "kodeKECAMATAN": 5204131,
        "kodeKABUPATEN": 5204,
        "namaKECAMATAN": "LABANGKA"
      },
      {
        "kodeKECAMATAN": 5204132,
        "kodeKABUPATEN": 5204,
        "namaKECAMATAN": "MARONGE"
      },
      {
        "kodeKECAMATAN": 5204140,
        "kodeKABUPATEN": 5204,
        "namaKECAMATAN": "EMPANG"
      },
      {
        "kodeKECAMATAN": 5204141,
        "kodeKABUPATEN": 5204,
        "namaKECAMATAN": "TARANO"
      },
      {
        "kodeKECAMATAN": 5205010,
        "kodeKABUPATEN": 5205,
        "namaKECAMATAN": "HU'U"
      },
      {
        "kodeKECAMATAN": 5205011,
        "kodeKABUPATEN": 5205,
        "namaKECAMATAN": "PAJO"
      },
      {
        "kodeKECAMATAN": 5205020,
        "kodeKABUPATEN": 5205,
        "namaKECAMATAN": "DOMPU"
      },
      {
        "kodeKECAMATAN": 5205030,
        "kodeKABUPATEN": 5205,
        "namaKECAMATAN": "WOJA"
      },
      {
        "kodeKECAMATAN": 5205040,
        "kodeKABUPATEN": 5205,
        "namaKECAMATAN": "KILO"
      },
      {
        "kodeKECAMATAN": 5205050,
        "kodeKABUPATEN": 5205,
        "namaKECAMATAN": "KEMPO"
      },
      {
        "kodeKECAMATAN": 5205051,
        "kodeKABUPATEN": 5205,
        "namaKECAMATAN": "MANGGALEWA"
      },
      {
        "kodeKECAMATAN": 5205060,
        "kodeKABUPATEN": 5205,
        "namaKECAMATAN": "PEKAT"
      },
      {
        "kodeKECAMATAN": 5206010,
        "kodeKABUPATEN": 5206,
        "namaKECAMATAN": "MONTA"
      },
      {
        "kodeKECAMATAN": 5206011,
        "kodeKABUPATEN": 5206,
        "namaKECAMATAN": "PARADO"
      },
      {
        "kodeKECAMATAN": 5206020,
        "kodeKABUPATEN": 5206,
        "namaKECAMATAN": "BOLO"
      },
      {
        "kodeKECAMATAN": 5206021,
        "kodeKABUPATEN": 5206,
        "namaKECAMATAN": "MADA PANGGA"
      },
      {
        "kodeKECAMATAN": 5206030,
        "kodeKABUPATEN": 5206,
        "namaKECAMATAN": "WOHA"
      },
      {
        "kodeKECAMATAN": 5206040,
        "kodeKABUPATEN": 5206,
        "namaKECAMATAN": "BELO"
      },
      {
        "kodeKECAMATAN": 5206041,
        "kodeKABUPATEN": 5206,
        "namaKECAMATAN": "PALIBELO"
      },
      {
        "kodeKECAMATAN": 5206050,
        "kodeKABUPATEN": 5206,
        "namaKECAMATAN": "WAWO"
      },
      {
        "kodeKECAMATAN": 5206051,
        "kodeKABUPATEN": 5206,
        "namaKECAMATAN": "LANGGUDU"
      },
      {
        "kodeKECAMATAN": 5206052,
        "kodeKABUPATEN": 5206,
        "namaKECAMATAN": "LAMBITU"
      },
      {
        "kodeKECAMATAN": 5206060,
        "kodeKABUPATEN": 5206,
        "namaKECAMATAN": "SAPE"
      },
      {
        "kodeKECAMATAN": 5206061,
        "kodeKABUPATEN": 5206,
        "namaKECAMATAN": "LAMBU"
      },
      {
        "kodeKECAMATAN": 5206070,
        "kodeKABUPATEN": 5206,
        "namaKECAMATAN": "WERA"
      },
      {
        "kodeKECAMATAN": 5206071,
        "kodeKABUPATEN": 5206,
        "namaKECAMATAN": "AMBALAWI"
      },
      {
        "kodeKECAMATAN": 5206080,
        "kodeKABUPATEN": 5206,
        "namaKECAMATAN": "DONGGO"
      },
      {
        "kodeKECAMATAN": 5206081,
        "kodeKABUPATEN": 5206,
        "namaKECAMATAN": "SOROMANDI"
      },
      {
        "kodeKECAMATAN": 5206090,
        "kodeKABUPATEN": 5206,
        "namaKECAMATAN": "SANGGAR"
      },
      {
        "kodeKECAMATAN": 5206091,
        "kodeKABUPATEN": 5206,
        "namaKECAMATAN": "TAMBORA"
      },
      {
        "kodeKECAMATAN": 5207010,
        "kodeKABUPATEN": 5207,
        "namaKECAMATAN": "SEKONGKANG"
      },
      {
        "kodeKECAMATAN": 5207020,
        "kodeKABUPATEN": 5207,
        "namaKECAMATAN": "JEREWEH"
      },
      {
        "kodeKECAMATAN": 5207021,
        "kodeKABUPATEN": 5207,
        "namaKECAMATAN": "MALUK"
      },
      {
        "kodeKECAMATAN": 5207030,
        "kodeKABUPATEN": 5207,
        "namaKECAMATAN": "TALIWANG"
      },
      {
        "kodeKECAMATAN": 5207031,
        "kodeKABUPATEN": 5207,
        "namaKECAMATAN": "BRANG ENE"
      },
      {
        "kodeKECAMATAN": 5207040,
        "kodeKABUPATEN": 5207,
        "namaKECAMATAN": "BRANG REA"
      },
      {
        "kodeKECAMATAN": 5207050,
        "kodeKABUPATEN": 5207,
        "namaKECAMATAN": "SETELUK"
      },
      {
        "kodeKECAMATAN": 5207051,
        "kodeKABUPATEN": 5207,
        "namaKECAMATAN": "POTO TANO"
      },
      {
        "kodeKECAMATAN": 5208010,
        "kodeKABUPATEN": 5208,
        "namaKECAMATAN": "PEMENANG"
      },
      {
        "kodeKECAMATAN": 5208020,
        "kodeKABUPATEN": 5208,
        "namaKECAMATAN": "TANJUNG"
      },
      {
        "kodeKECAMATAN": 5208030,
        "kodeKABUPATEN": 5208,
        "namaKECAMATAN": "GANGGA"
      },
      {
        "kodeKECAMATAN": 5208040,
        "kodeKABUPATEN": 5208,
        "namaKECAMATAN": "KAYANGAN"
      },
      {
        "kodeKECAMATAN": 5208050,
        "kodeKABUPATEN": 5208,
        "namaKECAMATAN": "BAYAN"
      },
      {
        "kodeKECAMATAN": 5271010,
        "kodeKABUPATEN": 5271,
        "namaKECAMATAN": "AMPENAN"
      },
      {
        "kodeKECAMATAN": 5271011,
        "kodeKABUPATEN": 5271,
        "namaKECAMATAN": "SEKARBELA"
      },
      {
        "kodeKECAMATAN": 5271020,
        "kodeKABUPATEN": 5271,
        "namaKECAMATAN": "MATARAM"
      },
      {
        "kodeKECAMATAN": 5271021,
        "kodeKABUPATEN": 5271,
        "namaKECAMATAN": "SELAPARANG"
      },
      {
        "kodeKECAMATAN": 5271030,
        "kodeKABUPATEN": 5271,
        "namaKECAMATAN": "CAKRANEGARA"
      },
      {
        "kodeKECAMATAN": 5271031,
        "kodeKABUPATEN": 5271,
        "namaKECAMATAN": "SANDUBAYA"
      },
      {
        "kodeKECAMATAN": 5272010,
        "kodeKABUPATEN": 5272,
        "namaKECAMATAN": "RASANAE BARAT"
      },
      {
        "kodeKECAMATAN": 5272011,
        "kodeKABUPATEN": 5272,
        "namaKECAMATAN": "MPUNDA"
      },
      {
        "kodeKECAMATAN": 5272020,
        "kodeKABUPATEN": 5272,
        "namaKECAMATAN": "RASANAE TIMUR"
      },
      {
        "kodeKECAMATAN": 5272021,
        "kodeKABUPATEN": 5272,
        "namaKECAMATAN": "RABA"
      },
      {
        "kodeKECAMATAN": 5272030,
        "kodeKABUPATEN": 5272,
        "namaKECAMATAN": "ASAKOTA"
      },
      {
        "kodeKECAMATAN": 5301021,
        "kodeKABUPATEN": 5301,
        "namaKECAMATAN": "LAMBOYA"
      },
      {
        "kodeKECAMATAN": 5301022,
        "kodeKABUPATEN": 5301,
        "namaKECAMATAN": "WANOKAKA"
      },
      {
        "kodeKECAMATAN": 5301023,
        "kodeKABUPATEN": 5301,
        "namaKECAMATAN": "LABOYA BARAT"
      },
      {
        "kodeKECAMATAN": 5301050,
        "kodeKABUPATEN": 5301,
        "namaKECAMATAN": "LOLI"
      },
      {
        "kodeKECAMATAN": 5301060,
        "kodeKABUPATEN": 5301,
        "namaKECAMATAN": "KOTA WAIKABUBAK"
      },
      {
        "kodeKECAMATAN": 5301072,
        "kodeKABUPATEN": 5301,
        "namaKECAMATAN": "TANA RIGHU"
      },
      {
        "kodeKECAMATAN": 5302010,
        "kodeKABUPATEN": 5302,
        "namaKECAMATAN": "LEWA"
      },
      {
        "kodeKECAMATAN": 5302011,
        "kodeKABUPATEN": 5302,
        "namaKECAMATAN": "NGGAHA ORIANGU"
      },
      {
        "kodeKECAMATAN": 5302012,
        "kodeKABUPATEN": 5302,
        "namaKECAMATAN": "LEWA TIDAHU"
      },
      {
        "kodeKECAMATAN": 5302013,
        "kodeKABUPATEN": 5302,
        "namaKECAMATAN": "KATALA HAMU LINGU"
      },
      {
        "kodeKECAMATAN": 5302020,
        "kodeKABUPATEN": 5302,
        "namaKECAMATAN": "TABUNDUNG"
      },
      {
        "kodeKECAMATAN": 5302021,
        "kodeKABUPATEN": 5302,
        "namaKECAMATAN": "PINUPAHAR"
      },
      {
        "kodeKECAMATAN": 5302030,
        "kodeKABUPATEN": 5302,
        "namaKECAMATAN": "PABERIWAI"
      },
      {
        "kodeKECAMATAN": 5302031,
        "kodeKABUPATEN": 5302,
        "namaKECAMATAN": "KARERA"
      },
      {
        "kodeKECAMATAN": 5302032,
        "kodeKABUPATEN": 5302,
        "namaKECAMATAN": "MATAWAI LA PAWU"
      },
      {
        "kodeKECAMATAN": 5302033,
        "kodeKABUPATEN": 5302,
        "namaKECAMATAN": "KAHAUNGU ETI"
      },
      {
        "kodeKECAMATAN": 5302034,
        "kodeKABUPATEN": 5302,
        "namaKECAMATAN": "MAHU"
      },
      {
        "kodeKECAMATAN": 5302035,
        "kodeKABUPATEN": 5302,
        "namaKECAMATAN": "NGADU NGALA"
      },
      {
        "kodeKECAMATAN": 5302040,
        "kodeKABUPATEN": 5302,
        "namaKECAMATAN": "PAHUNGA LODU"
      },
      {
        "kodeKECAMATAN": 5302041,
        "kodeKABUPATEN": 5302,
        "namaKECAMATAN": "WULA WAIJELU"
      },
      {
        "kodeKECAMATAN": 5302051,
        "kodeKABUPATEN": 5302,
        "namaKECAMATAN": "RINDI"
      },
      {
        "kodeKECAMATAN": 5302052,
        "kodeKABUPATEN": 5302,
        "namaKECAMATAN": "UMALULU"
      },
      {
        "kodeKECAMATAN": 5302060,
        "kodeKABUPATEN": 5302,
        "namaKECAMATAN": "PANDAWAI"
      },
      {
        "kodeKECAMATAN": 5302061,
        "kodeKABUPATEN": 5302,
        "namaKECAMATAN": "KAMBATA MAPAMBUHANG"
      },
      {
        "kodeKECAMATAN": 5302070,
        "kodeKABUPATEN": 5302,
        "namaKECAMATAN": "KOTA WAINGAPU"
      },
      {
        "kodeKECAMATAN": 5302071,
        "kodeKABUPATEN": 5302,
        "namaKECAMATAN": "KAMBERA"
      },
      {
        "kodeKECAMATAN": 5302080,
        "kodeKABUPATEN": 5302,
        "namaKECAMATAN": "HAHARU"
      },
      {
        "kodeKECAMATAN": 5302081,
        "kodeKABUPATEN": 5302,
        "namaKECAMATAN": "KANATANG"
      },
      {
        "kodeKECAMATAN": 5303100,
        "kodeKABUPATEN": 5303,
        "namaKECAMATAN": "SEMAU"
      },
      {
        "kodeKECAMATAN": 5303101,
        "kodeKABUPATEN": 5303,
        "namaKECAMATAN": "SEMAU SELATAN"
      },
      {
        "kodeKECAMATAN": 5303110,
        "kodeKABUPATEN": 5303,
        "namaKECAMATAN": "KUPANG BARAT"
      },
      {
        "kodeKECAMATAN": 5303111,
        "kodeKABUPATEN": 5303,
        "namaKECAMATAN": "NEKAMESE"
      },
      {
        "kodeKECAMATAN": 5303120,
        "kodeKABUPATEN": 5303,
        "namaKECAMATAN": "KUPANG TENGAH"
      },
      {
        "kodeKECAMATAN": 5303121,
        "kodeKABUPATEN": 5303,
        "namaKECAMATAN": "TAEBENU"
      },
      {
        "kodeKECAMATAN": 5303130,
        "kodeKABUPATEN": 5303,
        "namaKECAMATAN": "AMARASI"
      },
      {
        "kodeKECAMATAN": 5303131,
        "kodeKABUPATEN": 5303,
        "namaKECAMATAN": "AMARASI BARAT"
      },
      {
        "kodeKECAMATAN": 5303132,
        "kodeKABUPATEN": 5303,
        "namaKECAMATAN": "AMARASI SELATAN"
      },
      {
        "kodeKECAMATAN": 5303133,
        "kodeKABUPATEN": 5303,
        "namaKECAMATAN": "AMARASI TIMUR"
      },
      {
        "kodeKECAMATAN": 5303140,
        "kodeKABUPATEN": 5303,
        "namaKECAMATAN": "KUPANG TIMUR"
      },
      {
        "kodeKECAMATAN": 5303141,
        "kodeKABUPATEN": 5303,
        "namaKECAMATAN": "AMABI OEFETO TIMUR"
      },
      {
        "kodeKECAMATAN": 5303142,
        "kodeKABUPATEN": 5303,
        "namaKECAMATAN": "AMABI OEFETO"
      },
      {
        "kodeKECAMATAN": 5303150,
        "kodeKABUPATEN": 5303,
        "namaKECAMATAN": "SULAMU"
      },
      {
        "kodeKECAMATAN": 5303160,
        "kodeKABUPATEN": 5303,
        "namaKECAMATAN": "FATULEU"
      },
      {
        "kodeKECAMATAN": 5303161,
        "kodeKABUPATEN": 5303,
        "namaKECAMATAN": "FATULEU TENGAH"
      },
      {
        "kodeKECAMATAN": 5303162,
        "kodeKABUPATEN": 5303,
        "namaKECAMATAN": "FATULEU BARAT"
      },
      {
        "kodeKECAMATAN": 5303170,
        "kodeKABUPATEN": 5303,
        "namaKECAMATAN": "TAKARI"
      },
      {
        "kodeKECAMATAN": 5303180,
        "kodeKABUPATEN": 5303,
        "namaKECAMATAN": "AMFOANG SELATAN"
      },
      {
        "kodeKECAMATAN": 5303181,
        "kodeKABUPATEN": 5303,
        "namaKECAMATAN": "AMFOANG BARAT DAYA"
      },
      {
        "kodeKECAMATAN": 5303182,
        "kodeKABUPATEN": 5303,
        "namaKECAMATAN": "AMFOANG TENGAH"
      },
      {
        "kodeKECAMATAN": 5303190,
        "kodeKABUPATEN": 5303,
        "namaKECAMATAN": "AMFOANG UTARA"
      },
      {
        "kodeKECAMATAN": 5303191,
        "kodeKABUPATEN": 5303,
        "namaKECAMATAN": "AMFOANG BARAT LAUT"
      },
      {
        "kodeKECAMATAN": 5303192,
        "kodeKABUPATEN": 5303,
        "namaKECAMATAN": "AMFOANG TIMUR"
      },
      {
        "kodeKECAMATAN": 5304010,
        "kodeKABUPATEN": 5304,
        "namaKECAMATAN": "MOLLO UTARA"
      },
      {
        "kodeKECAMATAN": 5304011,
        "kodeKABUPATEN": 5304,
        "namaKECAMATAN": "FATUMNASI"
      },
      {
        "kodeKECAMATAN": 5304012,
        "kodeKABUPATEN": 5304,
        "namaKECAMATAN": "TOBU"
      },
      {
        "kodeKECAMATAN": 5304013,
        "kodeKABUPATEN": 5304,
        "namaKECAMATAN": "NUNBENA"
      },
      {
        "kodeKECAMATAN": 5304020,
        "kodeKABUPATEN": 5304,
        "namaKECAMATAN": "MOLLO SELATAN"
      },
      {
        "kodeKECAMATAN": 5304021,
        "kodeKABUPATEN": 5304,
        "namaKECAMATAN": "POLEN"
      },
      {
        "kodeKECAMATAN": 5304022,
        "kodeKABUPATEN": 5304,
        "namaKECAMATAN": "MOLLO BARAT"
      },
      {
        "kodeKECAMATAN": 5304023,
        "kodeKABUPATEN": 5304,
        "namaKECAMATAN": "MOLLO TENGAH"
      },
      {
        "kodeKECAMATAN": 5304030,
        "kodeKABUPATEN": 5304,
        "namaKECAMATAN": "KOTA SOE"
      },
      {
        "kodeKECAMATAN": 5304040,
        "kodeKABUPATEN": 5304,
        "namaKECAMATAN": "AMANUBAN BARAT"
      },
      {
        "kodeKECAMATAN": 5304041,
        "kodeKABUPATEN": 5304,
        "namaKECAMATAN": "BATU PUTIH"
      },
      {
        "kodeKECAMATAN": 5304042,
        "kodeKABUPATEN": 5304,
        "namaKECAMATAN": "KUATNANA"
      },
      {
        "kodeKECAMATAN": 5304050,
        "kodeKABUPATEN": 5304,
        "namaKECAMATAN": "AMANUBAN SELATAN"
      },
      {
        "kodeKECAMATAN": 5304051,
        "kodeKABUPATEN": 5304,
        "namaKECAMATAN": "NOEBEBA"
      },
      {
        "kodeKECAMATAN": 5304060,
        "kodeKABUPATEN": 5304,
        "namaKECAMATAN": "KUAN FATU"
      },
      {
        "kodeKECAMATAN": 5304061,
        "kodeKABUPATEN": 5304,
        "namaKECAMATAN": "KUALIN"
      },
      {
        "kodeKECAMATAN": 5304070,
        "kodeKABUPATEN": 5304,
        "namaKECAMATAN": "AMANUBAN TENGAH"
      },
      {
        "kodeKECAMATAN": 5304071,
        "kodeKABUPATEN": 5304,
        "namaKECAMATAN": "KOLBANO"
      },
      {
        "kodeKECAMATAN": 5304072,
        "kodeKABUPATEN": 5304,
        "namaKECAMATAN": "OENINO"
      },
      {
        "kodeKECAMATAN": 5304080,
        "kodeKABUPATEN": 5304,
        "namaKECAMATAN": "AMANUBAN TIMUR"
      },
      {
        "kodeKECAMATAN": 5304081,
        "kodeKABUPATEN": 5304,
        "namaKECAMATAN": "FAUTMOLO"
      },
      {
        "kodeKECAMATAN": 5304082,
        "kodeKABUPATEN": 5304,
        "namaKECAMATAN": "FATUKOPA"
      },
      {
        "kodeKECAMATAN": 5304090,
        "kodeKABUPATEN": 5304,
        "namaKECAMATAN": "KIE"
      },
      {
        "kodeKECAMATAN": 5304091,
        "kodeKABUPATEN": 5304,
        "namaKECAMATAN": "KOT'OLIN"
      },
      {
        "kodeKECAMATAN": 5304100,
        "kodeKABUPATEN": 5304,
        "namaKECAMATAN": "AMANATUN SELATAN"
      },
      {
        "kodeKECAMATAN": 5304101,
        "kodeKABUPATEN": 5304,
        "namaKECAMATAN": "BOKING"
      },
      {
        "kodeKECAMATAN": 5304102,
        "kodeKABUPATEN": 5304,
        "namaKECAMATAN": "NUNKOLO"
      },
      {
        "kodeKECAMATAN": 5304103,
        "kodeKABUPATEN": 5304,
        "namaKECAMATAN": "NOEBANA"
      },
      {
        "kodeKECAMATAN": 5304104,
        "kodeKABUPATEN": 5304,
        "namaKECAMATAN": "SANTIAN"
      },
      {
        "kodeKECAMATAN": 5304110,
        "kodeKABUPATEN": 5304,
        "namaKECAMATAN": "AMANATUN UTARA"
      },
      {
        "kodeKECAMATAN": 5304111,
        "kodeKABUPATEN": 5304,
        "namaKECAMATAN": "TOIANAS"
      },
      {
        "kodeKECAMATAN": 5304112,
        "kodeKABUPATEN": 5304,
        "namaKECAMATAN": "KOKBAUN"
      },
      {
        "kodeKECAMATAN": 5305010,
        "kodeKABUPATEN": 5305,
        "namaKECAMATAN": "MIOMAFFO BARAT"
      },
      {
        "kodeKECAMATAN": 5305011,
        "kodeKABUPATEN": 5305,
        "namaKECAMATAN": "MIOMAFFO TENGAH"
      },
      {
        "kodeKECAMATAN": 5305012,
        "kodeKABUPATEN": 5305,
        "namaKECAMATAN": "MUSI"
      },
      {
        "kodeKECAMATAN": 5305013,
        "kodeKABUPATEN": 5305,
        "namaKECAMATAN": "MUTIS"
      },
      {
        "kodeKECAMATAN": 5305020,
        "kodeKABUPATEN": 5305,
        "namaKECAMATAN": "MIOMAFFO TIMUR"
      },
      {
        "kodeKECAMATAN": 5305021,
        "kodeKABUPATEN": 5305,
        "namaKECAMATAN": "NOEMUTI"
      },
      {
        "kodeKECAMATAN": 5305022,
        "kodeKABUPATEN": 5305,
        "namaKECAMATAN": "BIKOMI SELATAN"
      },
      {
        "kodeKECAMATAN": 5305023,
        "kodeKABUPATEN": 5305,
        "namaKECAMATAN": "BIKOMI TENGAH"
      },
      {
        "kodeKECAMATAN": 5305024,
        "kodeKABUPATEN": 5305,
        "namaKECAMATAN": "BIKOMI NILULAT"
      },
      {
        "kodeKECAMATAN": 5305025,
        "kodeKABUPATEN": 5305,
        "namaKECAMATAN": "BIKOMI UTARA"
      },
      {
        "kodeKECAMATAN": 5305026,
        "kodeKABUPATEN": 5305,
        "namaKECAMATAN": "NAIBENU"
      },
      {
        "kodeKECAMATAN": 5305027,
        "kodeKABUPATEN": 5305,
        "namaKECAMATAN": "NOEMUTI TIMUR"
      },
      {
        "kodeKECAMATAN": 5305030,
        "kodeKABUPATEN": 5305,
        "namaKECAMATAN": "KOTA KEFAMENANU"
      },
      {
        "kodeKECAMATAN": 5305040,
        "kodeKABUPATEN": 5305,
        "namaKECAMATAN": "INSANA"
      },
      {
        "kodeKECAMATAN": 5305041,
        "kodeKABUPATEN": 5305,
        "namaKECAMATAN": "INSANA UTARA"
      },
      {
        "kodeKECAMATAN": 5305042,
        "kodeKABUPATEN": 5305,
        "namaKECAMATAN": "INSANA BARAT"
      },
      {
        "kodeKECAMATAN": 5305043,
        "kodeKABUPATEN": 5305,
        "namaKECAMATAN": "INSANA TENGAH"
      },
      {
        "kodeKECAMATAN": 5305044,
        "kodeKABUPATEN": 5305,
        "namaKECAMATAN": "INSANA FAFINESU"
      },
      {
        "kodeKECAMATAN": 5305050,
        "kodeKABUPATEN": 5305,
        "namaKECAMATAN": "BIBOKI SELATAN"
      },
      {
        "kodeKECAMATAN": 5305051,
        "kodeKABUPATEN": 5305,
        "namaKECAMATAN": "BIBOKI TANPAH"
      },
      {
        "kodeKECAMATAN": 5305052,
        "kodeKABUPATEN": 5305,
        "namaKECAMATAN": "BIBOKI MOENLEU"
      },
      {
        "kodeKECAMATAN": 5305060,
        "kodeKABUPATEN": 5305,
        "namaKECAMATAN": "BIBOKI UTARA"
      },
      {
        "kodeKECAMATAN": 5305061,
        "kodeKABUPATEN": 5305,
        "namaKECAMATAN": "BIBOKI ANLEU"
      },
      {
        "kodeKECAMATAN": 5305062,
        "kodeKABUPATEN": 5305,
        "namaKECAMATAN": "BIBOKI FEOTLEU"
      },
      {
        "kodeKECAMATAN": 5306032,
        "kodeKABUPATEN": 5306,
        "namaKECAMATAN": "RAI MANUK"
      },
      {
        "kodeKECAMATAN": 5306050,
        "kodeKABUPATEN": 5306,
        "namaKECAMATAN": "TASIFETO BARAT"
      },
      {
        "kodeKECAMATAN": 5306051,
        "kodeKABUPATEN": 5306,
        "namaKECAMATAN": "KAKULUK MESAK"
      },
      {
        "kodeKECAMATAN": 5306052,
        "kodeKABUPATEN": 5306,
        "namaKECAMATAN": "NANAET DUBESI"
      },
      {
        "kodeKECAMATAN": 5306060,
        "kodeKABUPATEN": 5306,
        "namaKECAMATAN": "ATAMBUA"
      },
      {
        "kodeKECAMATAN": 5306061,
        "kodeKABUPATEN": 5306,
        "namaKECAMATAN": "ATAMBUA BARAT"
      },
      {
        "kodeKECAMATAN": 5306062,
        "kodeKABUPATEN": 5306,
        "namaKECAMATAN": "ATAMBUA SELATAN"
      },
      {
        "kodeKECAMATAN": 5306070,
        "kodeKABUPATEN": 5306,
        "namaKECAMATAN": "TASIFETO TIMUR"
      },
      {
        "kodeKECAMATAN": 5306071,
        "kodeKABUPATEN": 5306,
        "namaKECAMATAN": "RAIHAT"
      },
      {
        "kodeKECAMATAN": 5306072,
        "kodeKABUPATEN": 5306,
        "namaKECAMATAN": "LASIOLAT"
      },
      {
        "kodeKECAMATAN": 5306080,
        "kodeKABUPATEN": 5306,
        "namaKECAMATAN": "LAMAKNEN"
      },
      {
        "kodeKECAMATAN": 5306081,
        "kodeKABUPATEN": 5306,
        "namaKECAMATAN": "LAMAKNEN SELATAN"
      },
      {
        "kodeKECAMATAN": 5307010,
        "kodeKABUPATEN": 5307,
        "namaKECAMATAN": "PANTAR"
      },
      {
        "kodeKECAMATAN": 5307011,
        "kodeKABUPATEN": 5307,
        "namaKECAMATAN": "PANTAR BARAT"
      },
      {
        "kodeKECAMATAN": 5307012,
        "kodeKABUPATEN": 5307,
        "namaKECAMATAN": "PANTAR TIMUR"
      },
      {
        "kodeKECAMATAN": 5307013,
        "kodeKABUPATEN": 5307,
        "namaKECAMATAN": "PANTAR BARAT LAUT"
      },
      {
        "kodeKECAMATAN": 5307014,
        "kodeKABUPATEN": 5307,
        "namaKECAMATAN": "PANTAR TENGAH"
      },
      {
        "kodeKECAMATAN": 5307020,
        "kodeKABUPATEN": 5307,
        "namaKECAMATAN": "ALOR BARAT DAYA"
      },
      {
        "kodeKECAMATAN": 5307021,
        "kodeKABUPATEN": 5307,
        "namaKECAMATAN": "MATARU"
      },
      {
        "kodeKECAMATAN": 5307030,
        "kodeKABUPATEN": 5307,
        "namaKECAMATAN": "ALOR SELATAN"
      },
      {
        "kodeKECAMATAN": 5307040,
        "kodeKABUPATEN": 5307,
        "namaKECAMATAN": "ALOR TIMUR"
      },
      {
        "kodeKECAMATAN": 5307041,
        "kodeKABUPATEN": 5307,
        "namaKECAMATAN": "ALOR TIMUR LAUT"
      },
      {
        "kodeKECAMATAN": 5307042,
        "kodeKABUPATEN": 5307,
        "namaKECAMATAN": "PUREMAN"
      },
      {
        "kodeKECAMATAN": 5307050,
        "kodeKABUPATEN": 5307,
        "namaKECAMATAN": "TELUK MUTIARA"
      },
      {
        "kodeKECAMATAN": 5307051,
        "kodeKABUPATEN": 5307,
        "namaKECAMATAN": "KABOLA"
      },
      {
        "kodeKECAMATAN": 5307060,
        "kodeKABUPATEN": 5307,
        "namaKECAMATAN": "ALOR BARAT LAUT"
      },
      {
        "kodeKECAMATAN": 5307061,
        "kodeKABUPATEN": 5307,
        "namaKECAMATAN": "ALOR TENGAH UTARA"
      },
      {
        "kodeKECAMATAN": 5307062,
        "kodeKABUPATEN": 5307,
        "namaKECAMATAN": "PULAU PURA"
      },
      {
        "kodeKECAMATAN": 5307063,
        "kodeKABUPATEN": 5307,
        "namaKECAMATAN": "LEMBUR"
      },
      {
        "kodeKECAMATAN": 5308010,
        "kodeKABUPATEN": 5308,
        "namaKECAMATAN": "NAGAWUTUNG"
      },
      {
        "kodeKECAMATAN": 5308011,
        "kodeKABUPATEN": 5308,
        "namaKECAMATAN": "WULANDONI"
      },
      {
        "kodeKECAMATAN": 5308020,
        "kodeKABUPATEN": 5308,
        "namaKECAMATAN": "ATADEI"
      },
      {
        "kodeKECAMATAN": 5308030,
        "kodeKABUPATEN": 5308,
        "namaKECAMATAN": "ILE APE"
      },
      {
        "kodeKECAMATAN": 5308031,
        "kodeKABUPATEN": 5308,
        "namaKECAMATAN": "ILE APE TIMUR"
      },
      {
        "kodeKECAMATAN": 5308040,
        "kodeKABUPATEN": 5308,
        "namaKECAMATAN": "LEBATUKAN"
      },
      {
        "kodeKECAMATAN": 5308050,
        "kodeKABUPATEN": 5308,
        "namaKECAMATAN": "NUBATUKAN"
      },
      {
        "kodeKECAMATAN": 5308060,
        "kodeKABUPATEN": 5308,
        "namaKECAMATAN": "OMESURI"
      },
      {
        "kodeKECAMATAN": 5308070,
        "kodeKABUPATEN": 5308,
        "namaKECAMATAN": "BUYASARI"
      },
      {
        "kodeKECAMATAN": 5309010,
        "kodeKABUPATEN": 5309,
        "namaKECAMATAN": "WULANGGITANG"
      },
      {
        "kodeKECAMATAN": 5309011,
        "kodeKABUPATEN": 5309,
        "namaKECAMATAN": "TITEHENA"
      },
      {
        "kodeKECAMATAN": 5309012,
        "kodeKABUPATEN": 5309,
        "namaKECAMATAN": "ILEBURA"
      },
      {
        "kodeKECAMATAN": 5309020,
        "kodeKABUPATEN": 5309,
        "namaKECAMATAN": "TANJUNG BUNGA"
      },
      {
        "kodeKECAMATAN": 5309021,
        "kodeKABUPATEN": 5309,
        "namaKECAMATAN": "LEWO LEMA"
      },
      {
        "kodeKECAMATAN": 5309030,
        "kodeKABUPATEN": 5309,
        "namaKECAMATAN": "LARANTUKA"
      },
      {
        "kodeKECAMATAN": 5309031,
        "kodeKABUPATEN": 5309,
        "namaKECAMATAN": "ILE MANDIRI"
      },
      {
        "kodeKECAMATAN": 5309032,
        "kodeKABUPATEN": 5309,
        "namaKECAMATAN": "DEMON PAGONG"
      },
      {
        "kodeKECAMATAN": 5309040,
        "kodeKABUPATEN": 5309,
        "namaKECAMATAN": "SOLOR BARAT"
      },
      {
        "kodeKECAMATAN": 5309041,
        "kodeKABUPATEN": 5309,
        "namaKECAMATAN": "SOLOR SELATAN"
      },
      {
        "kodeKECAMATAN": 5309050,
        "kodeKABUPATEN": 5309,
        "namaKECAMATAN": "SOLOR TIMUR"
      },
      {
        "kodeKECAMATAN": 5309060,
        "kodeKABUPATEN": 5309,
        "namaKECAMATAN": "ADONARA BARAT"
      },
      {
        "kodeKECAMATAN": 5309061,
        "kodeKABUPATEN": 5309,
        "namaKECAMATAN": "WOTAN ULU MADO"
      },
      {
        "kodeKECAMATAN": 5309062,
        "kodeKABUPATEN": 5309,
        "namaKECAMATAN": "ADONARA TENGAH"
      },
      {
        "kodeKECAMATAN": 5309070,
        "kodeKABUPATEN": 5309,
        "namaKECAMATAN": "ADONARA TIMUR"
      },
      {
        "kodeKECAMATAN": 5309071,
        "kodeKABUPATEN": 5309,
        "namaKECAMATAN": "ILE BOLENG"
      },
      {
        "kodeKECAMATAN": 5309072,
        "kodeKABUPATEN": 5309,
        "namaKECAMATAN": "WITIHAMA"
      },
      {
        "kodeKECAMATAN": 5309073,
        "kodeKABUPATEN": 5309,
        "namaKECAMATAN": "KELUBAGOLIT"
      },
      {
        "kodeKECAMATAN": 5309074,
        "kodeKABUPATEN": 5309,
        "namaKECAMATAN": "ADONARA"
      },
      {
        "kodeKECAMATAN": 5310010,
        "kodeKABUPATEN": 5310,
        "namaKECAMATAN": "PAGA"
      },
      {
        "kodeKECAMATAN": 5310011,
        "kodeKABUPATEN": 5310,
        "namaKECAMATAN": "MEGO"
      },
      {
        "kodeKECAMATAN": 5310012,
        "kodeKABUPATEN": 5310,
        "namaKECAMATAN": "TANA WAWO"
      },
      {
        "kodeKECAMATAN": 5310020,
        "kodeKABUPATEN": 5310,
        "namaKECAMATAN": "LELA"
      },
      {
        "kodeKECAMATAN": 5310030,
        "kodeKABUPATEN": 5310,
        "namaKECAMATAN": "BOLA"
      },
      {
        "kodeKECAMATAN": 5310031,
        "kodeKABUPATEN": 5310,
        "namaKECAMATAN": "DORENG"
      },
      {
        "kodeKECAMATAN": 5310032,
        "kodeKABUPATEN": 5310,
        "namaKECAMATAN": "MAPITARA"
      },
      {
        "kodeKECAMATAN": 5310040,
        "kodeKABUPATEN": 5310,
        "namaKECAMATAN": "TALIBURA"
      },
      {
        "kodeKECAMATAN": 5310041,
        "kodeKABUPATEN": 5310,
        "namaKECAMATAN": "WAIGETE"
      },
      {
        "kodeKECAMATAN": 5310042,
        "kodeKABUPATEN": 5310,
        "namaKECAMATAN": "WAIBLAMA"
      },
      {
        "kodeKECAMATAN": 5310050,
        "kodeKABUPATEN": 5310,
        "namaKECAMATAN": "KEWAPANTE"
      },
      {
        "kodeKECAMATAN": 5310051,
        "kodeKABUPATEN": 5310,
        "namaKECAMATAN": "HEWOKLOANG"
      },
      {
        "kodeKECAMATAN": 5310052,
        "kodeKABUPATEN": 5310,
        "namaKECAMATAN": "KANGAE"
      },
      {
        "kodeKECAMATAN": 5310061,
        "kodeKABUPATEN": 5310,
        "namaKECAMATAN": "PALUE"
      },
      {
        "kodeKECAMATAN": 5310062,
        "kodeKABUPATEN": 5310,
        "namaKECAMATAN": "KOTING"
      },
      {
        "kodeKECAMATAN": 5310063,
        "kodeKABUPATEN": 5310,
        "namaKECAMATAN": "NELLE"
      },
      {
        "kodeKECAMATAN": 5310070,
        "kodeKABUPATEN": 5310,
        "namaKECAMATAN": "NITA"
      },
      {
        "kodeKECAMATAN": 5310071,
        "kodeKABUPATEN": 5310,
        "namaKECAMATAN": "MAGEPANDA"
      },
      {
        "kodeKECAMATAN": 5310080,
        "kodeKABUPATEN": 5310,
        "namaKECAMATAN": "ALOK"
      },
      {
        "kodeKECAMATAN": 5310081,
        "kodeKABUPATEN": 5310,
        "namaKECAMATAN": "ALOK BARAT"
      },
      {
        "kodeKECAMATAN": 5310082,
        "kodeKABUPATEN": 5310,
        "namaKECAMATAN": "ALOK TIMUR"
      },
      {
        "kodeKECAMATAN": 5311010,
        "kodeKABUPATEN": 5311,
        "namaKECAMATAN": "NANGAPANDA"
      },
      {
        "kodeKECAMATAN": 5311011,
        "kodeKABUPATEN": 5311,
        "namaKECAMATAN": "PULAU ENDE"
      },
      {
        "kodeKECAMATAN": 5311012,
        "kodeKABUPATEN": 5311,
        "namaKECAMATAN": "MAUKARO"
      },
      {
        "kodeKECAMATAN": 5311020,
        "kodeKABUPATEN": 5311,
        "namaKECAMATAN": "ENDE"
      },
      {
        "kodeKECAMATAN": 5311030,
        "kodeKABUPATEN": 5311,
        "namaKECAMATAN": "ENDE SELATAN"
      },
      {
        "kodeKECAMATAN": 5311031,
        "kodeKABUPATEN": 5311,
        "namaKECAMATAN": "ENDE TIMUR"
      },
      {
        "kodeKECAMATAN": 5311032,
        "kodeKABUPATEN": 5311,
        "namaKECAMATAN": "ENDE TENGAH"
      },
      {
        "kodeKECAMATAN": 5311033,
        "kodeKABUPATEN": 5311,
        "namaKECAMATAN": "ENDE UTARA"
      },
      {
        "kodeKECAMATAN": 5311040,
        "kodeKABUPATEN": 5311,
        "namaKECAMATAN": "NDONA"
      },
      {
        "kodeKECAMATAN": 5311041,
        "kodeKABUPATEN": 5311,
        "namaKECAMATAN": "NDONA TIMUR"
      },
      {
        "kodeKECAMATAN": 5311050,
        "kodeKABUPATEN": 5311,
        "namaKECAMATAN": "WOLOWARU"
      },
      {
        "kodeKECAMATAN": 5311051,
        "kodeKABUPATEN": 5311,
        "namaKECAMATAN": "WOLOJITA"
      },
      {
        "kodeKECAMATAN": 5311052,
        "kodeKABUPATEN": 5311,
        "namaKECAMATAN": "LIO TIMUR"
      },
      {
        "kodeKECAMATAN": 5311053,
        "kodeKABUPATEN": 5311,
        "namaKECAMATAN": "KELIMUTU"
      },
      {
        "kodeKECAMATAN": 5311054,
        "kodeKABUPATEN": 5311,
        "namaKECAMATAN": "NDORI"
      },
      {
        "kodeKECAMATAN": 5311060,
        "kodeKABUPATEN": 5311,
        "namaKECAMATAN": "MAUROLE"
      },
      {
        "kodeKECAMATAN": 5311061,
        "kodeKABUPATEN": 5311,
        "namaKECAMATAN": "KOTABARU"
      },
      {
        "kodeKECAMATAN": 5311062,
        "kodeKABUPATEN": 5311,
        "namaKECAMATAN": "DETUKELI"
      },
      {
        "kodeKECAMATAN": 5311063,
        "kodeKABUPATEN": 5311,
        "namaKECAMATAN": "LEPEMBUSU KELISOKE"
      },
      {
        "kodeKECAMATAN": 5311070,
        "kodeKABUPATEN": 5311,
        "namaKECAMATAN": "DETUSOKO"
      },
      {
        "kodeKECAMATAN": 5311071,
        "kodeKABUPATEN": 5311,
        "namaKECAMATAN": "WEWARIA"
      },
      {
        "kodeKECAMATAN": 5312010,
        "kodeKABUPATEN": 5312,
        "namaKECAMATAN": "AIMERE"
      },
      {
        "kodeKECAMATAN": 5312011,
        "kodeKABUPATEN": 5312,
        "namaKECAMATAN": "JEREBUU"
      },
      {
        "kodeKECAMATAN": 5312012,
        "kodeKABUPATEN": 5312,
        "namaKECAMATAN": "INERIE"
      },
      {
        "kodeKECAMATAN": 5312020,
        "kodeKABUPATEN": 5312,
        "namaKECAMATAN": "BAJAWA"
      },
      {
        "kodeKECAMATAN": 5312030,
        "kodeKABUPATEN": 5312,
        "namaKECAMATAN": "GOLEWA"
      },
      {
        "kodeKECAMATAN": 5312031,
        "kodeKABUPATEN": 5312,
        "namaKECAMATAN": "GOLEWA SELATAN"
      },
      {
        "kodeKECAMATAN": 5312032,
        "kodeKABUPATEN": 5312,
        "namaKECAMATAN": "GOLEWA BARAT"
      },
      {
        "kodeKECAMATAN": 5312070,
        "kodeKABUPATEN": 5312,
        "namaKECAMATAN": "BAJAWA UTARA"
      },
      {
        "kodeKECAMATAN": 5312071,
        "kodeKABUPATEN": 5312,
        "namaKECAMATAN": "SOA"
      },
      {
        "kodeKECAMATAN": 5312080,
        "kodeKABUPATEN": 5312,
        "namaKECAMATAN": "RIUNG"
      },
      {
        "kodeKECAMATAN": 5312081,
        "kodeKABUPATEN": 5312,
        "namaKECAMATAN": "RIUNG BARAT"
      },
      {
        "kodeKECAMATAN": 5312082,
        "kodeKABUPATEN": 5312,
        "namaKECAMATAN": "WOLOMEZE"
      },
      {
        "kodeKECAMATAN": 5313040,
        "kodeKABUPATEN": 5313,
        "namaKECAMATAN": "SATAR MESE"
      },
      {
        "kodeKECAMATAN": 5313041,
        "kodeKABUPATEN": 5313,
        "namaKECAMATAN": "SATAR MESE BARAT"
      },
      {
        "kodeKECAMATAN": 5313110,
        "kodeKABUPATEN": 5313,
        "namaKECAMATAN": "LANGKE REMBONG"
      },
      {
        "kodeKECAMATAN": 5313120,
        "kodeKABUPATEN": 5313,
        "namaKECAMATAN": "RUTENG"
      },
      {
        "kodeKECAMATAN": 5313121,
        "kodeKABUPATEN": 5313,
        "namaKECAMATAN": "WAE RII"
      },
      {
        "kodeKECAMATAN": 5313122,
        "kodeKABUPATEN": 5313,
        "namaKECAMATAN": "LELAK"
      },
      {
        "kodeKECAMATAN": 5313123,
        "kodeKABUPATEN": 5313,
        "namaKECAMATAN": "RAHONG UTARA"
      },
      {
        "kodeKECAMATAN": 5313130,
        "kodeKABUPATEN": 5313,
        "namaKECAMATAN": "CIBAL"
      },
      {
        "kodeKECAMATAN": 5313131,
        "kodeKABUPATEN": 5313,
        "namaKECAMATAN": "CIBAL BARAT"
      },
      {
        "kodeKECAMATAN": 5313140,
        "kodeKABUPATEN": 5313,
        "namaKECAMATAN": "REOK"
      },
      {
        "kodeKECAMATAN": 5313141,
        "kodeKABUPATEN": 5313,
        "namaKECAMATAN": "REOK BARAT"
      },
      {
        "kodeKECAMATAN": 5314010,
        "kodeKABUPATEN": 5314,
        "namaKECAMATAN": "ROTE BARAT DAYA"
      },
      {
        "kodeKECAMATAN": 5314020,
        "kodeKABUPATEN": 5314,
        "namaKECAMATAN": "ROTE BARAT LAUT"
      },
      {
        "kodeKECAMATAN": 5314030,
        "kodeKABUPATEN": 5314,
        "namaKECAMATAN": "LOBALAIN"
      },
      {
        "kodeKECAMATAN": 5314040,
        "kodeKABUPATEN": 5314,
        "namaKECAMATAN": "ROTE TENGAH"
      },
      {
        "kodeKECAMATAN": 5314041,
        "kodeKABUPATEN": 5314,
        "namaKECAMATAN": "ROTE SELATAN"
      },
      {
        "kodeKECAMATAN": 5314050,
        "kodeKABUPATEN": 5314,
        "namaKECAMATAN": "PANTAI BARU"
      },
      {
        "kodeKECAMATAN": 5314060,
        "kodeKABUPATEN": 5314,
        "namaKECAMATAN": "ROTE TIMUR"
      },
      {
        "kodeKECAMATAN": 5314061,
        "kodeKABUPATEN": 5314,
        "namaKECAMATAN": "LANDU LEKO"
      },
      {
        "kodeKECAMATAN": 5314070,
        "kodeKABUPATEN": 5314,
        "namaKECAMATAN": "ROTE BARAT"
      },
      {
        "kodeKECAMATAN": 5314071,
        "kodeKABUPATEN": 5314,
        "namaKECAMATAN": "NDAO NUSE"
      },
      {
        "kodeKECAMATAN": 5315010,
        "kodeKABUPATEN": 5315,
        "namaKECAMATAN": "KOMODO"
      },
      {
        "kodeKECAMATAN": 5315011,
        "kodeKABUPATEN": 5315,
        "namaKECAMATAN": "BOLENG"
      },
      {
        "kodeKECAMATAN": 5315020,
        "kodeKABUPATEN": 5315,
        "namaKECAMATAN": "SANO NGGOANG"
      },
      {
        "kodeKECAMATAN": 5315021,
        "kodeKABUPATEN": 5315,
        "namaKECAMATAN": "MBELILING"
      },
      {
        "kodeKECAMATAN": 5315030,
        "kodeKABUPATEN": 5315,
        "namaKECAMATAN": "LEMBOR"
      },
      {
        "kodeKECAMATAN": 5315031,
        "kodeKABUPATEN": 5315,
        "namaKECAMATAN": "WELAK"
      },
      {
        "kodeKECAMATAN": 5315032,
        "kodeKABUPATEN": 5315,
        "namaKECAMATAN": "LEMBOR SELATAN"
      },
      {
        "kodeKECAMATAN": 5315040,
        "kodeKABUPATEN": 5315,
        "namaKECAMATAN": "KUWUS"
      },
      {
        "kodeKECAMATAN": 5315041,
        "kodeKABUPATEN": 5315,
        "namaKECAMATAN": "NDOSO"
      },
      {
        "kodeKECAMATAN": 5315050,
        "kodeKABUPATEN": 5315,
        "namaKECAMATAN": "MACANG PACAR"
      },
      {
        "kodeKECAMATAN": 5316010,
        "kodeKABUPATEN": 5316,
        "namaKECAMATAN": "KATIKUTANA"
      },
      {
        "kodeKECAMATAN": 5316011,
        "kodeKABUPATEN": 5316,
        "namaKECAMATAN": "KATIKUTANA SELATAN"
      },
      {
        "kodeKECAMATAN": 5316020,
        "kodeKABUPATEN": 5316,
        "namaKECAMATAN": "UMBU RATU NGGAY BARAT"
      },
      {
        "kodeKECAMATAN": 5316030,
        "kodeKABUPATEN": 5316,
        "namaKECAMATAN": "UMBU RATU NGGAY"
      },
      {
        "kodeKECAMATAN": 5316040,
        "kodeKABUPATEN": 5316,
        "namaKECAMATAN": "MAMBORO"
      },
      {
        "kodeKECAMATAN": 5317010,
        "kodeKABUPATEN": 5317,
        "namaKECAMATAN": "KODI BANGEDO"
      },
      {
        "kodeKECAMATAN": 5317011,
        "kodeKABUPATEN": 5317,
        "namaKECAMATAN": "KODI BALAGHAR"
      },
      {
        "kodeKECAMATAN": 5317020,
        "kodeKABUPATEN": 5317,
        "namaKECAMATAN": "KODI"
      },
      {
        "kodeKECAMATAN": 5317030,
        "kodeKABUPATEN": 5317,
        "namaKECAMATAN": "KODI UTARA"
      },
      {
        "kodeKECAMATAN": 5317040,
        "kodeKABUPATEN": 5317,
        "namaKECAMATAN": "WEWEWA SELATAN"
      },
      {
        "kodeKECAMATAN": 5317050,
        "kodeKABUPATEN": 5317,
        "namaKECAMATAN": "WEWEWA BARAT"
      },
      {
        "kodeKECAMATAN": 5317060,
        "kodeKABUPATEN": 5317,
        "namaKECAMATAN": "WEWEWA TIMUR"
      },
      {
        "kodeKECAMATAN": 5317061,
        "kodeKABUPATEN": 5317,
        "namaKECAMATAN": "WEWEWA TENGAH"
      },
      {
        "kodeKECAMATAN": 5317070,
        "kodeKABUPATEN": 5317,
        "namaKECAMATAN": "WEWEWA UTARA"
      },
      {
        "kodeKECAMATAN": 5317080,
        "kodeKABUPATEN": 5317,
        "namaKECAMATAN": "LOURA"
      },
      {
        "kodeKECAMATAN": 5317081,
        "kodeKABUPATEN": 5317,
        "namaKECAMATAN": "KOTA TAMBOLAKA"
      },
      {
        "kodeKECAMATAN": 5318010,
        "kodeKABUPATEN": 5318,
        "namaKECAMATAN": "MAUPONGGO"
      },
      {
        "kodeKECAMATAN": 5318020,
        "kodeKABUPATEN": 5318,
        "namaKECAMATAN": "KEO TENGAH"
      },
      {
        "kodeKECAMATAN": 5318030,
        "kodeKABUPATEN": 5318,
        "namaKECAMATAN": "NANGARORO"
      },
      {
        "kodeKECAMATAN": 5318040,
        "kodeKABUPATEN": 5318,
        "namaKECAMATAN": "BOAWAE"
      },
      {
        "kodeKECAMATAN": 5318050,
        "kodeKABUPATEN": 5318,
        "namaKECAMATAN": "AESESA SELATAN"
      },
      {
        "kodeKECAMATAN": 5318060,
        "kodeKABUPATEN": 5318,
        "namaKECAMATAN": "AESESA"
      },
      {
        "kodeKECAMATAN": 5318070,
        "kodeKABUPATEN": 5318,
        "namaKECAMATAN": "WOLOWAE"
      },
      {
        "kodeKECAMATAN": 5319010,
        "kodeKABUPATEN": 5319,
        "namaKECAMATAN": "BORONG"
      },
      {
        "kodeKECAMATAN": 5319011,
        "kodeKABUPATEN": 5319,
        "namaKECAMATAN": "RANA MESE"
      },
      {
        "kodeKECAMATAN": 5319020,
        "kodeKABUPATEN": 5319,
        "namaKECAMATAN": "KOTA KOMBA"
      },
      {
        "kodeKECAMATAN": 5319030,
        "kodeKABUPATEN": 5319,
        "namaKECAMATAN": "ELAR"
      },
      {
        "kodeKECAMATAN": 5319031,
        "kodeKABUPATEN": 5319,
        "namaKECAMATAN": "ELAR SELATAN"
      },
      {
        "kodeKECAMATAN": 5319040,
        "kodeKABUPATEN": 5319,
        "namaKECAMATAN": "SAMBI RAMPAS"
      },
      {
        "kodeKECAMATAN": 5319050,
        "kodeKABUPATEN": 5319,
        "namaKECAMATAN": "POCO RANAKA"
      },
      {
        "kodeKECAMATAN": 5319051,
        "kodeKABUPATEN": 5319,
        "namaKECAMATAN": "POCO RANAKA TIMUR"
      },
      {
        "kodeKECAMATAN": 5319060,
        "kodeKABUPATEN": 5319,
        "namaKECAMATAN": "LAMBA LEDA"
      },
      {
        "kodeKECAMATAN": 5320010,
        "kodeKABUPATEN": 5320,
        "namaKECAMATAN": "RAIJUA"
      },
      {
        "kodeKECAMATAN": 5320020,
        "kodeKABUPATEN": 5320,
        "namaKECAMATAN": "HAWU MEHARA"
      },
      {
        "kodeKECAMATAN": 5320030,
        "kodeKABUPATEN": 5320,
        "namaKECAMATAN": "SABU LIAE"
      },
      {
        "kodeKECAMATAN": 5320040,
        "kodeKABUPATEN": 5320,
        "namaKECAMATAN": "SABU BARAT"
      },
      {
        "kodeKECAMATAN": 5320050,
        "kodeKABUPATEN": 5320,
        "namaKECAMATAN": "SABU TENGAH"
      },
      {
        "kodeKECAMATAN": 5320060,
        "kodeKABUPATEN": 5320,
        "namaKECAMATAN": "SABU TIMUR"
      },
      {
        "kodeKECAMATAN": 5321010,
        "kodeKABUPATEN": 5321,
        "namaKECAMATAN": "WEWIKU"
      },
      {
        "kodeKECAMATAN": 5321020,
        "kodeKABUPATEN": 5321,
        "namaKECAMATAN": "MALAKA BARAT"
      },
      {
        "kodeKECAMATAN": 5321030,
        "kodeKABUPATEN": 5321,
        "namaKECAMATAN": "WELIMAN"
      },
      {
        "kodeKECAMATAN": 5321040,
        "kodeKABUPATEN": 5321,
        "namaKECAMATAN": "RINHAT"
      },
      {
        "kodeKECAMATAN": 5321050,
        "kodeKABUPATEN": 5321,
        "namaKECAMATAN": "IO KUFEU"
      },
      {
        "kodeKECAMATAN": 5321060,
        "kodeKABUPATEN": 5321,
        "namaKECAMATAN": "SASITA MEAN"
      },
      {
        "kodeKECAMATAN": 5321070,
        "kodeKABUPATEN": 5321,
        "namaKECAMATAN": "MALAKA TENGAH"
      },
      {
        "kodeKECAMATAN": 5321080,
        "kodeKABUPATEN": 5321,
        "namaKECAMATAN": "BOTIN LEOBELE"
      },
      {
        "kodeKECAMATAN": 5321090,
        "kodeKABUPATEN": 5321,
        "namaKECAMATAN": "LAEN MANEN"
      },
      {
        "kodeKECAMATAN": 5321100,
        "kodeKABUPATEN": 5321,
        "namaKECAMATAN": "MALAKA TIMUR"
      },
      {
        "kodeKECAMATAN": 5321110,
        "kodeKABUPATEN": 5321,
        "namaKECAMATAN": "KOBALIMA"
      },
      {
        "kodeKECAMATAN": 5321120,
        "kodeKABUPATEN": 5321,
        "namaKECAMATAN": "KOBALIMA TIMUR"
      },
      {
        "kodeKECAMATAN": 5371010,
        "kodeKABUPATEN": 5371,
        "namaKECAMATAN": "ALAK"
      },
      {
        "kodeKECAMATAN": 5371020,
        "kodeKABUPATEN": 5371,
        "namaKECAMATAN": "MAULAFA"
      },
      {
        "kodeKECAMATAN": 5371030,
        "kodeKABUPATEN": 5371,
        "namaKECAMATAN": "OEBOBO"
      },
      {
        "kodeKECAMATAN": 5371031,
        "kodeKABUPATEN": 5371,
        "namaKECAMATAN": "KOTA RAJA"
      },
      {
        "kodeKECAMATAN": 5371040,
        "kodeKABUPATEN": 5371,
        "namaKECAMATAN": "KELAPA LIMA"
      },
      {
        "kodeKECAMATAN": 5371041,
        "kodeKABUPATEN": 5371,
        "namaKECAMATAN": "KOTA LAMA"
      },
      {
        "kodeKECAMATAN": 6101010,
        "kodeKABUPATEN": 6101,
        "namaKECAMATAN": "SELAKAU"
      },
      {
        "kodeKECAMATAN": 6101011,
        "kodeKABUPATEN": 6101,
        "namaKECAMATAN": "SELAKAU TIMUR"
      },
      {
        "kodeKECAMATAN": 6101020,
        "kodeKABUPATEN": 6101,
        "namaKECAMATAN": "PEMANGKAT"
      },
      {
        "kodeKECAMATAN": 6101021,
        "kodeKABUPATEN": 6101,
        "namaKECAMATAN": "SEMPARUK"
      },
      {
        "kodeKECAMATAN": 6101022,
        "kodeKABUPATEN": 6101,
        "namaKECAMATAN": "SALATIGA"
      },
      {
        "kodeKECAMATAN": 6101030,
        "kodeKABUPATEN": 6101,
        "namaKECAMATAN": "TEBAS"
      },
      {
        "kodeKECAMATAN": 6101031,
        "kodeKABUPATEN": 6101,
        "namaKECAMATAN": "TEKARANG"
      },
      {
        "kodeKECAMATAN": 6101040,
        "kodeKABUPATEN": 6101,
        "namaKECAMATAN": "SAMBAS"
      },
      {
        "kodeKECAMATAN": 6101041,
        "kodeKABUPATEN": 6101,
        "namaKECAMATAN": "SUBAH"
      },
      {
        "kodeKECAMATAN": 6101042,
        "kodeKABUPATEN": 6101,
        "namaKECAMATAN": "SEBAWI"
      },
      {
        "kodeKECAMATAN": 6101043,
        "kodeKABUPATEN": 6101,
        "namaKECAMATAN": "SAJAD"
      },
      {
        "kodeKECAMATAN": 6101050,
        "kodeKABUPATEN": 6101,
        "namaKECAMATAN": "JAWAI"
      },
      {
        "kodeKECAMATAN": 6101051,
        "kodeKABUPATEN": 6101,
        "namaKECAMATAN": "JAWAI SELATAN"
      },
      {
        "kodeKECAMATAN": 6101060,
        "kodeKABUPATEN": 6101,
        "namaKECAMATAN": "TELUK KERAMAT"
      },
      {
        "kodeKECAMATAN": 6101061,
        "kodeKABUPATEN": 6101,
        "namaKECAMATAN": "GALING"
      },
      {
        "kodeKECAMATAN": 6101062,
        "kodeKABUPATEN": 6101,
        "namaKECAMATAN": "TANGARAN"
      },
      {
        "kodeKECAMATAN": 6101070,
        "kodeKABUPATEN": 6101,
        "namaKECAMATAN": "SEJANGKUNG"
      },
      {
        "kodeKECAMATAN": 6101080,
        "kodeKABUPATEN": 6101,
        "namaKECAMATAN": "SAJINGAN BESAR"
      },
      {
        "kodeKECAMATAN": 6101090,
        "kodeKABUPATEN": 6101,
        "namaKECAMATAN": "PALOH"
      },
      {
        "kodeKECAMATAN": 6102010,
        "kodeKABUPATEN": 6102,
        "namaKECAMATAN": "SUNGAI RAYA"
      },
      {
        "kodeKECAMATAN": 6102011,
        "kodeKABUPATEN": 6102,
        "namaKECAMATAN": "CAPKALA"
      },
      {
        "kodeKECAMATAN": 6102012,
        "kodeKABUPATEN": 6102,
        "namaKECAMATAN": "SUNGAI RAYA KEPULAUAN"
      },
      {
        "kodeKECAMATAN": 6102030,
        "kodeKABUPATEN": 6102,
        "namaKECAMATAN": "SAMALANTAN"
      },
      {
        "kodeKECAMATAN": 6102031,
        "kodeKABUPATEN": 6102,
        "namaKECAMATAN": "MONTERADO"
      },
      {
        "kodeKECAMATAN": 6102032,
        "kodeKABUPATEN": 6102,
        "namaKECAMATAN": "LEMBAH BAWANG"
      },
      {
        "kodeKECAMATAN": 6102040,
        "kodeKABUPATEN": 6102,
        "namaKECAMATAN": "BENGKAYANG"
      },
      {
        "kodeKECAMATAN": 6102041,
        "kodeKABUPATEN": 6102,
        "namaKECAMATAN": "TERIAK"
      },
      {
        "kodeKECAMATAN": 6102042,
        "kodeKABUPATEN": 6102,
        "namaKECAMATAN": "SUNGAI BETUNG"
      },
      {
        "kodeKECAMATAN": 6102050,
        "kodeKABUPATEN": 6102,
        "namaKECAMATAN": "LEDO"
      },
      {
        "kodeKECAMATAN": 6102051,
        "kodeKABUPATEN": 6102,
        "namaKECAMATAN": "SUTI SEMARANG"
      },
      {
        "kodeKECAMATAN": 6102052,
        "kodeKABUPATEN": 6102,
        "namaKECAMATAN": "LUMAR"
      },
      {
        "kodeKECAMATAN": 6102060,
        "kodeKABUPATEN": 6102,
        "namaKECAMATAN": "SANGGAU LEDO"
      },
      {
        "kodeKECAMATAN": 6102061,
        "kodeKABUPATEN": 6102,
        "namaKECAMATAN": "TUJUHBELAS"
      },
      {
        "kodeKECAMATAN": 6102070,
        "kodeKABUPATEN": 6102,
        "namaKECAMATAN": "SELUAS"
      },
      {
        "kodeKECAMATAN": 6102080,
        "kodeKABUPATEN": 6102,
        "namaKECAMATAN": "JAGOI BABANG"
      },
      {
        "kodeKECAMATAN": 6102081,
        "kodeKABUPATEN": 6102,
        "namaKECAMATAN": "SIDING"
      },
      {
        "kodeKECAMATAN": 6103020,
        "kodeKABUPATEN": 6103,
        "namaKECAMATAN": "SEBANGKI"
      },
      {
        "kodeKECAMATAN": 6103030,
        "kodeKABUPATEN": 6103,
        "namaKECAMATAN": "NGABANG"
      },
      {
        "kodeKECAMATAN": 6103031,
        "kodeKABUPATEN": 6103,
        "namaKECAMATAN": "JELIMPO"
      },
      {
        "kodeKECAMATAN": 6103040,
        "kodeKABUPATEN": 6103,
        "namaKECAMATAN": "SENGAH TEMILA"
      },
      {
        "kodeKECAMATAN": 6103050,
        "kodeKABUPATEN": 6103,
        "namaKECAMATAN": "MANDOR"
      },
      {
        "kodeKECAMATAN": 6103060,
        "kodeKABUPATEN": 6103,
        "namaKECAMATAN": "MENJALIN"
      },
      {
        "kodeKECAMATAN": 6103070,
        "kodeKABUPATEN": 6103,
        "namaKECAMATAN": "MEMPAWAH HULU"
      },
      {
        "kodeKECAMATAN": 6103071,
        "kodeKABUPATEN": 6103,
        "namaKECAMATAN": "SOMPAK"
      },
      {
        "kodeKECAMATAN": 6103080,
        "kodeKABUPATEN": 6103,
        "namaKECAMATAN": "MENYUKE"
      },
      {
        "kodeKECAMATAN": 6103081,
        "kodeKABUPATEN": 6103,
        "namaKECAMATAN": "BANYUKE HULU"
      },
      {
        "kodeKECAMATAN": 6103090,
        "kodeKABUPATEN": 6103,
        "namaKECAMATAN": "MERANTI"
      },
      {
        "kodeKECAMATAN": 6103100,
        "kodeKABUPATEN": 6103,
        "namaKECAMATAN": "KUALA BEHE"
      },
      {
        "kodeKECAMATAN": 6103110,
        "kodeKABUPATEN": 6103,
        "namaKECAMATAN": "AIR BESAR"
      },
      {
        "kodeKECAMATAN": 6104080,
        "kodeKABUPATEN": 6104,
        "namaKECAMATAN": "SIANTAN"
      },
      {
        "kodeKECAMATAN": 6104081,
        "kodeKABUPATEN": 6104,
        "namaKECAMATAN": "SEGEDONG"
      },
      {
        "kodeKECAMATAN": 6104090,
        "kodeKABUPATEN": 6104,
        "namaKECAMATAN": "SUNGAI PINYUH"
      },
      {
        "kodeKECAMATAN": 6104091,
        "kodeKABUPATEN": 6104,
        "namaKECAMATAN": "ANJONGAN"
      },
      {
        "kodeKECAMATAN": 6104100,
        "kodeKABUPATEN": 6104,
        "namaKECAMATAN": "MEMPAWAH HILIR"
      },
      {
        "kodeKECAMATAN": 6104101,
        "kodeKABUPATEN": 6104,
        "namaKECAMATAN": "MEMPAWAH TIMUR"
      },
      {
        "kodeKECAMATAN": 6104110,
        "kodeKABUPATEN": 6104,
        "namaKECAMATAN": "SUNGAI KUNYIT"
      },
      {
        "kodeKECAMATAN": 6104120,
        "kodeKABUPATEN": 6104,
        "namaKECAMATAN": "TOHO"
      },
      {
        "kodeKECAMATAN": 6104121,
        "kodeKABUPATEN": 6104,
        "namaKECAMATAN": "SADANIANG"
      },
      {
        "kodeKECAMATAN": 6105010,
        "kodeKABUPATEN": 6105,
        "namaKECAMATAN": "TOBA"
      },
      {
        "kodeKECAMATAN": 6105020,
        "kodeKABUPATEN": 6105,
        "namaKECAMATAN": "MELIAU"
      },
      {
        "kodeKECAMATAN": 6105060,
        "kodeKABUPATEN": 6105,
        "namaKECAMATAN": "KAPUAS"
      },
      {
        "kodeKECAMATAN": 6105070,
        "kodeKABUPATEN": 6105,
        "namaKECAMATAN": "MUKOK"
      },
      {
        "kodeKECAMATAN": 6105120,
        "kodeKABUPATEN": 6105,
        "namaKECAMATAN": "JANGKANG"
      },
      {
        "kodeKECAMATAN": 6105130,
        "kodeKABUPATEN": 6105,
        "namaKECAMATAN": "BONTI"
      },
      {
        "kodeKECAMATAN": 6105140,
        "kodeKABUPATEN": 6105,
        "namaKECAMATAN": "PARINDU"
      },
      {
        "kodeKECAMATAN": 6105150,
        "kodeKABUPATEN": 6105,
        "namaKECAMATAN": "TAYAN HILIR"
      },
      {
        "kodeKECAMATAN": 6105160,
        "kodeKABUPATEN": 6105,
        "namaKECAMATAN": "BALAI"
      },
      {
        "kodeKECAMATAN": 6105170,
        "kodeKABUPATEN": 6105,
        "namaKECAMATAN": "TAYAN HULU"
      },
      {
        "kodeKECAMATAN": 6105180,
        "kodeKABUPATEN": 6105,
        "namaKECAMATAN": "KEMBAYAN"
      },
      {
        "kodeKECAMATAN": 6105190,
        "kodeKABUPATEN": 6105,
        "namaKECAMATAN": "BEDUWAI"
      },
      {
        "kodeKECAMATAN": 6105200,
        "kodeKABUPATEN": 6105,
        "namaKECAMATAN": "NOYAN"
      },
      {
        "kodeKECAMATAN": 6105210,
        "kodeKABUPATEN": 6105,
        "namaKECAMATAN": "SEKAYAM"
      },
      {
        "kodeKECAMATAN": 6105220,
        "kodeKABUPATEN": 6105,
        "namaKECAMATAN": "ENTIKONG"
      },
      {
        "kodeKECAMATAN": 6106010,
        "kodeKABUPATEN": 6106,
        "namaKECAMATAN": "KENDAWANGAN"
      },
      {
        "kodeKECAMATAN": 6106020,
        "kodeKABUPATEN": 6106,
        "namaKECAMATAN": "MANIS MATA"
      },
      {
        "kodeKECAMATAN": 6106030,
        "kodeKABUPATEN": 6106,
        "namaKECAMATAN": "MARAU"
      },
      {
        "kodeKECAMATAN": 6106031,
        "kodeKABUPATEN": 6106,
        "namaKECAMATAN": "SINGKUP"
      },
      {
        "kodeKECAMATAN": 6106032,
        "kodeKABUPATEN": 6106,
        "namaKECAMATAN": "AIR UPAS"
      },
      {
        "kodeKECAMATAN": 6106040,
        "kodeKABUPATEN": 6106,
        "namaKECAMATAN": "JELAI HULU"
      },
      {
        "kodeKECAMATAN": 6106050,
        "kodeKABUPATEN": 6106,
        "namaKECAMATAN": "TUMBANG TITI"
      },
      {
        "kodeKECAMATAN": 6106051,
        "kodeKABUPATEN": 6106,
        "namaKECAMATAN": "PEMAHAN"
      },
      {
        "kodeKECAMATAN": 6106052,
        "kodeKABUPATEN": 6106,
        "namaKECAMATAN": "SUNGAI MELAYU RAYAK"
      },
      {
        "kodeKECAMATAN": 6106060,
        "kodeKABUPATEN": 6106,
        "namaKECAMATAN": "MATAN HILIR SELATAN"
      },
      {
        "kodeKECAMATAN": 6106061,
        "kodeKABUPATEN": 6106,
        "namaKECAMATAN": "BENUA KAYONG"
      },
      {
        "kodeKECAMATAN": 6106070,
        "kodeKABUPATEN": 6106,
        "namaKECAMATAN": "MATAN HILIR UTARA"
      },
      {
        "kodeKECAMATAN": 6106071,
        "kodeKABUPATEN": 6106,
        "namaKECAMATAN": "DELTA PAWAN"
      },
      {
        "kodeKECAMATAN": 6106072,
        "kodeKABUPATEN": 6106,
        "namaKECAMATAN": "MUARA PAWAN"
      },
      {
        "kodeKECAMATAN": 6106090,
        "kodeKABUPATEN": 6106,
        "namaKECAMATAN": "NANGA TAYAP"
      },
      {
        "kodeKECAMATAN": 6106100,
        "kodeKABUPATEN": 6106,
        "namaKECAMATAN": "SANDAI"
      },
      {
        "kodeKECAMATAN": 6106101,
        "kodeKABUPATEN": 6106,
        "namaKECAMATAN": "HULU SUNGAI"
      },
      {
        "kodeKECAMATAN": 6106110,
        "kodeKABUPATEN": 6106,
        "namaKECAMATAN": "SUNGAI LAUR"
      },
      {
        "kodeKECAMATAN": 6106120,
        "kodeKABUPATEN": 6106,
        "namaKECAMATAN": "SIMPANG HULU"
      },
      {
        "kodeKECAMATAN": 6106121,
        "kodeKABUPATEN": 6106,
        "namaKECAMATAN": "SIMPANG DUA"
      },
      {
        "kodeKECAMATAN": 6107060,
        "kodeKABUPATEN": 6107,
        "namaKECAMATAN": "SERAWAI"
      },
      {
        "kodeKECAMATAN": 6107070,
        "kodeKABUPATEN": 6107,
        "namaKECAMATAN": "AMBALAU"
      },
      {
        "kodeKECAMATAN": 6107080,
        "kodeKABUPATEN": 6107,
        "namaKECAMATAN": "KAYAN HULU"
      },
      {
        "kodeKECAMATAN": 6107110,
        "kodeKABUPATEN": 6107,
        "namaKECAMATAN": "SEPAUK"
      },
      {
        "kodeKECAMATAN": 6107120,
        "kodeKABUPATEN": 6107,
        "namaKECAMATAN": "TEMPUNAK"
      },
      {
        "kodeKECAMATAN": 6107130,
        "kodeKABUPATEN": 6107,
        "namaKECAMATAN": "SUNGAI TEBELIAN"
      },
      {
        "kodeKECAMATAN": 6107140,
        "kodeKABUPATEN": 6107,
        "namaKECAMATAN": "SINTANG"
      },
      {
        "kodeKECAMATAN": 6107150,
        "kodeKABUPATEN": 6107,
        "namaKECAMATAN": "DEDAI"
      },
      {
        "kodeKECAMATAN": 6107160,
        "kodeKABUPATEN": 6107,
        "namaKECAMATAN": "KAYAN HILIR"
      },
      {
        "kodeKECAMATAN": 6107170,
        "kodeKABUPATEN": 6107,
        "namaKECAMATAN": "KELAM PERMAI"
      },
      {
        "kodeKECAMATAN": 6107180,
        "kodeKABUPATEN": 6107,
        "namaKECAMATAN": "BINJAI HULU"
      },
      {
        "kodeKECAMATAN": 6107190,
        "kodeKABUPATEN": 6107,
        "namaKECAMATAN": "KETUNGAU HILIR"
      },
      {
        "kodeKECAMATAN": 6107200,
        "kodeKABUPATEN": 6107,
        "namaKECAMATAN": "KETUNGAU TENGAH"
      },
      {
        "kodeKECAMATAN": 6107210,
        "kodeKABUPATEN": 6107,
        "namaKECAMATAN": "KETUNGAU HULU"
      },
      {
        "kodeKECAMATAN": 6108010,
        "kodeKABUPATEN": 6108,
        "namaKECAMATAN": "SILAT HILIR"
      },
      {
        "kodeKECAMATAN": 6108020,
        "kodeKABUPATEN": 6108,
        "namaKECAMATAN": "SILAT HULU"
      },
      {
        "kodeKECAMATAN": 6108030,
        "kodeKABUPATEN": 6108,
        "namaKECAMATAN": "HULU GURUNG"
      },
      {
        "kodeKECAMATAN": 6108040,
        "kodeKABUPATEN": 6108,
        "namaKECAMATAN": "BUNUT HULU"
      },
      {
        "kodeKECAMATAN": 6108050,
        "kodeKABUPATEN": 6108,
        "namaKECAMATAN": "MENTEBAH"
      },
      {
        "kodeKECAMATAN": 6108060,
        "kodeKABUPATEN": 6108,
        "namaKECAMATAN": "BIKA"
      },
      {
        "kodeKECAMATAN": 6108070,
        "kodeKABUPATEN": 6108,
        "namaKECAMATAN": "KALIS"
      },
      {
        "kodeKECAMATAN": 6108080,
        "kodeKABUPATEN": 6108,
        "namaKECAMATAN": "PUTUSSIBAU SELATAN"
      },
      {
        "kodeKECAMATAN": 6108090,
        "kodeKABUPATEN": 6108,
        "namaKECAMATAN": "EMBALOH HILIR"
      },
      {
        "kodeKECAMATAN": 6108100,
        "kodeKABUPATEN": 6108,
        "namaKECAMATAN": "BUNUT HILIR"
      },
      {
        "kodeKECAMATAN": 6108110,
        "kodeKABUPATEN": 6108,
        "namaKECAMATAN": "BOYAN TANJUNG"
      },
      {
        "kodeKECAMATAN": 6108120,
        "kodeKABUPATEN": 6108,
        "namaKECAMATAN": "PENGKADAN"
      },
      {
        "kodeKECAMATAN": 6108130,
        "kodeKABUPATEN": 6108,
        "namaKECAMATAN": "JONGKONG"
      },
      {
        "kodeKECAMATAN": 6108140,
        "kodeKABUPATEN": 6108,
        "namaKECAMATAN": "SELIMBAU"
      },
      {
        "kodeKECAMATAN": 6108150,
        "kodeKABUPATEN": 6108,
        "namaKECAMATAN": "SUHAID"
      },
      {
        "kodeKECAMATAN": 6108160,
        "kodeKABUPATEN": 6108,
        "namaKECAMATAN": "SEBERUANG"
      },
      {
        "kodeKECAMATAN": 6108170,
        "kodeKABUPATEN": 6108,
        "namaKECAMATAN": "SEMITAU"
      },
      {
        "kodeKECAMATAN": 6108180,
        "kodeKABUPATEN": 6108,
        "namaKECAMATAN": "EMPANANG"
      },
      {
        "kodeKECAMATAN": 6108190,
        "kodeKABUPATEN": 6108,
        "namaKECAMATAN": "PURING KENCANA"
      },
      {
        "kodeKECAMATAN": 6108200,
        "kodeKABUPATEN": 6108,
        "namaKECAMATAN": "BADAU"
      },
      {
        "kodeKECAMATAN": 6108210,
        "kodeKABUPATEN": 6108,
        "namaKECAMATAN": "BATANG LUPAR"
      },
      {
        "kodeKECAMATAN": 6108220,
        "kodeKABUPATEN": 6108,
        "namaKECAMATAN": "EMBALOH HULU"
      },
      {
        "kodeKECAMATAN": 6108230,
        "kodeKABUPATEN": 6108,
        "namaKECAMATAN": "PUTUSSIBAU UTARA"
      },
      {
        "kodeKECAMATAN": 6109010,
        "kodeKABUPATEN": 6109,
        "namaKECAMATAN": "NANGA MAHAP"
      },
      {
        "kodeKECAMATAN": 6109020,
        "kodeKABUPATEN": 6109,
        "namaKECAMATAN": "NANGA TAMAN"
      },
      {
        "kodeKECAMATAN": 6109030,
        "kodeKABUPATEN": 6109,
        "namaKECAMATAN": "SEKADAU HULU"
      },
      {
        "kodeKECAMATAN": 6109040,
        "kodeKABUPATEN": 6109,
        "namaKECAMATAN": "SEKADAU HILIR"
      },
      {
        "kodeKECAMATAN": 6109050,
        "kodeKABUPATEN": 6109,
        "namaKECAMATAN": "BELITANG HILIR"
      },
      {
        "kodeKECAMATAN": 6109060,
        "kodeKABUPATEN": 6109,
        "namaKECAMATAN": "BELITANG"
      },
      {
        "kodeKECAMATAN": 6109070,
        "kodeKABUPATEN": 6109,
        "namaKECAMATAN": "BELITANG HULU"
      },
      {
        "kodeKECAMATAN": 6110010,
        "kodeKABUPATEN": 6110,
        "namaKECAMATAN": "SOKAN"
      },
      {
        "kodeKECAMATAN": 6110020,
        "kodeKABUPATEN": 6110,
        "namaKECAMATAN": "TANAH PINOH"
      },
      {
        "kodeKECAMATAN": 6110021,
        "kodeKABUPATEN": 6110,
        "namaKECAMATAN": "TANAH PINOH BARAT"
      },
      {
        "kodeKECAMATAN": 6110030,
        "kodeKABUPATEN": 6110,
        "namaKECAMATAN": "SAYAN"
      },
      {
        "kodeKECAMATAN": 6110040,
        "kodeKABUPATEN": 6110,
        "namaKECAMATAN": "BELIMBING"
      },
      {
        "kodeKECAMATAN": 6110041,
        "kodeKABUPATEN": 6110,
        "namaKECAMATAN": "BELIMBING HULU"
      },
      {
        "kodeKECAMATAN": 6110050,
        "kodeKABUPATEN": 6110,
        "namaKECAMATAN": "NANGA PINOH"
      },
      {
        "kodeKECAMATAN": 6110051,
        "kodeKABUPATEN": 6110,
        "namaKECAMATAN": "PINOH SELATAN"
      },
      {
        "kodeKECAMATAN": 6110052,
        "kodeKABUPATEN": 6110,
        "namaKECAMATAN": "PINOH UTARA"
      },
      {
        "kodeKECAMATAN": 6110060,
        "kodeKABUPATEN": 6110,
        "namaKECAMATAN": "ELLA HILIR"
      },
      {
        "kodeKECAMATAN": 6110070,
        "kodeKABUPATEN": 6110,
        "namaKECAMATAN": "MENUKUNG"
      },
      {
        "kodeKECAMATAN": 6111010,
        "kodeKABUPATEN": 6111,
        "namaKECAMATAN": "PULAU MAYA"
      },
      {
        "kodeKECAMATAN": 6111011,
        "kodeKABUPATEN": 6111,
        "namaKECAMATAN": "KEPULAUAN KARIMATA"
      },
      {
        "kodeKECAMATAN": 6111020,
        "kodeKABUPATEN": 6111,
        "namaKECAMATAN": "SUKADANA"
      },
      {
        "kodeKECAMATAN": 6111030,
        "kodeKABUPATEN": 6111,
        "namaKECAMATAN": "SIMPANG HILIR"
      },
      {
        "kodeKECAMATAN": 6111040,
        "kodeKABUPATEN": 6111,
        "namaKECAMATAN": "TELUK BATANG"
      },
      {
        "kodeKECAMATAN": 6111050,
        "kodeKABUPATEN": 6111,
        "namaKECAMATAN": "SEPONTI"
      },
      {
        "kodeKECAMATAN": 6112010,
        "kodeKABUPATEN": 6112,
        "namaKECAMATAN": "BATU AMPAR"
      },
      {
        "kodeKECAMATAN": 6112020,
        "kodeKABUPATEN": 6112,
        "namaKECAMATAN": "TERENTANG"
      },
      {
        "kodeKECAMATAN": 6112030,
        "kodeKABUPATEN": 6112,
        "namaKECAMATAN": "KUBU"
      },
      {
        "kodeKECAMATAN": 6112040,
        "kodeKABUPATEN": 6112,
        "namaKECAMATAN": "TELOK PA'KEDAI"
      },
      {
        "kodeKECAMATAN": 6112050,
        "kodeKABUPATEN": 6112,
        "namaKECAMATAN": "SUNGAI KAKAP"
      },
      {
        "kodeKECAMATAN": 6112060,
        "kodeKABUPATEN": 6112,
        "namaKECAMATAN": "RASAU JAYA"
      },
      {
        "kodeKECAMATAN": 6112070,
        "kodeKABUPATEN": 6112,
        "namaKECAMATAN": "SUNGAI RAYA"
      },
      {
        "kodeKECAMATAN": 6112080,
        "kodeKABUPATEN": 6112,
        "namaKECAMATAN": "SUNGAI AMBAWANG"
      },
      {
        "kodeKECAMATAN": 6112090,
        "kodeKABUPATEN": 6112,
        "namaKECAMATAN": "KUALA MANDOR-B"
      },
      {
        "kodeKECAMATAN": 6171010,
        "kodeKABUPATEN": 6171,
        "namaKECAMATAN": "PONTIANAK SELATAN"
      },
      {
        "kodeKECAMATAN": 6171011,
        "kodeKABUPATEN": 6171,
        "namaKECAMATAN": "PONTIANAK TENGGARA"
      },
      {
        "kodeKECAMATAN": 6171020,
        "kodeKABUPATEN": 6171,
        "namaKECAMATAN": "PONTIANAK TIMUR"
      },
      {
        "kodeKECAMATAN": 6171030,
        "kodeKABUPATEN": 6171,
        "namaKECAMATAN": "PONTIANAK BARAT"
      },
      {
        "kodeKECAMATAN": 6171031,
        "kodeKABUPATEN": 6171,
        "namaKECAMATAN": "PONTIANAK KOTA"
      },
      {
        "kodeKECAMATAN": 6171040,
        "kodeKABUPATEN": 6171,
        "namaKECAMATAN": "PONTIANAK UTARA"
      },
      {
        "kodeKECAMATAN": 6172010,
        "kodeKABUPATEN": 6172,
        "namaKECAMATAN": "SINGKAWANG SELATAN"
      },
      {
        "kodeKECAMATAN": 6172020,
        "kodeKABUPATEN": 6172,
        "namaKECAMATAN": "SINGKAWANG TIMUR"
      },
      {
        "kodeKECAMATAN": 6172030,
        "kodeKABUPATEN": 6172,
        "namaKECAMATAN": "SINGKAWANG UTARA"
      },
      {
        "kodeKECAMATAN": 6172040,
        "kodeKABUPATEN": 6172,
        "namaKECAMATAN": "SINGKAWANG BARAT"
      },
      {
        "kodeKECAMATAN": 6172050,
        "kodeKABUPATEN": 6172,
        "namaKECAMATAN": "SINGKAWANG TENGAH"
      },
      {
        "kodeKECAMATAN": 6201040,
        "kodeKABUPATEN": 6201,
        "namaKECAMATAN": "KOTAWARINGIN LAMA"
      },
      {
        "kodeKECAMATAN": 6201050,
        "kodeKABUPATEN": 6201,
        "namaKECAMATAN": "ARUT SELATAN"
      },
      {
        "kodeKECAMATAN": 6201060,
        "kodeKABUPATEN": 6201,
        "namaKECAMATAN": "KUMAI"
      },
      {
        "kodeKECAMATAN": 6201061,
        "kodeKABUPATEN": 6201,
        "namaKECAMATAN": "PANGKALAN BANTENG"
      },
      {
        "kodeKECAMATAN": 6201062,
        "kodeKABUPATEN": 6201,
        "namaKECAMATAN": "PANGKALAN LADA"
      },
      {
        "kodeKECAMATAN": 6201070,
        "kodeKABUPATEN": 6201,
        "namaKECAMATAN": "ARUT UTARA"
      },
      {
        "kodeKECAMATAN": 6202020,
        "kodeKABUPATEN": 6202,
        "namaKECAMATAN": "MENTAYA HILIR SELATAN"
      },
      {
        "kodeKECAMATAN": 6202021,
        "kodeKABUPATEN": 6202,
        "namaKECAMATAN": "TELUK SAMPIT"
      },
      {
        "kodeKECAMATAN": 6202050,
        "kodeKABUPATEN": 6202,
        "namaKECAMATAN": "PULAU HANAUT"
      },
      {
        "kodeKECAMATAN": 6202060,
        "kodeKABUPATEN": 6202,
        "namaKECAMATAN": "MENTAWA BARU/KETAPANG"
      },
      {
        "kodeKECAMATAN": 6202061,
        "kodeKABUPATEN": 6202,
        "namaKECAMATAN": "SERANAU"
      },
      {
        "kodeKECAMATAN": 6202070,
        "kodeKABUPATEN": 6202,
        "namaKECAMATAN": "MENTAYA HILIR UTARA"
      },
      {
        "kodeKECAMATAN": 6202110,
        "kodeKABUPATEN": 6202,
        "namaKECAMATAN": "KOTA BESI"
      },
      {
        "kodeKECAMATAN": 6202111,
        "kodeKABUPATEN": 6202,
        "namaKECAMATAN": "TELAWANG"
      },
      {
        "kodeKECAMATAN": 6202120,
        "kodeKABUPATEN": 6202,
        "namaKECAMATAN": "BAAMANG"
      },
      {
        "kodeKECAMATAN": 6202190,
        "kodeKABUPATEN": 6202,
        "namaKECAMATAN": "CEMPAGA"
      },
      {
        "kodeKECAMATAN": 6202191,
        "kodeKABUPATEN": 6202,
        "namaKECAMATAN": "CEMPAGA HULU"
      },
      {
        "kodeKECAMATAN": 6202200,
        "kodeKABUPATEN": 6202,
        "namaKECAMATAN": "PARENGGEAN"
      },
      {
        "kodeKECAMATAN": 6202201,
        "kodeKABUPATEN": 6202,
        "namaKECAMATAN": "TUALAN HULU"
      },
      {
        "kodeKECAMATAN": 6202210,
        "kodeKABUPATEN": 6202,
        "namaKECAMATAN": "MENTAYA HULU"
      },
      {
        "kodeKECAMATAN": 6202211,
        "kodeKABUPATEN": 6202,
        "namaKECAMATAN": "BUKIT SANTUAI"
      },
      {
        "kodeKECAMATAN": 6202230,
        "kodeKABUPATEN": 6202,
        "namaKECAMATAN": "ANTANG KALANG"
      },
      {
        "kodeKECAMATAN": 6202231,
        "kodeKABUPATEN": 6202,
        "namaKECAMATAN": "TELAGA ANTANG"
      },
      {
        "kodeKECAMATAN": 6203020,
        "kodeKABUPATEN": 6203,
        "namaKECAMATAN": "KAPUAS KUALA"
      },
      {
        "kodeKECAMATAN": 6203021,
        "kodeKABUPATEN": 6203,
        "namaKECAMATAN": "TAMBAN CATUR"
      },
      {
        "kodeKECAMATAN": 6203030,
        "kodeKABUPATEN": 6203,
        "namaKECAMATAN": "KAPUAS TIMUR"
      },
      {
        "kodeKECAMATAN": 6203040,
        "kodeKABUPATEN": 6203,
        "namaKECAMATAN": "SELAT"
      },
      {
        "kodeKECAMATAN": 6203041,
        "kodeKABUPATEN": 6203,
        "namaKECAMATAN": "BATAGUH"
      },
      {
        "kodeKECAMATAN": 6203070,
        "kodeKABUPATEN": 6203,
        "namaKECAMATAN": "BASARANG"
      },
      {
        "kodeKECAMATAN": 6203080,
        "kodeKABUPATEN": 6203,
        "namaKECAMATAN": "KAPUAS HILIR"
      },
      {
        "kodeKECAMATAN": 6203090,
        "kodeKABUPATEN": 6203,
        "namaKECAMATAN": "PULAU PETAK"
      },
      {
        "kodeKECAMATAN": 6203100,
        "kodeKABUPATEN": 6203,
        "namaKECAMATAN": "KAPUAS MURUNG"
      },
      {
        "kodeKECAMATAN": 6203101,
        "kodeKABUPATEN": 6203,
        "namaKECAMATAN": "DADAHUP"
      },
      {
        "kodeKECAMATAN": 6203110,
        "kodeKABUPATEN": 6203,
        "namaKECAMATAN": "KAPUAS BARAT"
      },
      {
        "kodeKECAMATAN": 6203150,
        "kodeKABUPATEN": 6203,
        "namaKECAMATAN": "MANTANGAI"
      },
      {
        "kodeKECAMATAN": 6203160,
        "kodeKABUPATEN": 6203,
        "namaKECAMATAN": "TIMPAH"
      },
      {
        "kodeKECAMATAN": 6203170,
        "kodeKABUPATEN": 6203,
        "namaKECAMATAN": "KAPUAS TENGAH"
      },
      {
        "kodeKECAMATAN": 6203171,
        "kodeKABUPATEN": 6203,
        "namaKECAMATAN": "PASAK TALAWANG"
      },
      {
        "kodeKECAMATAN": 6203180,
        "kodeKABUPATEN": 6203,
        "namaKECAMATAN": "KAPUAS HULU"
      },
      {
        "kodeKECAMATAN": 6203181,
        "kodeKABUPATEN": 6203,
        "namaKECAMATAN": "MANDAU TALAWANG"
      },
      {
        "kodeKECAMATAN": 6204010,
        "kodeKABUPATEN": 6204,
        "namaKECAMATAN": "JENAMAS"
      },
      {
        "kodeKECAMATAN": 6204020,
        "kodeKABUPATEN": 6204,
        "namaKECAMATAN": "DUSUN HILIR"
      },
      {
        "kodeKECAMATAN": 6204030,
        "kodeKABUPATEN": 6204,
        "namaKECAMATAN": "KARAU KUALA"
      },
      {
        "kodeKECAMATAN": 6204040,
        "kodeKABUPATEN": 6204,
        "namaKECAMATAN": "DUSUN SELATAN"
      },
      {
        "kodeKECAMATAN": 6204050,
        "kodeKABUPATEN": 6204,
        "namaKECAMATAN": "DUSUN UTARA"
      },
      {
        "kodeKECAMATAN": 6204060,
        "kodeKABUPATEN": 6204,
        "namaKECAMATAN": "GUNUNG BINTANG AWAI"
      },
      {
        "kodeKECAMATAN": 6205010,
        "kodeKABUPATEN": 6205,
        "namaKECAMATAN": "MONTALLAT"
      },
      {
        "kodeKECAMATAN": 6205020,
        "kodeKABUPATEN": 6205,
        "namaKECAMATAN": "GUNUNG TIMANG"
      },
      {
        "kodeKECAMATAN": 6205030,
        "kodeKABUPATEN": 6205,
        "namaKECAMATAN": "GUNUNG PUREI"
      },
      {
        "kodeKECAMATAN": 6205040,
        "kodeKABUPATEN": 6205,
        "namaKECAMATAN": "TEWEH TIMUR"
      },
      {
        "kodeKECAMATAN": 6205050,
        "kodeKABUPATEN": 6205,
        "namaKECAMATAN": "TEWEH TENGAH"
      },
      {
        "kodeKECAMATAN": 6205051,
        "kodeKABUPATEN": 6205,
        "namaKECAMATAN": "TEWEH  BARU"
      },
      {
        "kodeKECAMATAN": 6205052,
        "kodeKABUPATEN": 6205,
        "namaKECAMATAN": "TEWEH SELATAN"
      },
      {
        "kodeKECAMATAN": 6205060,
        "kodeKABUPATEN": 6205,
        "namaKECAMATAN": "LAHEI"
      },
      {
        "kodeKECAMATAN": 6205061,
        "kodeKABUPATEN": 6205,
        "namaKECAMATAN": "LAHEI BARAT"
      },
      {
        "kodeKECAMATAN": 6206010,
        "kodeKABUPATEN": 6206,
        "namaKECAMATAN": "JELAI"
      },
      {
        "kodeKECAMATAN": 6206011,
        "kodeKABUPATEN": 6206,
        "namaKECAMATAN": "PANTAI LUNCI"
      },
      {
        "kodeKECAMATAN": 6206020,
        "kodeKABUPATEN": 6206,
        "namaKECAMATAN": "SUKAMARA"
      },
      {
        "kodeKECAMATAN": 6206030,
        "kodeKABUPATEN": 6206,
        "namaKECAMATAN": "BALAI RIAM"
      },
      {
        "kodeKECAMATAN": 6206031,
        "kodeKABUPATEN": 6206,
        "namaKECAMATAN": "PERMATA KECUBUNG"
      },
      {
        "kodeKECAMATAN": 6207010,
        "kodeKABUPATEN": 6207,
        "namaKECAMATAN": "BULIK"
      },
      {
        "kodeKECAMATAN": 6207011,
        "kodeKABUPATEN": 6207,
        "namaKECAMATAN": "SEMATU JAYA"
      },
      {
        "kodeKECAMATAN": 6207012,
        "kodeKABUPATEN": 6207,
        "namaKECAMATAN": "MENTHOBI RAYA"
      },
      {
        "kodeKECAMATAN": 6207013,
        "kodeKABUPATEN": 6207,
        "namaKECAMATAN": "BULIK TIMUR"
      },
      {
        "kodeKECAMATAN": 6207020,
        "kodeKABUPATEN": 6207,
        "namaKECAMATAN": "LAMANDAU"
      },
      {
        "kodeKECAMATAN": 6207021,
        "kodeKABUPATEN": 6207,
        "namaKECAMATAN": "BELANTIKAN RAYA"
      },
      {
        "kodeKECAMATAN": 6207030,
        "kodeKABUPATEN": 6207,
        "namaKECAMATAN": "DELANG"
      },
      {
        "kodeKECAMATAN": 6207031,
        "kodeKABUPATEN": 6207,
        "namaKECAMATAN": "BATANGKAWA"
      },
      {
        "kodeKECAMATAN": 6208010,
        "kodeKABUPATEN": 6208,
        "namaKECAMATAN": "SERUYAN HILIR"
      },
      {
        "kodeKECAMATAN": 6208011,
        "kodeKABUPATEN": 6208,
        "namaKECAMATAN": "SERUYAN HILIR TIMUR"
      },
      {
        "kodeKECAMATAN": 6208020,
        "kodeKABUPATEN": 6208,
        "namaKECAMATAN": "DANAU SEMBULUH"
      },
      {
        "kodeKECAMATAN": 6208021,
        "kodeKABUPATEN": 6208,
        "namaKECAMATAN": "SERUYAN RAYA"
      },
      {
        "kodeKECAMATAN": 6208030,
        "kodeKABUPATEN": 6208,
        "namaKECAMATAN": "HANAU"
      },
      {
        "kodeKECAMATAN": 6208031,
        "kodeKABUPATEN": 6208,
        "namaKECAMATAN": "DANAU SELULUK"
      },
      {
        "kodeKECAMATAN": 6208040,
        "kodeKABUPATEN": 6208,
        "namaKECAMATAN": "SERUYAN TENGAH"
      },
      {
        "kodeKECAMATAN": 6208041,
        "kodeKABUPATEN": 6208,
        "namaKECAMATAN": "BATU AMPAR"
      },
      {
        "kodeKECAMATAN": 6208050,
        "kodeKABUPATEN": 6208,
        "namaKECAMATAN": "SERUYAN HULU"
      },
      {
        "kodeKECAMATAN": 6208051,
        "kodeKABUPATEN": 6208,
        "namaKECAMATAN": "SULING TAMBUN"
      },
      {
        "kodeKECAMATAN": 6209010,
        "kodeKABUPATEN": 6209,
        "namaKECAMATAN": "KATINGAN KUALA"
      },
      {
        "kodeKECAMATAN": 6209020,
        "kodeKABUPATEN": 6209,
        "namaKECAMATAN": "MENDAWAI"
      },
      {
        "kodeKECAMATAN": 6209030,
        "kodeKABUPATEN": 6209,
        "namaKECAMATAN": "KAMIPANG"
      },
      {
        "kodeKECAMATAN": 6209040,
        "kodeKABUPATEN": 6209,
        "namaKECAMATAN": "TASIK PAYAWAN"
      },
      {
        "kodeKECAMATAN": 6209050,
        "kodeKABUPATEN": 6209,
        "namaKECAMATAN": "KATINGAN HILIR"
      },
      {
        "kodeKECAMATAN": 6209060,
        "kodeKABUPATEN": 6209,
        "namaKECAMATAN": "TEWANG SANGALANG GARING"
      },
      {
        "kodeKECAMATAN": 6209070,
        "kodeKABUPATEN": 6209,
        "namaKECAMATAN": "PULAU MALAN"
      },
      {
        "kodeKECAMATAN": 6209080,
        "kodeKABUPATEN": 6209,
        "namaKECAMATAN": "KATINGAN TENGAH"
      },
      {
        "kodeKECAMATAN": 6209090,
        "kodeKABUPATEN": 6209,
        "namaKECAMATAN": "SANAMAN MANTIKEI"
      },
      {
        "kodeKECAMATAN": 6209091,
        "kodeKABUPATEN": 6209,
        "namaKECAMATAN": "PETAK MALAI"
      },
      {
        "kodeKECAMATAN": 6209100,
        "kodeKABUPATEN": 6209,
        "namaKECAMATAN": "MARIKIT"
      },
      {
        "kodeKECAMATAN": 6209110,
        "kodeKABUPATEN": 6209,
        "namaKECAMATAN": "KATINGAN HULU"
      },
      {
        "kodeKECAMATAN": 6209111,
        "kodeKABUPATEN": 6209,
        "namaKECAMATAN": "BUKIT RAYA"
      },
      {
        "kodeKECAMATAN": 6210010,
        "kodeKABUPATEN": 6210,
        "namaKECAMATAN": "KAHAYAN KUALA"
      },
      {
        "kodeKECAMATAN": 6210011,
        "kodeKABUPATEN": 6210,
        "namaKECAMATAN": "SEBANGAU KUALA"
      },
      {
        "kodeKECAMATAN": 6210020,
        "kodeKABUPATEN": 6210,
        "namaKECAMATAN": "PANDIH BATU"
      },
      {
        "kodeKECAMATAN": 6210030,
        "kodeKABUPATEN": 6210,
        "namaKECAMATAN": "MALIKU"
      },
      {
        "kodeKECAMATAN": 6210040,
        "kodeKABUPATEN": 6210,
        "namaKECAMATAN": "KAHAYAN HILIR"
      },
      {
        "kodeKECAMATAN": 6210041,
        "kodeKABUPATEN": 6210,
        "namaKECAMATAN": "JABIREN RAYA"
      },
      {
        "kodeKECAMATAN": 6210050,
        "kodeKABUPATEN": 6210,
        "namaKECAMATAN": "KAHAYAN TENGAH"
      },
      {
        "kodeKECAMATAN": 6210060,
        "kodeKABUPATEN": 6210,
        "namaKECAMATAN": "BANAMA TINGANG"
      },
      {
        "kodeKECAMATAN": 6211010,
        "kodeKABUPATEN": 6211,
        "namaKECAMATAN": "MANUHING"
      },
      {
        "kodeKECAMATAN": 6211011,
        "kodeKABUPATEN": 6211,
        "namaKECAMATAN": "MANUHING RAYA"
      },
      {
        "kodeKECAMATAN": 6211020,
        "kodeKABUPATEN": 6211,
        "namaKECAMATAN": "RUNGAN"
      },
      {
        "kodeKECAMATAN": 6211021,
        "kodeKABUPATEN": 6211,
        "namaKECAMATAN": "RUNGAN HULU"
      },
      {
        "kodeKECAMATAN": 6211022,
        "kodeKABUPATEN": 6211,
        "namaKECAMATAN": "RUNGAN BARAT"
      },
      {
        "kodeKECAMATAN": 6211030,
        "kodeKABUPATEN": 6211,
        "namaKECAMATAN": "SEPANG"
      },
      {
        "kodeKECAMATAN": 6211031,
        "kodeKABUPATEN": 6211,
        "namaKECAMATAN": "MIHING RAYA"
      },
      {
        "kodeKECAMATAN": 6211040,
        "kodeKABUPATEN": 6211,
        "namaKECAMATAN": "KURUN"
      },
      {
        "kodeKECAMATAN": 6211050,
        "kodeKABUPATEN": 6211,
        "namaKECAMATAN": "TEWAH"
      },
      {
        "kodeKECAMATAN": 6211060,
        "kodeKABUPATEN": 6211,
        "namaKECAMATAN": "KAHAYAN HULU UTARA"
      },
      {
        "kodeKECAMATAN": 6211061,
        "kodeKABUPATEN": 6211,
        "namaKECAMATAN": "DAMANG BATU"
      },
      {
        "kodeKECAMATAN": 6211062,
        "kodeKABUPATEN": 6211,
        "namaKECAMATAN": "MIRI MANASA"
      },
      {
        "kodeKECAMATAN": 6212010,
        "kodeKABUPATEN": 6212,
        "namaKECAMATAN": "BENUA LIMA"
      },
      {
        "kodeKECAMATAN": 6212020,
        "kodeKABUPATEN": 6212,
        "namaKECAMATAN": "DUSUN TIMUR"
      },
      {
        "kodeKECAMATAN": 6212021,
        "kodeKABUPATEN": 6212,
        "namaKECAMATAN": "PAJU EPAT"
      },
      {
        "kodeKECAMATAN": 6212030,
        "kodeKABUPATEN": 6212,
        "namaKECAMATAN": "AWANG"
      },
      {
        "kodeKECAMATAN": 6212040,
        "kodeKABUPATEN": 6212,
        "namaKECAMATAN": "PATANGKEP TUTUI"
      },
      {
        "kodeKECAMATAN": 6212050,
        "kodeKABUPATEN": 6212,
        "namaKECAMATAN": "DUSUN TENGAH"
      },
      {
        "kodeKECAMATAN": 6212051,
        "kodeKABUPATEN": 6212,
        "namaKECAMATAN": "RAREN BATUAH"
      },
      {
        "kodeKECAMATAN": 6212052,
        "kodeKABUPATEN": 6212,
        "namaKECAMATAN": "PAKU"
      },
      {
        "kodeKECAMATAN": 6212053,
        "kodeKABUPATEN": 6212,
        "namaKECAMATAN": "KARUSEN JANANG"
      },
      {
        "kodeKECAMATAN": 6212060,
        "kodeKABUPATEN": 6212,
        "namaKECAMATAN": "PEMATANG KARAU"
      },
      {
        "kodeKECAMATAN": 6213010,
        "kodeKABUPATEN": 6213,
        "namaKECAMATAN": "PERMATA INTAN"
      },
      {
        "kodeKECAMATAN": 6213011,
        "kodeKABUPATEN": 6213,
        "namaKECAMATAN": "SUNGAI BABUAT"
      },
      {
        "kodeKECAMATAN": 6213020,
        "kodeKABUPATEN": 6213,
        "namaKECAMATAN": "MURUNG"
      },
      {
        "kodeKECAMATAN": 6213030,
        "kodeKABUPATEN": 6213,
        "namaKECAMATAN": "LAUNG TUHUP"
      },
      {
        "kodeKECAMATAN": 6213031,
        "kodeKABUPATEN": 6213,
        "namaKECAMATAN": "BARITO TUHUP RAYA"
      },
      {
        "kodeKECAMATAN": 6213040,
        "kodeKABUPATEN": 6213,
        "namaKECAMATAN": "TANAH SIANG"
      },
      {
        "kodeKECAMATAN": 6213041,
        "kodeKABUPATEN": 6213,
        "namaKECAMATAN": "TANAH SIANG SELATAN"
      },
      {
        "kodeKECAMATAN": 6213050,
        "kodeKABUPATEN": 6213,
        "namaKECAMATAN": "SUMBER BARITO"
      },
      {
        "kodeKECAMATAN": 6213051,
        "kodeKABUPATEN": 6213,
        "namaKECAMATAN": "SERIBU RIAM"
      },
      {
        "kodeKECAMATAN": 6213052,
        "kodeKABUPATEN": 6213,
        "namaKECAMATAN": "UUT MURUNG"
      },
      {
        "kodeKECAMATAN": 6271010,
        "kodeKABUPATEN": 6271,
        "namaKECAMATAN": "PAHANDUT"
      },
      {
        "kodeKECAMATAN": 6271011,
        "kodeKABUPATEN": 6271,
        "namaKECAMATAN": "SABANGAU"
      },
      {
        "kodeKECAMATAN": 6271012,
        "kodeKABUPATEN": 6271,
        "namaKECAMATAN": "JEKAN RAYA"
      },
      {
        "kodeKECAMATAN": 6271020,
        "kodeKABUPATEN": 6271,
        "namaKECAMATAN": "BUKIT BATU"
      },
      {
        "kodeKECAMATAN": 6271021,
        "kodeKABUPATEN": 6271,
        "namaKECAMATAN": "RAKUMPIT"
      },
      {
        "kodeKECAMATAN": 6301010,
        "kodeKABUPATEN": 6301,
        "namaKECAMATAN": "PANYIPATAN"
      },
      {
        "kodeKECAMATAN": 6301020,
        "kodeKABUPATEN": 6301,
        "namaKECAMATAN": "TAKISUNG"
      },
      {
        "kodeKECAMATAN": 6301030,
        "kodeKABUPATEN": 6301,
        "namaKECAMATAN": "KURAU"
      },
      {
        "kodeKECAMATAN": 6301031,
        "kodeKABUPATEN": 6301,
        "namaKECAMATAN": "BUMI MAKMUR"
      },
      {
        "kodeKECAMATAN": 6301040,
        "kodeKABUPATEN": 6301,
        "namaKECAMATAN": "BATI - BATI"
      },
      {
        "kodeKECAMATAN": 6301050,
        "kodeKABUPATEN": 6301,
        "namaKECAMATAN": "TAMBANG ULANG"
      },
      {
        "kodeKECAMATAN": 6301060,
        "kodeKABUPATEN": 6301,
        "namaKECAMATAN": "PELAIHARI"
      },
      {
        "kodeKECAMATAN": 6301061,
        "kodeKABUPATEN": 6301,
        "namaKECAMATAN": "BAJUIN"
      },
      {
        "kodeKECAMATAN": 6301070,
        "kodeKABUPATEN": 6301,
        "namaKECAMATAN": "BATU AMPAR"
      },
      {
        "kodeKECAMATAN": 6301080,
        "kodeKABUPATEN": 6301,
        "namaKECAMATAN": "JORONG"
      },
      {
        "kodeKECAMATAN": 6301090,
        "kodeKABUPATEN": 6301,
        "namaKECAMATAN": "KINTAP"
      },
      {
        "kodeKECAMATAN": 6302010,
        "kodeKABUPATEN": 6302,
        "namaKECAMATAN": "PULAU SEMBILAN"
      },
      {
        "kodeKECAMATAN": 6302020,
        "kodeKABUPATEN": 6302,
        "namaKECAMATAN": "PULAU LAUT BARAT"
      },
      {
        "kodeKECAMATAN": 6302021,
        "kodeKABUPATEN": 6302,
        "namaKECAMATAN": "PULAU LAUT TANJUNG SELAYAR"
      },
      {
        "kodeKECAMATAN": 6302030,
        "kodeKABUPATEN": 6302,
        "namaKECAMATAN": "PULAU LAUT SELATAN"
      },
      {
        "kodeKECAMATAN": 6302031,
        "kodeKABUPATEN": 6302,
        "namaKECAMATAN": "PULAU LAUT KEPULAUAN"
      },
      {
        "kodeKECAMATAN": 6302040,
        "kodeKABUPATEN": 6302,
        "namaKECAMATAN": "PULAU LAUT TIMUR"
      },
      {
        "kodeKECAMATAN": 6302050,
        "kodeKABUPATEN": 6302,
        "namaKECAMATAN": "PULAU SEBUKU"
      },
      {
        "kodeKECAMATAN": 6302060,
        "kodeKABUPATEN": 6302,
        "namaKECAMATAN": "PULAU LAUT UTARA"
      },
      {
        "kodeKECAMATAN": 6302061,
        "kodeKABUPATEN": 6302,
        "namaKECAMATAN": "PULAU LAUT TENGAH"
      },
      {
        "kodeKECAMATAN": 6302120,
        "kodeKABUPATEN": 6302,
        "namaKECAMATAN": "KELUMPANG SELATAN"
      },
      {
        "kodeKECAMATAN": 6302121,
        "kodeKABUPATEN": 6302,
        "namaKECAMATAN": "KELUMPANG HILIR"
      },
      {
        "kodeKECAMATAN": 6302130,
        "kodeKABUPATEN": 6302,
        "namaKECAMATAN": "KELUMPANG HULU"
      },
      {
        "kodeKECAMATAN": 6302140,
        "kodeKABUPATEN": 6302,
        "namaKECAMATAN": "HAMPANG"
      },
      {
        "kodeKECAMATAN": 6302150,
        "kodeKABUPATEN": 6302,
        "namaKECAMATAN": "SUNGAI DURIAN"
      },
      {
        "kodeKECAMATAN": 6302160,
        "kodeKABUPATEN": 6302,
        "namaKECAMATAN": "KELUMPANG TENGAH"
      },
      {
        "kodeKECAMATAN": 6302161,
        "kodeKABUPATEN": 6302,
        "namaKECAMATAN": "KELUMPANG BARAT"
      },
      {
        "kodeKECAMATAN": 6302170,
        "kodeKABUPATEN": 6302,
        "namaKECAMATAN": "KELUMPANG UTARA"
      },
      {
        "kodeKECAMATAN": 6302180,
        "kodeKABUPATEN": 6302,
        "namaKECAMATAN": "PAMUKAN SELATAN"
      },
      {
        "kodeKECAMATAN": 6302190,
        "kodeKABUPATEN": 6302,
        "namaKECAMATAN": "SAMPANAHAN"
      },
      {
        "kodeKECAMATAN": 6302200,
        "kodeKABUPATEN": 6302,
        "namaKECAMATAN": "PAMUKAN UTARA"
      },
      {
        "kodeKECAMATAN": 6302201,
        "kodeKABUPATEN": 6302,
        "namaKECAMATAN": "PAMUKAN BARAT"
      },
      {
        "kodeKECAMATAN": 6303010,
        "kodeKABUPATEN": 6303,
        "namaKECAMATAN": "ALUH - ALUH"
      },
      {
        "kodeKECAMATAN": 6303011,
        "kodeKABUPATEN": 6303,
        "namaKECAMATAN": "BERUNTUNG BARU"
      },
      {
        "kodeKECAMATAN": 6303020,
        "kodeKABUPATEN": 6303,
        "namaKECAMATAN": "GAMBUT"
      },
      {
        "kodeKECAMATAN": 6303030,
        "kodeKABUPATEN": 6303,
        "namaKECAMATAN": "KERTAK HANYAR"
      },
      {
        "kodeKECAMATAN": 6303031,
        "kodeKABUPATEN": 6303,
        "namaKECAMATAN": "TATAH MAKMUR"
      },
      {
        "kodeKECAMATAN": 6303040,
        "kodeKABUPATEN": 6303,
        "namaKECAMATAN": "SUNGAI TABUK"
      },
      {
        "kodeKECAMATAN": 6303050,
        "kodeKABUPATEN": 6303,
        "namaKECAMATAN": "MARTAPURA"
      },
      {
        "kodeKECAMATAN": 6303051,
        "kodeKABUPATEN": 6303,
        "namaKECAMATAN": "MARTAPURA TIMUR"
      },
      {
        "kodeKECAMATAN": 6303052,
        "kodeKABUPATEN": 6303,
        "namaKECAMATAN": "MARTAPURA BARAT"
      },
      {
        "kodeKECAMATAN": 6303060,
        "kodeKABUPATEN": 6303,
        "namaKECAMATAN": "ASTAMBUL"
      },
      {
        "kodeKECAMATAN": 6303070,
        "kodeKABUPATEN": 6303,
        "namaKECAMATAN": "KARANG INTAN"
      },
      {
        "kodeKECAMATAN": 6303080,
        "kodeKABUPATEN": 6303,
        "namaKECAMATAN": "ARANIO"
      },
      {
        "kodeKECAMATAN": 6303090,
        "kodeKABUPATEN": 6303,
        "namaKECAMATAN": "SUNGAI PINANG"
      },
      {
        "kodeKECAMATAN": 6303091,
        "kodeKABUPATEN": 6303,
        "namaKECAMATAN": "PARAMASAN"
      },
      {
        "kodeKECAMATAN": 6303100,
        "kodeKABUPATEN": 6303,
        "namaKECAMATAN": "PENGARON"
      },
      {
        "kodeKECAMATAN": 6303101,
        "kodeKABUPATEN": 6303,
        "namaKECAMATAN": "SAMBUNG MAKMUR"
      },
      {
        "kodeKECAMATAN": 6303110,
        "kodeKABUPATEN": 6303,
        "namaKECAMATAN": "MATARAMAN"
      },
      {
        "kodeKECAMATAN": 6303120,
        "kodeKABUPATEN": 6303,
        "namaKECAMATAN": "SIMPANG EMPAT"
      },
      {
        "kodeKECAMATAN": 6303121,
        "kodeKABUPATEN": 6303,
        "namaKECAMATAN": "TELAGA BAUNTUNG"
      },
      {
        "kodeKECAMATAN": 6304010,
        "kodeKABUPATEN": 6304,
        "namaKECAMATAN": "TABUNGANEN"
      },
      {
        "kodeKECAMATAN": 6304020,
        "kodeKABUPATEN": 6304,
        "namaKECAMATAN": "TAMBAN"
      },
      {
        "kodeKECAMATAN": 6304030,
        "kodeKABUPATEN": 6304,
        "namaKECAMATAN": "MEKAR SARI"
      },
      {
        "kodeKECAMATAN": 6304040,
        "kodeKABUPATEN": 6304,
        "namaKECAMATAN": "ANJIR PASAR"
      },
      {
        "kodeKECAMATAN": 6304050,
        "kodeKABUPATEN": 6304,
        "namaKECAMATAN": "ANJIR MUARA"
      },
      {
        "kodeKECAMATAN": 6304060,
        "kodeKABUPATEN": 6304,
        "namaKECAMATAN": "ALALAK"
      },
      {
        "kodeKECAMATAN": 6304070,
        "kodeKABUPATEN": 6304,
        "namaKECAMATAN": "MANDASTANA"
      },
      {
        "kodeKECAMATAN": 6304071,
        "kodeKABUPATEN": 6304,
        "namaKECAMATAN": "JEJANGKIT"
      },
      {
        "kodeKECAMATAN": 6304080,
        "kodeKABUPATEN": 6304,
        "namaKECAMATAN": "BELAWANG"
      },
      {
        "kodeKECAMATAN": 6304090,
        "kodeKABUPATEN": 6304,
        "namaKECAMATAN": "WANARAYA"
      },
      {
        "kodeKECAMATAN": 6304100,
        "kodeKABUPATEN": 6304,
        "namaKECAMATAN": "BARAMBAI"
      },
      {
        "kodeKECAMATAN": 6304110,
        "kodeKABUPATEN": 6304,
        "namaKECAMATAN": "RANTAU BADAUH"
      },
      {
        "kodeKECAMATAN": 6304120,
        "kodeKABUPATEN": 6304,
        "namaKECAMATAN": "CERBON"
      },
      {
        "kodeKECAMATAN": 6304130,
        "kodeKABUPATEN": 6304,
        "namaKECAMATAN": "BAKUMPAI"
      },
      {
        "kodeKECAMATAN": 6304140,
        "kodeKABUPATEN": 6304,
        "namaKECAMATAN": "MARABAHAN"
      },
      {
        "kodeKECAMATAN": 6304150,
        "kodeKABUPATEN": 6304,
        "namaKECAMATAN": "TABUKAN"
      },
      {
        "kodeKECAMATAN": 6304160,
        "kodeKABUPATEN": 6304,
        "namaKECAMATAN": "KURIPAN"
      },
      {
        "kodeKECAMATAN": 6305010,
        "kodeKABUPATEN": 6305,
        "namaKECAMATAN": "BINUANG"
      },
      {
        "kodeKECAMATAN": 6305011,
        "kodeKABUPATEN": 6305,
        "namaKECAMATAN": "HATUNGUN"
      },
      {
        "kodeKECAMATAN": 6305020,
        "kodeKABUPATEN": 6305,
        "namaKECAMATAN": "TAPIN SELATAN"
      },
      {
        "kodeKECAMATAN": 6305021,
        "kodeKABUPATEN": 6305,
        "namaKECAMATAN": "SALAM BABARIS"
      },
      {
        "kodeKECAMATAN": 6305030,
        "kodeKABUPATEN": 6305,
        "namaKECAMATAN": "TAPIN TENGAH"
      },
      {
        "kodeKECAMATAN": 6305040,
        "kodeKABUPATEN": 6305,
        "namaKECAMATAN": "BUNGUR"
      },
      {
        "kodeKECAMATAN": 6305050,
        "kodeKABUPATEN": 6305,
        "namaKECAMATAN": "PIANI"
      },
      {
        "kodeKECAMATAN": 6305060,
        "kodeKABUPATEN": 6305,
        "namaKECAMATAN": "LOKPAIKAT"
      },
      {
        "kodeKECAMATAN": 6305070,
        "kodeKABUPATEN": 6305,
        "namaKECAMATAN": "TAPIN UTARA"
      },
      {
        "kodeKECAMATAN": 6305080,
        "kodeKABUPATEN": 6305,
        "namaKECAMATAN": "BAKARANGAN"
      },
      {
        "kodeKECAMATAN": 6305090,
        "kodeKABUPATEN": 6305,
        "namaKECAMATAN": "CANDI LARAS SELATAN"
      },
      {
        "kodeKECAMATAN": 6305100,
        "kodeKABUPATEN": 6305,
        "namaKECAMATAN": "CANDI LARAS UTARA"
      },
      {
        "kodeKECAMATAN": 6306010,
        "kodeKABUPATEN": 6306,
        "namaKECAMATAN": "PADANG BATUNG"
      },
      {
        "kodeKECAMATAN": 6306020,
        "kodeKABUPATEN": 6306,
        "namaKECAMATAN": "LOKSADO"
      },
      {
        "kodeKECAMATAN": 6306030,
        "kodeKABUPATEN": 6306,
        "namaKECAMATAN": "TELAGA LANGSAT"
      },
      {
        "kodeKECAMATAN": 6306040,
        "kodeKABUPATEN": 6306,
        "namaKECAMATAN": "ANGKINANG"
      },
      {
        "kodeKECAMATAN": 6306050,
        "kodeKABUPATEN": 6306,
        "namaKECAMATAN": "KANDANGAN"
      },
      {
        "kodeKECAMATAN": 6306060,
        "kodeKABUPATEN": 6306,
        "namaKECAMATAN": "SUNGAI RAYA"
      },
      {
        "kodeKECAMATAN": 6306070,
        "kodeKABUPATEN": 6306,
        "namaKECAMATAN": "SIMPUR"
      },
      {
        "kodeKECAMATAN": 6306080,
        "kodeKABUPATEN": 6306,
        "namaKECAMATAN": "KALUMPANG"
      },
      {
        "kodeKECAMATAN": 6306090,
        "kodeKABUPATEN": 6306,
        "namaKECAMATAN": "DAHA SELATAN"
      },
      {
        "kodeKECAMATAN": 6306091,
        "kodeKABUPATEN": 6306,
        "namaKECAMATAN": "DAHA BARAT"
      },
      {
        "kodeKECAMATAN": 6306100,
        "kodeKABUPATEN": 6306,
        "namaKECAMATAN": "DAHA UTARA"
      },
      {
        "kodeKECAMATAN": 6307010,
        "kodeKABUPATEN": 6307,
        "namaKECAMATAN": "HARUYAN"
      },
      {
        "kodeKECAMATAN": 6307020,
        "kodeKABUPATEN": 6307,
        "namaKECAMATAN": "BATU BENAWA"
      },
      {
        "kodeKECAMATAN": 6307030,
        "kodeKABUPATEN": 6307,
        "namaKECAMATAN": "HANTAKAN"
      },
      {
        "kodeKECAMATAN": 6307040,
        "kodeKABUPATEN": 6307,
        "namaKECAMATAN": "BATANG ALAI SELATAN"
      },
      {
        "kodeKECAMATAN": 6307041,
        "kodeKABUPATEN": 6307,
        "namaKECAMATAN": "BATANG ALAI TIMUR"
      },
      {
        "kodeKECAMATAN": 6307050,
        "kodeKABUPATEN": 6307,
        "namaKECAMATAN": "BARABAI"
      },
      {
        "kodeKECAMATAN": 6307060,
        "kodeKABUPATEN": 6307,
        "namaKECAMATAN": "LABUAN AMAS SELATAN"
      },
      {
        "kodeKECAMATAN": 6307070,
        "kodeKABUPATEN": 6307,
        "namaKECAMATAN": "LABUAN AMAS UTARA"
      },
      {
        "kodeKECAMATAN": 6307080,
        "kodeKABUPATEN": 6307,
        "namaKECAMATAN": "PANDAWAN"
      },
      {
        "kodeKECAMATAN": 6307090,
        "kodeKABUPATEN": 6307,
        "namaKECAMATAN": "BATANG ALAI UTARA"
      },
      {
        "kodeKECAMATAN": 6307091,
        "kodeKABUPATEN": 6307,
        "namaKECAMATAN": "LIMPASU"
      },
      {
        "kodeKECAMATAN": 6308010,
        "kodeKABUPATEN": 6308,
        "namaKECAMATAN": "DANAU PANGGANG"
      },
      {
        "kodeKECAMATAN": 6308011,
        "kodeKABUPATEN": 6308,
        "namaKECAMATAN": "PAMINGGIR"
      },
      {
        "kodeKECAMATAN": 6308020,
        "kodeKABUPATEN": 6308,
        "namaKECAMATAN": "BABIRIK"
      },
      {
        "kodeKECAMATAN": 6308030,
        "kodeKABUPATEN": 6308,
        "namaKECAMATAN": "SUNGAI PANDAN"
      },
      {
        "kodeKECAMATAN": 6308031,
        "kodeKABUPATEN": 6308,
        "namaKECAMATAN": "SUNGAI TABUKAN"
      },
      {
        "kodeKECAMATAN": 6308040,
        "kodeKABUPATEN": 6308,
        "namaKECAMATAN": "AMUNTAI SELATAN"
      },
      {
        "kodeKECAMATAN": 6308050,
        "kodeKABUPATEN": 6308,
        "namaKECAMATAN": "AMUNTAI TENGAH"
      },
      {
        "kodeKECAMATAN": 6308060,
        "kodeKABUPATEN": 6308,
        "namaKECAMATAN": "BANJANG"
      },
      {
        "kodeKECAMATAN": 6308070,
        "kodeKABUPATEN": 6308,
        "namaKECAMATAN": "AMUNTAI UTARA"
      },
      {
        "kodeKECAMATAN": 6308071,
        "kodeKABUPATEN": 6308,
        "namaKECAMATAN": "HAUR GADING"
      },
      {
        "kodeKECAMATAN": 6309010,
        "kodeKABUPATEN": 6309,
        "namaKECAMATAN": "BANUA LAWAS"
      },
      {
        "kodeKECAMATAN": 6309020,
        "kodeKABUPATEN": 6309,
        "namaKECAMATAN": "PUGAAN"
      },
      {
        "kodeKECAMATAN": 6309030,
        "kodeKABUPATEN": 6309,
        "namaKECAMATAN": "KELUA"
      },
      {
        "kodeKECAMATAN": 6309040,
        "kodeKABUPATEN": 6309,
        "namaKECAMATAN": "MUARA HARUS"
      },
      {
        "kodeKECAMATAN": 6309050,
        "kodeKABUPATEN": 6309,
        "namaKECAMATAN": "TANTA"
      },
      {
        "kodeKECAMATAN": 6309060,
        "kodeKABUPATEN": 6309,
        "namaKECAMATAN": "TANJUNG"
      },
      {
        "kodeKECAMATAN": 6309070,
        "kodeKABUPATEN": 6309,
        "namaKECAMATAN": "MURUNG PUDAK"
      },
      {
        "kodeKECAMATAN": 6309080,
        "kodeKABUPATEN": 6309,
        "namaKECAMATAN": "HARUAI"
      },
      {
        "kodeKECAMATAN": 6309081,
        "kodeKABUPATEN": 6309,
        "namaKECAMATAN": "BINTANG ARA"
      },
      {
        "kodeKECAMATAN": 6309090,
        "kodeKABUPATEN": 6309,
        "namaKECAMATAN": "UPAU"
      },
      {
        "kodeKECAMATAN": 6309100,
        "kodeKABUPATEN": 6309,
        "namaKECAMATAN": "MUARA UYA"
      },
      {
        "kodeKECAMATAN": 6309110,
        "kodeKABUPATEN": 6309,
        "namaKECAMATAN": "JARO"
      },
      {
        "kodeKECAMATAN": 6310010,
        "kodeKABUPATEN": 6310,
        "namaKECAMATAN": "KUSAN HILIR"
      },
      {
        "kodeKECAMATAN": 6310020,
        "kodeKABUPATEN": 6310,
        "namaKECAMATAN": "SUNGAI LOBAN"
      },
      {
        "kodeKECAMATAN": 6310030,
        "kodeKABUPATEN": 6310,
        "namaKECAMATAN": "SATUI"
      },
      {
        "kodeKECAMATAN": 6310031,
        "kodeKABUPATEN": 6310,
        "namaKECAMATAN": "ANGSANA"
      },
      {
        "kodeKECAMATAN": 6310040,
        "kodeKABUPATEN": 6310,
        "namaKECAMATAN": "KUSAN HULU"
      },
      {
        "kodeKECAMATAN": 6310041,
        "kodeKABUPATEN": 6310,
        "namaKECAMATAN": "KURANJI"
      },
      {
        "kodeKECAMATAN": 6310050,
        "kodeKABUPATEN": 6310,
        "namaKECAMATAN": "BATU LICIN"
      },
      {
        "kodeKECAMATAN": 6310051,
        "kodeKABUPATEN": 6310,
        "namaKECAMATAN": "KARANG BINTANG"
      },
      {
        "kodeKECAMATAN": 6310052,
        "kodeKABUPATEN": 6310,
        "namaKECAMATAN": "SIMPANG EMPAT"
      },
      {
        "kodeKECAMATAN": 6310053,
        "kodeKABUPATEN": 6310,
        "namaKECAMATAN": "MANTEWE"
      },
      {
        "kodeKECAMATAN": 6311010,
        "kodeKABUPATEN": 6311,
        "namaKECAMATAN": "LAMPIHONG"
      },
      {
        "kodeKECAMATAN": 6311020,
        "kodeKABUPATEN": 6311,
        "namaKECAMATAN": "BATU MANDI"
      },
      {
        "kodeKECAMATAN": 6311030,
        "kodeKABUPATEN": 6311,
        "namaKECAMATAN": "AWAYAN"
      },
      {
        "kodeKECAMATAN": 6311031,
        "kodeKABUPATEN": 6311,
        "namaKECAMATAN": "TEBING TINGGI"
      },
      {
        "kodeKECAMATAN": 6311040,
        "kodeKABUPATEN": 6311,
        "namaKECAMATAN": "PARINGIN"
      },
      {
        "kodeKECAMATAN": 6311041,
        "kodeKABUPATEN": 6311,
        "namaKECAMATAN": "PARINGIN SELATAN"
      },
      {
        "kodeKECAMATAN": 6311050,
        "kodeKABUPATEN": 6311,
        "namaKECAMATAN": "JUAI"
      },
      {
        "kodeKECAMATAN": 6311060,
        "kodeKABUPATEN": 6311,
        "namaKECAMATAN": "HALONG"
      },
      {
        "kodeKECAMATAN": 6371010,
        "kodeKABUPATEN": 6371,
        "namaKECAMATAN": "BANJARMASIN SELATAN"
      },
      {
        "kodeKECAMATAN": 6371020,
        "kodeKABUPATEN": 6371,
        "namaKECAMATAN": "BANJARMASIN TIMUR"
      },
      {
        "kodeKECAMATAN": 6371030,
        "kodeKABUPATEN": 6371,
        "namaKECAMATAN": "BANJARMASIN BARAT"
      },
      {
        "kodeKECAMATAN": 6371031,
        "kodeKABUPATEN": 6371,
        "namaKECAMATAN": "BANJARMASIN TENGAH"
      },
      {
        "kodeKECAMATAN": 6371040,
        "kodeKABUPATEN": 6371,
        "namaKECAMATAN": "BANJARMASIN UTARA"
      },
      {
        "kodeKECAMATAN": 6372010,
        "kodeKABUPATEN": 6372,
        "namaKECAMATAN": "LANDASAN ULIN"
      },
      {
        "kodeKECAMATAN": 6372011,
        "kodeKABUPATEN": 6372,
        "namaKECAMATAN": "LIANG ANGGANG"
      },
      {
        "kodeKECAMATAN": 6372020,
        "kodeKABUPATEN": 6372,
        "namaKECAMATAN": "CEMPAKA"
      },
      {
        "kodeKECAMATAN": 6372031,
        "kodeKABUPATEN": 6372,
        "namaKECAMATAN": "BANJAR BARU UTARA"
      },
      {
        "kodeKECAMATAN": 6372032,
        "kodeKABUPATEN": 6372,
        "namaKECAMATAN": "BANJAR BARU SELATAN"
      },
      {
        "kodeKECAMATAN": 6401010,
        "kodeKABUPATEN": 6401,
        "namaKECAMATAN": "BATU SOPANG"
      },
      {
        "kodeKECAMATAN": 6401011,
        "kodeKABUPATEN": 6401,
        "namaKECAMATAN": "MUARA SAMU"
      },
      {
        "kodeKECAMATAN": 6401021,
        "kodeKABUPATEN": 6401,
        "namaKECAMATAN": "BATU ENGAU"
      },
      {
        "kodeKECAMATAN": 6401022,
        "kodeKABUPATEN": 6401,
        "namaKECAMATAN": "TANJUNG HARAPAN"
      },
      {
        "kodeKECAMATAN": 6401030,
        "kodeKABUPATEN": 6401,
        "namaKECAMATAN": "PASIR BELENGKONG"
      },
      {
        "kodeKECAMATAN": 6401040,
        "kodeKABUPATEN": 6401,
        "namaKECAMATAN": "TANAH GROGOT"
      },
      {
        "kodeKECAMATAN": 6401050,
        "kodeKABUPATEN": 6401,
        "namaKECAMATAN": "KUARO"
      },
      {
        "kodeKECAMATAN": 6401060,
        "kodeKABUPATEN": 6401,
        "namaKECAMATAN": "LONG IKIS"
      },
      {
        "kodeKECAMATAN": 6401070,
        "kodeKABUPATEN": 6401,
        "namaKECAMATAN": "MUARA KOMAM"
      },
      {
        "kodeKECAMATAN": 6401080,
        "kodeKABUPATEN": 6401,
        "namaKECAMATAN": "LONG KALI"
      },
      {
        "kodeKECAMATAN": 6402010,
        "kodeKABUPATEN": 6402,
        "namaKECAMATAN": "BONGAN"
      },
      {
        "kodeKECAMATAN": 6402020,
        "kodeKABUPATEN": 6402,
        "namaKECAMATAN": "JEMPANG"
      },
      {
        "kodeKECAMATAN": 6402030,
        "kodeKABUPATEN": 6402,
        "namaKECAMATAN": "PENYINGGAHAN"
      },
      {
        "kodeKECAMATAN": 6402040,
        "kodeKABUPATEN": 6402,
        "namaKECAMATAN": "MUARA PAHU"
      },
      {
        "kodeKECAMATAN": 6402041,
        "kodeKABUPATEN": 6402,
        "namaKECAMATAN": "SILUQ NGURAI"
      },
      {
        "kodeKECAMATAN": 6402050,
        "kodeKABUPATEN": 6402,
        "namaKECAMATAN": "MUARA LAWA"
      },
      {
        "kodeKECAMATAN": 6402051,
        "kodeKABUPATEN": 6402,
        "namaKECAMATAN": "BENTIAN BESAR"
      },
      {
        "kodeKECAMATAN": 6402060,
        "kodeKABUPATEN": 6402,
        "namaKECAMATAN": "DAMAI"
      },
      {
        "kodeKECAMATAN": 6402061,
        "kodeKABUPATEN": 6402,
        "namaKECAMATAN": "NYUATAN"
      },
      {
        "kodeKECAMATAN": 6402070,
        "kodeKABUPATEN": 6402,
        "namaKECAMATAN": "BARONG TONGKOK"
      },
      {
        "kodeKECAMATAN": 6402071,
        "kodeKABUPATEN": 6402,
        "namaKECAMATAN": "LINGGANG BIGUNG"
      },
      {
        "kodeKECAMATAN": 6402080,
        "kodeKABUPATEN": 6402,
        "namaKECAMATAN": "MELAK"
      },
      {
        "kodeKECAMATAN": 6402081,
        "kodeKABUPATEN": 6402,
        "namaKECAMATAN": "SEKOLAQ DARAT"
      },
      {
        "kodeKECAMATAN": 6402082,
        "kodeKABUPATEN": 6402,
        "namaKECAMATAN": "MANOR BULATN"
      },
      {
        "kodeKECAMATAN": 6402090,
        "kodeKABUPATEN": 6402,
        "namaKECAMATAN": "LONG IRAM"
      },
      {
        "kodeKECAMATAN": 6402091,
        "kodeKABUPATEN": 6402,
        "namaKECAMATAN": "TERING"
      },
      {
        "kodeKECAMATAN": 6403010,
        "kodeKABUPATEN": 6403,
        "namaKECAMATAN": "SEMBOJA"
      },
      {
        "kodeKECAMATAN": 6403020,
        "kodeKABUPATEN": 6403,
        "namaKECAMATAN": "MUARA JAWA"
      },
      {
        "kodeKECAMATAN": 6403030,
        "kodeKABUPATEN": 6403,
        "namaKECAMATAN": "SANGA-SANGA"
      },
      {
        "kodeKECAMATAN": 6403040,
        "kodeKABUPATEN": 6403,
        "namaKECAMATAN": "LOA JANAN"
      },
      {
        "kodeKECAMATAN": 6403050,
        "kodeKABUPATEN": 6403,
        "namaKECAMATAN": "LOA KULU"
      },
      {
        "kodeKECAMATAN": 6403060,
        "kodeKABUPATEN": 6403,
        "namaKECAMATAN": "MUARA MUNTAI"
      },
      {
        "kodeKECAMATAN": 6403070,
        "kodeKABUPATEN": 6403,
        "namaKECAMATAN": "MUARA WIS"
      },
      {
        "kodeKECAMATAN": 6403080,
        "kodeKABUPATEN": 6403,
        "namaKECAMATAN": "KOTABANGUN"
      },
      {
        "kodeKECAMATAN": 6403090,
        "kodeKABUPATEN": 6403,
        "namaKECAMATAN": "TENGGARONG"
      },
      {
        "kodeKECAMATAN": 6403100,
        "kodeKABUPATEN": 6403,
        "namaKECAMATAN": "SEBULU"
      },
      {
        "kodeKECAMATAN": 6403110,
        "kodeKABUPATEN": 6403,
        "namaKECAMATAN": "TENGGARONG SEBERANG"
      },
      {
        "kodeKECAMATAN": 6403120,
        "kodeKABUPATEN": 6403,
        "namaKECAMATAN": "ANGGANA"
      },
      {
        "kodeKECAMATAN": 6403130,
        "kodeKABUPATEN": 6403,
        "namaKECAMATAN": "MUARA BADAK"
      },
      {
        "kodeKECAMATAN": 6403140,
        "kodeKABUPATEN": 6403,
        "namaKECAMATAN": "MARANG KAYU"
      },
      {
        "kodeKECAMATAN": 6403150,
        "kodeKABUPATEN": 6403,
        "namaKECAMATAN": "MUARA KAMAN"
      },
      {
        "kodeKECAMATAN": 6403160,
        "kodeKABUPATEN": 6403,
        "namaKECAMATAN": "KENOHAN"
      },
      {
        "kodeKECAMATAN": 6403170,
        "kodeKABUPATEN": 6403,
        "namaKECAMATAN": "KEMBANG JANGGUT"
      },
      {
        "kodeKECAMATAN": 6403180,
        "kodeKABUPATEN": 6403,
        "namaKECAMATAN": "TABANG"
      },
      {
        "kodeKECAMATAN": 6404010,
        "kodeKABUPATEN": 6404,
        "namaKECAMATAN": "MUARA ANCALONG"
      },
      {
        "kodeKECAMATAN": 6404011,
        "kodeKABUPATEN": 6404,
        "namaKECAMATAN": "BUSANG"
      },
      {
        "kodeKECAMATAN": 6404012,
        "kodeKABUPATEN": 6404,
        "namaKECAMATAN": "LONG MESANGAT"
      },
      {
        "kodeKECAMATAN": 6404020,
        "kodeKABUPATEN": 6404,
        "namaKECAMATAN": "MUARA WAHAU"
      },
      {
        "kodeKECAMATAN": 6404021,
        "kodeKABUPATEN": 6404,
        "namaKECAMATAN": "TELEN"
      },
      {
        "kodeKECAMATAN": 6404022,
        "kodeKABUPATEN": 6404,
        "namaKECAMATAN": "KONGBENG"
      },
      {
        "kodeKECAMATAN": 6404030,
        "kodeKABUPATEN": 6404,
        "namaKECAMATAN": "MUARA BENGKAL"
      },
      {
        "kodeKECAMATAN": 6404031,
        "kodeKABUPATEN": 6404,
        "namaKECAMATAN": "BATU AMPAR"
      },
      {
        "kodeKECAMATAN": 6404040,
        "kodeKABUPATEN": 6404,
        "namaKECAMATAN": "SANGATTA UTARA"
      },
      {
        "kodeKECAMATAN": 6404041,
        "kodeKABUPATEN": 6404,
        "namaKECAMATAN": "BENGALON"
      },
      {
        "kodeKECAMATAN": 6404042,
        "kodeKABUPATEN": 6404,
        "namaKECAMATAN": "TELUK PANDAN"
      },
      {
        "kodeKECAMATAN": 6404043,
        "kodeKABUPATEN": 6404,
        "namaKECAMATAN": "SANGATTA SELATAN"
      },
      {
        "kodeKECAMATAN": 6404044,
        "kodeKABUPATEN": 6404,
        "namaKECAMATAN": "RANTAU PULUNG"
      },
      {
        "kodeKECAMATAN": 6404050,
        "kodeKABUPATEN": 6404,
        "namaKECAMATAN": "SANGKULIRANG"
      },
      {
        "kodeKECAMATAN": 6404051,
        "kodeKABUPATEN": 6404,
        "namaKECAMATAN": "KALIORANG"
      },
      {
        "kodeKECAMATAN": 6404052,
        "kodeKABUPATEN": 6404,
        "namaKECAMATAN": "SANDARAN"
      },
      {
        "kodeKECAMATAN": 6404053,
        "kodeKABUPATEN": 6404,
        "namaKECAMATAN": "KAUBUN"
      },
      {
        "kodeKECAMATAN": 6404054,
        "kodeKABUPATEN": 6404,
        "namaKECAMATAN": "KARANGAN"
      },
      {
        "kodeKECAMATAN": 6405010,
        "kodeKABUPATEN": 6405,
        "namaKECAMATAN": "KELAY"
      },
      {
        "kodeKECAMATAN": 6405020,
        "kodeKABUPATEN": 6405,
        "namaKECAMATAN": "TALISAYAN"
      },
      {
        "kodeKECAMATAN": 6405021,
        "kodeKABUPATEN": 6405,
        "namaKECAMATAN": "TABALAR"
      },
      {
        "kodeKECAMATAN": 6405030,
        "kodeKABUPATEN": 6405,
        "namaKECAMATAN": "BIDUK BIDUK"
      },
      {
        "kodeKECAMATAN": 6405040,
        "kodeKABUPATEN": 6405,
        "namaKECAMATAN": "PULAU DERAWAN"
      },
      {
        "kodeKECAMATAN": 6405041,
        "kodeKABUPATEN": 6405,
        "namaKECAMATAN": "MARATUA"
      },
      {
        "kodeKECAMATAN": 6405050,
        "kodeKABUPATEN": 6405,
        "namaKECAMATAN": "SAMBALIUNG"
      },
      {
        "kodeKECAMATAN": 6405060,
        "kodeKABUPATEN": 6405,
        "namaKECAMATAN": "TANJUNG REDEB"
      },
      {
        "kodeKECAMATAN": 6405070,
        "kodeKABUPATEN": 6405,
        "namaKECAMATAN": "GUNUNG TABUR"
      },
      {
        "kodeKECAMATAN": 6405080,
        "kodeKABUPATEN": 6405,
        "namaKECAMATAN": "SEGAH"
      },
      {
        "kodeKECAMATAN": 6405090,
        "kodeKABUPATEN": 6405,
        "namaKECAMATAN": "TELUK BAYUR"
      },
      {
        "kodeKECAMATAN": 6405100,
        "kodeKABUPATEN": 6405,
        "namaKECAMATAN": "BATU PUTIH"
      },
      {
        "kodeKECAMATAN": 6405110,
        "kodeKABUPATEN": 6405,
        "namaKECAMATAN": "BIATAN"
      },
      {
        "kodeKECAMATAN": 6409010,
        "kodeKABUPATEN": 6409,
        "namaKECAMATAN": "BABULU"
      },
      {
        "kodeKECAMATAN": 6409020,
        "kodeKABUPATEN": 6409,
        "namaKECAMATAN": "WARU"
      },
      {
        "kodeKECAMATAN": 6409030,
        "kodeKABUPATEN": 6409,
        "namaKECAMATAN": "PENAJAM"
      },
      {
        "kodeKECAMATAN": 6409040,
        "kodeKABUPATEN": 6409,
        "namaKECAMATAN": "SEPAKU"
      },
      {
        "kodeKECAMATAN": 6411010,
        "kodeKABUPATEN": 6411,
        "namaKECAMATAN": "LAHAM"
      },
      {
        "kodeKECAMATAN": 6411020,
        "kodeKABUPATEN": 6411,
        "namaKECAMATAN": "LONG HUBUNG"
      },
      {
        "kodeKECAMATAN": 6411030,
        "kodeKABUPATEN": 6411,
        "namaKECAMATAN": "LONG BAGUN"
      },
      {
        "kodeKECAMATAN": 6411040,
        "kodeKABUPATEN": 6411,
        "namaKECAMATAN": "LONG PAHANGAI"
      },
      {
        "kodeKECAMATAN": 6411050,
        "kodeKABUPATEN": 6411,
        "namaKECAMATAN": "LONG APARI"
      },
      {
        "kodeKECAMATAN": 6471010,
        "kodeKABUPATEN": 6471,
        "namaKECAMATAN": "BALIKPAPAN SELATAN"
      },
      {
        "kodeKECAMATAN": 6471011,
        "kodeKABUPATEN": 6471,
        "namaKECAMATAN": "BALIKPAPAN KOTA"
      },
      {
        "kodeKECAMATAN": 6471020,
        "kodeKABUPATEN": 6471,
        "namaKECAMATAN": "BALIKPAPAN TIMUR"
      },
      {
        "kodeKECAMATAN": 6471030,
        "kodeKABUPATEN": 6471,
        "namaKECAMATAN": "BALIKPAPAN UTARA"
      },
      {
        "kodeKECAMATAN": 6471040,
        "kodeKABUPATEN": 6471,
        "namaKECAMATAN": "BALIKPAPAN TENGAH"
      },
      {
        "kodeKECAMATAN": 6471050,
        "kodeKABUPATEN": 6471,
        "namaKECAMATAN": "BALIKPAPAN BARAT"
      },
      {
        "kodeKECAMATAN": 6472010,
        "kodeKABUPATEN": 6472,
        "namaKECAMATAN": "PALARAN"
      },
      {
        "kodeKECAMATAN": 6472020,
        "kodeKABUPATEN": 6472,
        "namaKECAMATAN": "SAMARINDA ILIR"
      },
      {
        "kodeKECAMATAN": 6472021,
        "kodeKABUPATEN": 6472,
        "namaKECAMATAN": "SAMARINDA KOTA"
      },
      {
        "kodeKECAMATAN": 6472022,
        "kodeKABUPATEN": 6472,
        "namaKECAMATAN": "SAMBUTAN"
      },
      {
        "kodeKECAMATAN": 6472030,
        "kodeKABUPATEN": 6472,
        "namaKECAMATAN": "SAMARINDA SEBERANG"
      },
      {
        "kodeKECAMATAN": 6472031,
        "kodeKABUPATEN": 6472,
        "namaKECAMATAN": "LOA JANAN ILIR"
      },
      {
        "kodeKECAMATAN": 6472040,
        "kodeKABUPATEN": 6472,
        "namaKECAMATAN": "SUNGAI KUNJANG"
      },
      {
        "kodeKECAMATAN": 6472050,
        "kodeKABUPATEN": 6472,
        "namaKECAMATAN": "SAMARINDA ULU"
      },
      {
        "kodeKECAMATAN": 6472060,
        "kodeKABUPATEN": 6472,
        "namaKECAMATAN": "SAMARINDA UTARA"
      },
      {
        "kodeKECAMATAN": 6472061,
        "kodeKABUPATEN": 6472,
        "namaKECAMATAN": "SUNGAI PINANG"
      },
      {
        "kodeKECAMATAN": 6474010,
        "kodeKABUPATEN": 6474,
        "namaKECAMATAN": "BONTANG SELATAN"
      },
      {
        "kodeKECAMATAN": 6474020,
        "kodeKABUPATEN": 6474,
        "namaKECAMATAN": "BONTANG UTARA"
      },
      {
        "kodeKECAMATAN": 6474030,
        "kodeKABUPATEN": 6474,
        "namaKECAMATAN": "BONTANG BARAT"
      },
      {
        "kodeKECAMATAN": 6501010,
        "kodeKABUPATEN": 6501,
        "namaKECAMATAN": "SUNGAI BOH"
      },
      {
        "kodeKECAMATAN": 6501020,
        "kodeKABUPATEN": 6501,
        "namaKECAMATAN": "KAYAN SELATAN"
      },
      {
        "kodeKECAMATAN": 6501030,
        "kodeKABUPATEN": 6501,
        "namaKECAMATAN": "KAYAN HULU"
      },
      {
        "kodeKECAMATAN": 6501040,
        "kodeKABUPATEN": 6501,
        "namaKECAMATAN": "KAYAN HILIR"
      },
      {
        "kodeKECAMATAN": 6501050,
        "kodeKABUPATEN": 6501,
        "namaKECAMATAN": "PUJUNGAN"
      },
      {
        "kodeKECAMATAN": 6501060,
        "kodeKABUPATEN": 6501,
        "namaKECAMATAN": "BAHAU HULU"
      },
      {
        "kodeKECAMATAN": 6501070,
        "kodeKABUPATEN": 6501,
        "namaKECAMATAN": "SUNGAI TUBU"
      },
      {
        "kodeKECAMATAN": 6501080,
        "kodeKABUPATEN": 6501,
        "namaKECAMATAN": "MALINAU SELATAN HULU"
      },
      {
        "kodeKECAMATAN": 6501090,
        "kodeKABUPATEN": 6501,
        "namaKECAMATAN": "MALINAU SELATAN"
      },
      {
        "kodeKECAMATAN": 6501100,
        "kodeKABUPATEN": 6501,
        "namaKECAMATAN": "MALINAU SELATAN HILIR"
      },
      {
        "kodeKECAMATAN": 6501110,
        "kodeKABUPATEN": 6501,
        "namaKECAMATAN": "MENTARANG"
      },
      {
        "kodeKECAMATAN": 6501120,
        "kodeKABUPATEN": 6501,
        "namaKECAMATAN": "MENTARANG HULU"
      },
      {
        "kodeKECAMATAN": 6501130,
        "kodeKABUPATEN": 6501,
        "namaKECAMATAN": "MALINAU UTARA"
      },
      {
        "kodeKECAMATAN": 6501140,
        "kodeKABUPATEN": 6501,
        "namaKECAMATAN": "MALINAU BARAT"
      },
      {
        "kodeKECAMATAN": 6501150,
        "kodeKABUPATEN": 6501,
        "namaKECAMATAN": "MALINAU KOTA"
      },
      {
        "kodeKECAMATAN": 6502010,
        "kodeKABUPATEN": 6502,
        "namaKECAMATAN": "PESO"
      },
      {
        "kodeKECAMATAN": 6502020,
        "kodeKABUPATEN": 6502,
        "namaKECAMATAN": "PESO HILIR"
      },
      {
        "kodeKECAMATAN": 6502030,
        "kodeKABUPATEN": 6502,
        "namaKECAMATAN": "TANJUNG PALAS BARAT"
      },
      {
        "kodeKECAMATAN": 6502040,
        "kodeKABUPATEN": 6502,
        "namaKECAMATAN": "TANJUNG PALAS"
      },
      {
        "kodeKECAMATAN": 6502050,
        "kodeKABUPATEN": 6502,
        "namaKECAMATAN": "TANJUNG SELOR"
      },
      {
        "kodeKECAMATAN": 6502060,
        "kodeKABUPATEN": 6502,
        "namaKECAMATAN": "TANJUNG PALAS TIMUR"
      },
      {
        "kodeKECAMATAN": 6502070,
        "kodeKABUPATEN": 6502,
        "namaKECAMATAN": "TANJUNG PALAS TENGAH"
      },
      {
        "kodeKECAMATAN": 6502080,
        "kodeKABUPATEN": 6502,
        "namaKECAMATAN": "TANJUNG PALAS UTARA"
      },
      {
        "kodeKECAMATAN": 6502090,
        "kodeKABUPATEN": 6502,
        "namaKECAMATAN": "SEKATAK"
      },
      {
        "kodeKECAMATAN": 6502100,
        "kodeKABUPATEN": 6502,
        "namaKECAMATAN": "BUNYU"
      },
      {
        "kodeKECAMATAN": 6503010,
        "kodeKABUPATEN": 6503,
        "namaKECAMATAN": "MURUK RIAN"
      },
      {
        "kodeKECAMATAN": 6503020,
        "kodeKABUPATEN": 6503,
        "namaKECAMATAN": "SESAYAP"
      },
      {
        "kodeKECAMATAN": 6503030,
        "kodeKABUPATEN": 6503,
        "namaKECAMATAN": "BETAYAU"
      },
      {
        "kodeKECAMATAN": 6503040,
        "kodeKABUPATEN": 6503,
        "namaKECAMATAN": "SESAYAP HILIR"
      },
      {
        "kodeKECAMATAN": 6503050,
        "kodeKABUPATEN": 6503,
        "namaKECAMATAN": "TANA LIA"
      },
      {
        "kodeKECAMATAN": 6504010,
        "kodeKABUPATEN": 6504,
        "namaKECAMATAN": "KRAYAN SELATAN"
      },
      {
        "kodeKECAMATAN": 6504020,
        "kodeKABUPATEN": 6504,
        "namaKECAMATAN": "KRAYAN"
      },
      {
        "kodeKECAMATAN": 6504030,
        "kodeKABUPATEN": 6504,
        "namaKECAMATAN": "LUMBIS OGONG"
      },
      {
        "kodeKECAMATAN": 6504040,
        "kodeKABUPATEN": 6504,
        "namaKECAMATAN": "LUMBIS"
      },
      {
        "kodeKECAMATAN": 6504050,
        "kodeKABUPATEN": 6504,
        "namaKECAMATAN": "SEMBAKUNG ATULAI"
      },
      {
        "kodeKECAMATAN": 6504060,
        "kodeKABUPATEN": 6504,
        "namaKECAMATAN": "SEMBAKUNG"
      },
      {
        "kodeKECAMATAN": 6504070,
        "kodeKABUPATEN": 6504,
        "namaKECAMATAN": "SEBUKU"
      },
      {
        "kodeKECAMATAN": 6504080,
        "kodeKABUPATEN": 6504,
        "namaKECAMATAN": "TULIN ONSOI"
      },
      {
        "kodeKECAMATAN": 6504090,
        "kodeKABUPATEN": 6504,
        "namaKECAMATAN": "SEI MENGGARIS"
      },
      {
        "kodeKECAMATAN": 6504100,
        "kodeKABUPATEN": 6504,
        "namaKECAMATAN": "NUNUKAN"
      },
      {
        "kodeKECAMATAN": 6504110,
        "kodeKABUPATEN": 6504,
        "namaKECAMATAN": "NUNUKAN SELATAN"
      },
      {
        "kodeKECAMATAN": 6504120,
        "kodeKABUPATEN": 6504,
        "namaKECAMATAN": "SEBATIK BARAT"
      },
      {
        "kodeKECAMATAN": 6504130,
        "kodeKABUPATEN": 6504,
        "namaKECAMATAN": "SEBATIK"
      },
      {
        "kodeKECAMATAN": 6504140,
        "kodeKABUPATEN": 6504,
        "namaKECAMATAN": "SEBATIK TIMUR"
      },
      {
        "kodeKECAMATAN": 6504150,
        "kodeKABUPATEN": 6504,
        "namaKECAMATAN": "SEBATIK TENGAH"
      },
      {
        "kodeKECAMATAN": 6504160,
        "kodeKABUPATEN": 6504,
        "namaKECAMATAN": "SEBATIK UTARA"
      },
      {
        "kodeKECAMATAN": 6571010,
        "kodeKABUPATEN": 6571,
        "namaKECAMATAN": "TARAKAN TIMUR"
      },
      {
        "kodeKECAMATAN": 6571020,
        "kodeKABUPATEN": 6571,
        "namaKECAMATAN": "TARAKAN TENGAH"
      },
      {
        "kodeKECAMATAN": 6571030,
        "kodeKABUPATEN": 6571,
        "namaKECAMATAN": "TARAKAN BARAT"
      },
      {
        "kodeKECAMATAN": 6571040,
        "kodeKABUPATEN": 6571,
        "namaKECAMATAN": "TARAKAN UTARA"
      },
      {
        "kodeKECAMATAN": 7101021,
        "kodeKABUPATEN": 7101,
        "namaKECAMATAN": "DUMOGA BARAT"
      },
      {
        "kodeKECAMATAN": 7101022,
        "kodeKABUPATEN": 7101,
        "namaKECAMATAN": "DUMOGA UTARA"
      },
      {
        "kodeKECAMATAN": 7101023,
        "kodeKABUPATEN": 7101,
        "namaKECAMATAN": "DUMOGA TIMUR"
      },
      {
        "kodeKECAMATAN": 7101024,
        "kodeKABUPATEN": 7101,
        "namaKECAMATAN": "DUMOGA TENGAH"
      },
      {
        "kodeKECAMATAN": 7101025,
        "kodeKABUPATEN": 7101,
        "namaKECAMATAN": "DUMOGA TENGGARA"
      },
      {
        "kodeKECAMATAN": 7101026,
        "kodeKABUPATEN": 7101,
        "namaKECAMATAN": "DUMOGA"
      },
      {
        "kodeKECAMATAN": 7101060,
        "kodeKABUPATEN": 7101,
        "namaKECAMATAN": "LOLAYAN"
      },
      {
        "kodeKECAMATAN": 7101081,
        "kodeKABUPATEN": 7101,
        "namaKECAMATAN": "PASSI BARAT"
      },
      {
        "kodeKECAMATAN": 7101082,
        "kodeKABUPATEN": 7101,
        "namaKECAMATAN": "PASSI TIMUR"
      },
      {
        "kodeKECAMATAN": 7101083,
        "kodeKABUPATEN": 7101,
        "namaKECAMATAN": "BILALANG"
      },
      {
        "kodeKECAMATAN": 7101090,
        "kodeKABUPATEN": 7101,
        "namaKECAMATAN": "POIGAR"
      },
      {
        "kodeKECAMATAN": 7101100,
        "kodeKABUPATEN": 7101,
        "namaKECAMATAN": "BOLAANG"
      },
      {
        "kodeKECAMATAN": 7101101,
        "kodeKABUPATEN": 7101,
        "namaKECAMATAN": "BOLAANG TIMUR"
      },
      {
        "kodeKECAMATAN": 7101110,
        "kodeKABUPATEN": 7101,
        "namaKECAMATAN": "LOLAK"
      },
      {
        "kodeKECAMATAN": 7101120,
        "kodeKABUPATEN": 7101,
        "namaKECAMATAN": "SANGTOMBOLANG"
      },
      {
        "kodeKECAMATAN": 7102091,
        "kodeKABUPATEN": 7102,
        "namaKECAMATAN": "LANGOWAN TIMUR"
      },
      {
        "kodeKECAMATAN": 7102092,
        "kodeKABUPATEN": 7102,
        "namaKECAMATAN": "LANGOWAN BARAT"
      },
      {
        "kodeKECAMATAN": 7102093,
        "kodeKABUPATEN": 7102,
        "namaKECAMATAN": "LANGOWAN SELATAN"
      },
      {
        "kodeKECAMATAN": 7102094,
        "kodeKABUPATEN": 7102,
        "namaKECAMATAN": "LANGOWAN UTARA"
      },
      {
        "kodeKECAMATAN": 7102110,
        "kodeKABUPATEN": 7102,
        "namaKECAMATAN": "TOMPASO"
      },
      {
        "kodeKECAMATAN": 7102111,
        "kodeKABUPATEN": 7102,
        "namaKECAMATAN": "TOMPASO BARAT"
      },
      {
        "kodeKECAMATAN": 7102120,
        "kodeKABUPATEN": 7102,
        "namaKECAMATAN": "KAWANGKOAN"
      },
      {
        "kodeKECAMATAN": 7102121,
        "kodeKABUPATEN": 7102,
        "namaKECAMATAN": "KAWANGKOAN BARAT"
      },
      {
        "kodeKECAMATAN": 7102122,
        "kodeKABUPATEN": 7102,
        "namaKECAMATAN": "KAWANGKOAN UTARA"
      },
      {
        "kodeKECAMATAN": 7102130,
        "kodeKABUPATEN": 7102,
        "namaKECAMATAN": "SONDER"
      },
      {
        "kodeKECAMATAN": 7102160,
        "kodeKABUPATEN": 7102,
        "namaKECAMATAN": "TOMBARIRI"
      },
      {
        "kodeKECAMATAN": 7102161,
        "kodeKABUPATEN": 7102,
        "namaKECAMATAN": "TOMBARIRI TIMUR"
      },
      {
        "kodeKECAMATAN": 7102170,
        "kodeKABUPATEN": 7102,
        "namaKECAMATAN": "PINELENG"
      },
      {
        "kodeKECAMATAN": 7102171,
        "kodeKABUPATEN": 7102,
        "namaKECAMATAN": "TOMBULU"
      },
      {
        "kodeKECAMATAN": 7102172,
        "kodeKABUPATEN": 7102,
        "namaKECAMATAN": "MANDOLANG"
      },
      {
        "kodeKECAMATAN": 7102190,
        "kodeKABUPATEN": 7102,
        "namaKECAMATAN": "TONDANO BARAT"
      },
      {
        "kodeKECAMATAN": 7102191,
        "kodeKABUPATEN": 7102,
        "namaKECAMATAN": "TONDANO SELATAN"
      },
      {
        "kodeKECAMATAN": 7102200,
        "kodeKABUPATEN": 7102,
        "namaKECAMATAN": "REMBOKEN"
      },
      {
        "kodeKECAMATAN": 7102210,
        "kodeKABUPATEN": 7102,
        "namaKECAMATAN": "KAKAS"
      },
      {
        "kodeKECAMATAN": 7102211,
        "kodeKABUPATEN": 7102,
        "namaKECAMATAN": "KAKAS BARAT"
      },
      {
        "kodeKECAMATAN": 7102220,
        "kodeKABUPATEN": 7102,
        "namaKECAMATAN": "LEMBEAN TIMUR"
      },
      {
        "kodeKECAMATAN": 7102230,
        "kodeKABUPATEN": 7102,
        "namaKECAMATAN": "ERIS"
      },
      {
        "kodeKECAMATAN": 7102240,
        "kodeKABUPATEN": 7102,
        "namaKECAMATAN": "KOMBI"
      },
      {
        "kodeKECAMATAN": 7102250,
        "kodeKABUPATEN": 7102,
        "namaKECAMATAN": "TONDANO TIMUR"
      },
      {
        "kodeKECAMATAN": 7102251,
        "kodeKABUPATEN": 7102,
        "namaKECAMATAN": "TONDANO UTARA"
      },
      {
        "kodeKECAMATAN": 7103040,
        "kodeKABUPATEN": 7103,
        "namaKECAMATAN": "MANGANITU SELATAN"
      },
      {
        "kodeKECAMATAN": 7103041,
        "kodeKABUPATEN": 7103,
        "namaKECAMATAN": "TATOARENG"
      },
      {
        "kodeKECAMATAN": 7103050,
        "kodeKABUPATEN": 7103,
        "namaKECAMATAN": "TAMAKO"
      },
      {
        "kodeKECAMATAN": 7103060,
        "kodeKABUPATEN": 7103,
        "namaKECAMATAN": "TABUKAN SELATAN"
      },
      {
        "kodeKECAMATAN": 7103061,
        "kodeKABUPATEN": 7103,
        "namaKECAMATAN": "TABUKAN SELATAN TENGAH"
      },
      {
        "kodeKECAMATAN": 7103062,
        "kodeKABUPATEN": 7103,
        "namaKECAMATAN": "TABUKAN SELATAN TENGGARA"
      },
      {
        "kodeKECAMATAN": 7103070,
        "kodeKABUPATEN": 7103,
        "namaKECAMATAN": "TABUKAN TENGAH"
      },
      {
        "kodeKECAMATAN": 7103080,
        "kodeKABUPATEN": 7103,
        "namaKECAMATAN": "MANGANITU"
      },
      {
        "kodeKECAMATAN": 7103090,
        "kodeKABUPATEN": 7103,
        "namaKECAMATAN": "TAHUNA"
      },
      {
        "kodeKECAMATAN": 7103091,
        "kodeKABUPATEN": 7103,
        "namaKECAMATAN": "TAHUNA TIMUR"
      },
      {
        "kodeKECAMATAN": 7103092,
        "kodeKABUPATEN": 7103,
        "namaKECAMATAN": "TAHUNA BARAT"
      },
      {
        "kodeKECAMATAN": 7103100,
        "kodeKABUPATEN": 7103,
        "namaKECAMATAN": "TABUKAN UTARA"
      },
      {
        "kodeKECAMATAN": 7103101,
        "kodeKABUPATEN": 7103,
        "namaKECAMATAN": "NUSA TABUKAN"
      },
      {
        "kodeKECAMATAN": 7103102,
        "kodeKABUPATEN": 7103,
        "namaKECAMATAN": "KEPULAUAN MARORE"
      },
      {
        "kodeKECAMATAN": 7103110,
        "kodeKABUPATEN": 7103,
        "namaKECAMATAN": "KENDAHE"
      },
      {
        "kodeKECAMATAN": 7104010,
        "kodeKABUPATEN": 7104,
        "namaKECAMATAN": "KABARUAN"
      },
      {
        "kodeKECAMATAN": 7104011,
        "kodeKABUPATEN": 7104,
        "namaKECAMATAN": "DAMAU"
      },
      {
        "kodeKECAMATAN": 7104020,
        "kodeKABUPATEN": 7104,
        "namaKECAMATAN": "LIRUNG"
      },
      {
        "kodeKECAMATAN": 7104021,
        "kodeKABUPATEN": 7104,
        "namaKECAMATAN": "SALIBABU"
      },
      {
        "kodeKECAMATAN": 7104022,
        "kodeKABUPATEN": 7104,
        "namaKECAMATAN": "KALONGAN"
      },
      {
        "kodeKECAMATAN": 7104023,
        "kodeKABUPATEN": 7104,
        "namaKECAMATAN": "MORONGE"
      },
      {
        "kodeKECAMATAN": 7104030,
        "kodeKABUPATEN": 7104,
        "namaKECAMATAN": "MELONGUANE"
      },
      {
        "kodeKECAMATAN": 7104031,
        "kodeKABUPATEN": 7104,
        "namaKECAMATAN": "MELONGUANE TIMUR"
      },
      {
        "kodeKECAMATAN": 7104040,
        "kodeKABUPATEN": 7104,
        "namaKECAMATAN": "BEO"
      },
      {
        "kodeKECAMATAN": 7104041,
        "kodeKABUPATEN": 7104,
        "namaKECAMATAN": "BEO UTARA"
      },
      {
        "kodeKECAMATAN": 7104042,
        "kodeKABUPATEN": 7104,
        "namaKECAMATAN": "BEO SELATAN"
      },
      {
        "kodeKECAMATAN": 7104050,
        "kodeKABUPATEN": 7104,
        "namaKECAMATAN": "RAINIS"
      },
      {
        "kodeKECAMATAN": 7104051,
        "kodeKABUPATEN": 7104,
        "namaKECAMATAN": "TAMPA NA'MMA"
      },
      {
        "kodeKECAMATAN": 7104052,
        "kodeKABUPATEN": 7104,
        "namaKECAMATAN": "PULUTAN"
      },
      {
        "kodeKECAMATAN": 7104060,
        "kodeKABUPATEN": 7104,
        "namaKECAMATAN": "ESSANG"
      },
      {
        "kodeKECAMATAN": 7104061,
        "kodeKABUPATEN": 7104,
        "namaKECAMATAN": "ESSANG SELATAN"
      },
      {
        "kodeKECAMATAN": 7104070,
        "kodeKABUPATEN": 7104,
        "namaKECAMATAN": "GEMEH"
      },
      {
        "kodeKECAMATAN": 7104080,
        "kodeKABUPATEN": 7104,
        "namaKECAMATAN": "NANUSA"
      },
      {
        "kodeKECAMATAN": 7104081,
        "kodeKABUPATEN": 7104,
        "namaKECAMATAN": "MIANGAS"
      },
      {
        "kodeKECAMATAN": 7105010,
        "kodeKABUPATEN": 7105,
        "namaKECAMATAN": "MODOINDING"
      },
      {
        "kodeKECAMATAN": 7105020,
        "kodeKABUPATEN": 7105,
        "namaKECAMATAN": "TOMPASO BARU"
      },
      {
        "kodeKECAMATAN": 7105021,
        "kodeKABUPATEN": 7105,
        "namaKECAMATAN": "MAESAAN"
      },
      {
        "kodeKECAMATAN": 7105070,
        "kodeKABUPATEN": 7105,
        "namaKECAMATAN": "RANOYAPO"
      },
      {
        "kodeKECAMATAN": 7105080,
        "kodeKABUPATEN": 7105,
        "namaKECAMATAN": "MOTOLING"
      },
      {
        "kodeKECAMATAN": 7105081,
        "kodeKABUPATEN": 7105,
        "namaKECAMATAN": "KUMELEMBUAI"
      },
      {
        "kodeKECAMATAN": 7105082,
        "kodeKABUPATEN": 7105,
        "namaKECAMATAN": "MOTOLING BARAT"
      },
      {
        "kodeKECAMATAN": 7105083,
        "kodeKABUPATEN": 7105,
        "namaKECAMATAN": "MOTOLING TIMUR"
      },
      {
        "kodeKECAMATAN": 7105090,
        "kodeKABUPATEN": 7105,
        "namaKECAMATAN": "SINONSAYANG"
      },
      {
        "kodeKECAMATAN": 7105100,
        "kodeKABUPATEN": 7105,
        "namaKECAMATAN": "TENGA"
      },
      {
        "kodeKECAMATAN": 7105111,
        "kodeKABUPATEN": 7105,
        "namaKECAMATAN": "AMURANG"
      },
      {
        "kodeKECAMATAN": 7105112,
        "kodeKABUPATEN": 7105,
        "namaKECAMATAN": "AMURANG BARAT"
      },
      {
        "kodeKECAMATAN": 7105113,
        "kodeKABUPATEN": 7105,
        "namaKECAMATAN": "AMURANG TIMUR"
      },
      {
        "kodeKECAMATAN": 7105120,
        "kodeKABUPATEN": 7105,
        "namaKECAMATAN": "TARERAN"
      },
      {
        "kodeKECAMATAN": 7105121,
        "kodeKABUPATEN": 7105,
        "namaKECAMATAN": "SULTA"
      },
      {
        "kodeKECAMATAN": 7105130,
        "kodeKABUPATEN": 7105,
        "namaKECAMATAN": "TUMPAAN"
      },
      {
        "kodeKECAMATAN": 7105131,
        "kodeKABUPATEN": 7105,
        "namaKECAMATAN": "TATAPAAN"
      },
      {
        "kodeKECAMATAN": 7106010,
        "kodeKABUPATEN": 7106,
        "namaKECAMATAN": "KEMA"
      },
      {
        "kodeKECAMATAN": 7106020,
        "kodeKABUPATEN": 7106,
        "namaKECAMATAN": "KAUDITAN"
      },
      {
        "kodeKECAMATAN": 7106030,
        "kodeKABUPATEN": 7106,
        "namaKECAMATAN": "AIRMADIDI"
      },
      {
        "kodeKECAMATAN": 7106040,
        "kodeKABUPATEN": 7106,
        "namaKECAMATAN": "KALAWAT"
      },
      {
        "kodeKECAMATAN": 7106050,
        "kodeKABUPATEN": 7106,
        "namaKECAMATAN": "DIMEMBE"
      },
      {
        "kodeKECAMATAN": 7106051,
        "kodeKABUPATEN": 7106,
        "namaKECAMATAN": "TALAWAAN"
      },
      {
        "kodeKECAMATAN": 7106060,
        "kodeKABUPATEN": 7106,
        "namaKECAMATAN": "WORI"
      },
      {
        "kodeKECAMATAN": 7106070,
        "kodeKABUPATEN": 7106,
        "namaKECAMATAN": "LIKUPANG BARAT"
      },
      {
        "kodeKECAMATAN": 7106080,
        "kodeKABUPATEN": 7106,
        "namaKECAMATAN": "LIKUPANG TIMUR"
      },
      {
        "kodeKECAMATAN": 7106081,
        "kodeKABUPATEN": 7106,
        "namaKECAMATAN": "LIKUPANG SELATAN"
      },
      {
        "kodeKECAMATAN": 7107010,
        "kodeKABUPATEN": 7107,
        "namaKECAMATAN": "SANGKUB"
      },
      {
        "kodeKECAMATAN": 7107020,
        "kodeKABUPATEN": 7107,
        "namaKECAMATAN": "BINTAUNA"
      },
      {
        "kodeKECAMATAN": 7107030,
        "kodeKABUPATEN": 7107,
        "namaKECAMATAN": "BOLANG ITANG TIMUR"
      },
      {
        "kodeKECAMATAN": 7107040,
        "kodeKABUPATEN": 7107,
        "namaKECAMATAN": "BOLANG ITANG BARAT"
      },
      {
        "kodeKECAMATAN": 7107050,
        "kodeKABUPATEN": 7107,
        "namaKECAMATAN": "KAIDIPANG"
      },
      {
        "kodeKECAMATAN": 7107060,
        "kodeKABUPATEN": 7107,
        "namaKECAMATAN": "PINOGALUMAN"
      },
      {
        "kodeKECAMATAN": 7108010,
        "kodeKABUPATEN": 7108,
        "namaKECAMATAN": "BIARO"
      },
      {
        "kodeKECAMATAN": 7108020,
        "kodeKABUPATEN": 7108,
        "namaKECAMATAN": "TAGULANDANG SELATAN"
      },
      {
        "kodeKECAMATAN": 7108030,
        "kodeKABUPATEN": 7108,
        "namaKECAMATAN": "TAGULANDANG"
      },
      {
        "kodeKECAMATAN": 7108040,
        "kodeKABUPATEN": 7108,
        "namaKECAMATAN": "TAGULANDANG UTARA"
      },
      {
        "kodeKECAMATAN": 7108050,
        "kodeKABUPATEN": 7108,
        "namaKECAMATAN": "SIAU BARAT SELATAN"
      },
      {
        "kodeKECAMATAN": 7108060,
        "kodeKABUPATEN": 7108,
        "namaKECAMATAN": "SIAU TIMUR SELATAN"
      },
      {
        "kodeKECAMATAN": 7108070,
        "kodeKABUPATEN": 7108,
        "namaKECAMATAN": "SIAU BARAT"
      },
      {
        "kodeKECAMATAN": 7108080,
        "kodeKABUPATEN": 7108,
        "namaKECAMATAN": "SIAU TENGAH"
      },
      {
        "kodeKECAMATAN": 7108090,
        "kodeKABUPATEN": 7108,
        "namaKECAMATAN": "SIAU TIMUR"
      },
      {
        "kodeKECAMATAN": 7108100,
        "kodeKABUPATEN": 7108,
        "namaKECAMATAN": "SIAU BARAT UTARA"
      },
      {
        "kodeKECAMATAN": 7109010,
        "kodeKABUPATEN": 7109,
        "namaKECAMATAN": "RATATOTOK"
      },
      {
        "kodeKECAMATAN": 7109020,
        "kodeKABUPATEN": 7109,
        "namaKECAMATAN": "PUSOMAEN"
      },
      {
        "kodeKECAMATAN": 7109030,
        "kodeKABUPATEN": 7109,
        "namaKECAMATAN": "BELANG"
      },
      {
        "kodeKECAMATAN": 7109040,
        "kodeKABUPATEN": 7109,
        "namaKECAMATAN": "RATAHAN"
      },
      {
        "kodeKECAMATAN": 7109041,
        "kodeKABUPATEN": 7109,
        "namaKECAMATAN": "PASAN"
      },
      {
        "kodeKECAMATAN": 7109042,
        "kodeKABUPATEN": 7109,
        "namaKECAMATAN": "RATAHAN TIMUR"
      },
      {
        "kodeKECAMATAN": 7109050,
        "kodeKABUPATEN": 7109,
        "namaKECAMATAN": "TOMBATU"
      },
      {
        "kodeKECAMATAN": 7109051,
        "kodeKABUPATEN": 7109,
        "namaKECAMATAN": "TOMBATU TIMUR"
      },
      {
        "kodeKECAMATAN": 7109052,
        "kodeKABUPATEN": 7109,
        "namaKECAMATAN": "TOMBATU UTARA"
      },
      {
        "kodeKECAMATAN": 7109060,
        "kodeKABUPATEN": 7109,
        "namaKECAMATAN": "TOULUAAN"
      },
      {
        "kodeKECAMATAN": 7109061,
        "kodeKABUPATEN": 7109,
        "namaKECAMATAN": "TOULUAAN SELATAN"
      },
      {
        "kodeKECAMATAN": 7109062,
        "kodeKABUPATEN": 7109,
        "namaKECAMATAN": "SILIAN RAYA"
      },
      {
        "kodeKECAMATAN": 7110010,
        "kodeKABUPATEN": 7110,
        "namaKECAMATAN": "POSIGADAN"
      },
      {
        "kodeKECAMATAN": 7110020,
        "kodeKABUPATEN": 7110,
        "namaKECAMATAN": "BOLANG UKI"
      },
      {
        "kodeKECAMATAN": 7110021,
        "kodeKABUPATEN": 7110,
        "namaKECAMATAN": "HELUMO"
      },
      {
        "kodeKECAMATAN": 7110030,
        "kodeKABUPATEN": 7110,
        "namaKECAMATAN": "PINOLOSIAN"
      },
      {
        "kodeKECAMATAN": 7110040,
        "kodeKABUPATEN": 7110,
        "namaKECAMATAN": "PINOLOSIAN TENGAH"
      },
      {
        "kodeKECAMATAN": 7110050,
        "kodeKABUPATEN": 7110,
        "namaKECAMATAN": "PINOLOSIAN TIMUR"
      },
      {
        "kodeKECAMATAN": 7111010,
        "kodeKABUPATEN": 7111,
        "namaKECAMATAN": "NUANGAN"
      },
      {
        "kodeKECAMATAN": 7111020,
        "kodeKABUPATEN": 7111,
        "namaKECAMATAN": "TUTUYAN"
      },
      {
        "kodeKECAMATAN": 7111030,
        "kodeKABUPATEN": 7111,
        "namaKECAMATAN": "KOTABUNAN"
      },
      {
        "kodeKECAMATAN": 7111040,
        "kodeKABUPATEN": 7111,
        "namaKECAMATAN": "MODAYAG"
      },
      {
        "kodeKECAMATAN": 7111050,
        "kodeKABUPATEN": 7111,
        "namaKECAMATAN": "MODAYAG BARAT"
      },
      {
        "kodeKECAMATAN": 7171010,
        "kodeKABUPATEN": 7171,
        "namaKECAMATAN": "MALALAYANG"
      },
      {
        "kodeKECAMATAN": 7171020,
        "kodeKABUPATEN": 7171,
        "namaKECAMATAN": "SARIO"
      },
      {
        "kodeKECAMATAN": 7171021,
        "kodeKABUPATEN": 7171,
        "namaKECAMATAN": "WANEA"
      },
      {
        "kodeKECAMATAN": 7171030,
        "kodeKABUPATEN": 7171,
        "namaKECAMATAN": "WENANG"
      },
      {
        "kodeKECAMATAN": 7171031,
        "kodeKABUPATEN": 7171,
        "namaKECAMATAN": "TIKALA"
      },
      {
        "kodeKECAMATAN": 7171032,
        "kodeKABUPATEN": 7171,
        "namaKECAMATAN": "PAAL DUA"
      },
      {
        "kodeKECAMATAN": 7171040,
        "kodeKABUPATEN": 7171,
        "namaKECAMATAN": "MAPANGET"
      },
      {
        "kodeKECAMATAN": 7171051,
        "kodeKABUPATEN": 7171,
        "namaKECAMATAN": "SINGKIL"
      },
      {
        "kodeKECAMATAN": 7171052,
        "kodeKABUPATEN": 7171,
        "namaKECAMATAN": "TUMINTING"
      },
      {
        "kodeKECAMATAN": 7171053,
        "kodeKABUPATEN": 7171,
        "namaKECAMATAN": "BUNAKEN"
      },
      {
        "kodeKECAMATAN": 7171054,
        "kodeKABUPATEN": 7171,
        "namaKECAMATAN": "BUNAKEN KEPULAUAN"
      },
      {
        "kodeKECAMATAN": 7172010,
        "kodeKABUPATEN": 7172,
        "namaKECAMATAN": "MADIDIR"
      },
      {
        "kodeKECAMATAN": 7172011,
        "kodeKABUPATEN": 7172,
        "namaKECAMATAN": "MATUARI"
      },
      {
        "kodeKECAMATAN": 7172012,
        "kodeKABUPATEN": 7172,
        "namaKECAMATAN": "GIRIAN"
      },
      {
        "kodeKECAMATAN": 7172021,
        "kodeKABUPATEN": 7172,
        "namaKECAMATAN": "LEMBEH SELATAN"
      },
      {
        "kodeKECAMATAN": 7172022,
        "kodeKABUPATEN": 7172,
        "namaKECAMATAN": "LEMBEH UTARA"
      },
      {
        "kodeKECAMATAN": 7172030,
        "kodeKABUPATEN": 7172,
        "namaKECAMATAN": "AERTEMBAGA"
      },
      {
        "kodeKECAMATAN": 7172031,
        "kodeKABUPATEN": 7172,
        "namaKECAMATAN": "MAESA"
      },
      {
        "kodeKECAMATAN": 7172040,
        "kodeKABUPATEN": 7172,
        "namaKECAMATAN": "RANOWULU"
      },
      {
        "kodeKECAMATAN": 7173010,
        "kodeKABUPATEN": 7173,
        "namaKECAMATAN": "TOMOHON SELATAN"
      },
      {
        "kodeKECAMATAN": 7173020,
        "kodeKABUPATEN": 7173,
        "namaKECAMATAN": "TOMOHON TENGAH"
      },
      {
        "kodeKECAMATAN": 7173021,
        "kodeKABUPATEN": 7173,
        "namaKECAMATAN": "TOMOHON TIMUR"
      },
      {
        "kodeKECAMATAN": 7173022,
        "kodeKABUPATEN": 7173,
        "namaKECAMATAN": "TOMOHON BARAT"
      },
      {
        "kodeKECAMATAN": 7173030,
        "kodeKABUPATEN": 7173,
        "namaKECAMATAN": "TOMOHON UTARA"
      },
      {
        "kodeKECAMATAN": 7174010,
        "kodeKABUPATEN": 7174,
        "namaKECAMATAN": "KOTAMOBAGU SELATAN"
      },
      {
        "kodeKECAMATAN": 7174020,
        "kodeKABUPATEN": 7174,
        "namaKECAMATAN": "KOTAMOBAGU TIMUR"
      },
      {
        "kodeKECAMATAN": 7174030,
        "kodeKABUPATEN": 7174,
        "namaKECAMATAN": "KOTAMOBAGU BARAT"
      },
      {
        "kodeKECAMATAN": 7174040,
        "kodeKABUPATEN": 7174,
        "namaKECAMATAN": "KOTAMOBAGU UTARA"
      },
      {
        "kodeKECAMATAN": 7201030,
        "kodeKABUPATEN": 7201,
        "namaKECAMATAN": "TOTIKUM"
      },
      {
        "kodeKECAMATAN": 7201031,
        "kodeKABUPATEN": 7201,
        "namaKECAMATAN": "TOTIKUM SELATAN"
      },
      {
        "kodeKECAMATAN": 7201040,
        "kodeKABUPATEN": 7201,
        "namaKECAMATAN": "TINANGKUNG"
      },
      {
        "kodeKECAMATAN": 7201041,
        "kodeKABUPATEN": 7201,
        "namaKECAMATAN": "TINANGKUNG SELATAN"
      },
      {
        "kodeKECAMATAN": 7201042,
        "kodeKABUPATEN": 7201,
        "namaKECAMATAN": "TINANGKUNG UTARA"
      },
      {
        "kodeKECAMATAN": 7201050,
        "kodeKABUPATEN": 7201,
        "namaKECAMATAN": "LIANG"
      },
      {
        "kodeKECAMATAN": 7201051,
        "kodeKABUPATEN": 7201,
        "namaKECAMATAN": "PELING TENGAH"
      },
      {
        "kodeKECAMATAN": 7201060,
        "kodeKABUPATEN": 7201,
        "namaKECAMATAN": "BULAGI"
      },
      {
        "kodeKECAMATAN": 7201061,
        "kodeKABUPATEN": 7201,
        "namaKECAMATAN": "BULAGI SELATAN"
      },
      {
        "kodeKECAMATAN": 7201062,
        "kodeKABUPATEN": 7201,
        "namaKECAMATAN": "BULAGI UTARA"
      },
      {
        "kodeKECAMATAN": 7201070,
        "kodeKABUPATEN": 7201,
        "namaKECAMATAN": "BUKO"
      },
      {
        "kodeKECAMATAN": 7201071,
        "kodeKABUPATEN": 7201,
        "namaKECAMATAN": "BUKO SELATAN"
      },
      {
        "kodeKECAMATAN": 7202010,
        "kodeKABUPATEN": 7202,
        "namaKECAMATAN": "TOILI"
      },
      {
        "kodeKECAMATAN": 7202011,
        "kodeKABUPATEN": 7202,
        "namaKECAMATAN": "TOILI BARAT"
      },
      {
        "kodeKECAMATAN": 7202012,
        "kodeKABUPATEN": 7202,
        "namaKECAMATAN": "MOILONG"
      },
      {
        "kodeKECAMATAN": 7202020,
        "kodeKABUPATEN": 7202,
        "namaKECAMATAN": "BATUI"
      },
      {
        "kodeKECAMATAN": 7202021,
        "kodeKABUPATEN": 7202,
        "namaKECAMATAN": "BATUI SELATAN"
      },
      {
        "kodeKECAMATAN": 7202030,
        "kodeKABUPATEN": 7202,
        "namaKECAMATAN": "BUNTA"
      },
      {
        "kodeKECAMATAN": 7202031,
        "kodeKABUPATEN": 7202,
        "namaKECAMATAN": "NUHON"
      },
      {
        "kodeKECAMATAN": 7202032,
        "kodeKABUPATEN": 7202,
        "namaKECAMATAN": "SIMPANG RAYA"
      },
      {
        "kodeKECAMATAN": 7202040,
        "kodeKABUPATEN": 7202,
        "namaKECAMATAN": "KINTOM"
      },
      {
        "kodeKECAMATAN": 7202050,
        "kodeKABUPATEN": 7202,
        "namaKECAMATAN": "LUWUK"
      },
      {
        "kodeKECAMATAN": 7202051,
        "kodeKABUPATEN": 7202,
        "namaKECAMATAN": "LUWUK TIMUR"
      },
      {
        "kodeKECAMATAN": 7202052,
        "kodeKABUPATEN": 7202,
        "namaKECAMATAN": "LUWUK UTARA"
      },
      {
        "kodeKECAMATAN": 7202053,
        "kodeKABUPATEN": 7202,
        "namaKECAMATAN": "LUWUK SELATAN"
      },
      {
        "kodeKECAMATAN": 7202054,
        "kodeKABUPATEN": 7202,
        "namaKECAMATAN": "NAMBO"
      },
      {
        "kodeKECAMATAN": 7202060,
        "kodeKABUPATEN": 7202,
        "namaKECAMATAN": "PAGIMANA"
      },
      {
        "kodeKECAMATAN": 7202061,
        "kodeKABUPATEN": 7202,
        "namaKECAMATAN": "BUALEMO"
      },
      {
        "kodeKECAMATAN": 7202062,
        "kodeKABUPATEN": 7202,
        "namaKECAMATAN": "LOBU"
      },
      {
        "kodeKECAMATAN": 7202070,
        "kodeKABUPATEN": 7202,
        "namaKECAMATAN": "LAMALA"
      },
      {
        "kodeKECAMATAN": 7202071,
        "kodeKABUPATEN": 7202,
        "namaKECAMATAN": "MASAMA"
      },
      {
        "kodeKECAMATAN": 7202072,
        "kodeKABUPATEN": 7202,
        "namaKECAMATAN": "MANTOH"
      },
      {
        "kodeKECAMATAN": 7202080,
        "kodeKABUPATEN": 7202,
        "namaKECAMATAN": "BALANTAK"
      },
      {
        "kodeKECAMATAN": 7202081,
        "kodeKABUPATEN": 7202,
        "namaKECAMATAN": "BALANTAK SELATAN"
      },
      {
        "kodeKECAMATAN": 7202082,
        "kodeKABUPATEN": 7202,
        "namaKECAMATAN": "BALANTAK UTARA"
      },
      {
        "kodeKECAMATAN": 7203010,
        "kodeKABUPATEN": 7203,
        "namaKECAMATAN": "MENUI KEPULAUAN"
      },
      {
        "kodeKECAMATAN": 7203020,
        "kodeKABUPATEN": 7203,
        "namaKECAMATAN": "BUNGKU SELATAN"
      },
      {
        "kodeKECAMATAN": 7203021,
        "kodeKABUPATEN": 7203,
        "namaKECAMATAN": "BAHODOPI"
      },
      {
        "kodeKECAMATAN": 7203022,
        "kodeKABUPATEN": 7203,
        "namaKECAMATAN": "BUNGKU PESISIR"
      },
      {
        "kodeKECAMATAN": 7203030,
        "kodeKABUPATEN": 7203,
        "namaKECAMATAN": "BUNGKU TENGAH"
      },
      {
        "kodeKECAMATAN": 7203031,
        "kodeKABUPATEN": 7203,
        "namaKECAMATAN": "BUNGKU TIMUR"
      },
      {
        "kodeKECAMATAN": 7203040,
        "kodeKABUPATEN": 7203,
        "namaKECAMATAN": "BUNGKU BARAT"
      },
      {
        "kodeKECAMATAN": 7203041,
        "kodeKABUPATEN": 7203,
        "namaKECAMATAN": "BUMI RAYA"
      },
      {
        "kodeKECAMATAN": 7203042,
        "kodeKABUPATEN": 7203,
        "namaKECAMATAN": "WITA PONDA"
      },
      {
        "kodeKECAMATAN": 7204010,
        "kodeKABUPATEN": 7204,
        "namaKECAMATAN": "PAMONA SELATAN"
      },
      {
        "kodeKECAMATAN": 7204011,
        "kodeKABUPATEN": 7204,
        "namaKECAMATAN": "PAMONA BARAT"
      },
      {
        "kodeKECAMATAN": 7204012,
        "kodeKABUPATEN": 7204,
        "namaKECAMATAN": "PAMONA TENGGARA"
      },
      {
        "kodeKECAMATAN": 7204020,
        "kodeKABUPATEN": 7204,
        "namaKECAMATAN": "LORE SELATAN"
      },
      {
        "kodeKECAMATAN": 7204021,
        "kodeKABUPATEN": 7204,
        "namaKECAMATAN": "LORE BARAT"
      },
      {
        "kodeKECAMATAN": 7204030,
        "kodeKABUPATEN": 7204,
        "namaKECAMATAN": "PAMONA PUSALEMBA"
      },
      {
        "kodeKECAMATAN": 7204031,
        "kodeKABUPATEN": 7204,
        "namaKECAMATAN": "PAMONA TIMUR"
      },
      {
        "kodeKECAMATAN": 7204032,
        "kodeKABUPATEN": 7204,
        "namaKECAMATAN": "PAMONA UTARA"
      },
      {
        "kodeKECAMATAN": 7204040,
        "kodeKABUPATEN": 7204,
        "namaKECAMATAN": "LORE UTARA"
      },
      {
        "kodeKECAMATAN": 7204041,
        "kodeKABUPATEN": 7204,
        "namaKECAMATAN": "LORE TENGAH"
      },
      {
        "kodeKECAMATAN": 7204042,
        "kodeKABUPATEN": 7204,
        "namaKECAMATAN": "LORE TIMUR"
      },
      {
        "kodeKECAMATAN": 7204043,
        "kodeKABUPATEN": 7204,
        "namaKECAMATAN": "LORE PEORE"
      },
      {
        "kodeKECAMATAN": 7204050,
        "kodeKABUPATEN": 7204,
        "namaKECAMATAN": "POSO PESISIR"
      },
      {
        "kodeKECAMATAN": 7204051,
        "kodeKABUPATEN": 7204,
        "namaKECAMATAN": "POSO PESISIR SELATAN"
      },
      {
        "kodeKECAMATAN": 7204052,
        "kodeKABUPATEN": 7204,
        "namaKECAMATAN": "POSO PESISIR UTARA"
      },
      {
        "kodeKECAMATAN": 7204060,
        "kodeKABUPATEN": 7204,
        "namaKECAMATAN": "LAGE"
      },
      {
        "kodeKECAMATAN": 7204070,
        "kodeKABUPATEN": 7204,
        "namaKECAMATAN": "POSO KOTA"
      },
      {
        "kodeKECAMATAN": 7204071,
        "kodeKABUPATEN": 7204,
        "namaKECAMATAN": "POSO KOTA UTARA"
      },
      {
        "kodeKECAMATAN": 7204072,
        "kodeKABUPATEN": 7204,
        "namaKECAMATAN": "POSO KOTA SELATAN"
      },
      {
        "kodeKECAMATAN": 7205041,
        "kodeKABUPATEN": 7205,
        "namaKECAMATAN": "RIO PAKAVA"
      },
      {
        "kodeKECAMATAN": 7205051,
        "kodeKABUPATEN": 7205,
        "namaKECAMATAN": "PINEMBANI"
      },
      {
        "kodeKECAMATAN": 7205080,
        "kodeKABUPATEN": 7205,
        "namaKECAMATAN": "BANAWA"
      },
      {
        "kodeKECAMATAN": 7205081,
        "kodeKABUPATEN": 7205,
        "namaKECAMATAN": "BANAWA SELATAN"
      },
      {
        "kodeKECAMATAN": 7205082,
        "kodeKABUPATEN": 7205,
        "namaKECAMATAN": "BANAWA TENGAH"
      },
      {
        "kodeKECAMATAN": 7205090,
        "kodeKABUPATEN": 7205,
        "namaKECAMATAN": "LABUAN"
      },
      {
        "kodeKECAMATAN": 7205091,
        "kodeKABUPATEN": 7205,
        "namaKECAMATAN": "TANANTOVEA"
      },
      {
        "kodeKECAMATAN": 7205100,
        "kodeKABUPATEN": 7205,
        "namaKECAMATAN": "SINDUE"
      },
      {
        "kodeKECAMATAN": 7205101,
        "kodeKABUPATEN": 7205,
        "namaKECAMATAN": "SINDUE TOMBUSABORA"
      },
      {
        "kodeKECAMATAN": 7205102,
        "kodeKABUPATEN": 7205,
        "namaKECAMATAN": "SINDUE TOBATA"
      },
      {
        "kodeKECAMATAN": 7205120,
        "kodeKABUPATEN": 7205,
        "namaKECAMATAN": "SIRENJA"
      },
      {
        "kodeKECAMATAN": 7205130,
        "kodeKABUPATEN": 7205,
        "namaKECAMATAN": "BALAESANG"
      },
      {
        "kodeKECAMATAN": 7205131,
        "kodeKABUPATEN": 7205,
        "namaKECAMATAN": "BALAESANG TANJUNG"
      },
      {
        "kodeKECAMATAN": 7205140,
        "kodeKABUPATEN": 7205,
        "namaKECAMATAN": "DAMPELAS"
      },
      {
        "kodeKECAMATAN": 7205160,
        "kodeKABUPATEN": 7205,
        "namaKECAMATAN": "SOJOL"
      },
      {
        "kodeKECAMATAN": 7205161,
        "kodeKABUPATEN": 7205,
        "namaKECAMATAN": "SOJOL UTARA"
      },
      {
        "kodeKECAMATAN": 7206010,
        "kodeKABUPATEN": 7206,
        "namaKECAMATAN": "DAMPAL SELATAN"
      },
      {
        "kodeKECAMATAN": 7206020,
        "kodeKABUPATEN": 7206,
        "namaKECAMATAN": "DAMPAL UTARA"
      },
      {
        "kodeKECAMATAN": 7206030,
        "kodeKABUPATEN": 7206,
        "namaKECAMATAN": "DONDO"
      },
      {
        "kodeKECAMATAN": 7206031,
        "kodeKABUPATEN": 7206,
        "namaKECAMATAN": "OGODEIDE"
      },
      {
        "kodeKECAMATAN": 7206032,
        "kodeKABUPATEN": 7206,
        "namaKECAMATAN": "BASIDONDO"
      },
      {
        "kodeKECAMATAN": 7206040,
        "kodeKABUPATEN": 7206,
        "namaKECAMATAN": "BAOLAN"
      },
      {
        "kodeKECAMATAN": 7206041,
        "kodeKABUPATEN": 7206,
        "namaKECAMATAN": "LAMPASIO"
      },
      {
        "kodeKECAMATAN": 7206050,
        "kodeKABUPATEN": 7206,
        "namaKECAMATAN": "GALANG"
      },
      {
        "kodeKECAMATAN": 7206060,
        "kodeKABUPATEN": 7206,
        "namaKECAMATAN": "TOLITOLI UTARA"
      },
      {
        "kodeKECAMATAN": 7206061,
        "kodeKABUPATEN": 7206,
        "namaKECAMATAN": "DAKO PAMEAN"
      },
      {
        "kodeKECAMATAN": 7207010,
        "kodeKABUPATEN": 7207,
        "namaKECAMATAN": "LAKEA"
      },
      {
        "kodeKECAMATAN": 7207011,
        "kodeKABUPATEN": 7207,
        "namaKECAMATAN": "BIAU"
      },
      {
        "kodeKECAMATAN": 7207012,
        "kodeKABUPATEN": 7207,
        "namaKECAMATAN": "KARAMAT"
      },
      {
        "kodeKECAMATAN": 7207020,
        "kodeKABUPATEN": 7207,
        "namaKECAMATAN": "MOMUNU"
      },
      {
        "kodeKECAMATAN": 7207021,
        "kodeKABUPATEN": 7207,
        "namaKECAMATAN": "TILOAN"
      },
      {
        "kodeKECAMATAN": 7207030,
        "kodeKABUPATEN": 7207,
        "namaKECAMATAN": "BOKAT"
      },
      {
        "kodeKECAMATAN": 7207031,
        "kodeKABUPATEN": 7207,
        "namaKECAMATAN": "BUKAL"
      },
      {
        "kodeKECAMATAN": 7207040,
        "kodeKABUPATEN": 7207,
        "namaKECAMATAN": "BUNOBOGU"
      },
      {
        "kodeKECAMATAN": 7207041,
        "kodeKABUPATEN": 7207,
        "namaKECAMATAN": "GADUNG"
      },
      {
        "kodeKECAMATAN": 7207050,
        "kodeKABUPATEN": 7207,
        "namaKECAMATAN": "PALELEH"
      },
      {
        "kodeKECAMATAN": 7207051,
        "kodeKABUPATEN": 7207,
        "namaKECAMATAN": "PALELEH BARAT"
      },
      {
        "kodeKECAMATAN": 7208010,
        "kodeKABUPATEN": 7208,
        "namaKECAMATAN": "SAUSU"
      },
      {
        "kodeKECAMATAN": 7208011,
        "kodeKABUPATEN": 7208,
        "namaKECAMATAN": "TORUE"
      },
      {
        "kodeKECAMATAN": 7208012,
        "kodeKABUPATEN": 7208,
        "namaKECAMATAN": "BALINGGI"
      },
      {
        "kodeKECAMATAN": 7208020,
        "kodeKABUPATEN": 7208,
        "namaKECAMATAN": "PARIGI"
      },
      {
        "kodeKECAMATAN": 7208021,
        "kodeKABUPATEN": 7208,
        "namaKECAMATAN": "PARIGI SELATAN"
      },
      {
        "kodeKECAMATAN": 7208022,
        "kodeKABUPATEN": 7208,
        "namaKECAMATAN": "PARIGI BARAT"
      },
      {
        "kodeKECAMATAN": 7208023,
        "kodeKABUPATEN": 7208,
        "namaKECAMATAN": "PARIGI UTARA"
      },
      {
        "kodeKECAMATAN": 7208024,
        "kodeKABUPATEN": 7208,
        "namaKECAMATAN": "PARIGI TENGAH"
      },
      {
        "kodeKECAMATAN": 7208030,
        "kodeKABUPATEN": 7208,
        "namaKECAMATAN": "AMPIBABO"
      },
      {
        "kodeKECAMATAN": 7208031,
        "kodeKABUPATEN": 7208,
        "namaKECAMATAN": "KASIMBAR"
      },
      {
        "kodeKECAMATAN": 7208032,
        "kodeKABUPATEN": 7208,
        "namaKECAMATAN": "TORIBULU"
      },
      {
        "kodeKECAMATAN": 7208033,
        "kodeKABUPATEN": 7208,
        "namaKECAMATAN": "SINIU"
      },
      {
        "kodeKECAMATAN": 7208040,
        "kodeKABUPATEN": 7208,
        "namaKECAMATAN": "TINOMBO"
      },
      {
        "kodeKECAMATAN": 7208041,
        "kodeKABUPATEN": 7208,
        "namaKECAMATAN": "TINOMBO SELATAN"
      },
      {
        "kodeKECAMATAN": 7208042,
        "kodeKABUPATEN": 7208,
        "namaKECAMATAN": "SIDOAN"
      },
      {
        "kodeKECAMATAN": 7208050,
        "kodeKABUPATEN": 7208,
        "namaKECAMATAN": "TOMINI"
      },
      {
        "kodeKECAMATAN": 7208051,
        "kodeKABUPATEN": 7208,
        "namaKECAMATAN": "MEPANGA"
      },
      {
        "kodeKECAMATAN": 7208052,
        "kodeKABUPATEN": 7208,
        "namaKECAMATAN": "PALASA"
      },
      {
        "kodeKECAMATAN": 7208060,
        "kodeKABUPATEN": 7208,
        "namaKECAMATAN": "MOUTONG"
      },
      {
        "kodeKECAMATAN": 7208061,
        "kodeKABUPATEN": 7208,
        "namaKECAMATAN": "BOLANO LAMBUNU"
      },
      {
        "kodeKECAMATAN": 7208062,
        "kodeKABUPATEN": 7208,
        "namaKECAMATAN": "TAOPA"
      },
      {
        "kodeKECAMATAN": 7208063,
        "kodeKABUPATEN": 7208,
        "namaKECAMATAN": "BOLANO"
      },
      {
        "kodeKECAMATAN": 7208064,
        "kodeKABUPATEN": 7208,
        "namaKECAMATAN": "ONGKA MALINO"
      },
      {
        "kodeKECAMATAN": 7209010,
        "kodeKABUPATEN": 7209,
        "namaKECAMATAN": "TOJO BARAT"
      },
      {
        "kodeKECAMATAN": 7209020,
        "kodeKABUPATEN": 7209,
        "namaKECAMATAN": "TOJO"
      },
      {
        "kodeKECAMATAN": 7209030,
        "kodeKABUPATEN": 7209,
        "namaKECAMATAN": "ULUBONGKA"
      },
      {
        "kodeKECAMATAN": 7209040,
        "kodeKABUPATEN": 7209,
        "namaKECAMATAN": "AMPANA TETE"
      },
      {
        "kodeKECAMATAN": 7209050,
        "kodeKABUPATEN": 7209,
        "namaKECAMATAN": "AMPANA KOTA"
      },
      {
        "kodeKECAMATAN": 7209051,
        "kodeKABUPATEN": 7209,
        "namaKECAMATAN": "RATOLINDO"
      },
      {
        "kodeKECAMATAN": 7209060,
        "kodeKABUPATEN": 7209,
        "namaKECAMATAN": "UNA - UNA"
      },
      {
        "kodeKECAMATAN": 7209061,
        "kodeKABUPATEN": 7209,
        "namaKECAMATAN": "BATUDAKA"
      },
      {
        "kodeKECAMATAN": 7209070,
        "kodeKABUPATEN": 7209,
        "namaKECAMATAN": "TOGEAN"
      },
      {
        "kodeKECAMATAN": 7209080,
        "kodeKABUPATEN": 7209,
        "namaKECAMATAN": "WALEA KEPULAUAN"
      },
      {
        "kodeKECAMATAN": 7209081,
        "kodeKABUPATEN": 7209,
        "namaKECAMATAN": "WALEA BESAR"
      },
      {
        "kodeKECAMATAN": 7209082,
        "kodeKABUPATEN": 7209,
        "namaKECAMATAN": "TALATAKO"
      },
      {
        "kodeKECAMATAN": 7210010,
        "kodeKABUPATEN": 7210,
        "namaKECAMATAN": "PIPIKORO"
      },
      {
        "kodeKECAMATAN": 7210020,
        "kodeKABUPATEN": 7210,
        "namaKECAMATAN": "KULAWI SELATAN"
      },
      {
        "kodeKECAMATAN": 7210030,
        "kodeKABUPATEN": 7210,
        "namaKECAMATAN": "KULAWI"
      },
      {
        "kodeKECAMATAN": 7210040,
        "kodeKABUPATEN": 7210,
        "namaKECAMATAN": "LINDU"
      },
      {
        "kodeKECAMATAN": 7210050,
        "kodeKABUPATEN": 7210,
        "namaKECAMATAN": "NOKILALAKI"
      },
      {
        "kodeKECAMATAN": 7210060,
        "kodeKABUPATEN": 7210,
        "namaKECAMATAN": "PALOLO"
      },
      {
        "kodeKECAMATAN": 7210070,
        "kodeKABUPATEN": 7210,
        "namaKECAMATAN": "GUMBASA"
      },
      {
        "kodeKECAMATAN": 7210080,
        "kodeKABUPATEN": 7210,
        "namaKECAMATAN": "DOLO SELATAN"
      },
      {
        "kodeKECAMATAN": 7210090,
        "kodeKABUPATEN": 7210,
        "namaKECAMATAN": "DOLO BARAT"
      },
      {
        "kodeKECAMATAN": 7210100,
        "kodeKABUPATEN": 7210,
        "namaKECAMATAN": "TANAMBULAVA"
      },
      {
        "kodeKECAMATAN": 7210110,
        "kodeKABUPATEN": 7210,
        "namaKECAMATAN": "DOLO"
      },
      {
        "kodeKECAMATAN": 7210120,
        "kodeKABUPATEN": 7210,
        "namaKECAMATAN": "SIGI BIROMARU"
      },
      {
        "kodeKECAMATAN": 7210130,
        "kodeKABUPATEN": 7210,
        "namaKECAMATAN": "MARAWOLA"
      },
      {
        "kodeKECAMATAN": 7210140,
        "kodeKABUPATEN": 7210,
        "namaKECAMATAN": "MARAWOLA BARAT"
      },
      {
        "kodeKECAMATAN": 7210150,
        "kodeKABUPATEN": 7210,
        "namaKECAMATAN": "KINOVARO"
      },
      {
        "kodeKECAMATAN": 7211010,
        "kodeKABUPATEN": 7211,
        "namaKECAMATAN": "BANGKURUNG"
      },
      {
        "kodeKECAMATAN": 7211020,
        "kodeKABUPATEN": 7211,
        "namaKECAMATAN": "LABOBO"
      },
      {
        "kodeKECAMATAN": 7211030,
        "kodeKABUPATEN": 7211,
        "namaKECAMATAN": "BANGGAI UTARA"
      },
      {
        "kodeKECAMATAN": 7211040,
        "kodeKABUPATEN": 7211,
        "namaKECAMATAN": "BANGGAI"
      },
      {
        "kodeKECAMATAN": 7211050,
        "kodeKABUPATEN": 7211,
        "namaKECAMATAN": "BANGGAI TENGAH"
      },
      {
        "kodeKECAMATAN": 7211060,
        "kodeKABUPATEN": 7211,
        "namaKECAMATAN": "BANGGAI SELATAN"
      },
      {
        "kodeKECAMATAN": 7211070,
        "kodeKABUPATEN": 7211,
        "namaKECAMATAN": "BOKAN KEPULAUAN"
      },
      {
        "kodeKECAMATAN": 7212010,
        "kodeKABUPATEN": 7212,
        "namaKECAMATAN": "MORI ATAS"
      },
      {
        "kodeKECAMATAN": 7212020,
        "kodeKABUPATEN": 7212,
        "namaKECAMATAN": "LEMBO"
      },
      {
        "kodeKECAMATAN": 7212030,
        "kodeKABUPATEN": 7212,
        "namaKECAMATAN": "LEMBO RAYA"
      },
      {
        "kodeKECAMATAN": 7212040,
        "kodeKABUPATEN": 7212,
        "namaKECAMATAN": "PETASIA TIMUR"
      },
      {
        "kodeKECAMATAN": 7212050,
        "kodeKABUPATEN": 7212,
        "namaKECAMATAN": "PETASIA"
      },
      {
        "kodeKECAMATAN": 7212060,
        "kodeKABUPATEN": 7212,
        "namaKECAMATAN": "PETASIA BARAT"
      },
      {
        "kodeKECAMATAN": 7212070,
        "kodeKABUPATEN": 7212,
        "namaKECAMATAN": "MORI UTARA"
      },
      {
        "kodeKECAMATAN": 7212080,
        "kodeKABUPATEN": 7212,
        "namaKECAMATAN": "SOYO JAYA"
      },
      {
        "kodeKECAMATAN": 7212090,
        "kodeKABUPATEN": 7212,
        "namaKECAMATAN": "BUNGKU UTARA"
      },
      {
        "kodeKECAMATAN": 7212100,
        "kodeKABUPATEN": 7212,
        "namaKECAMATAN": "MAMOSALATO"
      },
      {
        "kodeKECAMATAN": 7271010,
        "kodeKABUPATEN": 7271,
        "namaKECAMATAN": "PALU BARAT"
      },
      {
        "kodeKECAMATAN": 7271011,
        "kodeKABUPATEN": 7271,
        "namaKECAMATAN": "TATANGA"
      },
      {
        "kodeKECAMATAN": 7271012,
        "kodeKABUPATEN": 7271,
        "namaKECAMATAN": "ULUJADI"
      },
      {
        "kodeKECAMATAN": 7271020,
        "kodeKABUPATEN": 7271,
        "namaKECAMATAN": "PALU SELATAN"
      },
      {
        "kodeKECAMATAN": 7271030,
        "kodeKABUPATEN": 7271,
        "namaKECAMATAN": "PALU TIMUR"
      },
      {
        "kodeKECAMATAN": 7271031,
        "kodeKABUPATEN": 7271,
        "namaKECAMATAN": "MANTIKULORE"
      },
      {
        "kodeKECAMATAN": 7271040,
        "kodeKABUPATEN": 7271,
        "namaKECAMATAN": "PALU UTARA"
      },
      {
        "kodeKECAMATAN": 7271041,
        "kodeKABUPATEN": 7271,
        "namaKECAMATAN": "TAWAELI"
      },
      {
        "kodeKECAMATAN": 7301010,
        "kodeKABUPATEN": 7301,
        "namaKECAMATAN": "PASIMARANNU"
      },
      {
        "kodeKECAMATAN": 7301011,
        "kodeKABUPATEN": 7301,
        "namaKECAMATAN": "PASILAMBENA"
      },
      {
        "kodeKECAMATAN": 7301020,
        "kodeKABUPATEN": 7301,
        "namaKECAMATAN": "PASIMASSUNGGU"
      },
      {
        "kodeKECAMATAN": 7301021,
        "kodeKABUPATEN": 7301,
        "namaKECAMATAN": "TAKABONERATE"
      },
      {
        "kodeKECAMATAN": 7301022,
        "kodeKABUPATEN": 7301,
        "namaKECAMATAN": "PASIMASSUNGGU TIMUR"
      },
      {
        "kodeKECAMATAN": 7301030,
        "kodeKABUPATEN": 7301,
        "namaKECAMATAN": "BONTOSIKUYU"
      },
      {
        "kodeKECAMATAN": 7301040,
        "kodeKABUPATEN": 7301,
        "namaKECAMATAN": "BONTOHARU"
      },
      {
        "kodeKECAMATAN": 7301041,
        "kodeKABUPATEN": 7301,
        "namaKECAMATAN": "BENTENG"
      },
      {
        "kodeKECAMATAN": 7301042,
        "kodeKABUPATEN": 7301,
        "namaKECAMATAN": "BONTOMANAI"
      },
      {
        "kodeKECAMATAN": 7301050,
        "kodeKABUPATEN": 7301,
        "namaKECAMATAN": "BONTOMATENE"
      },
      {
        "kodeKECAMATAN": 7301051,
        "kodeKABUPATEN": 7301,
        "namaKECAMATAN": "BUKI"
      },
      {
        "kodeKECAMATAN": 7302010,
        "kodeKABUPATEN": 7302,
        "namaKECAMATAN": "GANTARANG"
      },
      {
        "kodeKECAMATAN": 7302020,
        "kodeKABUPATEN": 7302,
        "namaKECAMATAN": "UJUNG BULU"
      },
      {
        "kodeKECAMATAN": 7302021,
        "kodeKABUPATEN": 7302,
        "namaKECAMATAN": "UJUNG LOE"
      },
      {
        "kodeKECAMATAN": 7302030,
        "kodeKABUPATEN": 7302,
        "namaKECAMATAN": "BONTO BAHARI"
      },
      {
        "kodeKECAMATAN": 7302040,
        "kodeKABUPATEN": 7302,
        "namaKECAMATAN": "BONTOTIRO"
      },
      {
        "kodeKECAMATAN": 7302050,
        "kodeKABUPATEN": 7302,
        "namaKECAMATAN": "HERO LANGE-LANGE"
      },
      {
        "kodeKECAMATAN": 7302060,
        "kodeKABUPATEN": 7302,
        "namaKECAMATAN": "KAJANG"
      },
      {
        "kodeKECAMATAN": 7302070,
        "kodeKABUPATEN": 7302,
        "namaKECAMATAN": "BULUKUMPA"
      },
      {
        "kodeKECAMATAN": 7302080,
        "kodeKABUPATEN": 7302,
        "namaKECAMATAN": "RILAU ALE"
      },
      {
        "kodeKECAMATAN": 7302090,
        "kodeKABUPATEN": 7302,
        "namaKECAMATAN": "KINDANG"
      },
      {
        "kodeKECAMATAN": 7303010,
        "kodeKABUPATEN": 7303,
        "namaKECAMATAN": "BISSAPPU"
      },
      {
        "kodeKECAMATAN": 7303011,
        "kodeKABUPATEN": 7303,
        "namaKECAMATAN": "ULUERE"
      },
      {
        "kodeKECAMATAN": 7303012,
        "kodeKABUPATEN": 7303,
        "namaKECAMATAN": "SINOA"
      },
      {
        "kodeKECAMATAN": 7303020,
        "kodeKABUPATEN": 7303,
        "namaKECAMATAN": "BANTAENG"
      },
      {
        "kodeKECAMATAN": 7303021,
        "kodeKABUPATEN": 7303,
        "namaKECAMATAN": "EREMERASA"
      },
      {
        "kodeKECAMATAN": 7303030,
        "kodeKABUPATEN": 7303,
        "namaKECAMATAN": "TOMPOBULU"
      },
      {
        "kodeKECAMATAN": 7303031,
        "kodeKABUPATEN": 7303,
        "namaKECAMATAN": "PA'JUKUKANG"
      },
      {
        "kodeKECAMATAN": 7303032,
        "kodeKABUPATEN": 7303,
        "namaKECAMATAN": "GANTARANGKEKE"
      },
      {
        "kodeKECAMATAN": 7304010,
        "kodeKABUPATEN": 7304,
        "namaKECAMATAN": "BANGKALA"
      },
      {
        "kodeKECAMATAN": 7304011,
        "kodeKABUPATEN": 7304,
        "namaKECAMATAN": "BANGKALA BARAT"
      },
      {
        "kodeKECAMATAN": 7304020,
        "kodeKABUPATEN": 7304,
        "namaKECAMATAN": "TAMALATEA"
      },
      {
        "kodeKECAMATAN": 7304021,
        "kodeKABUPATEN": 7304,
        "namaKECAMATAN": "BONTORAMBA"
      },
      {
        "kodeKECAMATAN": 7304030,
        "kodeKABUPATEN": 7304,
        "namaKECAMATAN": "BINAMU"
      },
      {
        "kodeKECAMATAN": 7304031,
        "kodeKABUPATEN": 7304,
        "namaKECAMATAN": "TURATEA"
      },
      {
        "kodeKECAMATAN": 7304040,
        "kodeKABUPATEN": 7304,
        "namaKECAMATAN": "BATANG"
      },
      {
        "kodeKECAMATAN": 7304041,
        "kodeKABUPATEN": 7304,
        "namaKECAMATAN": "ARUNGKEKE"
      },
      {
        "kodeKECAMATAN": 7304042,
        "kodeKABUPATEN": 7304,
        "namaKECAMATAN": "TAROWANG"
      },
      {
        "kodeKECAMATAN": 7304050,
        "kodeKABUPATEN": 7304,
        "namaKECAMATAN": "KELARA"
      },
      {
        "kodeKECAMATAN": 7304051,
        "kodeKABUPATEN": 7304,
        "namaKECAMATAN": "RUMBIA"
      },
      {
        "kodeKECAMATAN": 7305010,
        "kodeKABUPATEN": 7305,
        "namaKECAMATAN": "MANGARA BOMBANG"
      },
      {
        "kodeKECAMATAN": 7305020,
        "kodeKABUPATEN": 7305,
        "namaKECAMATAN": "MAPPAKASUNGGU"
      },
      {
        "kodeKECAMATAN": 7305021,
        "kodeKABUPATEN": 7305,
        "namaKECAMATAN": "SANROBONE"
      },
      {
        "kodeKECAMATAN": 7305030,
        "kodeKABUPATEN": 7305,
        "namaKECAMATAN": "POLOMBANGKENG SELATAN"
      },
      {
        "kodeKECAMATAN": 7305031,
        "kodeKABUPATEN": 7305,
        "namaKECAMATAN": "PATTALLASSANG"
      },
      {
        "kodeKECAMATAN": 7305040,
        "kodeKABUPATEN": 7305,
        "namaKECAMATAN": "POLOMBANGKENG UTARA"
      },
      {
        "kodeKECAMATAN": 7305050,
        "kodeKABUPATEN": 7305,
        "namaKECAMATAN": "GALESONG SELATAN"
      },
      {
        "kodeKECAMATAN": 7305051,
        "kodeKABUPATEN": 7305,
        "namaKECAMATAN": "GALESONG"
      },
      {
        "kodeKECAMATAN": 7305060,
        "kodeKABUPATEN": 7305,
        "namaKECAMATAN": "GALESONG UTARA"
      },
      {
        "kodeKECAMATAN": 7306010,
        "kodeKABUPATEN": 7306,
        "namaKECAMATAN": "BONTONOMPO"
      },
      {
        "kodeKECAMATAN": 7306011,
        "kodeKABUPATEN": 7306,
        "namaKECAMATAN": "BONTONOMPO SELATAN"
      },
      {
        "kodeKECAMATAN": 7306020,
        "kodeKABUPATEN": 7306,
        "namaKECAMATAN": "BAJENG"
      },
      {
        "kodeKECAMATAN": 7306021,
        "kodeKABUPATEN": 7306,
        "namaKECAMATAN": "BAJENG BARAT"
      },
      {
        "kodeKECAMATAN": 7306030,
        "kodeKABUPATEN": 7306,
        "namaKECAMATAN": "PALLANGGA"
      },
      {
        "kodeKECAMATAN": 7306031,
        "kodeKABUPATEN": 7306,
        "namaKECAMATAN": "BAROMBONG"
      },
      {
        "kodeKECAMATAN": 7306040,
        "kodeKABUPATEN": 7306,
        "namaKECAMATAN": "SOMBA OPU"
      },
      {
        "kodeKECAMATAN": 7306050,
        "kodeKABUPATEN": 7306,
        "namaKECAMATAN": "BONTOMARANNU"
      },
      {
        "kodeKECAMATAN": 7306051,
        "kodeKABUPATEN": 7306,
        "namaKECAMATAN": "PATTALLASSANG"
      },
      {
        "kodeKECAMATAN": 7306060,
        "kodeKABUPATEN": 7306,
        "namaKECAMATAN": "PARANGLOE"
      },
      {
        "kodeKECAMATAN": 7306061,
        "kodeKABUPATEN": 7306,
        "namaKECAMATAN": "MANUJU"
      },
      {
        "kodeKECAMATAN": 7306070,
        "kodeKABUPATEN": 7306,
        "namaKECAMATAN": "TINGGIMONCONG"
      },
      {
        "kodeKECAMATAN": 7306071,
        "kodeKABUPATEN": 7306,
        "namaKECAMATAN": "TOMBOLO PAO"
      },
      {
        "kodeKECAMATAN": 7306072,
        "kodeKABUPATEN": 7306,
        "namaKECAMATAN": "PARIGI"
      },
      {
        "kodeKECAMATAN": 7306080,
        "kodeKABUPATEN": 7306,
        "namaKECAMATAN": "BUNGAYA"
      },
      {
        "kodeKECAMATAN": 7306081,
        "kodeKABUPATEN": 7306,
        "namaKECAMATAN": "BONTOLEMPANGAN"
      },
      {
        "kodeKECAMATAN": 7306090,
        "kodeKABUPATEN": 7306,
        "namaKECAMATAN": "TOMPOBULU"
      },
      {
        "kodeKECAMATAN": 7306091,
        "kodeKABUPATEN": 7306,
        "namaKECAMATAN": "BIRINGBULU"
      },
      {
        "kodeKECAMATAN": 7307010,
        "kodeKABUPATEN": 7307,
        "namaKECAMATAN": "SINJAI BARAT"
      },
      {
        "kodeKECAMATAN": 7307020,
        "kodeKABUPATEN": 7307,
        "namaKECAMATAN": "SINJAI BORONG"
      },
      {
        "kodeKECAMATAN": 7307030,
        "kodeKABUPATEN": 7307,
        "namaKECAMATAN": "SINJAI SELATAN"
      },
      {
        "kodeKECAMATAN": 7307040,
        "kodeKABUPATEN": 7307,
        "namaKECAMATAN": "TELLU LIMPOE"
      },
      {
        "kodeKECAMATAN": 7307050,
        "kodeKABUPATEN": 7307,
        "namaKECAMATAN": "SINJAI TIMUR"
      },
      {
        "kodeKECAMATAN": 7307060,
        "kodeKABUPATEN": 7307,
        "namaKECAMATAN": "SINJAI TENGAH"
      },
      {
        "kodeKECAMATAN": 7307070,
        "kodeKABUPATEN": 7307,
        "namaKECAMATAN": "SINJAI UTARA"
      },
      {
        "kodeKECAMATAN": 7307080,
        "kodeKABUPATEN": 7307,
        "namaKECAMATAN": "BULUPODDO"
      },
      {
        "kodeKECAMATAN": 7307090,
        "kodeKABUPATEN": 7307,
        "namaKECAMATAN": "PULAU SEMBILAN"
      },
      {
        "kodeKECAMATAN": 7308010,
        "kodeKABUPATEN": 7308,
        "namaKECAMATAN": "MANDAI"
      },
      {
        "kodeKECAMATAN": 7308011,
        "kodeKABUPATEN": 7308,
        "namaKECAMATAN": "MONCONGLOE"
      },
      {
        "kodeKECAMATAN": 7308020,
        "kodeKABUPATEN": 7308,
        "namaKECAMATAN": "MAROS BARU"
      },
      {
        "kodeKECAMATAN": 7308021,
        "kodeKABUPATEN": 7308,
        "namaKECAMATAN": "MARUSU"
      },
      {
        "kodeKECAMATAN": 7308022,
        "kodeKABUPATEN": 7308,
        "namaKECAMATAN": "TURIKALE"
      },
      {
        "kodeKECAMATAN": 7308023,
        "kodeKABUPATEN": 7308,
        "namaKECAMATAN": "LAU"
      },
      {
        "kodeKECAMATAN": 7308030,
        "kodeKABUPATEN": 7308,
        "namaKECAMATAN": "BONTOA"
      },
      {
        "kodeKECAMATAN": 7308040,
        "kodeKABUPATEN": 7308,
        "namaKECAMATAN": "BANTIMURUNG"
      },
      {
        "kodeKECAMATAN": 7308041,
        "kodeKABUPATEN": 7308,
        "namaKECAMATAN": "SIMBANG"
      },
      {
        "kodeKECAMATAN": 7308050,
        "kodeKABUPATEN": 7308,
        "namaKECAMATAN": "TANRALILI"
      },
      {
        "kodeKECAMATAN": 7308051,
        "kodeKABUPATEN": 7308,
        "namaKECAMATAN": "TOMPU BULU"
      },
      {
        "kodeKECAMATAN": 7308060,
        "kodeKABUPATEN": 7308,
        "namaKECAMATAN": "CAMBA"
      },
      {
        "kodeKECAMATAN": 7308061,
        "kodeKABUPATEN": 7308,
        "namaKECAMATAN": "CENRANA"
      },
      {
        "kodeKECAMATAN": 7308070,
        "kodeKABUPATEN": 7308,
        "namaKECAMATAN": "MALLAWA"
      },
      {
        "kodeKECAMATAN": 7309010,
        "kodeKABUPATEN": 7309,
        "namaKECAMATAN": "LIUKANG TANGAYA"
      },
      {
        "kodeKECAMATAN": 7309020,
        "kodeKABUPATEN": 7309,
        "namaKECAMATAN": "LIUKANG KALMAS"
      },
      {
        "kodeKECAMATAN": 7309030,
        "kodeKABUPATEN": 7309,
        "namaKECAMATAN": "LIUKANG TUPABBIRING"
      },
      {
        "kodeKECAMATAN": 7309031,
        "kodeKABUPATEN": 7309,
        "namaKECAMATAN": "LIUKANG TUPABBIRING UTARA"
      },
      {
        "kodeKECAMATAN": 7309040,
        "kodeKABUPATEN": 7309,
        "namaKECAMATAN": "PANGKAJENE"
      },
      {
        "kodeKECAMATAN": 7309041,
        "kodeKABUPATEN": 7309,
        "namaKECAMATAN": "MINASATENE"
      },
      {
        "kodeKECAMATAN": 7309050,
        "kodeKABUPATEN": 7309,
        "namaKECAMATAN": "BALOCCI"
      },
      {
        "kodeKECAMATAN": 7309051,
        "kodeKABUPATEN": 7309,
        "namaKECAMATAN": "TONDONG TALLASA"
      },
      {
        "kodeKECAMATAN": 7309060,
        "kodeKABUPATEN": 7309,
        "namaKECAMATAN": "BUNGORO"
      },
      {
        "kodeKECAMATAN": 7309070,
        "kodeKABUPATEN": 7309,
        "namaKECAMATAN": "LABAKKANG"
      },
      {
        "kodeKECAMATAN": 7309080,
        "kodeKABUPATEN": 7309,
        "namaKECAMATAN": "MA'RANG"
      },
      {
        "kodeKECAMATAN": 7309091,
        "kodeKABUPATEN": 7309,
        "namaKECAMATAN": "SEGERI"
      },
      {
        "kodeKECAMATAN": 7309092,
        "kodeKABUPATEN": 7309,
        "namaKECAMATAN": "MANDALLE"
      },
      {
        "kodeKECAMATAN": 7310010,
        "kodeKABUPATEN": 7310,
        "namaKECAMATAN": "TANETE RIAJA"
      },
      {
        "kodeKECAMATAN": 7310011,
        "kodeKABUPATEN": 7310,
        "namaKECAMATAN": "PUJANANTING"
      },
      {
        "kodeKECAMATAN": 7310020,
        "kodeKABUPATEN": 7310,
        "namaKECAMATAN": "TANETE RILAU"
      },
      {
        "kodeKECAMATAN": 7310030,
        "kodeKABUPATEN": 7310,
        "namaKECAMATAN": "BARRU"
      },
      {
        "kodeKECAMATAN": 7310040,
        "kodeKABUPATEN": 7310,
        "namaKECAMATAN": "SOPPENG RIAJA"
      },
      {
        "kodeKECAMATAN": 7310041,
        "kodeKABUPATEN": 7310,
        "namaKECAMATAN": "BALUSU"
      },
      {
        "kodeKECAMATAN": 7310050,
        "kodeKABUPATEN": 7310,
        "namaKECAMATAN": "MALLUSETASI"
      },
      {
        "kodeKECAMATAN": 7311010,
        "kodeKABUPATEN": 7311,
        "namaKECAMATAN": "BONTOCANI"
      },
      {
        "kodeKECAMATAN": 7311020,
        "kodeKABUPATEN": 7311,
        "namaKECAMATAN": "KAHU"
      },
      {
        "kodeKECAMATAN": 7311030,
        "kodeKABUPATEN": 7311,
        "namaKECAMATAN": "KAJUARA"
      },
      {
        "kodeKECAMATAN": 7311040,
        "kodeKABUPATEN": 7311,
        "namaKECAMATAN": "SALOMEKKO"
      },
      {
        "kodeKECAMATAN": 7311050,
        "kodeKABUPATEN": 7311,
        "namaKECAMATAN": "TONRA"
      },
      {
        "kodeKECAMATAN": 7311060,
        "kodeKABUPATEN": 7311,
        "namaKECAMATAN": "PATIMPENG"
      },
      {
        "kodeKECAMATAN": 7311070,
        "kodeKABUPATEN": 7311,
        "namaKECAMATAN": "LIBURENG"
      },
      {
        "kodeKECAMATAN": 7311080,
        "kodeKABUPATEN": 7311,
        "namaKECAMATAN": "MARE"
      },
      {
        "kodeKECAMATAN": 7311090,
        "kodeKABUPATEN": 7311,
        "namaKECAMATAN": "SIBULUE"
      },
      {
        "kodeKECAMATAN": 7311100,
        "kodeKABUPATEN": 7311,
        "namaKECAMATAN": "CINA"
      },
      {
        "kodeKECAMATAN": 7311110,
        "kodeKABUPATEN": 7311,
        "namaKECAMATAN": "BAREBBO"
      },
      {
        "kodeKECAMATAN": 7311120,
        "kodeKABUPATEN": 7311,
        "namaKECAMATAN": "PONRE"
      },
      {
        "kodeKECAMATAN": 7311130,
        "kodeKABUPATEN": 7311,
        "namaKECAMATAN": "LAPPARIAJA"
      },
      {
        "kodeKECAMATAN": 7311140,
        "kodeKABUPATEN": 7311,
        "namaKECAMATAN": "LAMURU"
      },
      {
        "kodeKECAMATAN": 7311141,
        "kodeKABUPATEN": 7311,
        "namaKECAMATAN": "TELLU LIMPOE"
      },
      {
        "kodeKECAMATAN": 7311150,
        "kodeKABUPATEN": 7311,
        "namaKECAMATAN": "BENGO"
      },
      {
        "kodeKECAMATAN": 7311160,
        "kodeKABUPATEN": 7311,
        "namaKECAMATAN": "ULAWENG"
      },
      {
        "kodeKECAMATAN": 7311170,
        "kodeKABUPATEN": 7311,
        "namaKECAMATAN": "PALAKKA"
      },
      {
        "kodeKECAMATAN": 7311180,
        "kodeKABUPATEN": 7311,
        "namaKECAMATAN": "AWANGPONE"
      },
      {
        "kodeKECAMATAN": 7311190,
        "kodeKABUPATEN": 7311,
        "namaKECAMATAN": "TELLU SIATTINGE"
      },
      {
        "kodeKECAMATAN": 7311200,
        "kodeKABUPATEN": 7311,
        "namaKECAMATAN": "AMALI"
      },
      {
        "kodeKECAMATAN": 7311210,
        "kodeKABUPATEN": 7311,
        "namaKECAMATAN": "AJANGALE"
      },
      {
        "kodeKECAMATAN": 7311220,
        "kodeKABUPATEN": 7311,
        "namaKECAMATAN": "DUA BOCCOE"
      },
      {
        "kodeKECAMATAN": 7311230,
        "kodeKABUPATEN": 7311,
        "namaKECAMATAN": "CENRANA"
      },
      {
        "kodeKECAMATAN": 7311710,
        "kodeKABUPATEN": 7311,
        "namaKECAMATAN": "TANETE RIATTANG BARAT"
      },
      {
        "kodeKECAMATAN": 7311720,
        "kodeKABUPATEN": 7311,
        "namaKECAMATAN": "TANETE RIATTANG"
      },
      {
        "kodeKECAMATAN": 7311730,
        "kodeKABUPATEN": 7311,
        "namaKECAMATAN": "TANETE RIATTANG TIMUR"
      },
      {
        "kodeKECAMATAN": 7312010,
        "kodeKABUPATEN": 7312,
        "namaKECAMATAN": "MARIO RIWAWO"
      },
      {
        "kodeKECAMATAN": 7312020,
        "kodeKABUPATEN": 7312,
        "namaKECAMATAN": "LALABATA"
      },
      {
        "kodeKECAMATAN": 7312030,
        "kodeKABUPATEN": 7312,
        "namaKECAMATAN": "LILI RIAJA"
      },
      {
        "kodeKECAMATAN": 7312031,
        "kodeKABUPATEN": 7312,
        "namaKECAMATAN": "GANRA"
      },
      {
        "kodeKECAMATAN": 7312032,
        "kodeKABUPATEN": 7312,
        "namaKECAMATAN": "CITTA"
      },
      {
        "kodeKECAMATAN": 7312040,
        "kodeKABUPATEN": 7312,
        "namaKECAMATAN": "LILI RILAU"
      },
      {
        "kodeKECAMATAN": 7312050,
        "kodeKABUPATEN": 7312,
        "namaKECAMATAN": "DONRI DONRI"
      },
      {
        "kodeKECAMATAN": 7312060,
        "kodeKABUPATEN": 7312,
        "namaKECAMATAN": "MARIO RIAWA"
      },
      {
        "kodeKECAMATAN": 7313010,
        "kodeKABUPATEN": 7313,
        "namaKECAMATAN": "SABBANG PARU"
      },
      {
        "kodeKECAMATAN": 7313020,
        "kodeKABUPATEN": 7313,
        "namaKECAMATAN": "TEMPE"
      },
      {
        "kodeKECAMATAN": 7313030,
        "kodeKABUPATEN": 7313,
        "namaKECAMATAN": "PAMMANA"
      },
      {
        "kodeKECAMATAN": 7313040,
        "kodeKABUPATEN": 7313,
        "namaKECAMATAN": "BOLA"
      },
      {
        "kodeKECAMATAN": 7313050,
        "kodeKABUPATEN": 7313,
        "namaKECAMATAN": "TAKKALALLA"
      },
      {
        "kodeKECAMATAN": 7313060,
        "kodeKABUPATEN": 7313,
        "namaKECAMATAN": "SAJOANGING"
      },
      {
        "kodeKECAMATAN": 7313061,
        "kodeKABUPATEN": 7313,
        "namaKECAMATAN": "PENRANG"
      },
      {
        "kodeKECAMATAN": 7313070,
        "kodeKABUPATEN": 7313,
        "namaKECAMATAN": "MAJAULENG"
      },
      {
        "kodeKECAMATAN": 7313080,
        "kodeKABUPATEN": 7313,
        "namaKECAMATAN": "TANA SITOLO"
      },
      {
        "kodeKECAMATAN": 7313090,
        "kodeKABUPATEN": 7313,
        "namaKECAMATAN": "BELAWA"
      },
      {
        "kodeKECAMATAN": 7313100,
        "kodeKABUPATEN": 7313,
        "namaKECAMATAN": "MANIANG PAJO"
      },
      {
        "kodeKECAMATAN": 7313101,
        "kodeKABUPATEN": 7313,
        "namaKECAMATAN": "GILIRENG"
      },
      {
        "kodeKECAMATAN": 7313110,
        "kodeKABUPATEN": 7313,
        "namaKECAMATAN": "KEERA"
      },
      {
        "kodeKECAMATAN": 7313120,
        "kodeKABUPATEN": 7313,
        "namaKECAMATAN": "PITUMPANUA"
      },
      {
        "kodeKECAMATAN": 7314010,
        "kodeKABUPATEN": 7314,
        "namaKECAMATAN": "PANCA LAUTANG"
      },
      {
        "kodeKECAMATAN": 7314020,
        "kodeKABUPATEN": 7314,
        "namaKECAMATAN": "TELLULIMPO E"
      },
      {
        "kodeKECAMATAN": 7314030,
        "kodeKABUPATEN": 7314,
        "namaKECAMATAN": "WATANG PULU"
      },
      {
        "kodeKECAMATAN": 7314040,
        "kodeKABUPATEN": 7314,
        "namaKECAMATAN": "BARANTI"
      },
      {
        "kodeKECAMATAN": 7314050,
        "kodeKABUPATEN": 7314,
        "namaKECAMATAN": "PANCA RIJANG"
      },
      {
        "kodeKECAMATAN": 7314051,
        "kodeKABUPATEN": 7314,
        "namaKECAMATAN": "KULO"
      },
      {
        "kodeKECAMATAN": 7314060,
        "kodeKABUPATEN": 7314,
        "namaKECAMATAN": "MARITENGNGAE"
      },
      {
        "kodeKECAMATAN": 7314061,
        "kodeKABUPATEN": 7314,
        "namaKECAMATAN": "WATANG SIDENRENG"
      },
      {
        "kodeKECAMATAN": 7314070,
        "kodeKABUPATEN": 7314,
        "namaKECAMATAN": "PITU RIAWA"
      },
      {
        "kodeKECAMATAN": 7314080,
        "kodeKABUPATEN": 7314,
        "namaKECAMATAN": "DUAPITUE"
      },
      {
        "kodeKECAMATAN": 7314081,
        "kodeKABUPATEN": 7314,
        "namaKECAMATAN": "PITU RIASE"
      },
      {
        "kodeKECAMATAN": 7315010,
        "kodeKABUPATEN": 7315,
        "namaKECAMATAN": "SUPPA"
      },
      {
        "kodeKECAMATAN": 7315020,
        "kodeKABUPATEN": 7315,
        "namaKECAMATAN": "MATTIROSOMPE"
      },
      {
        "kodeKECAMATAN": 7315021,
        "kodeKABUPATEN": 7315,
        "namaKECAMATAN": "LANRISANG"
      },
      {
        "kodeKECAMATAN": 7315030,
        "kodeKABUPATEN": 7315,
        "namaKECAMATAN": "MATTIRO BULU"
      },
      {
        "kodeKECAMATAN": 7315040,
        "kodeKABUPATEN": 7315,
        "namaKECAMATAN": "WATANG SAWITTO"
      },
      {
        "kodeKECAMATAN": 7315041,
        "kodeKABUPATEN": 7315,
        "namaKECAMATAN": "PALETEANG"
      },
      {
        "kodeKECAMATAN": 7315042,
        "kodeKABUPATEN": 7315,
        "namaKECAMATAN": "TIROANG"
      },
      {
        "kodeKECAMATAN": 7315050,
        "kodeKABUPATEN": 7315,
        "namaKECAMATAN": "PATAMPANUA"
      },
      {
        "kodeKECAMATAN": 7315060,
        "kodeKABUPATEN": 7315,
        "namaKECAMATAN": "CEMPA"
      },
      {
        "kodeKECAMATAN": 7315070,
        "kodeKABUPATEN": 7315,
        "namaKECAMATAN": "DUAMPANUA"
      },
      {
        "kodeKECAMATAN": 7315071,
        "kodeKABUPATEN": 7315,
        "namaKECAMATAN": "BATULAPPA"
      },
      {
        "kodeKECAMATAN": 7315080,
        "kodeKABUPATEN": 7315,
        "namaKECAMATAN": "LEMBANG"
      },
      {
        "kodeKECAMATAN": 7316010,
        "kodeKABUPATEN": 7316,
        "namaKECAMATAN": "MAIWA"
      },
      {
        "kodeKECAMATAN": 7316011,
        "kodeKABUPATEN": 7316,
        "namaKECAMATAN": "BUNGIN"
      },
      {
        "kodeKECAMATAN": 7316020,
        "kodeKABUPATEN": 7316,
        "namaKECAMATAN": "ENREKANG"
      },
      {
        "kodeKECAMATAN": 7316021,
        "kodeKABUPATEN": 7316,
        "namaKECAMATAN": "CENDANA"
      },
      {
        "kodeKECAMATAN": 7316030,
        "kodeKABUPATEN": 7316,
        "namaKECAMATAN": "BARAKA"
      },
      {
        "kodeKECAMATAN": 7316031,
        "kodeKABUPATEN": 7316,
        "namaKECAMATAN": "BUNTU BATU"
      },
      {
        "kodeKECAMATAN": 7316040,
        "kodeKABUPATEN": 7316,
        "namaKECAMATAN": "ANGGERAJA"
      },
      {
        "kodeKECAMATAN": 7316041,
        "kodeKABUPATEN": 7316,
        "namaKECAMATAN": "MALUA"
      },
      {
        "kodeKECAMATAN": 7316050,
        "kodeKABUPATEN": 7316,
        "namaKECAMATAN": "ALLA"
      },
      {
        "kodeKECAMATAN": 7316051,
        "kodeKABUPATEN": 7316,
        "namaKECAMATAN": "CURIO"
      },
      {
        "kodeKECAMATAN": 7316052,
        "kodeKABUPATEN": 7316,
        "namaKECAMATAN": "MASALLE"
      },
      {
        "kodeKECAMATAN": 7316053,
        "kodeKABUPATEN": 7316,
        "namaKECAMATAN": "BAROKO"
      },
      {
        "kodeKECAMATAN": 7317010,
        "kodeKABUPATEN": 7317,
        "namaKECAMATAN": "LAROMPONG"
      },
      {
        "kodeKECAMATAN": 7317011,
        "kodeKABUPATEN": 7317,
        "namaKECAMATAN": "LAROMPONG SELATAN"
      },
      {
        "kodeKECAMATAN": 7317020,
        "kodeKABUPATEN": 7317,
        "namaKECAMATAN": "SULI"
      },
      {
        "kodeKECAMATAN": 7317021,
        "kodeKABUPATEN": 7317,
        "namaKECAMATAN": "SULI BARAT"
      },
      {
        "kodeKECAMATAN": 7317030,
        "kodeKABUPATEN": 7317,
        "namaKECAMATAN": "BELOPA"
      },
      {
        "kodeKECAMATAN": 7317031,
        "kodeKABUPATEN": 7317,
        "namaKECAMATAN": "KAMANRE"
      },
      {
        "kodeKECAMATAN": 7317032,
        "kodeKABUPATEN": 7317,
        "namaKECAMATAN": "BELOPA UTARA"
      },
      {
        "kodeKECAMATAN": 7317040,
        "kodeKABUPATEN": 7317,
        "namaKECAMATAN": "BAJO"
      },
      {
        "kodeKECAMATAN": 7317041,
        "kodeKABUPATEN": 7317,
        "namaKECAMATAN": "BAJO BARAT"
      },
      {
        "kodeKECAMATAN": 7317050,
        "kodeKABUPATEN": 7317,
        "namaKECAMATAN": "BASSESANGTEMPE"
      },
      {
        "kodeKECAMATAN": 7317051,
        "kodeKABUPATEN": 7317,
        "namaKECAMATAN": "LATIMOJONG"
      },
      {
        "kodeKECAMATAN": 7317052,
        "kodeKABUPATEN": 7317,
        "namaKECAMATAN": "BASSESANGTEMPE UTARA"
      },
      {
        "kodeKECAMATAN": 7317060,
        "kodeKABUPATEN": 7317,
        "namaKECAMATAN": "BUPON"
      },
      {
        "kodeKECAMATAN": 7317061,
        "kodeKABUPATEN": 7317,
        "namaKECAMATAN": "PONRANG"
      },
      {
        "kodeKECAMATAN": 7317062,
        "kodeKABUPATEN": 7317,
        "namaKECAMATAN": "PONRANG SELATAN"
      },
      {
        "kodeKECAMATAN": 7317070,
        "kodeKABUPATEN": 7317,
        "namaKECAMATAN": "BUA"
      },
      {
        "kodeKECAMATAN": 7317080,
        "kodeKABUPATEN": 7317,
        "namaKECAMATAN": "WALENRANG"
      },
      {
        "kodeKECAMATAN": 7317081,
        "kodeKABUPATEN": 7317,
        "namaKECAMATAN": "WALENRANG TIMUR"
      },
      {
        "kodeKECAMATAN": 7317090,
        "kodeKABUPATEN": 7317,
        "namaKECAMATAN": "LAMASI"
      },
      {
        "kodeKECAMATAN": 7317091,
        "kodeKABUPATEN": 7317,
        "namaKECAMATAN": "WALENRANG UTARA"
      },
      {
        "kodeKECAMATAN": 7317092,
        "kodeKABUPATEN": 7317,
        "namaKECAMATAN": "WALENRANG BARAT"
      },
      {
        "kodeKECAMATAN": 7317093,
        "kodeKABUPATEN": 7317,
        "namaKECAMATAN": "LAMASI TIMUR"
      },
      {
        "kodeKECAMATAN": 7318010,
        "kodeKABUPATEN": 7318,
        "namaKECAMATAN": "BONGGAKARADENG"
      },
      {
        "kodeKECAMATAN": 7318011,
        "kodeKABUPATEN": 7318,
        "namaKECAMATAN": "SIMBUANG"
      },
      {
        "kodeKECAMATAN": 7318012,
        "kodeKABUPATEN": 7318,
        "namaKECAMATAN": "RANO"
      },
      {
        "kodeKECAMATAN": 7318013,
        "kodeKABUPATEN": 7318,
        "namaKECAMATAN": "MAPPAK"
      },
      {
        "kodeKECAMATAN": 7318020,
        "kodeKABUPATEN": 7318,
        "namaKECAMATAN": "MENGKENDEK"
      },
      {
        "kodeKECAMATAN": 7318021,
        "kodeKABUPATEN": 7318,
        "namaKECAMATAN": "GANDANG BATU SILANAN"
      },
      {
        "kodeKECAMATAN": 7318030,
        "kodeKABUPATEN": 7318,
        "namaKECAMATAN": "SANGALLA"
      },
      {
        "kodeKECAMATAN": 7318031,
        "kodeKABUPATEN": 7318,
        "namaKECAMATAN": "SANGALA SELATAN"
      },
      {
        "kodeKECAMATAN": 7318032,
        "kodeKABUPATEN": 7318,
        "namaKECAMATAN": "SANGALLA UTARA"
      },
      {
        "kodeKECAMATAN": 7318040,
        "kodeKABUPATEN": 7318,
        "namaKECAMATAN": "MAKALE"
      },
      {
        "kodeKECAMATAN": 7318041,
        "kodeKABUPATEN": 7318,
        "namaKECAMATAN": "MAKALE SELATAN"
      },
      {
        "kodeKECAMATAN": 7318042,
        "kodeKABUPATEN": 7318,
        "namaKECAMATAN": "MAKALE UTARA"
      },
      {
        "kodeKECAMATAN": 7318050,
        "kodeKABUPATEN": 7318,
        "namaKECAMATAN": "SALUPUTTI"
      },
      {
        "kodeKECAMATAN": 7318051,
        "kodeKABUPATEN": 7318,
        "namaKECAMATAN": "BITTUANG"
      },
      {
        "kodeKECAMATAN": 7318052,
        "kodeKABUPATEN": 7318,
        "namaKECAMATAN": "REMBON"
      },
      {
        "kodeKECAMATAN": 7318053,
        "kodeKABUPATEN": 7318,
        "namaKECAMATAN": "MASANDA"
      },
      {
        "kodeKECAMATAN": 7318054,
        "kodeKABUPATEN": 7318,
        "namaKECAMATAN": "MALIMBONG BALEPE"
      },
      {
        "kodeKECAMATAN": 7318061,
        "kodeKABUPATEN": 7318,
        "namaKECAMATAN": "RANTETAYO"
      },
      {
        "kodeKECAMATAN": 7318067,
        "kodeKABUPATEN": 7318,
        "namaKECAMATAN": "KURRA"
      },
      {
        "kodeKECAMATAN": 7322010,
        "kodeKABUPATEN": 7322,
        "namaKECAMATAN": "SABBANG"
      },
      {
        "kodeKECAMATAN": 7322020,
        "kodeKABUPATEN": 7322,
        "namaKECAMATAN": "BAEBUNTA"
      },
      {
        "kodeKECAMATAN": 7322030,
        "kodeKABUPATEN": 7322,
        "namaKECAMATAN": "MALANGKE"
      },
      {
        "kodeKECAMATAN": 7322031,
        "kodeKABUPATEN": 7322,
        "namaKECAMATAN": "MALANGKE BARAT"
      },
      {
        "kodeKECAMATAN": 7322040,
        "kodeKABUPATEN": 7322,
        "namaKECAMATAN": "SUKAMAJU"
      },
      {
        "kodeKECAMATAN": 7322050,
        "kodeKABUPATEN": 7322,
        "namaKECAMATAN": "BONE-BONE"
      },
      {
        "kodeKECAMATAN": 7322051,
        "kodeKABUPATEN": 7322,
        "namaKECAMATAN": "TANA LILI"
      },
      {
        "kodeKECAMATAN": 7322120,
        "kodeKABUPATEN": 7322,
        "namaKECAMATAN": "MASAMBA"
      },
      {
        "kodeKECAMATAN": 7322121,
        "kodeKABUPATEN": 7322,
        "namaKECAMATAN": "MAPPEDECENG"
      },
      {
        "kodeKECAMATAN": 7322122,
        "kodeKABUPATEN": 7322,
        "namaKECAMATAN": "RAMPI"
      },
      {
        "kodeKECAMATAN": 7322130,
        "kodeKABUPATEN": 7322,
        "namaKECAMATAN": "LIMBONG"
      },
      {
        "kodeKECAMATAN": 7322131,
        "kodeKABUPATEN": 7322,
        "namaKECAMATAN": "SEKO"
      },
      {
        "kodeKECAMATAN": 7325010,
        "kodeKABUPATEN": 7325,
        "namaKECAMATAN": "BURAU"
      },
      {
        "kodeKECAMATAN": 7325020,
        "kodeKABUPATEN": 7325,
        "namaKECAMATAN": "WOTU"
      },
      {
        "kodeKECAMATAN": 7325030,
        "kodeKABUPATEN": 7325,
        "namaKECAMATAN": "TOMONI"
      },
      {
        "kodeKECAMATAN": 7325031,
        "kodeKABUPATEN": 7325,
        "namaKECAMATAN": "TOMONI TIMUR"
      },
      {
        "kodeKECAMATAN": 7325040,
        "kodeKABUPATEN": 7325,
        "namaKECAMATAN": "ANGKONA"
      },
      {
        "kodeKECAMATAN": 7325050,
        "kodeKABUPATEN": 7325,
        "namaKECAMATAN": "MALILI"
      },
      {
        "kodeKECAMATAN": 7325060,
        "kodeKABUPATEN": 7325,
        "namaKECAMATAN": "TOWUTI"
      },
      {
        "kodeKECAMATAN": 7325070,
        "kodeKABUPATEN": 7325,
        "namaKECAMATAN": "NUHA"
      },
      {
        "kodeKECAMATAN": 7325071,
        "kodeKABUPATEN": 7325,
        "namaKECAMATAN": "WASUPONDA"
      },
      {
        "kodeKECAMATAN": 7325080,
        "kodeKABUPATEN": 7325,
        "namaKECAMATAN": "MANGKUTANA"
      },
      {
        "kodeKECAMATAN": 7325081,
        "kodeKABUPATEN": 7325,
        "namaKECAMATAN": "KALAENA"
      },
      {
        "kodeKECAMATAN": 7326010,
        "kodeKABUPATEN": 7326,
        "namaKECAMATAN": "SOPAI"
      },
      {
        "kodeKECAMATAN": 7326020,
        "kodeKABUPATEN": 7326,
        "namaKECAMATAN": "KESU"
      },
      {
        "kodeKECAMATAN": 7326030,
        "kodeKABUPATEN": 7326,
        "namaKECAMATAN": "SANGGALANGI"
      },
      {
        "kodeKECAMATAN": 7326040,
        "kodeKABUPATEN": 7326,
        "namaKECAMATAN": "BUNTAO"
      },
      {
        "kodeKECAMATAN": 7326050,
        "kodeKABUPATEN": 7326,
        "namaKECAMATAN": "RANTEBUA"
      },
      {
        "kodeKECAMATAN": 7326060,
        "kodeKABUPATEN": 7326,
        "namaKECAMATAN": "NANGGALA"
      },
      {
        "kodeKECAMATAN": 7326070,
        "kodeKABUPATEN": 7326,
        "namaKECAMATAN": "TONDON"
      },
      {
        "kodeKECAMATAN": 7326080,
        "kodeKABUPATEN": 7326,
        "namaKECAMATAN": "TALLUNGLIPU"
      },
      {
        "kodeKECAMATAN": 7326090,
        "kodeKABUPATEN": 7326,
        "namaKECAMATAN": "RANTEPAO"
      },
      {
        "kodeKECAMATAN": 7326100,
        "kodeKABUPATEN": 7326,
        "namaKECAMATAN": "TIKALA"
      },
      {
        "kodeKECAMATAN": 7326110,
        "kodeKABUPATEN": 7326,
        "namaKECAMATAN": "SESEAN"
      },
      {
        "kodeKECAMATAN": 7326120,
        "kodeKABUPATEN": 7326,
        "namaKECAMATAN": "BALUSU"
      },
      {
        "kodeKECAMATAN": 7326130,
        "kodeKABUPATEN": 7326,
        "namaKECAMATAN": "SA'DAN"
      },
      {
        "kodeKECAMATAN": 7326140,
        "kodeKABUPATEN": 7326,
        "namaKECAMATAN": "BENGKELEKILA"
      },
      {
        "kodeKECAMATAN": 7326150,
        "kodeKABUPATEN": 7326,
        "namaKECAMATAN": "SESEAN SULOARA"
      },
      {
        "kodeKECAMATAN": 7326160,
        "kodeKABUPATEN": 7326,
        "namaKECAMATAN": "KAPALA PITU"
      },
      {
        "kodeKECAMATAN": 7326170,
        "kodeKABUPATEN": 7326,
        "namaKECAMATAN": "DENDE PIONGAN NAPO"
      },
      {
        "kodeKECAMATAN": 7326180,
        "kodeKABUPATEN": 7326,
        "namaKECAMATAN": "AWAN RANTE KARUA"
      },
      {
        "kodeKECAMATAN": 7326190,
        "kodeKABUPATEN": 7326,
        "namaKECAMATAN": "RINDINGALO"
      },
      {
        "kodeKECAMATAN": 7326200,
        "kodeKABUPATEN": 7326,
        "namaKECAMATAN": "BUNTU PEPASAN"
      },
      {
        "kodeKECAMATAN": 7326210,
        "kodeKABUPATEN": 7326,
        "namaKECAMATAN": "BARUPPU"
      },
      {
        "kodeKECAMATAN": 7371010,
        "kodeKABUPATEN": 7371,
        "namaKECAMATAN": "MARISO"
      },
      {
        "kodeKECAMATAN": 7371020,
        "kodeKABUPATEN": 7371,
        "namaKECAMATAN": "MAMAJANG"
      },
      {
        "kodeKECAMATAN": 7371030,
        "kodeKABUPATEN": 7371,
        "namaKECAMATAN": "TAMALATE"
      },
      {
        "kodeKECAMATAN": 7371031,
        "kodeKABUPATEN": 7371,
        "namaKECAMATAN": "RAPPOCINI"
      },
      {
        "kodeKECAMATAN": 7371040,
        "kodeKABUPATEN": 7371,
        "namaKECAMATAN": "MAKASSAR"
      },
      {
        "kodeKECAMATAN": 7371050,
        "kodeKABUPATEN": 7371,
        "namaKECAMATAN": "UJUNG PANDANG"
      },
      {
        "kodeKECAMATAN": 7371060,
        "kodeKABUPATEN": 7371,
        "namaKECAMATAN": "WAJO"
      },
      {
        "kodeKECAMATAN": 7371070,
        "kodeKABUPATEN": 7371,
        "namaKECAMATAN": "BONTOALA"
      },
      {
        "kodeKECAMATAN": 7371080,
        "kodeKABUPATEN": 7371,
        "namaKECAMATAN": "UJUNG TANAH"
      },
      {
        "kodeKECAMATAN": 7371090,
        "kodeKABUPATEN": 7371,
        "namaKECAMATAN": "TALLO"
      },
      {
        "kodeKECAMATAN": 7371100,
        "kodeKABUPATEN": 7371,
        "namaKECAMATAN": "PANAKKUKANG"
      },
      {
        "kodeKECAMATAN": 7371101,
        "kodeKABUPATEN": 7371,
        "namaKECAMATAN": "MANGGALA"
      },
      {
        "kodeKECAMATAN": 7371110,
        "kodeKABUPATEN": 7371,
        "namaKECAMATAN": "BIRING KANAYA"
      },
      {
        "kodeKECAMATAN": 7371111,
        "kodeKABUPATEN": 7371,
        "namaKECAMATAN": "TAMALANREA"
      },
      {
        "kodeKECAMATAN": 7372010,
        "kodeKABUPATEN": 7372,
        "namaKECAMATAN": "BACUKIKI"
      },
      {
        "kodeKECAMATAN": 7372011,
        "kodeKABUPATEN": 7372,
        "namaKECAMATAN": "BACUKIKI BARAT"
      },
      {
        "kodeKECAMATAN": 7372020,
        "kodeKABUPATEN": 7372,
        "namaKECAMATAN": "UJUNG"
      },
      {
        "kodeKECAMATAN": 7372030,
        "kodeKABUPATEN": 7372,
        "namaKECAMATAN": "SOREANG"
      },
      {
        "kodeKECAMATAN": 7373010,
        "kodeKABUPATEN": 7373,
        "namaKECAMATAN": "WARA SELATAN"
      },
      {
        "kodeKECAMATAN": 7373011,
        "kodeKABUPATEN": 7373,
        "namaKECAMATAN": "SENDANA"
      },
      {
        "kodeKECAMATAN": 7373020,
        "kodeKABUPATEN": 7373,
        "namaKECAMATAN": "WARA"
      },
      {
        "kodeKECAMATAN": 7373021,
        "kodeKABUPATEN": 7373,
        "namaKECAMATAN": "WARA TIMUR"
      },
      {
        "kodeKECAMATAN": 7373022,
        "kodeKABUPATEN": 7373,
        "namaKECAMATAN": "MUNGKAJANG"
      },
      {
        "kodeKECAMATAN": 7373030,
        "kodeKABUPATEN": 7373,
        "namaKECAMATAN": "WARA UTARA"
      },
      {
        "kodeKECAMATAN": 7373031,
        "kodeKABUPATEN": 7373,
        "namaKECAMATAN": "BARA"
      },
      {
        "kodeKECAMATAN": 7373040,
        "kodeKABUPATEN": 7373,
        "namaKECAMATAN": "TELLUWANUA"
      },
      {
        "kodeKECAMATAN": 7373041,
        "kodeKABUPATEN": 7373,
        "namaKECAMATAN": "WARA BARAT"
      },
      {
        "kodeKECAMATAN": 7401050,
        "kodeKABUPATEN": 7401,
        "namaKECAMATAN": "LASALIMU"
      },
      {
        "kodeKECAMATAN": 7401051,
        "kodeKABUPATEN": 7401,
        "namaKECAMATAN": "LASALIMU SELATAN"
      },
      {
        "kodeKECAMATAN": 7401052,
        "kodeKABUPATEN": 7401,
        "namaKECAMATAN": "SIONTAPINA"
      },
      {
        "kodeKECAMATAN": 7401060,
        "kodeKABUPATEN": 7401,
        "namaKECAMATAN": "PASAR WAJO"
      },
      {
        "kodeKECAMATAN": 7401061,
        "kodeKABUPATEN": 7401,
        "namaKECAMATAN": "WOLOWA"
      },
      {
        "kodeKECAMATAN": 7401062,
        "kodeKABUPATEN": 7401,
        "namaKECAMATAN": "WABULA"
      },
      {
        "kodeKECAMATAN": 7401110,
        "kodeKABUPATEN": 7401,
        "namaKECAMATAN": "KAPONTORI"
      },
      {
        "kodeKECAMATAN": 7402010,
        "kodeKABUPATEN": 7402,
        "namaKECAMATAN": "TONGKUNO"
      },
      {
        "kodeKECAMATAN": 7402011,
        "kodeKABUPATEN": 7402,
        "namaKECAMATAN": "TONGKUNO SELATAN"
      },
      {
        "kodeKECAMATAN": 7402020,
        "kodeKABUPATEN": 7402,
        "namaKECAMATAN": "PARIGI"
      },
      {
        "kodeKECAMATAN": 7402021,
        "kodeKABUPATEN": 7402,
        "namaKECAMATAN": "BONE"
      },
      {
        "kodeKECAMATAN": 7402022,
        "kodeKABUPATEN": 7402,
        "namaKECAMATAN": "MAROBO"
      },
      {
        "kodeKECAMATAN": 7402030,
        "kodeKABUPATEN": 7402,
        "namaKECAMATAN": "KABAWO"
      },
      {
        "kodeKECAMATAN": 7402031,
        "kodeKABUPATEN": 7402,
        "namaKECAMATAN": "KABANGKA"
      },
      {
        "kodeKECAMATAN": 7402032,
        "kodeKABUPATEN": 7402,
        "namaKECAMATAN": "KONTUKOWUNA"
      },
      {
        "kodeKECAMATAN": 7402061,
        "kodeKABUPATEN": 7402,
        "namaKECAMATAN": "KONTUNAGA"
      },
      {
        "kodeKECAMATAN": 7402062,
        "kodeKABUPATEN": 7402,
        "namaKECAMATAN": "WATOPUTE"
      },
      {
        "kodeKECAMATAN": 7402070,
        "kodeKABUPATEN": 7402,
        "namaKECAMATAN": "KATOBU"
      },
      {
        "kodeKECAMATAN": 7402071,
        "kodeKABUPATEN": 7402,
        "namaKECAMATAN": "LOHIA"
      },
      {
        "kodeKECAMATAN": 7402072,
        "kodeKABUPATEN": 7402,
        "namaKECAMATAN": "DURUKA"
      },
      {
        "kodeKECAMATAN": 7402073,
        "kodeKABUPATEN": 7402,
        "namaKECAMATAN": "BATALAIWORU"
      },
      {
        "kodeKECAMATAN": 7402080,
        "kodeKABUPATEN": 7402,
        "namaKECAMATAN": "NAPABALANO"
      },
      {
        "kodeKECAMATAN": 7402081,
        "kodeKABUPATEN": 7402,
        "namaKECAMATAN": "LASALEPA"
      },
      {
        "kodeKECAMATAN": 7402083,
        "kodeKABUPATEN": 7402,
        "namaKECAMATAN": "TOWEA"
      },
      {
        "kodeKECAMATAN": 7402090,
        "kodeKABUPATEN": 7402,
        "namaKECAMATAN": "WAKORUMBA SELATAN"
      },
      {
        "kodeKECAMATAN": 7402091,
        "kodeKABUPATEN": 7402,
        "namaKECAMATAN": "PASIR PUTIH"
      },
      {
        "kodeKECAMATAN": 7402092,
        "kodeKABUPATEN": 7402,
        "namaKECAMATAN": "PASI KOLAGA"
      },
      {
        "kodeKECAMATAN": 7402111,
        "kodeKABUPATEN": 7402,
        "namaKECAMATAN": "MALIGANO"
      },
      {
        "kodeKECAMATAN": 7402112,
        "kodeKABUPATEN": 7402,
        "namaKECAMATAN": "BATUKARA"
      },
      {
        "kodeKECAMATAN": 7403090,
        "kodeKABUPATEN": 7403,
        "namaKECAMATAN": "SOROPIA"
      },
      {
        "kodeKECAMATAN": 7403091,
        "kodeKABUPATEN": 7403,
        "namaKECAMATAN": "LALONGGASUMEETO"
      },
      {
        "kodeKECAMATAN": 7403100,
        "kodeKABUPATEN": 7403,
        "namaKECAMATAN": "SAMPARA"
      },
      {
        "kodeKECAMATAN": 7403101,
        "kodeKABUPATEN": 7403,
        "namaKECAMATAN": "BONDOALA"
      },
      {
        "kodeKECAMATAN": 7403102,
        "kodeKABUPATEN": 7403,
        "namaKECAMATAN": "BESULUTU"
      },
      {
        "kodeKECAMATAN": 7403103,
        "kodeKABUPATEN": 7403,
        "namaKECAMATAN": "KAPOIALA"
      },
      {
        "kodeKECAMATAN": 7403104,
        "kodeKABUPATEN": 7403,
        "namaKECAMATAN": "ANGGALOMOARE"
      },
      {
        "kodeKECAMATAN": 7403105,
        "kodeKABUPATEN": 7403,
        "namaKECAMATAN": "MOROSI"
      },
      {
        "kodeKECAMATAN": 7403130,
        "kodeKABUPATEN": 7403,
        "namaKECAMATAN": "LAMBUYA"
      },
      {
        "kodeKECAMATAN": 7403131,
        "kodeKABUPATEN": 7403,
        "namaKECAMATAN": "UEPAI"
      },
      {
        "kodeKECAMATAN": 7403132,
        "kodeKABUPATEN": 7403,
        "namaKECAMATAN": "PURIALA"
      },
      {
        "kodeKECAMATAN": 7403133,
        "kodeKABUPATEN": 7403,
        "namaKECAMATAN": "ONEMBUTE"
      },
      {
        "kodeKECAMATAN": 7403140,
        "kodeKABUPATEN": 7403,
        "namaKECAMATAN": "PONDIDAHA"
      },
      {
        "kodeKECAMATAN": 7403141,
        "kodeKABUPATEN": 7403,
        "namaKECAMATAN": "WONGGEDUKU"
      },
      {
        "kodeKECAMATAN": 7403142,
        "kodeKABUPATEN": 7403,
        "namaKECAMATAN": "AMONGGEDO"
      },
      {
        "kodeKECAMATAN": 7403143,
        "kodeKABUPATEN": 7403,
        "namaKECAMATAN": "WONGGEDUKU BARAT"
      },
      {
        "kodeKECAMATAN": 7403150,
        "kodeKABUPATEN": 7403,
        "namaKECAMATAN": "WAWOTOBI"
      },
      {
        "kodeKECAMATAN": 7403151,
        "kodeKABUPATEN": 7403,
        "namaKECAMATAN": "MELUHU"
      },
      {
        "kodeKECAMATAN": 7403152,
        "kodeKABUPATEN": 7403,
        "namaKECAMATAN": "KONAWE"
      },
      {
        "kodeKECAMATAN": 7403170,
        "kodeKABUPATEN": 7403,
        "namaKECAMATAN": "UNAAHA"
      },
      {
        "kodeKECAMATAN": 7403171,
        "kodeKABUPATEN": 7403,
        "namaKECAMATAN": "ANGGABERI"
      },
      {
        "kodeKECAMATAN": 7403180,
        "kodeKABUPATEN": 7403,
        "namaKECAMATAN": "ABUKI"
      },
      {
        "kodeKECAMATAN": 7403181,
        "kodeKABUPATEN": 7403,
        "namaKECAMATAN": "LATOMA"
      },
      {
        "kodeKECAMATAN": 7403182,
        "kodeKABUPATEN": 7403,
        "namaKECAMATAN": "TONGAUNA"
      },
      {
        "kodeKECAMATAN": 7403183,
        "kodeKABUPATEN": 7403,
        "namaKECAMATAN": "ASINUA"
      },
      {
        "kodeKECAMATAN": 7403184,
        "kodeKABUPATEN": 7403,
        "namaKECAMATAN": "PADANGGUNI"
      },
      {
        "kodeKECAMATAN": 7403193,
        "kodeKABUPATEN": 7403,
        "namaKECAMATAN": "ROUTA"
      },
      {
        "kodeKECAMATAN": 7404010,
        "kodeKABUPATEN": 7404,
        "namaKECAMATAN": "WATUBANGGA"
      },
      {
        "kodeKECAMATAN": 7404011,
        "kodeKABUPATEN": 7404,
        "namaKECAMATAN": "TANGGETADA"
      },
      {
        "kodeKECAMATAN": 7404012,
        "kodeKABUPATEN": 7404,
        "namaKECAMATAN": "TOARI"
      },
      {
        "kodeKECAMATAN": 7404013,
        "kodeKABUPATEN": 7404,
        "namaKECAMATAN": "POLINGGONA"
      },
      {
        "kodeKECAMATAN": 7404020,
        "kodeKABUPATEN": 7404,
        "namaKECAMATAN": "POMALAA"
      },
      {
        "kodeKECAMATAN": 7404030,
        "kodeKABUPATEN": 7404,
        "namaKECAMATAN": "WUNDULAKO"
      },
      {
        "kodeKECAMATAN": 7404031,
        "kodeKABUPATEN": 7404,
        "namaKECAMATAN": "BAULA"
      },
      {
        "kodeKECAMATAN": 7404060,
        "kodeKABUPATEN": 7404,
        "namaKECAMATAN": "KOLAKA"
      },
      {
        "kodeKECAMATAN": 7404061,
        "kodeKABUPATEN": 7404,
        "namaKECAMATAN": "LATAMBAGA"
      },
      {
        "kodeKECAMATAN": 7404070,
        "kodeKABUPATEN": 7404,
        "namaKECAMATAN": "WOLO"
      },
      {
        "kodeKECAMATAN": 7404071,
        "kodeKABUPATEN": 7404,
        "namaKECAMATAN": "SAMATURU"
      },
      {
        "kodeKECAMATAN": 7404072,
        "kodeKABUPATEN": 7404,
        "namaKECAMATAN": "IWOIMENDAA"
      },
      {
        "kodeKECAMATAN": 7405010,
        "kodeKABUPATEN": 7405,
        "namaKECAMATAN": "TINANGGEA"
      },
      {
        "kodeKECAMATAN": 7405011,
        "kodeKABUPATEN": 7405,
        "namaKECAMATAN": "LALEMBUU"
      },
      {
        "kodeKECAMATAN": 7405020,
        "kodeKABUPATEN": 7405,
        "namaKECAMATAN": "ANDOOLO"
      },
      {
        "kodeKECAMATAN": 7405021,
        "kodeKABUPATEN": 7405,
        "namaKECAMATAN": "BUKE"
      },
      {
        "kodeKECAMATAN": 7405022,
        "kodeKABUPATEN": 7405,
        "namaKECAMATAN": "ANDOOLO BARAT"
      },
      {
        "kodeKECAMATAN": 7405030,
        "kodeKABUPATEN": 7405,
        "namaKECAMATAN": "PALANGGA"
      },
      {
        "kodeKECAMATAN": 7405031,
        "kodeKABUPATEN": 7405,
        "namaKECAMATAN": "PALANGGA SELATAN"
      },
      {
        "kodeKECAMATAN": 7405032,
        "kodeKABUPATEN": 7405,
        "namaKECAMATAN": "BAITO"
      },
      {
        "kodeKECAMATAN": 7405040,
        "kodeKABUPATEN": 7405,
        "namaKECAMATAN": "LAINEA"
      },
      {
        "kodeKECAMATAN": 7405041,
        "kodeKABUPATEN": 7405,
        "namaKECAMATAN": "LAEYA"
      },
      {
        "kodeKECAMATAN": 7405050,
        "kodeKABUPATEN": 7405,
        "namaKECAMATAN": "KOLONO"
      },
      {
        "kodeKECAMATAN": 7405051,
        "kodeKABUPATEN": 7405,
        "namaKECAMATAN": "KOLONO TIMUR"
      },
      {
        "kodeKECAMATAN": 7405060,
        "kodeKABUPATEN": 7405,
        "namaKECAMATAN": "LAONTI"
      },
      {
        "kodeKECAMATAN": 7405070,
        "kodeKABUPATEN": 7405,
        "namaKECAMATAN": "MORAMO"
      },
      {
        "kodeKECAMATAN": 7405071,
        "kodeKABUPATEN": 7405,
        "namaKECAMATAN": "MORAMO UTARA"
      },
      {
        "kodeKECAMATAN": 7405080,
        "kodeKABUPATEN": 7405,
        "namaKECAMATAN": "KONDA"
      },
      {
        "kodeKECAMATAN": 7405081,
        "kodeKABUPATEN": 7405,
        "namaKECAMATAN": "WOLASI"
      },
      {
        "kodeKECAMATAN": 7405090,
        "kodeKABUPATEN": 7405,
        "namaKECAMATAN": "RANOMEETO"
      },
      {
        "kodeKECAMATAN": 7405091,
        "kodeKABUPATEN": 7405,
        "namaKECAMATAN": "RANOMEETO BARAT"
      },
      {
        "kodeKECAMATAN": 7405100,
        "kodeKABUPATEN": 7405,
        "namaKECAMATAN": "LANDONO"
      },
      {
        "kodeKECAMATAN": 7405101,
        "kodeKABUPATEN": 7405,
        "namaKECAMATAN": "MOWILA"
      },
      {
        "kodeKECAMATAN": 7405102,
        "kodeKABUPATEN": 7405,
        "namaKECAMATAN": "SABULAKOA"
      },
      {
        "kodeKECAMATAN": 7405110,
        "kodeKABUPATEN": 7405,
        "namaKECAMATAN": "ANGATA"
      },
      {
        "kodeKECAMATAN": 7405111,
        "kodeKABUPATEN": 7405,
        "namaKECAMATAN": "BENUA"
      },
      {
        "kodeKECAMATAN": 7405112,
        "kodeKABUPATEN": 7405,
        "namaKECAMATAN": "BASALA"
      },
      {
        "kodeKECAMATAN": 7406010,
        "kodeKABUPATEN": 7406,
        "namaKECAMATAN": "KABAENA"
      },
      {
        "kodeKECAMATAN": 7406011,
        "kodeKABUPATEN": 7406,
        "namaKECAMATAN": "KABAENA UTARA"
      },
      {
        "kodeKECAMATAN": 7406012,
        "kodeKABUPATEN": 7406,
        "namaKECAMATAN": "KABAENA SELATAN"
      },
      {
        "kodeKECAMATAN": 7406013,
        "kodeKABUPATEN": 7406,
        "namaKECAMATAN": "KABAENA BARAT"
      },
      {
        "kodeKECAMATAN": 7406020,
        "kodeKABUPATEN": 7406,
        "namaKECAMATAN": "KABAENA TIMUR"
      },
      {
        "kodeKECAMATAN": 7406021,
        "kodeKABUPATEN": 7406,
        "namaKECAMATAN": "KABAENA TENGAH"
      },
      {
        "kodeKECAMATAN": 7406030,
        "kodeKABUPATEN": 7406,
        "namaKECAMATAN": "RUMBIA"
      },
      {
        "kodeKECAMATAN": 7406031,
        "kodeKABUPATEN": 7406,
        "namaKECAMATAN": "MATA OLEO"
      },
      {
        "kodeKECAMATAN": 7406032,
        "kodeKABUPATEN": 7406,
        "namaKECAMATAN": "KEP. MASALOKA RAYA"
      },
      {
        "kodeKECAMATAN": 7406033,
        "kodeKABUPATEN": 7406,
        "namaKECAMATAN": "RUMBIA TENGAH"
      },
      {
        "kodeKECAMATAN": 7406040,
        "kodeKABUPATEN": 7406,
        "namaKECAMATAN": "RAROWATU"
      },
      {
        "kodeKECAMATAN": 7406041,
        "kodeKABUPATEN": 7406,
        "namaKECAMATAN": "RAROWATU UTARA"
      },
      {
        "kodeKECAMATAN": 7406042,
        "kodeKABUPATEN": 7406,
        "namaKECAMATAN": "MATA USU"
      },
      {
        "kodeKECAMATAN": 7406043,
        "kodeKABUPATEN": 7406,
        "namaKECAMATAN": "LANTARI JAYA"
      },
      {
        "kodeKECAMATAN": 7406050,
        "kodeKABUPATEN": 7406,
        "namaKECAMATAN": "POLEANG TIMUR"
      },
      {
        "kodeKECAMATAN": 7406051,
        "kodeKABUPATEN": 7406,
        "namaKECAMATAN": "POLEANG UTARA"
      },
      {
        "kodeKECAMATAN": 7406052,
        "kodeKABUPATEN": 7406,
        "namaKECAMATAN": "POLEANG SELATAN"
      },
      {
        "kodeKECAMATAN": 7406053,
        "kodeKABUPATEN": 7406,
        "namaKECAMATAN": "POLEANG TENGGARA"
      },
      {
        "kodeKECAMATAN": 7406060,
        "kodeKABUPATEN": 7406,
        "namaKECAMATAN": "POLEANG"
      },
      {
        "kodeKECAMATAN": 7406061,
        "kodeKABUPATEN": 7406,
        "namaKECAMATAN": "POLEANG BARAT"
      },
      {
        "kodeKECAMATAN": 7406062,
        "kodeKABUPATEN": 7406,
        "namaKECAMATAN": "TONTONUNU"
      },
      {
        "kodeKECAMATAN": 7406063,
        "kodeKABUPATEN": 7406,
        "namaKECAMATAN": "POLEANG TENGAH"
      },
      {
        "kodeKECAMATAN": 7407010,
        "kodeKABUPATEN": 7407,
        "namaKECAMATAN": "BINONGKO"
      },
      {
        "kodeKECAMATAN": 7407011,
        "kodeKABUPATEN": 7407,
        "namaKECAMATAN": "TOGO BINONGKO"
      },
      {
        "kodeKECAMATAN": 7407020,
        "kodeKABUPATEN": 7407,
        "namaKECAMATAN": "TOMIA"
      },
      {
        "kodeKECAMATAN": 7407021,
        "kodeKABUPATEN": 7407,
        "namaKECAMATAN": "TOMIA TIMUR"
      },
      {
        "kodeKECAMATAN": 7407030,
        "kodeKABUPATEN": 7407,
        "namaKECAMATAN": "KALEDUPA"
      },
      {
        "kodeKECAMATAN": 7407031,
        "kodeKABUPATEN": 7407,
        "namaKECAMATAN": "KALEDUPA SELATAN"
      },
      {
        "kodeKECAMATAN": 7407040,
        "kodeKABUPATEN": 7407,
        "namaKECAMATAN": "WANGI-WANGI"
      },
      {
        "kodeKECAMATAN": 7407050,
        "kodeKABUPATEN": 7407,
        "namaKECAMATAN": "WANGI-WANGI SELATAN"
      },
      {
        "kodeKECAMATAN": 7408010,
        "kodeKABUPATEN": 7408,
        "namaKECAMATAN": "RANTEANGIN"
      },
      {
        "kodeKECAMATAN": 7408011,
        "kodeKABUPATEN": 7408,
        "namaKECAMATAN": "LAMBAI"
      },
      {
        "kodeKECAMATAN": 7408012,
        "kodeKABUPATEN": 7408,
        "namaKECAMATAN": "WAWO"
      },
      {
        "kodeKECAMATAN": 7408020,
        "kodeKABUPATEN": 7408,
        "namaKECAMATAN": "LASUSUA"
      },
      {
        "kodeKECAMATAN": 7408021,
        "kodeKABUPATEN": 7408,
        "namaKECAMATAN": "KATOI"
      },
      {
        "kodeKECAMATAN": 7408030,
        "kodeKABUPATEN": 7408,
        "namaKECAMATAN": "KODEOHA"
      },
      {
        "kodeKECAMATAN": 7408031,
        "kodeKABUPATEN": 7408,
        "namaKECAMATAN": "TIWU"
      },
      {
        "kodeKECAMATAN": 7408040,
        "kodeKABUPATEN": 7408,
        "namaKECAMATAN": "NGAPA"
      },
      {
        "kodeKECAMATAN": 7408041,
        "kodeKABUPATEN": 7408,
        "namaKECAMATAN": "WATUNOHU"
      },
      {
        "kodeKECAMATAN": 7408050,
        "kodeKABUPATEN": 7408,
        "namaKECAMATAN": "PAKUE"
      },
      {
        "kodeKECAMATAN": 7408051,
        "kodeKABUPATEN": 7408,
        "namaKECAMATAN": "PAKUE UTARA"
      },
      {
        "kodeKECAMATAN": 7408052,
        "kodeKABUPATEN": 7408,
        "namaKECAMATAN": "PAKUE TENGAH"
      },
      {
        "kodeKECAMATAN": 7408060,
        "kodeKABUPATEN": 7408,
        "namaKECAMATAN": "BATU PUTIH"
      },
      {
        "kodeKECAMATAN": 7408061,
        "kodeKABUPATEN": 7408,
        "namaKECAMATAN": "POREHU"
      },
      {
        "kodeKECAMATAN": 7408062,
        "kodeKABUPATEN": 7408,
        "namaKECAMATAN": "TOLALA"
      },
      {
        "kodeKECAMATAN": 7409100,
        "kodeKABUPATEN": 7409,
        "namaKECAMATAN": "BONEGUNU"
      },
      {
        "kodeKECAMATAN": 7409101,
        "kodeKABUPATEN": 7409,
        "namaKECAMATAN": "KAMBOWA"
      },
      {
        "kodeKECAMATAN": 7409110,
        "kodeKABUPATEN": 7409,
        "namaKECAMATAN": "WAKORUMBA"
      },
      {
        "kodeKECAMATAN": 7409120,
        "kodeKABUPATEN": 7409,
        "namaKECAMATAN": "KULISUSU"
      },
      {
        "kodeKECAMATAN": 7409121,
        "kodeKABUPATEN": 7409,
        "namaKECAMATAN": "KULISUSU BARAT"
      },
      {
        "kodeKECAMATAN": 7409122,
        "kodeKABUPATEN": 7409,
        "namaKECAMATAN": "KULISUSU UTARA"
      },
      {
        "kodeKECAMATAN": 7410010,
        "kodeKABUPATEN": 7410,
        "namaKECAMATAN": "SAWA"
      },
      {
        "kodeKECAMATAN": 7410011,
        "kodeKABUPATEN": 7410,
        "namaKECAMATAN": "MOTUI"
      },
      {
        "kodeKECAMATAN": 7410020,
        "kodeKABUPATEN": 7410,
        "namaKECAMATAN": "LEMBO"
      },
      {
        "kodeKECAMATAN": 7410030,
        "kodeKABUPATEN": 7410,
        "namaKECAMATAN": "LASOLO"
      },
      {
        "kodeKECAMATAN": 7410040,
        "kodeKABUPATEN": 7410,
        "namaKECAMATAN": "MOLAWE"
      },
      {
        "kodeKECAMATAN": 7410050,
        "kodeKABUPATEN": 7410,
        "namaKECAMATAN": "ASERA"
      },
      {
        "kodeKECAMATAN": 7410051,
        "kodeKABUPATEN": 7410,
        "namaKECAMATAN": "ANDOWIA"
      },
      {
        "kodeKECAMATAN": 7410052,
        "kodeKABUPATEN": 7410,
        "namaKECAMATAN": "OHEO"
      },
      {
        "kodeKECAMATAN": 7410060,
        "kodeKABUPATEN": 7410,
        "namaKECAMATAN": "LANGGIKIMA"
      },
      {
        "kodeKECAMATAN": 7410070,
        "kodeKABUPATEN": 7410,
        "namaKECAMATAN": "WIWIRANO"
      },
      {
        "kodeKECAMATAN": 7411010,
        "kodeKABUPATEN": 7411,
        "namaKECAMATAN": "AERE"
      },
      {
        "kodeKECAMATAN": 7411020,
        "kodeKABUPATEN": 7411,
        "namaKECAMATAN": "LAMBANDIA"
      },
      {
        "kodeKECAMATAN": 7411030,
        "kodeKABUPATEN": 7411,
        "namaKECAMATAN": "POLI-POLIA"
      },
      {
        "kodeKECAMATAN": 7411040,
        "kodeKABUPATEN": 7411,
        "namaKECAMATAN": "DANGIA"
      },
      {
        "kodeKECAMATAN": 7411050,
        "kodeKABUPATEN": 7411,
        "namaKECAMATAN": "LADONGI"
      },
      {
        "kodeKECAMATAN": 7411060,
        "kodeKABUPATEN": 7411,
        "namaKECAMATAN": "LOEA"
      },
      {
        "kodeKECAMATAN": 7411070,
        "kodeKABUPATEN": 7411,
        "namaKECAMATAN": "TIRAWUTA"
      },
      {
        "kodeKECAMATAN": 7411080,
        "kodeKABUPATEN": 7411,
        "namaKECAMATAN": "LALOLAE"
      },
      {
        "kodeKECAMATAN": 7411090,
        "kodeKABUPATEN": 7411,
        "namaKECAMATAN": "MOWEWE"
      },
      {
        "kodeKECAMATAN": 7411100,
        "kodeKABUPATEN": 7411,
        "namaKECAMATAN": "TINONDO"
      },
      {
        "kodeKECAMATAN": 7411110,
        "kodeKABUPATEN": 7411,
        "namaKECAMATAN": "ULUIWOI"
      },
      {
        "kodeKECAMATAN": 7411120,
        "kodeKABUPATEN": 7411,
        "namaKECAMATAN": "UEESI"
      },
      {
        "kodeKECAMATAN": 7412010,
        "kodeKABUPATEN": 7412,
        "namaKECAMATAN": "WAWONII TENGGARA"
      },
      {
        "kodeKECAMATAN": 7412020,
        "kodeKABUPATEN": 7412,
        "namaKECAMATAN": "WAWONII TIMUR"
      },
      {
        "kodeKECAMATAN": 7412030,
        "kodeKABUPATEN": 7412,
        "namaKECAMATAN": "WAWONII TIMUR LAUT"
      },
      {
        "kodeKECAMATAN": 7412040,
        "kodeKABUPATEN": 7412,
        "namaKECAMATAN": "WAWONII UTARA"
      },
      {
        "kodeKECAMATAN": 7412050,
        "kodeKABUPATEN": 7412,
        "namaKECAMATAN": "WAWONII SELATAN"
      },
      {
        "kodeKECAMATAN": 7412060,
        "kodeKABUPATEN": 7412,
        "namaKECAMATAN": "WAWONII TENGAH"
      },
      {
        "kodeKECAMATAN": 7412070,
        "kodeKABUPATEN": 7412,
        "namaKECAMATAN": "WAWONII BARAT"
      },
      {
        "kodeKECAMATAN": 7413010,
        "kodeKABUPATEN": 7413,
        "namaKECAMATAN": "TIWORO KEPULAUAN"
      },
      {
        "kodeKECAMATAN": 7413020,
        "kodeKABUPATEN": 7413,
        "namaKECAMATAN": "MAGINTI"
      },
      {
        "kodeKECAMATAN": 7413030,
        "kodeKABUPATEN": 7413,
        "namaKECAMATAN": "TIWORO TENGAH"
      },
      {
        "kodeKECAMATAN": 7413040,
        "kodeKABUPATEN": 7413,
        "namaKECAMATAN": "TIWORO SELATAN"
      },
      {
        "kodeKECAMATAN": 7413050,
        "kodeKABUPATEN": 7413,
        "namaKECAMATAN": "TIWORO UTARA"
      },
      {
        "kodeKECAMATAN": 7413060,
        "kodeKABUPATEN": 7413,
        "namaKECAMATAN": "LAWA"
      },
      {
        "kodeKECAMATAN": 7413070,
        "kodeKABUPATEN": 7413,
        "namaKECAMATAN": "SAWERIGADI"
      },
      {
        "kodeKECAMATAN": 7413080,
        "kodeKABUPATEN": 7413,
        "namaKECAMATAN": "BARANGKA"
      },
      {
        "kodeKECAMATAN": 7413090,
        "kodeKABUPATEN": 7413,
        "namaKECAMATAN": "WA DAGA"
      },
      {
        "kodeKECAMATAN": 7413100,
        "kodeKABUPATEN": 7413,
        "namaKECAMATAN": "KUSAMBI"
      },
      {
        "kodeKECAMATAN": 7413110,
        "kodeKABUPATEN": 7413,
        "namaKECAMATAN": "NAPANO KUSAMBI"
      },
      {
        "kodeKECAMATAN": 7414010,
        "kodeKABUPATEN": 7414,
        "namaKECAMATAN": "TALAGA RAYA"
      },
      {
        "kodeKECAMATAN": 7414020,
        "kodeKABUPATEN": 7414,
        "namaKECAMATAN": "MAWASANGKA"
      },
      {
        "kodeKECAMATAN": 7414030,
        "kodeKABUPATEN": 7414,
        "namaKECAMATAN": "MAWASANGKA TENGAH"
      },
      {
        "kodeKECAMATAN": 7414040,
        "kodeKABUPATEN": 7414,
        "namaKECAMATAN": "MAWASANGKA TIMUR"
      },
      {
        "kodeKECAMATAN": 7414050,
        "kodeKABUPATEN": 7414,
        "namaKECAMATAN": "LAKUDO"
      },
      {
        "kodeKECAMATAN": 7414060,
        "kodeKABUPATEN": 7414,
        "namaKECAMATAN": "GU"
      },
      {
        "kodeKECAMATAN": 7414070,
        "kodeKABUPATEN": 7414,
        "namaKECAMATAN": "SANGIA WAMBULU"
      },
      {
        "kodeKECAMATAN": 7415010,
        "kodeKABUPATEN": 7415,
        "namaKECAMATAN": "BATU ATAS"
      },
      {
        "kodeKECAMATAN": 7415020,
        "kodeKABUPATEN": 7415,
        "namaKECAMATAN": "LAPANDEWA"
      },
      {
        "kodeKECAMATAN": 7415030,
        "kodeKABUPATEN": 7415,
        "namaKECAMATAN": "SAMPOLAWA"
      },
      {
        "kodeKECAMATAN": 7415040,
        "kodeKABUPATEN": 7415,
        "namaKECAMATAN": "BATAUGA"
      },
      {
        "kodeKECAMATAN": 7415050,
        "kodeKABUPATEN": 7415,
        "namaKECAMATAN": "SIOMPU BARAT"
      },
      {
        "kodeKECAMATAN": 7415060,
        "kodeKABUPATEN": 7415,
        "namaKECAMATAN": "SIOMPU"
      },
      {
        "kodeKECAMATAN": 7415070,
        "kodeKABUPATEN": 7415,
        "namaKECAMATAN": "KADATUA"
      },
      {
        "kodeKECAMATAN": 7471010,
        "kodeKABUPATEN": 7471,
        "namaKECAMATAN": "MANDONGA"
      },
      {
        "kodeKECAMATAN": 7471011,
        "kodeKABUPATEN": 7471,
        "namaKECAMATAN": "BARUGA"
      },
      {
        "kodeKECAMATAN": 7471012,
        "kodeKABUPATEN": 7471,
        "namaKECAMATAN": "PUUWATU"
      },
      {
        "kodeKECAMATAN": 7471013,
        "kodeKABUPATEN": 7471,
        "namaKECAMATAN": "KADIA"
      },
      {
        "kodeKECAMATAN": 7471014,
        "kodeKABUPATEN": 7471,
        "namaKECAMATAN": "WUA-WUA"
      },
      {
        "kodeKECAMATAN": 7471020,
        "kodeKABUPATEN": 7471,
        "namaKECAMATAN": "POASIA"
      },
      {
        "kodeKECAMATAN": 7471021,
        "kodeKABUPATEN": 7471,
        "namaKECAMATAN": "ABELI"
      },
      {
        "kodeKECAMATAN": 7471022,
        "kodeKABUPATEN": 7471,
        "namaKECAMATAN": "KAMBU"
      },
      {
        "kodeKECAMATAN": 7471030,
        "kodeKABUPATEN": 7471,
        "namaKECAMATAN": "KENDARI"
      },
      {
        "kodeKECAMATAN": 7471031,
        "kodeKABUPATEN": 7471,
        "namaKECAMATAN": "KENDARI BARAT"
      },
      {
        "kodeKECAMATAN": 7472010,
        "kodeKABUPATEN": 7472,
        "namaKECAMATAN": "BETOAMBARI"
      },
      {
        "kodeKECAMATAN": 7472011,
        "kodeKABUPATEN": 7472,
        "namaKECAMATAN": "MURHUM"
      },
      {
        "kodeKECAMATAN": 7472012,
        "kodeKABUPATEN": 7472,
        "namaKECAMATAN": "BATUPOARO"
      },
      {
        "kodeKECAMATAN": 7472020,
        "kodeKABUPATEN": 7472,
        "namaKECAMATAN": "WOLIO"
      },
      {
        "kodeKECAMATAN": 7472021,
        "kodeKABUPATEN": 7472,
        "namaKECAMATAN": "KOKALUKUNA"
      },
      {
        "kodeKECAMATAN": 7472030,
        "kodeKABUPATEN": 7472,
        "namaKECAMATAN": "SORAWOLIO"
      },
      {
        "kodeKECAMATAN": 7472040,
        "kodeKABUPATEN": 7472,
        "namaKECAMATAN": "BUNGI"
      },
      {
        "kodeKECAMATAN": 7472041,
        "kodeKABUPATEN": 7472,
        "namaKECAMATAN": "LEA-LEA"
      },
      {
        "kodeKECAMATAN": 7501031,
        "kodeKABUPATEN": 7501,
        "namaKECAMATAN": "MANANGGU"
      },
      {
        "kodeKECAMATAN": 7501040,
        "kodeKABUPATEN": 7501,
        "namaKECAMATAN": "TILAMUTA"
      },
      {
        "kodeKECAMATAN": 7501041,
        "kodeKABUPATEN": 7501,
        "namaKECAMATAN": "DULUPI"
      },
      {
        "kodeKECAMATAN": 7501042,
        "kodeKABUPATEN": 7501,
        "namaKECAMATAN": "BOTUMOITO"
      },
      {
        "kodeKECAMATAN": 7501050,
        "kodeKABUPATEN": 7501,
        "namaKECAMATAN": "PAGUYAMAN"
      },
      {
        "kodeKECAMATAN": 7501051,
        "kodeKABUPATEN": 7501,
        "namaKECAMATAN": "WONOSARI"
      },
      {
        "kodeKECAMATAN": 7501052,
        "kodeKABUPATEN": 7501,
        "namaKECAMATAN": "PAGUYAMAN PANTAI"
      },
      {
        "kodeKECAMATAN": 7502010,
        "kodeKABUPATEN": 7502,
        "namaKECAMATAN": "BATUDAA PANTAI"
      },
      {
        "kodeKECAMATAN": 7502011,
        "kodeKABUPATEN": 7502,
        "namaKECAMATAN": "BILUHU"
      },
      {
        "kodeKECAMATAN": 7502020,
        "kodeKABUPATEN": 7502,
        "namaKECAMATAN": "BATUDAA"
      },
      {
        "kodeKECAMATAN": 7502021,
        "kodeKABUPATEN": 7502,
        "namaKECAMATAN": "BONGOMEME"
      },
      {
        "kodeKECAMATAN": 7502022,
        "kodeKABUPATEN": 7502,
        "namaKECAMATAN": "TABONGO"
      },
      {
        "kodeKECAMATAN": 7502023,
        "kodeKABUPATEN": 7502,
        "namaKECAMATAN": "DUNGALIYO"
      },
      {
        "kodeKECAMATAN": 7502030,
        "kodeKABUPATEN": 7502,
        "namaKECAMATAN": "TIBAWA"
      },
      {
        "kodeKECAMATAN": 7502031,
        "kodeKABUPATEN": 7502,
        "namaKECAMATAN": "PULUBALA"
      },
      {
        "kodeKECAMATAN": 7502040,
        "kodeKABUPATEN": 7502,
        "namaKECAMATAN": "BOLIYOHUTO"
      },
      {
        "kodeKECAMATAN": 7502041,
        "kodeKABUPATEN": 7502,
        "namaKECAMATAN": "MOOTILANGO"
      },
      {
        "kodeKECAMATAN": 7502042,
        "kodeKABUPATEN": 7502,
        "namaKECAMATAN": "TOLANGOHULA"
      },
      {
        "kodeKECAMATAN": 7502043,
        "kodeKABUPATEN": 7502,
        "namaKECAMATAN": "ASPARAGA"
      },
      {
        "kodeKECAMATAN": 7502044,
        "kodeKABUPATEN": 7502,
        "namaKECAMATAN": "BILATO"
      },
      {
        "kodeKECAMATAN": 7502070,
        "kodeKABUPATEN": 7502,
        "namaKECAMATAN": "LIMBOTO"
      },
      {
        "kodeKECAMATAN": 7502071,
        "kodeKABUPATEN": 7502,
        "namaKECAMATAN": "LIMBOTO BARAT"
      },
      {
        "kodeKECAMATAN": 7502080,
        "kodeKABUPATEN": 7502,
        "namaKECAMATAN": "TELAGA"
      },
      {
        "kodeKECAMATAN": 7502081,
        "kodeKABUPATEN": 7502,
        "namaKECAMATAN": "TELAGA BIRU"
      },
      {
        "kodeKECAMATAN": 7502082,
        "kodeKABUPATEN": 7502,
        "namaKECAMATAN": "TILANGO"
      },
      {
        "kodeKECAMATAN": 7502083,
        "kodeKABUPATEN": 7502,
        "namaKECAMATAN": "TELAGA JAYA"
      },
      {
        "kodeKECAMATAN": 7503010,
        "kodeKABUPATEN": 7503,
        "namaKECAMATAN": "POPAYATO"
      },
      {
        "kodeKECAMATAN": 7503011,
        "kodeKABUPATEN": 7503,
        "namaKECAMATAN": "POPAYATO BARAT"
      },
      {
        "kodeKECAMATAN": 7503012,
        "kodeKABUPATEN": 7503,
        "namaKECAMATAN": "POPAYATO TIMUR"
      },
      {
        "kodeKECAMATAN": 7503020,
        "kodeKABUPATEN": 7503,
        "namaKECAMATAN": "LEMITO"
      },
      {
        "kodeKECAMATAN": 7503021,
        "kodeKABUPATEN": 7503,
        "namaKECAMATAN": "WANGGARASI"
      },
      {
        "kodeKECAMATAN": 7503030,
        "kodeKABUPATEN": 7503,
        "namaKECAMATAN": "MARISA"
      },
      {
        "kodeKECAMATAN": 7503031,
        "kodeKABUPATEN": 7503,
        "namaKECAMATAN": "PATILANGGIO"
      },
      {
        "kodeKECAMATAN": 7503032,
        "kodeKABUPATEN": 7503,
        "namaKECAMATAN": "BUNTULIA"
      },
      {
        "kodeKECAMATAN": 7503033,
        "kodeKABUPATEN": 7503,
        "namaKECAMATAN": "DUHIADAA"
      },
      {
        "kodeKECAMATAN": 7503040,
        "kodeKABUPATEN": 7503,
        "namaKECAMATAN": "RANDANGAN"
      },
      {
        "kodeKECAMATAN": 7503041,
        "kodeKABUPATEN": 7503,
        "namaKECAMATAN": "TALUDITI"
      },
      {
        "kodeKECAMATAN": 7503050,
        "kodeKABUPATEN": 7503,
        "namaKECAMATAN": "PAGUAT"
      },
      {
        "kodeKECAMATAN": 7503051,
        "kodeKABUPATEN": 7503,
        "namaKECAMATAN": "DENGILO"
      },
      {
        "kodeKECAMATAN": 7504010,
        "kodeKABUPATEN": 7504,
        "namaKECAMATAN": "TAPA"
      },
      {
        "kodeKECAMATAN": 7504011,
        "kodeKABUPATEN": 7504,
        "namaKECAMATAN": "BULANGO UTARA"
      },
      {
        "kodeKECAMATAN": 7504012,
        "kodeKABUPATEN": 7504,
        "namaKECAMATAN": "BULANGO SELATAN"
      },
      {
        "kodeKECAMATAN": 7504013,
        "kodeKABUPATEN": 7504,
        "namaKECAMATAN": "BULANGO TIMUR"
      },
      {
        "kodeKECAMATAN": 7504014,
        "kodeKABUPATEN": 7504,
        "namaKECAMATAN": "BULANGO ULU"
      },
      {
        "kodeKECAMATAN": 7504020,
        "kodeKABUPATEN": 7504,
        "namaKECAMATAN": "KABILA"
      },
      {
        "kodeKECAMATAN": 7504021,
        "kodeKABUPATEN": 7504,
        "namaKECAMATAN": "BOTU PINGGE"
      },
      {
        "kodeKECAMATAN": 7504022,
        "kodeKABUPATEN": 7504,
        "namaKECAMATAN": "TILONGKABILA"
      },
      {
        "kodeKECAMATAN": 7504030,
        "kodeKABUPATEN": 7504,
        "namaKECAMATAN": "SUWAWA"
      },
      {
        "kodeKECAMATAN": 7504031,
        "kodeKABUPATEN": 7504,
        "namaKECAMATAN": "SUWAWA SELATAN"
      },
      {
        "kodeKECAMATAN": 7504032,
        "kodeKABUPATEN": 7504,
        "namaKECAMATAN": "SUWAWA TIMUR"
      },
      {
        "kodeKECAMATAN": 7504033,
        "kodeKABUPATEN": 7504,
        "namaKECAMATAN": "SUWAWA TENGAH"
      },
      {
        "kodeKECAMATAN": 7504034,
        "kodeKABUPATEN": 7504,
        "namaKECAMATAN": "PINOGU"
      },
      {
        "kodeKECAMATAN": 7504040,
        "kodeKABUPATEN": 7504,
        "namaKECAMATAN": "BONEPANTAI"
      },
      {
        "kodeKECAMATAN": 7504041,
        "kodeKABUPATEN": 7504,
        "namaKECAMATAN": "KABILA BONE"
      },
      {
        "kodeKECAMATAN": 7504042,
        "kodeKABUPATEN": 7504,
        "namaKECAMATAN": "BONE RAYA"
      },
      {
        "kodeKECAMATAN": 7504043,
        "kodeKABUPATEN": 7504,
        "namaKECAMATAN": "BONE"
      },
      {
        "kodeKECAMATAN": 7504044,
        "kodeKABUPATEN": 7504,
        "namaKECAMATAN": "BULAWA"
      },
      {
        "kodeKECAMATAN": 7505010,
        "kodeKABUPATEN": 7505,
        "namaKECAMATAN": "ATINGGOLA"
      },
      {
        "kodeKECAMATAN": 7505011,
        "kodeKABUPATEN": 7505,
        "namaKECAMATAN": "GENTUMA RAYA"
      },
      {
        "kodeKECAMATAN": 7505020,
        "kodeKABUPATEN": 7505,
        "namaKECAMATAN": "KWANDANG"
      },
      {
        "kodeKECAMATAN": 7505021,
        "kodeKABUPATEN": 7505,
        "namaKECAMATAN": "TOMILITO"
      },
      {
        "kodeKECAMATAN": 7505022,
        "kodeKABUPATEN": 7505,
        "namaKECAMATAN": "PONELO KEPULAUAN"
      },
      {
        "kodeKECAMATAN": 7505030,
        "kodeKABUPATEN": 7505,
        "namaKECAMATAN": "ANGGREK"
      },
      {
        "kodeKECAMATAN": 7505031,
        "kodeKABUPATEN": 7505,
        "namaKECAMATAN": "MONANO"
      },
      {
        "kodeKECAMATAN": 7505040,
        "kodeKABUPATEN": 7505,
        "namaKECAMATAN": "SUMALATA"
      },
      {
        "kodeKECAMATAN": 7505041,
        "kodeKABUPATEN": 7505,
        "namaKECAMATAN": "SUMALATA TIMUR"
      },
      {
        "kodeKECAMATAN": 7505050,
        "kodeKABUPATEN": 7505,
        "namaKECAMATAN": "TOLINGGULA"
      },
      {
        "kodeKECAMATAN": 7505051,
        "kodeKABUPATEN": 7505,
        "namaKECAMATAN": "BIAU"
      },
      {
        "kodeKECAMATAN": 7571010,
        "kodeKABUPATEN": 7571,
        "namaKECAMATAN": "KOTA BARAT"
      },
      {
        "kodeKECAMATAN": 7571011,
        "kodeKABUPATEN": 7571,
        "namaKECAMATAN": "DUNGINGI"
      },
      {
        "kodeKECAMATAN": 7571020,
        "kodeKABUPATEN": 7571,
        "namaKECAMATAN": "KOTA SELATAN"
      },
      {
        "kodeKECAMATAN": 7571021,
        "kodeKABUPATEN": 7571,
        "namaKECAMATAN": "KOTA TIMUR"
      },
      {
        "kodeKECAMATAN": 7571022,
        "kodeKABUPATEN": 7571,
        "namaKECAMATAN": "HULONTHALANGI"
      },
      {
        "kodeKECAMATAN": 7571023,
        "kodeKABUPATEN": 7571,
        "namaKECAMATAN": "DUMBO RAYA"
      },
      {
        "kodeKECAMATAN": 7571030,
        "kodeKABUPATEN": 7571,
        "namaKECAMATAN": "KOTA UTARA"
      },
      {
        "kodeKECAMATAN": 7571031,
        "kodeKABUPATEN": 7571,
        "namaKECAMATAN": "KOTA TENGAH"
      },
      {
        "kodeKECAMATAN": 7571032,
        "kodeKABUPATEN": 7571,
        "namaKECAMATAN": "SIPATANA"
      },
      {
        "kodeKECAMATAN": 7601010,
        "kodeKABUPATEN": 7601,
        "namaKECAMATAN": "BANGGAE"
      },
      {
        "kodeKECAMATAN": 7601011,
        "kodeKABUPATEN": 7601,
        "namaKECAMATAN": "BANGGAE TIMUR"
      },
      {
        "kodeKECAMATAN": 7601020,
        "kodeKABUPATEN": 7601,
        "namaKECAMATAN": "PAMBOANG"
      },
      {
        "kodeKECAMATAN": 7601030,
        "kodeKABUPATEN": 7601,
        "namaKECAMATAN": "SENDANA"
      },
      {
        "kodeKECAMATAN": 7601031,
        "kodeKABUPATEN": 7601,
        "namaKECAMATAN": "TAMMERODO"
      },
      {
        "kodeKECAMATAN": 7601033,
        "kodeKABUPATEN": 7601,
        "namaKECAMATAN": "TUBO SENDANA"
      },
      {
        "kodeKECAMATAN": 7601040,
        "kodeKABUPATEN": 7601,
        "namaKECAMATAN": "MALUNDA"
      },
      {
        "kodeKECAMATAN": 7601041,
        "kodeKABUPATEN": 7601,
        "namaKECAMATAN": "ULUMANDA"
      },
      {
        "kodeKECAMATAN": 7602010,
        "kodeKABUPATEN": 7602,
        "namaKECAMATAN": "TINAMBUNG"
      },
      {
        "kodeKECAMATAN": 7602011,
        "kodeKABUPATEN": 7602,
        "namaKECAMATAN": "BALANIPA"
      },
      {
        "kodeKECAMATAN": 7602012,
        "kodeKABUPATEN": 7602,
        "namaKECAMATAN": "LIMBORO"
      },
      {
        "kodeKECAMATAN": 7602020,
        "kodeKABUPATEN": 7602,
        "namaKECAMATAN": "TUBBI TARAMANU"
      },
      {
        "kodeKECAMATAN": 7602021,
        "kodeKABUPATEN": 7602,
        "namaKECAMATAN": "ALU"
      },
      {
        "kodeKECAMATAN": 7602030,
        "kodeKABUPATEN": 7602,
        "namaKECAMATAN": "CAMPALAGIAN"
      },
      {
        "kodeKECAMATAN": 7602031,
        "kodeKABUPATEN": 7602,
        "namaKECAMATAN": "LUYO"
      },
      {
        "kodeKECAMATAN": 7602040,
        "kodeKABUPATEN": 7602,
        "namaKECAMATAN": "WONOMULYO"
      },
      {
        "kodeKECAMATAN": 7602041,
        "kodeKABUPATEN": 7602,
        "namaKECAMATAN": "MAPILLI"
      },
      {
        "kodeKECAMATAN": 7602042,
        "kodeKABUPATEN": 7602,
        "namaKECAMATAN": "TAPANGO"
      },
      {
        "kodeKECAMATAN": 7602043,
        "kodeKABUPATEN": 7602,
        "namaKECAMATAN": "MATAKALI"
      },
      {
        "kodeKECAMATAN": 7602044,
        "kodeKABUPATEN": 7602,
        "namaKECAMATAN": "B U L O"
      },
      {
        "kodeKECAMATAN": 7602050,
        "kodeKABUPATEN": 7602,
        "namaKECAMATAN": "POLEWALI"
      },
      {
        "kodeKECAMATAN": 7602051,
        "kodeKABUPATEN": 7602,
        "namaKECAMATAN": "BINUANG"
      },
      {
        "kodeKECAMATAN": 7602052,
        "kodeKABUPATEN": 7602,
        "namaKECAMATAN": "ANREAPI"
      },
      {
        "kodeKECAMATAN": 7602061,
        "kodeKABUPATEN": 7602,
        "namaKECAMATAN": "MATANGNGA"
      },
      {
        "kodeKECAMATAN": 7603010,
        "kodeKABUPATEN": 7603,
        "namaKECAMATAN": "SUMARORONG"
      },
      {
        "kodeKECAMATAN": 7603020,
        "kodeKABUPATEN": 7603,
        "namaKECAMATAN": "MESSAWA"
      },
      {
        "kodeKECAMATAN": 7603030,
        "kodeKABUPATEN": 7603,
        "namaKECAMATAN": "PANA"
      },
      {
        "kodeKECAMATAN": 7603031,
        "kodeKABUPATEN": 7603,
        "namaKECAMATAN": "NOSU"
      },
      {
        "kodeKECAMATAN": 7603040,
        "kodeKABUPATEN": 7603,
        "namaKECAMATAN": "TABANG"
      },
      {
        "kodeKECAMATAN": 7603050,
        "kodeKABUPATEN": 7603,
        "namaKECAMATAN": "MAMASA"
      },
      {
        "kodeKECAMATAN": 7603060,
        "kodeKABUPATEN": 7603,
        "namaKECAMATAN": "TANDUK KALUA"
      },
      {
        "kodeKECAMATAN": 7603061,
        "kodeKABUPATEN": 7603,
        "namaKECAMATAN": "BALLA"
      },
      {
        "kodeKECAMATAN": 7603070,
        "kodeKABUPATEN": 7603,
        "namaKECAMATAN": "SESENAPADANG"
      },
      {
        "kodeKECAMATAN": 7603071,
        "kodeKABUPATEN": 7603,
        "namaKECAMATAN": "TAWALIAN"
      },
      {
        "kodeKECAMATAN": 7603080,
        "kodeKABUPATEN": 7603,
        "namaKECAMATAN": "MAMBI"
      },
      {
        "kodeKECAMATAN": 7603081,
        "kodeKABUPATEN": 7603,
        "namaKECAMATAN": "BAMBANG"
      },
      {
        "kodeKECAMATAN": 7603082,
        "kodeKABUPATEN": 7603,
        "namaKECAMATAN": "RANTEBULAHAN TIMUR"
      },
      {
        "kodeKECAMATAN": 7603083,
        "kodeKABUPATEN": 7603,
        "namaKECAMATAN": "MEHALAAN"
      },
      {
        "kodeKECAMATAN": 7603090,
        "kodeKABUPATEN": 7603,
        "namaKECAMATAN": "ARALLE"
      },
      {
        "kodeKECAMATAN": 7603091,
        "kodeKABUPATEN": 7603,
        "namaKECAMATAN": "BUNTU MALANGKA"
      },
      {
        "kodeKECAMATAN": 7603100,
        "kodeKABUPATEN": 7603,
        "namaKECAMATAN": "TABULAHAN"
      },
      {
        "kodeKECAMATAN": 7604010,
        "kodeKABUPATEN": 7604,
        "namaKECAMATAN": "TAPALANG"
      },
      {
        "kodeKECAMATAN": 7604011,
        "kodeKABUPATEN": 7604,
        "namaKECAMATAN": "TAPALANG BARAT"
      },
      {
        "kodeKECAMATAN": 7604020,
        "kodeKABUPATEN": 7604,
        "namaKECAMATAN": "MAMUJU"
      },
      {
        "kodeKECAMATAN": 7604022,
        "kodeKABUPATEN": 7604,
        "namaKECAMATAN": "SIMBORO"
      },
      {
        "kodeKECAMATAN": 7604023,
        "kodeKABUPATEN": 7604,
        "namaKECAMATAN": "BALABALAKANG"
      },
      {
        "kodeKECAMATAN": 7604030,
        "kodeKABUPATEN": 7604,
        "namaKECAMATAN": "KALUKKU"
      },
      {
        "kodeKECAMATAN": 7604031,
        "kodeKABUPATEN": 7604,
        "namaKECAMATAN": "PAPALANG"
      },
      {
        "kodeKECAMATAN": 7604032,
        "kodeKABUPATEN": 7604,
        "namaKECAMATAN": "SAMPAGA"
      },
      {
        "kodeKECAMATAN": 7604033,
        "kodeKABUPATEN": 7604,
        "namaKECAMATAN": "TOMMO"
      },
      {
        "kodeKECAMATAN": 7604040,
        "kodeKABUPATEN": 7604,
        "namaKECAMATAN": "KALUMPANG"
      },
      {
        "kodeKECAMATAN": 7604041,
        "kodeKABUPATEN": 7604,
        "namaKECAMATAN": "BONEHAU"
      },
      {
        "kodeKECAMATAN": 7605010,
        "kodeKABUPATEN": 7605,
        "namaKECAMATAN": "SARUDU"
      },
      {
        "kodeKECAMATAN": 7605011,
        "kodeKABUPATEN": 7605,
        "namaKECAMATAN": "DAPURANG"
      },
      {
        "kodeKECAMATAN": 7605012,
        "kodeKABUPATEN": 7605,
        "namaKECAMATAN": "DURIPOKU"
      },
      {
        "kodeKECAMATAN": 7605020,
        "kodeKABUPATEN": 7605,
        "namaKECAMATAN": "BARAS"
      },
      {
        "kodeKECAMATAN": 7605021,
        "kodeKABUPATEN": 7605,
        "namaKECAMATAN": "BULU TABA"
      },
      {
        "kodeKECAMATAN": 7605022,
        "kodeKABUPATEN": 7605,
        "namaKECAMATAN": "LARIANG"
      },
      {
        "kodeKECAMATAN": 7605030,
        "kodeKABUPATEN": 7605,
        "namaKECAMATAN": "PASANGKAYU"
      },
      {
        "kodeKECAMATAN": 7605031,
        "kodeKABUPATEN": 7605,
        "namaKECAMATAN": "TIKKE RAYA"
      },
      {
        "kodeKECAMATAN": 7605032,
        "kodeKABUPATEN": 7605,
        "namaKECAMATAN": "PEDONGGA"
      },
      {
        "kodeKECAMATAN": 7605040,
        "kodeKABUPATEN": 7605,
        "namaKECAMATAN": "BAMBALAMOTU"
      },
      {
        "kodeKECAMATAN": 7605041,
        "kodeKABUPATEN": 7605,
        "namaKECAMATAN": "BAMBAIRA"
      },
      {
        "kodeKECAMATAN": 7605042,
        "kodeKABUPATEN": 7605,
        "namaKECAMATAN": "SARJO"
      },
      {
        "kodeKECAMATAN": 7606010,
        "kodeKABUPATEN": 7606,
        "namaKECAMATAN": "PANGALE"
      },
      {
        "kodeKECAMATAN": 7606020,
        "kodeKABUPATEN": 7606,
        "namaKECAMATAN": "BUDONG-BUDONG"
      },
      {
        "kodeKECAMATAN": 7606030,
        "kodeKABUPATEN": 7606,
        "namaKECAMATAN": "TOBADAK"
      },
      {
        "kodeKECAMATAN": 7606040,
        "kodeKABUPATEN": 7606,
        "namaKECAMATAN": "TOPOYO"
      },
      {
        "kodeKECAMATAN": 7606050,
        "kodeKABUPATEN": 7606,
        "namaKECAMATAN": "KAROSSA"
      },
      {
        "kodeKECAMATAN": 8101040,
        "kodeKABUPATEN": 8101,
        "namaKECAMATAN": "TANIMBAR SELATAN"
      },
      {
        "kodeKECAMATAN": 8101041,
        "kodeKABUPATEN": 8101,
        "namaKECAMATAN": "WER TAMRIAN"
      },
      {
        "kodeKECAMATAN": 8101042,
        "kodeKABUPATEN": 8101,
        "namaKECAMATAN": "WER MAKTIAN"
      },
      {
        "kodeKECAMATAN": 8101043,
        "kodeKABUPATEN": 8101,
        "namaKECAMATAN": "SELARU"
      },
      {
        "kodeKECAMATAN": 8101050,
        "kodeKABUPATEN": 8101,
        "namaKECAMATAN": "TANIMBAR UTARA"
      },
      {
        "kodeKECAMATAN": 8101051,
        "kodeKABUPATEN": 8101,
        "namaKECAMATAN": "YARU"
      },
      {
        "kodeKECAMATAN": 8101052,
        "kodeKABUPATEN": 8101,
        "namaKECAMATAN": "WUAR LABOBAR"
      },
      {
        "kodeKECAMATAN": 8101053,
        "kodeKABUPATEN": 8101,
        "namaKECAMATAN": "NIRUNMAS"
      },
      {
        "kodeKECAMATAN": 8101054,
        "kodeKABUPATEN": 8101,
        "namaKECAMATAN": "KORMOMOLIN"
      },
      {
        "kodeKECAMATAN": 8101055,
        "kodeKABUPATEN": 8101,
        "namaKECAMATAN": "MOLU MARU"
      },
      {
        "kodeKECAMATAN": 8102010,
        "kodeKABUPATEN": 8102,
        "namaKECAMATAN": "KEI KECIL"
      },
      {
        "kodeKECAMATAN": 8102012,
        "kodeKABUPATEN": 8102,
        "namaKECAMATAN": "KEI KECIL BARAT"
      },
      {
        "kodeKECAMATAN": 8102013,
        "kodeKABUPATEN": 8102,
        "namaKECAMATAN": "KEI KECIL TIMUR"
      },
      {
        "kodeKECAMATAN": 8102014,
        "kodeKABUPATEN": 8102,
        "namaKECAMATAN": "HOAT SORBAY"
      },
      {
        "kodeKECAMATAN": 8102015,
        "kodeKABUPATEN": 8102,
        "namaKECAMATAN": "MANYEUW"
      },
      {
        "kodeKECAMATAN": 8102016,
        "kodeKABUPATEN": 8102,
        "namaKECAMATAN": "KEI KECIL TIMUR SELATAN"
      },
      {
        "kodeKECAMATAN": 8102020,
        "kodeKABUPATEN": 8102,
        "namaKECAMATAN": "KEI BESAR"
      },
      {
        "kodeKECAMATAN": 8102021,
        "kodeKABUPATEN": 8102,
        "namaKECAMATAN": "KEI BESAR UTARA TIMUR"
      },
      {
        "kodeKECAMATAN": 8102022,
        "kodeKABUPATEN": 8102,
        "namaKECAMATAN": "KEI BESAR SELATAN"
      },
      {
        "kodeKECAMATAN": 8102023,
        "kodeKABUPATEN": 8102,
        "namaKECAMATAN": "KEI BESAR UTARA BARAT"
      },
      {
        "kodeKECAMATAN": 8102024,
        "kodeKABUPATEN": 8102,
        "namaKECAMATAN": "KEI BESAR SELATAN BARAT"
      },
      {
        "kodeKECAMATAN": 8103010,
        "kodeKABUPATEN": 8103,
        "namaKECAMATAN": "BANDA"
      },
      {
        "kodeKECAMATAN": 8103040,
        "kodeKABUPATEN": 8103,
        "namaKECAMATAN": "TEHORU"
      },
      {
        "kodeKECAMATAN": 8103041,
        "kodeKABUPATEN": 8103,
        "namaKECAMATAN": "TELUTIH"
      },
      {
        "kodeKECAMATAN": 8103050,
        "kodeKABUPATEN": 8103,
        "namaKECAMATAN": "AMAHAI"
      },
      {
        "kodeKECAMATAN": 8103051,
        "kodeKABUPATEN": 8103,
        "namaKECAMATAN": "KOTA MASOHI"
      },
      {
        "kodeKECAMATAN": 8103052,
        "kodeKABUPATEN": 8103,
        "namaKECAMATAN": "TELUK ELPAPUTIH"
      },
      {
        "kodeKECAMATAN": 8103060,
        "kodeKABUPATEN": 8103,
        "namaKECAMATAN": "TEON NILA SERUA"
      },
      {
        "kodeKECAMATAN": 8103080,
        "kodeKABUPATEN": 8103,
        "namaKECAMATAN": "SAPARUA"
      },
      {
        "kodeKECAMATAN": 8103081,
        "kodeKABUPATEN": 8103,
        "namaKECAMATAN": "NUSALAUT"
      },
      {
        "kodeKECAMATAN": 8103082,
        "kodeKABUPATEN": 8103,
        "namaKECAMATAN": "SAPARUA TIMUR"
      },
      {
        "kodeKECAMATAN": 8103090,
        "kodeKABUPATEN": 8103,
        "namaKECAMATAN": "P. HARUKU"
      },
      {
        "kodeKECAMATAN": 8103100,
        "kodeKABUPATEN": 8103,
        "namaKECAMATAN": "SALAHUTU"
      },
      {
        "kodeKECAMATAN": 8103110,
        "kodeKABUPATEN": 8103,
        "namaKECAMATAN": "LEIHITU"
      },
      {
        "kodeKECAMATAN": 8103111,
        "kodeKABUPATEN": 8103,
        "namaKECAMATAN": "LEIHITU BARAT"
      },
      {
        "kodeKECAMATAN": 8103140,
        "kodeKABUPATEN": 8103,
        "namaKECAMATAN": "SERAM UTARA"
      },
      {
        "kodeKECAMATAN": 8103141,
        "kodeKABUPATEN": 8103,
        "namaKECAMATAN": "SERAM UTARA BARAT"
      },
      {
        "kodeKECAMATAN": 8103142,
        "kodeKABUPATEN": 8103,
        "namaKECAMATAN": "SERAM UTARA TIMUR KOBI"
      },
      {
        "kodeKECAMATAN": 8103143,
        "kodeKABUPATEN": 8103,
        "namaKECAMATAN": "SERAM UTARA TIMUR SETI"
      },
      {
        "kodeKECAMATAN": 8104020,
        "kodeKABUPATEN": 8104,
        "namaKECAMATAN": "NAMLEA"
      },
      {
        "kodeKECAMATAN": 8104021,
        "kodeKABUPATEN": 8104,
        "namaKECAMATAN": "WAEAPO"
      },
      {
        "kodeKECAMATAN": 8104022,
        "kodeKABUPATEN": 8104,
        "namaKECAMATAN": "WAPLAU"
      },
      {
        "kodeKECAMATAN": 8104023,
        "kodeKABUPATEN": 8104,
        "namaKECAMATAN": "BATA BUAL"
      },
      {
        "kodeKECAMATAN": 8104024,
        "kodeKABUPATEN": 8104,
        "namaKECAMATAN": "TELUK KAIELY"
      },
      {
        "kodeKECAMATAN": 8104025,
        "kodeKABUPATEN": 8104,
        "namaKECAMATAN": "WAELATA"
      },
      {
        "kodeKECAMATAN": 8104026,
        "kodeKABUPATEN": 8104,
        "namaKECAMATAN": "LOLONG GUBA"
      },
      {
        "kodeKECAMATAN": 8104027,
        "kodeKABUPATEN": 8104,
        "namaKECAMATAN": "LILIALY"
      },
      {
        "kodeKECAMATAN": 8104030,
        "kodeKABUPATEN": 8104,
        "namaKECAMATAN": "AIR BUAYA"
      },
      {
        "kodeKECAMATAN": 8104031,
        "kodeKABUPATEN": 8104,
        "namaKECAMATAN": "FENA LEISELA"
      },
      {
        "kodeKECAMATAN": 8105010,
        "kodeKABUPATEN": 8105,
        "namaKECAMATAN": "ARU SELATAN"
      },
      {
        "kodeKECAMATAN": 8105011,
        "kodeKABUPATEN": 8105,
        "namaKECAMATAN": "ARU SELATAN TIMUR"
      },
      {
        "kodeKECAMATAN": 8105012,
        "kodeKABUPATEN": 8105,
        "namaKECAMATAN": "ARU SELATAN UTARA"
      },
      {
        "kodeKECAMATAN": 8105020,
        "kodeKABUPATEN": 8105,
        "namaKECAMATAN": "ARU TENGAH"
      },
      {
        "kodeKECAMATAN": 8105021,
        "kodeKABUPATEN": 8105,
        "namaKECAMATAN": "ARU TENGAH TIMUR"
      },
      {
        "kodeKECAMATAN": 8105022,
        "kodeKABUPATEN": 8105,
        "namaKECAMATAN": "ARU TENGAH SELATAN"
      },
      {
        "kodeKECAMATAN": 8105030,
        "kodeKABUPATEN": 8105,
        "namaKECAMATAN": "PULAU-PULAU ARU"
      },
      {
        "kodeKECAMATAN": 8105031,
        "kodeKABUPATEN": 8105,
        "namaKECAMATAN": "ARU UTARA"
      },
      {
        "kodeKECAMATAN": 8105032,
        "kodeKABUPATEN": 8105,
        "namaKECAMATAN": "ARU UTARA TIMUR BATULEY"
      },
      {
        "kodeKECAMATAN": 8105033,
        "kodeKABUPATEN": 8105,
        "namaKECAMATAN": "SIR-SIR"
      },
      {
        "kodeKECAMATAN": 8106010,
        "kodeKABUPATEN": 8106,
        "namaKECAMATAN": "HUAMUAL BELAKANG"
      },
      {
        "kodeKECAMATAN": 8106011,
        "kodeKABUPATEN": 8106,
        "namaKECAMATAN": "KEPULAUAN MANIPA"
      },
      {
        "kodeKECAMATAN": 8106020,
        "kodeKABUPATEN": 8106,
        "namaKECAMATAN": "SERAM BARAT"
      },
      {
        "kodeKECAMATAN": 8106021,
        "kodeKABUPATEN": 8106,
        "namaKECAMATAN": "HUAMUAL"
      },
      {
        "kodeKECAMATAN": 8106030,
        "kodeKABUPATEN": 8106,
        "namaKECAMATAN": "KAIRATU"
      },
      {
        "kodeKECAMATAN": 8106031,
        "kodeKABUPATEN": 8106,
        "namaKECAMATAN": "KAIRATU BARAT"
      },
      {
        "kodeKECAMATAN": 8106032,
        "kodeKABUPATEN": 8106,
        "namaKECAMATAN": "INAMOSOL"
      },
      {
        "kodeKECAMATAN": 8106033,
        "kodeKABUPATEN": 8106,
        "namaKECAMATAN": "AMALATU"
      },
      {
        "kodeKECAMATAN": 8106034,
        "kodeKABUPATEN": 8106,
        "namaKECAMATAN": "ELPAPUTIH"
      },
      {
        "kodeKECAMATAN": 8106040,
        "kodeKABUPATEN": 8106,
        "namaKECAMATAN": "TANIWEL"
      },
      {
        "kodeKECAMATAN": 8106041,
        "kodeKABUPATEN": 8106,
        "namaKECAMATAN": "TANIWEL TIMUR"
      },
      {
        "kodeKECAMATAN": 8107010,
        "kodeKABUPATEN": 8107,
        "namaKECAMATAN": "PULAU GOROM"
      },
      {
        "kodeKECAMATAN": 8107011,
        "kodeKABUPATEN": 8107,
        "namaKECAMATAN": "WAKATE"
      },
      {
        "kodeKECAMATAN": 8107012,
        "kodeKABUPATEN": 8107,
        "namaKECAMATAN": "TEOR"
      },
      {
        "kodeKECAMATAN": 8107013,
        "kodeKABUPATEN": 8107,
        "namaKECAMATAN": "GOROM TIMUR"
      },
      {
        "kodeKECAMATAN": 8107014,
        "kodeKABUPATEN": 8107,
        "namaKECAMATAN": "PULAU PANJANG"
      },
      {
        "kodeKECAMATAN": 8107020,
        "kodeKABUPATEN": 8107,
        "namaKECAMATAN": "SERAM TIMUR"
      },
      {
        "kodeKECAMATAN": 8107021,
        "kodeKABUPATEN": 8107,
        "namaKECAMATAN": "TUTUK TOLU"
      },
      {
        "kodeKECAMATAN": 8107022,
        "kodeKABUPATEN": 8107,
        "namaKECAMATAN": "KILMURY"
      },
      {
        "kodeKECAMATAN": 8107023,
        "kodeKABUPATEN": 8107,
        "namaKECAMATAN": "LIAN VITU"
      },
      {
        "kodeKECAMATAN": 8107024,
        "kodeKABUPATEN": 8107,
        "namaKECAMATAN": "KIAN DARAT"
      },
      {
        "kodeKECAMATAN": 8107030,
        "kodeKABUPATEN": 8107,
        "namaKECAMATAN": "WERINAMA"
      },
      {
        "kodeKECAMATAN": 8107031,
        "kodeKABUPATEN": 8107,
        "namaKECAMATAN": "SIWALALAT"
      },
      {
        "kodeKECAMATAN": 8107040,
        "kodeKABUPATEN": 8107,
        "namaKECAMATAN": "BULA"
      },
      {
        "kodeKECAMATAN": 8107041,
        "kodeKABUPATEN": 8107,
        "namaKECAMATAN": "BULA BARAT"
      },
      {
        "kodeKECAMATAN": 8107042,
        "kodeKABUPATEN": 8107,
        "namaKECAMATAN": "TELUK WARU"
      },
      {
        "kodeKECAMATAN": 8108010,
        "kodeKABUPATEN": 8108,
        "namaKECAMATAN": "WETAR"
      },
      {
        "kodeKECAMATAN": 8108011,
        "kodeKABUPATEN": 8108,
        "namaKECAMATAN": "WETAR BARAT"
      },
      {
        "kodeKECAMATAN": 8108012,
        "kodeKABUPATEN": 8108,
        "namaKECAMATAN": "WETAR UTARA"
      },
      {
        "kodeKECAMATAN": 8108013,
        "kodeKABUPATEN": 8108,
        "namaKECAMATAN": "WETAR TIMUR"
      },
      {
        "kodeKECAMATAN": 8108020,
        "kodeKABUPATEN": 8108,
        "namaKECAMATAN": "PP. TERSELATAN"
      },
      {
        "kodeKECAMATAN": 8108021,
        "kodeKABUPATEN": 8108,
        "namaKECAMATAN": "KISAR UTARA"
      },
      {
        "kodeKECAMATAN": 8108022,
        "kodeKABUPATEN": 8108,
        "namaKECAMATAN": "KEPULAUAN ROMANG"
      },
      {
        "kodeKECAMATAN": 8108030,
        "kodeKABUPATEN": 8108,
        "namaKECAMATAN": "LETTI"
      },
      {
        "kodeKECAMATAN": 8108041,
        "kodeKABUPATEN": 8108,
        "namaKECAMATAN": "MOA"
      },
      {
        "kodeKECAMATAN": 8108042,
        "kodeKABUPATEN": 8108,
        "namaKECAMATAN": "LAKOR"
      },
      {
        "kodeKECAMATAN": 8108050,
        "kodeKABUPATEN": 8108,
        "namaKECAMATAN": "DAMER"
      },
      {
        "kodeKECAMATAN": 8108060,
        "kodeKABUPATEN": 8108,
        "namaKECAMATAN": "MDONA HIERA"
      },
      {
        "kodeKECAMATAN": 8108070,
        "kodeKABUPATEN": 8108,
        "namaKECAMATAN": "PP. BABAR"
      },
      {
        "kodeKECAMATAN": 8108071,
        "kodeKABUPATEN": 8108,
        "namaKECAMATAN": "PULAU WETANG"
      },
      {
        "kodeKECAMATAN": 8108080,
        "kodeKABUPATEN": 8108,
        "namaKECAMATAN": "BABAR TIMUR"
      },
      {
        "kodeKECAMATAN": 8108081,
        "kodeKABUPATEN": 8108,
        "namaKECAMATAN": "PULAU MASELA"
      },
      {
        "kodeKECAMATAN": 8108082,
        "kodeKABUPATEN": 8108,
        "namaKECAMATAN": "DAWELOR DAWERA"
      },
      {
        "kodeKECAMATAN": 8109010,
        "kodeKABUPATEN": 8109,
        "namaKECAMATAN": "KEPALA MADAN"
      },
      {
        "kodeKECAMATAN": 8109020,
        "kodeKABUPATEN": 8109,
        "namaKECAMATAN": "LEKSULA"
      },
      {
        "kodeKECAMATAN": 8109021,
        "kodeKABUPATEN": 8109,
        "namaKECAMATAN": "FENA FAFAN"
      },
      {
        "kodeKECAMATAN": 8109030,
        "kodeKABUPATEN": 8109,
        "namaKECAMATAN": "NAMROLE"
      },
      {
        "kodeKECAMATAN": 8109040,
        "kodeKABUPATEN": 8109,
        "namaKECAMATAN": "WAISAMA"
      },
      {
        "kodeKECAMATAN": 8109050,
        "kodeKABUPATEN": 8109,
        "namaKECAMATAN": "AMBALAU"
      },
      {
        "kodeKECAMATAN": 8171010,
        "kodeKABUPATEN": 8171,
        "namaKECAMATAN": "NUSANIWE"
      },
      {
        "kodeKECAMATAN": 8171020,
        "kodeKABUPATEN": 8171,
        "namaKECAMATAN": "SIRIMAU"
      },
      {
        "kodeKECAMATAN": 8171021,
        "kodeKABUPATEN": 8171,
        "namaKECAMATAN": "LEITIMUR SELATAN"
      },
      {
        "kodeKECAMATAN": 8171030,
        "kodeKABUPATEN": 8171,
        "namaKECAMATAN": "TELUK AMBON BAGUALA"
      },
      {
        "kodeKECAMATAN": 8171031,
        "kodeKABUPATEN": 8171,
        "namaKECAMATAN": "TELUK AMBON"
      },
      {
        "kodeKECAMATAN": 8172010,
        "kodeKABUPATEN": 8172,
        "namaKECAMATAN": "PP. KUR"
      },
      {
        "kodeKECAMATAN": 8172011,
        "kodeKABUPATEN": 8172,
        "namaKECAMATAN": "KUR SELATAN"
      },
      {
        "kodeKECAMATAN": 8172020,
        "kodeKABUPATEN": 8172,
        "namaKECAMATAN": "TAYANDO TAM"
      },
      {
        "kodeKECAMATAN": 8172030,
        "kodeKABUPATEN": 8172,
        "namaKECAMATAN": "PULAU DULLAH UTARA"
      },
      {
        "kodeKECAMATAN": 8172040,
        "kodeKABUPATEN": 8172,
        "namaKECAMATAN": "PULAU DULLAH SELATAN"
      },
      {
        "kodeKECAMATAN": 8201090,
        "kodeKABUPATEN": 8201,
        "namaKECAMATAN": "JAILOLO"
      },
      {
        "kodeKECAMATAN": 8201091,
        "kodeKABUPATEN": 8201,
        "namaKECAMATAN": "JAILOLO SELATAN"
      },
      {
        "kodeKECAMATAN": 8201100,
        "kodeKABUPATEN": 8201,
        "namaKECAMATAN": "SAHU"
      },
      {
        "kodeKECAMATAN": 8201101,
        "kodeKABUPATEN": 8201,
        "namaKECAMATAN": "SAHU TIMUR"
      },
      {
        "kodeKECAMATAN": 8201130,
        "kodeKABUPATEN": 8201,
        "namaKECAMATAN": "IBU"
      },
      {
        "kodeKECAMATAN": 8201131,
        "kodeKABUPATEN": 8201,
        "namaKECAMATAN": "IBU SELATAN"
      },
      {
        "kodeKECAMATAN": 8201132,
        "kodeKABUPATEN": 8201,
        "namaKECAMATAN": "TABARU"
      },
      {
        "kodeKECAMATAN": 8201140,
        "kodeKABUPATEN": 8201,
        "namaKECAMATAN": "LOLODA"
      },
      {
        "kodeKECAMATAN": 8202030,
        "kodeKABUPATEN": 8202,
        "namaKECAMATAN": "WEDA"
      },
      {
        "kodeKECAMATAN": 8202031,
        "kodeKABUPATEN": 8202,
        "namaKECAMATAN": "WEDA SELATAN"
      },
      {
        "kodeKECAMATAN": 8202032,
        "kodeKABUPATEN": 8202,
        "namaKECAMATAN": "WEDA UTARA"
      },
      {
        "kodeKECAMATAN": 8202033,
        "kodeKABUPATEN": 8202,
        "namaKECAMATAN": "WEDA TENGAH"
      },
      {
        "kodeKECAMATAN": 8202034,
        "kodeKABUPATEN": 8202,
        "namaKECAMATAN": "WEDA TIMUR"
      },
      {
        "kodeKECAMATAN": 8202041,
        "kodeKABUPATEN": 8202,
        "namaKECAMATAN": "PULAU GEBE"
      },
      {
        "kodeKECAMATAN": 8202042,
        "kodeKABUPATEN": 8202,
        "namaKECAMATAN": "PATANI"
      },
      {
        "kodeKECAMATAN": 8202043,
        "kodeKABUPATEN": 8202,
        "namaKECAMATAN": "PATANI UTARA"
      },
      {
        "kodeKECAMATAN": 8202044,
        "kodeKABUPATEN": 8202,
        "namaKECAMATAN": "PATANI BARAT"
      },
      {
        "kodeKECAMATAN": 8202045,
        "kodeKABUPATEN": 8202,
        "namaKECAMATAN": "PATANI TIMUR"
      },
      {
        "kodeKECAMATAN": 8203010,
        "kodeKABUPATEN": 8203,
        "namaKECAMATAN": "SULA BESI BARAT"
      },
      {
        "kodeKECAMATAN": 8203011,
        "kodeKABUPATEN": 8203,
        "namaKECAMATAN": "SULABESI SELATAN"
      },
      {
        "kodeKECAMATAN": 8203020,
        "kodeKABUPATEN": 8203,
        "namaKECAMATAN": "SANANA"
      },
      {
        "kodeKECAMATAN": 8203021,
        "kodeKABUPATEN": 8203,
        "namaKECAMATAN": "SULA BESI TENGAH"
      },
      {
        "kodeKECAMATAN": 8203022,
        "kodeKABUPATEN": 8203,
        "namaKECAMATAN": "SULABESI TIMUR"
      },
      {
        "kodeKECAMATAN": 8203023,
        "kodeKABUPATEN": 8203,
        "namaKECAMATAN": "SANANA UTARA"
      },
      {
        "kodeKECAMATAN": 8203030,
        "kodeKABUPATEN": 8203,
        "namaKECAMATAN": "MANGOLI TIMUR"
      },
      {
        "kodeKECAMATAN": 8203031,
        "kodeKABUPATEN": 8203,
        "namaKECAMATAN": "MANGOLI TENGAH"
      },
      {
        "kodeKECAMATAN": 8203032,
        "kodeKABUPATEN": 8203,
        "namaKECAMATAN": "MANGOLI UTARA TIMUR"
      },
      {
        "kodeKECAMATAN": 8203040,
        "kodeKABUPATEN": 8203,
        "namaKECAMATAN": "MANGOLI BARAT"
      },
      {
        "kodeKECAMATAN": 8203041,
        "kodeKABUPATEN": 8203,
        "namaKECAMATAN": "MANGOLI UTARA"
      },
      {
        "kodeKECAMATAN": 8203042,
        "kodeKABUPATEN": 8203,
        "namaKECAMATAN": "MANGOLI SELATAN"
      },
      {
        "kodeKECAMATAN": 8204010,
        "kodeKABUPATEN": 8204,
        "namaKECAMATAN": "OBI SELATAN"
      },
      {
        "kodeKECAMATAN": 8204020,
        "kodeKABUPATEN": 8204,
        "namaKECAMATAN": "OBI"
      },
      {
        "kodeKECAMATAN": 8204021,
        "kodeKABUPATEN": 8204,
        "namaKECAMATAN": "OBI BARAT"
      },
      {
        "kodeKECAMATAN": 8204022,
        "kodeKABUPATEN": 8204,
        "namaKECAMATAN": "OBI TIMUR"
      },
      {
        "kodeKECAMATAN": 8204023,
        "kodeKABUPATEN": 8204,
        "namaKECAMATAN": "OBI UTARA"
      },
      {
        "kodeKECAMATAN": 8204030,
        "kodeKABUPATEN": 8204,
        "namaKECAMATAN": "BACAN"
      },
      {
        "kodeKECAMATAN": 8204031,
        "kodeKABUPATEN": 8204,
        "namaKECAMATAN": "MANDIOLI SELATAN"
      },
      {
        "kodeKECAMATAN": 8204032,
        "kodeKABUPATEN": 8204,
        "namaKECAMATAN": "MANDIOLI UTARA"
      },
      {
        "kodeKECAMATAN": 8204033,
        "kodeKABUPATEN": 8204,
        "namaKECAMATAN": "BACAN SELATAN"
      },
      {
        "kodeKECAMATAN": 8204034,
        "kodeKABUPATEN": 8204,
        "namaKECAMATAN": "BATANG LOMANG"
      },
      {
        "kodeKECAMATAN": 8204040,
        "kodeKABUPATEN": 8204,
        "namaKECAMATAN": "BACAN TIMUR"
      },
      {
        "kodeKECAMATAN": 8204041,
        "kodeKABUPATEN": 8204,
        "namaKECAMATAN": "BACAN TIMUR SELATAN"
      },
      {
        "kodeKECAMATAN": 8204042,
        "kodeKABUPATEN": 8204,
        "namaKECAMATAN": "BACAN TIMUR TENGAH"
      },
      {
        "kodeKECAMATAN": 8204050,
        "kodeKABUPATEN": 8204,
        "namaKECAMATAN": "BACAN BARAT"
      },
      {
        "kodeKECAMATAN": 8204051,
        "kodeKABUPATEN": 8204,
        "namaKECAMATAN": "KASIRUTA BARAT"
      },
      {
        "kodeKECAMATAN": 8204052,
        "kodeKABUPATEN": 8204,
        "namaKECAMATAN": "KASIRUTA TIMUR"
      },
      {
        "kodeKECAMATAN": 8204053,
        "kodeKABUPATEN": 8204,
        "namaKECAMATAN": "BACAN BARAT UTARA"
      },
      {
        "kodeKECAMATAN": 8204060,
        "kodeKABUPATEN": 8204,
        "namaKECAMATAN": "KAYOA"
      },
      {
        "kodeKECAMATAN": 8204061,
        "kodeKABUPATEN": 8204,
        "namaKECAMATAN": "KAYOA BARAT"
      },
      {
        "kodeKECAMATAN": 8204062,
        "kodeKABUPATEN": 8204,
        "namaKECAMATAN": "KAYOA SELATAN"
      },
      {
        "kodeKECAMATAN": 8204063,
        "kodeKABUPATEN": 8204,
        "namaKECAMATAN": "KAYOA UTARA"
      },
      {
        "kodeKECAMATAN": 8204070,
        "kodeKABUPATEN": 8204,
        "namaKECAMATAN": "PULAU MAKIAN"
      },
      {
        "kodeKECAMATAN": 8204071,
        "kodeKABUPATEN": 8204,
        "namaKECAMATAN": "MAKIAN BARAT"
      },
      {
        "kodeKECAMATAN": 8204080,
        "kodeKABUPATEN": 8204,
        "namaKECAMATAN": "GANE BARAT"
      },
      {
        "kodeKECAMATAN": 8204081,
        "kodeKABUPATEN": 8204,
        "namaKECAMATAN": "GANE BARAT SELATAN"
      },
      {
        "kodeKECAMATAN": 8204082,
        "kodeKABUPATEN": 8204,
        "namaKECAMATAN": "GANE BARAT UTARA"
      },
      {
        "kodeKECAMATAN": 8204083,
        "kodeKABUPATEN": 8204,
        "namaKECAMATAN": "KEPULAUAN JORONGA"
      },
      {
        "kodeKECAMATAN": 8204090,
        "kodeKABUPATEN": 8204,
        "namaKECAMATAN": "GANE TIMUR"
      },
      {
        "kodeKECAMATAN": 8204091,
        "kodeKABUPATEN": 8204,
        "namaKECAMATAN": "GANE TIMUR TENGAH"
      },
      {
        "kodeKECAMATAN": 8204092,
        "kodeKABUPATEN": 8204,
        "namaKECAMATAN": "GANE TIMUR SELATAN"
      },
      {
        "kodeKECAMATAN": 8205010,
        "kodeKABUPATEN": 8205,
        "namaKECAMATAN": "MALIFUT"
      },
      {
        "kodeKECAMATAN": 8205011,
        "kodeKABUPATEN": 8205,
        "namaKECAMATAN": "KAO TELUK"
      },
      {
        "kodeKECAMATAN": 8205020,
        "kodeKABUPATEN": 8205,
        "namaKECAMATAN": "KAO"
      },
      {
        "kodeKECAMATAN": 8205021,
        "kodeKABUPATEN": 8205,
        "namaKECAMATAN": "KAO BARAT"
      },
      {
        "kodeKECAMATAN": 8205022,
        "kodeKABUPATEN": 8205,
        "namaKECAMATAN": "KAO UTARA"
      },
      {
        "kodeKECAMATAN": 8205030,
        "kodeKABUPATEN": 8205,
        "namaKECAMATAN": "TOBELO SELATAN"
      },
      {
        "kodeKECAMATAN": 8205031,
        "kodeKABUPATEN": 8205,
        "namaKECAMATAN": "TOBELO BARAT"
      },
      {
        "kodeKECAMATAN": 8205032,
        "kodeKABUPATEN": 8205,
        "namaKECAMATAN": "TOBELO TIMUR"
      },
      {
        "kodeKECAMATAN": 8205040,
        "kodeKABUPATEN": 8205,
        "namaKECAMATAN": "TOBELO"
      },
      {
        "kodeKECAMATAN": 8205041,
        "kodeKABUPATEN": 8205,
        "namaKECAMATAN": "TOBELO TENGAH"
      },
      {
        "kodeKECAMATAN": 8205042,
        "kodeKABUPATEN": 8205,
        "namaKECAMATAN": "TOBELO UTARA"
      },
      {
        "kodeKECAMATAN": 8205050,
        "kodeKABUPATEN": 8205,
        "namaKECAMATAN": "GALELA"
      },
      {
        "kodeKECAMATAN": 8205051,
        "kodeKABUPATEN": 8205,
        "namaKECAMATAN": "GALELA SELATAN"
      },
      {
        "kodeKECAMATAN": 8205052,
        "kodeKABUPATEN": 8205,
        "namaKECAMATAN": "GALELA BARAT"
      },
      {
        "kodeKECAMATAN": 8205053,
        "kodeKABUPATEN": 8205,
        "namaKECAMATAN": "GALELA UTARA"
      },
      {
        "kodeKECAMATAN": 8205060,
        "kodeKABUPATEN": 8205,
        "namaKECAMATAN": "LOLODA UTARA"
      },
      {
        "kodeKECAMATAN": 8205061,
        "kodeKABUPATEN": 8205,
        "namaKECAMATAN": "LOLODA KEPULAUAN"
      },
      {
        "kodeKECAMATAN": 8206010,
        "kodeKABUPATEN": 8206,
        "namaKECAMATAN": "MABA SELATAN"
      },
      {
        "kodeKECAMATAN": 8206011,
        "kodeKABUPATEN": 8206,
        "namaKECAMATAN": "KOTA MABA"
      },
      {
        "kodeKECAMATAN": 8206020,
        "kodeKABUPATEN": 8206,
        "namaKECAMATAN": "WASILE SELATAN"
      },
      {
        "kodeKECAMATAN": 8206030,
        "kodeKABUPATEN": 8206,
        "namaKECAMATAN": "WASILE"
      },
      {
        "kodeKECAMATAN": 8206031,
        "kodeKABUPATEN": 8206,
        "namaKECAMATAN": "WASILE TIMUR"
      },
      {
        "kodeKECAMATAN": 8206032,
        "kodeKABUPATEN": 8206,
        "namaKECAMATAN": "WASILE TENGAH"
      },
      {
        "kodeKECAMATAN": 8206033,
        "kodeKABUPATEN": 8206,
        "namaKECAMATAN": "WASILE UTARA"
      },
      {
        "kodeKECAMATAN": 8206040,
        "kodeKABUPATEN": 8206,
        "namaKECAMATAN": "MABA"
      },
      {
        "kodeKECAMATAN": 8206041,
        "kodeKABUPATEN": 8206,
        "namaKECAMATAN": "MABA TENGAH"
      },
      {
        "kodeKECAMATAN": 8206042,
        "kodeKABUPATEN": 8206,
        "namaKECAMATAN": "MABA UTARA"
      },
      {
        "kodeKECAMATAN": 8207010,
        "kodeKABUPATEN": 8207,
        "namaKECAMATAN": "MOROTAI SELATAN"
      },
      {
        "kodeKECAMATAN": 8207020,
        "kodeKABUPATEN": 8207,
        "namaKECAMATAN": "MOROTAI TIMUR"
      },
      {
        "kodeKECAMATAN": 8207030,
        "kodeKABUPATEN": 8207,
        "namaKECAMATAN": "MOROTAI SELATAN BARAT"
      },
      {
        "kodeKECAMATAN": 8207040,
        "kodeKABUPATEN": 8207,
        "namaKECAMATAN": "MOROTAI JAYA"
      },
      {
        "kodeKECAMATAN": 8207050,
        "kodeKABUPATEN": 8207,
        "namaKECAMATAN": "MOROTAI UTARA"
      },
      {
        "kodeKECAMATAN": 8208010,
        "kodeKABUPATEN": 8208,
        "namaKECAMATAN": "TALIABU BARAT"
      },
      {
        "kodeKECAMATAN": 8208020,
        "kodeKABUPATEN": 8208,
        "namaKECAMATAN": "TALIABU SELATAN"
      },
      {
        "kodeKECAMATAN": 8208030,
        "kodeKABUPATEN": 8208,
        "namaKECAMATAN": "TABONA"
      },
      {
        "kodeKECAMATAN": 8208040,
        "kodeKABUPATEN": 8208,
        "namaKECAMATAN": "TALIABU TIMUR SELATAN"
      },
      {
        "kodeKECAMATAN": 8208050,
        "kodeKABUPATEN": 8208,
        "namaKECAMATAN": "TALIABU TIMUR"
      },
      {
        "kodeKECAMATAN": 8208060,
        "kodeKABUPATEN": 8208,
        "namaKECAMATAN": "TALIABU UTARA"
      },
      {
        "kodeKECAMATAN": 8208070,
        "kodeKABUPATEN": 8208,
        "namaKECAMATAN": "LEDE"
      },
      {
        "kodeKECAMATAN": 8208080,
        "kodeKABUPATEN": 8208,
        "namaKECAMATAN": "TALIABU BARAT LAUT"
      },
      {
        "kodeKECAMATAN": 8271010,
        "kodeKABUPATEN": 8271,
        "namaKECAMATAN": "PULAU TERNATE"
      },
      {
        "kodeKECAMATAN": 8271011,
        "kodeKABUPATEN": 8271,
        "namaKECAMATAN": "MOTI"
      },
      {
        "kodeKECAMATAN": 8271012,
        "kodeKABUPATEN": 8271,
        "namaKECAMATAN": "PULAU BATANG DUA"
      },
      {
        "kodeKECAMATAN": 8271013,
        "kodeKABUPATEN": 8271,
        "namaKECAMATAN": "PULAU HIRI"
      },
      {
        "kodeKECAMATAN": 8271020,
        "kodeKABUPATEN": 8271,
        "namaKECAMATAN": "TERNATE SELATAN"
      },
      {
        "kodeKECAMATAN": 8271021,
        "kodeKABUPATEN": 8271,
        "namaKECAMATAN": "TERNATE TENGAH"
      },
      {
        "kodeKECAMATAN": 8271030,
        "kodeKABUPATEN": 8271,
        "namaKECAMATAN": "TERNATE UTARA"
      },
      {
        "kodeKECAMATAN": 8272010,
        "kodeKABUPATEN": 8272,
        "namaKECAMATAN": "TIDORE SELATAN"
      },
      {
        "kodeKECAMATAN": 8272020,
        "kodeKABUPATEN": 8272,
        "namaKECAMATAN": "TIDORE UTARA"
      },
      {
        "kodeKECAMATAN": 8272030,
        "kodeKABUPATEN": 8272,
        "namaKECAMATAN": "TIDORE"
      },
      {
        "kodeKECAMATAN": 8272031,
        "kodeKABUPATEN": 8272,
        "namaKECAMATAN": "TIDORE TIMUR"
      },
      {
        "kodeKECAMATAN": 8272040,
        "kodeKABUPATEN": 8272,
        "namaKECAMATAN": "OBA"
      },
      {
        "kodeKECAMATAN": 8272041,
        "kodeKABUPATEN": 8272,
        "namaKECAMATAN": "OBA SELATAN"
      },
      {
        "kodeKECAMATAN": 8272050,
        "kodeKABUPATEN": 8272,
        "namaKECAMATAN": "OBA UTARA"
      },
      {
        "kodeKECAMATAN": 8272051,
        "kodeKABUPATEN": 8272,
        "namaKECAMATAN": "OBA TENGAH"
      },
      {
        "kodeKECAMATAN": 9101050,
        "kodeKABUPATEN": 9101,
        "namaKECAMATAN": "FAKFAK TIMUR"
      },
      {
        "kodeKECAMATAN": 9101051,
        "kodeKABUPATEN": 9101,
        "namaKECAMATAN": "KARAS"
      },
      {
        "kodeKECAMATAN": 9101060,
        "kodeKABUPATEN": 9101,
        "namaKECAMATAN": "FAKFAK"
      },
      {
        "kodeKECAMATAN": 9101061,
        "kodeKABUPATEN": 9101,
        "namaKECAMATAN": "FAKFAK TENGAH"
      },
      {
        "kodeKECAMATAN": 9101070,
        "kodeKABUPATEN": 9101,
        "namaKECAMATAN": "FAKFAK BARAT"
      },
      {
        "kodeKECAMATAN": 9101080,
        "kodeKABUPATEN": 9101,
        "namaKECAMATAN": "KOKAS"
      },
      {
        "kodeKECAMATAN": 9101081,
        "kodeKABUPATEN": 9101,
        "namaKECAMATAN": "TELUK PATIPI"
      },
      {
        "kodeKECAMATAN": 9101082,
        "kodeKABUPATEN": 9101,
        "namaKECAMATAN": "KRAMONGMONGGA"
      },
      {
        "kodeKECAMATAN": 9101083,
        "kodeKABUPATEN": 9101,
        "namaKECAMATAN": "BOMBERAY"
      },
      {
        "kodeKECAMATAN": 9102010,
        "kodeKABUPATEN": 9102,
        "namaKECAMATAN": "BURUWAY"
      },
      {
        "kodeKECAMATAN": 9102020,
        "kodeKABUPATEN": 9102,
        "namaKECAMATAN": "TELUK ARGUNI"
      },
      {
        "kodeKECAMATAN": 9102021,
        "kodeKABUPATEN": 9102,
        "namaKECAMATAN": "TELUK ARGUNI BAWAH"
      },
      {
        "kodeKECAMATAN": 9102030,
        "kodeKABUPATEN": 9102,
        "namaKECAMATAN": "KAIMANA"
      },
      {
        "kodeKECAMATAN": 9102031,
        "kodeKABUPATEN": 9102,
        "namaKECAMATAN": "KAMBRAU"
      },
      {
        "kodeKECAMATAN": 9102040,
        "kodeKABUPATEN": 9102,
        "namaKECAMATAN": "TELUK ETNA"
      },
      {
        "kodeKECAMATAN": 9102041,
        "kodeKABUPATEN": 9102,
        "namaKECAMATAN": "YAMOR"
      },
      {
        "kodeKECAMATAN": 9103010,
        "kodeKABUPATEN": 9103,
        "namaKECAMATAN": "NAIKERE"
      },
      {
        "kodeKECAMATAN": 9103020,
        "kodeKABUPATEN": 9103,
        "namaKECAMATAN": "WONDIBOY"
      },
      {
        "kodeKECAMATAN": 9103021,
        "kodeKABUPATEN": 9103,
        "namaKECAMATAN": "RASIEY"
      },
      {
        "kodeKECAMATAN": 9103022,
        "kodeKABUPATEN": 9103,
        "namaKECAMATAN": "KURI WAMESA"
      },
      {
        "kodeKECAMATAN": 9103030,
        "kodeKABUPATEN": 9103,
        "namaKECAMATAN": "WASIOR"
      },
      {
        "kodeKECAMATAN": 9103040,
        "kodeKABUPATEN": 9103,
        "namaKECAMATAN": "DUAIRI"
      },
      {
        "kodeKECAMATAN": 9103041,
        "kodeKABUPATEN": 9103,
        "namaKECAMATAN": "ROON"
      },
      {
        "kodeKECAMATAN": 9103050,
        "kodeKABUPATEN": 9103,
        "namaKECAMATAN": "WINDESI"
      },
      {
        "kodeKECAMATAN": 9103051,
        "kodeKABUPATEN": 9103,
        "namaKECAMATAN": "NIKIWAR"
      },
      {
        "kodeKECAMATAN": 9103060,
        "kodeKABUPATEN": 9103,
        "namaKECAMATAN": "WAMESA"
      },
      {
        "kodeKECAMATAN": 9103061,
        "kodeKABUPATEN": 9103,
        "namaKECAMATAN": "ROSWAR"
      },
      {
        "kodeKECAMATAN": 9103070,
        "kodeKABUPATEN": 9103,
        "namaKECAMATAN": "RUMBERPON"
      },
      {
        "kodeKECAMATAN": 9103071,
        "kodeKABUPATEN": 9103,
        "namaKECAMATAN": "SOUG JAYA"
      },
      {
        "kodeKECAMATAN": 9104010,
        "kodeKABUPATEN": 9104,
        "namaKECAMATAN": "FAFURWAR"
      },
      {
        "kodeKECAMATAN": 9104020,
        "kodeKABUPATEN": 9104,
        "namaKECAMATAN": "BABO"
      },
      {
        "kodeKECAMATAN": 9104021,
        "kodeKABUPATEN": 9104,
        "namaKECAMATAN": "SUMURI"
      },
      {
        "kodeKECAMATAN": 9104022,
        "kodeKABUPATEN": 9104,
        "namaKECAMATAN": "AROBA"
      },
      {
        "kodeKECAMATAN": 9104023,
        "kodeKABUPATEN": 9104,
        "namaKECAMATAN": "KAITARO"
      },
      {
        "kodeKECAMATAN": 9104030,
        "kodeKABUPATEN": 9104,
        "namaKECAMATAN": "KURI"
      },
      {
        "kodeKECAMATAN": 9104040,
        "kodeKABUPATEN": 9104,
        "namaKECAMATAN": "WAMESA"
      },
      {
        "kodeKECAMATAN": 9104050,
        "kodeKABUPATEN": 9104,
        "namaKECAMATAN": "BINTUNI"
      },
      {
        "kodeKECAMATAN": 9104051,
        "kodeKABUPATEN": 9104,
        "namaKECAMATAN": "MANIMERI"
      },
      {
        "kodeKECAMATAN": 9104052,
        "kodeKABUPATEN": 9104,
        "namaKECAMATAN": "TUHIBA"
      },
      {
        "kodeKECAMATAN": 9104053,
        "kodeKABUPATEN": 9104,
        "namaKECAMATAN": "DATARAN BEIMES"
      },
      {
        "kodeKECAMATAN": 9104060,
        "kodeKABUPATEN": 9104,
        "namaKECAMATAN": "TEMBUNI"
      },
      {
        "kodeKECAMATAN": 9104070,
        "kodeKABUPATEN": 9104,
        "namaKECAMATAN": "ARANDAY"
      },
      {
        "kodeKECAMATAN": 9104071,
        "kodeKABUPATEN": 9104,
        "namaKECAMATAN": "KAMUNDAN"
      },
      {
        "kodeKECAMATAN": 9104072,
        "kodeKABUPATEN": 9104,
        "namaKECAMATAN": "TOMU"
      },
      {
        "kodeKECAMATAN": 9104073,
        "kodeKABUPATEN": 9104,
        "namaKECAMATAN": "WERIAGAR"
      },
      {
        "kodeKECAMATAN": 9104080,
        "kodeKABUPATEN": 9104,
        "namaKECAMATAN": "MOSKONA SELATAN"
      },
      {
        "kodeKECAMATAN": 9104081,
        "kodeKABUPATEN": 9104,
        "namaKECAMATAN": "MEYADO"
      },
      {
        "kodeKECAMATAN": 9104082,
        "kodeKABUPATEN": 9104,
        "namaKECAMATAN": "MOSKONA BARAT"
      },
      {
        "kodeKECAMATAN": 9104090,
        "kodeKABUPATEN": 9104,
        "namaKECAMATAN": "MERDEY"
      },
      {
        "kodeKECAMATAN": 9104091,
        "kodeKABUPATEN": 9104,
        "namaKECAMATAN": "BISCOOP"
      },
      {
        "kodeKECAMATAN": 9104092,
        "kodeKABUPATEN": 9104,
        "namaKECAMATAN": "MASYETA"
      },
      {
        "kodeKECAMATAN": 9104100,
        "kodeKABUPATEN": 9104,
        "namaKECAMATAN": "MOSKONA UTARA"
      },
      {
        "kodeKECAMATAN": 9104101,
        "kodeKABUPATEN": 9104,
        "namaKECAMATAN": "MOSKONA TIMUR"
      },
      {
        "kodeKECAMATAN": 9105110,
        "kodeKABUPATEN": 9105,
        "namaKECAMATAN": "WARMARE"
      },
      {
        "kodeKECAMATAN": 9105120,
        "kodeKABUPATEN": 9105,
        "namaKECAMATAN": "PRAFI"
      },
      {
        "kodeKECAMATAN": 9105141,
        "kodeKABUPATEN": 9105,
        "namaKECAMATAN": "MANOKWARI BARAT"
      },
      {
        "kodeKECAMATAN": 9105142,
        "kodeKABUPATEN": 9105,
        "namaKECAMATAN": "MANOKWARI TIMUR"
      },
      {
        "kodeKECAMATAN": 9105143,
        "kodeKABUPATEN": 9105,
        "namaKECAMATAN": "MANOKWARI UTARA"
      },
      {
        "kodeKECAMATAN": 9105144,
        "kodeKABUPATEN": 9105,
        "namaKECAMATAN": "MANOKWARI SELATAN"
      },
      {
        "kodeKECAMATAN": 9105146,
        "kodeKABUPATEN": 9105,
        "namaKECAMATAN": "TANAH RUBU"
      },
      {
        "kodeKECAMATAN": 9105170,
        "kodeKABUPATEN": 9105,
        "namaKECAMATAN": "MASNI"
      },
      {
        "kodeKECAMATAN": 9105171,
        "kodeKABUPATEN": 9105,
        "namaKECAMATAN": "SIDEY"
      },
      {
        "kodeKECAMATAN": 9106010,
        "kodeKABUPATEN": 9106,
        "namaKECAMATAN": "INANWATAN"
      },
      {
        "kodeKECAMATAN": 9106011,
        "kodeKABUPATEN": 9106,
        "namaKECAMATAN": "METEMANI"
      },
      {
        "kodeKECAMATAN": 9106020,
        "kodeKABUPATEN": 9106,
        "namaKECAMATAN": "KOKODA"
      },
      {
        "kodeKECAMATAN": 9106021,
        "kodeKABUPATEN": 9106,
        "namaKECAMATAN": "KAIS"
      },
      {
        "kodeKECAMATAN": 9106022,
        "kodeKABUPATEN": 9106,
        "namaKECAMATAN": "KOKODA UTARA"
      },
      {
        "kodeKECAMATAN": 9106023,
        "kodeKABUPATEN": 9106,
        "namaKECAMATAN": "KAIS DARAT"
      },
      {
        "kodeKECAMATAN": 9106060,
        "kodeKABUPATEN": 9106,
        "namaKECAMATAN": "MOSWAREN"
      },
      {
        "kodeKECAMATAN": 9106070,
        "kodeKABUPATEN": 9106,
        "namaKECAMATAN": "TEMINABUAN"
      },
      {
        "kodeKECAMATAN": 9106071,
        "kodeKABUPATEN": 9106,
        "namaKECAMATAN": "SEREMUK"
      },
      {
        "kodeKECAMATAN": 9106072,
        "kodeKABUPATEN": 9106,
        "namaKECAMATAN": "WAYER"
      },
      {
        "kodeKECAMATAN": 9106073,
        "kodeKABUPATEN": 9106,
        "namaKECAMATAN": "KONDA"
      },
      {
        "kodeKECAMATAN": 9106074,
        "kodeKABUPATEN": 9106,
        "namaKECAMATAN": "SAIFI"
      },
      {
        "kodeKECAMATAN": 9106080,
        "kodeKABUPATEN": 9106,
        "namaKECAMATAN": "SAWIAT"
      },
      {
        "kodeKECAMATAN": 9106081,
        "kodeKABUPATEN": 9106,
        "namaKECAMATAN": "FOKOUR"
      },
      {
        "kodeKECAMATAN": 9106082,
        "kodeKABUPATEN": 9106,
        "namaKECAMATAN": "SALKMA"
      },
      {
        "kodeKECAMATAN": 9107060,
        "kodeKABUPATEN": 9107,
        "namaKECAMATAN": "MORAID"
      },
      {
        "kodeKECAMATAN": 9107061,
        "kodeKABUPATEN": 9107,
        "namaKECAMATAN": "KLASO"
      },
      {
        "kodeKECAMATAN": 9107100,
        "kodeKABUPATEN": 9107,
        "namaKECAMATAN": "MAKBON"
      },
      {
        "kodeKECAMATAN": 9107101,
        "kodeKABUPATEN": 9107,
        "namaKECAMATAN": "KLAYILI"
      },
      {
        "kodeKECAMATAN": 9107110,
        "kodeKABUPATEN": 9107,
        "namaKECAMATAN": "BERAUR"
      },
      {
        "kodeKECAMATAN": 9107111,
        "kodeKABUPATEN": 9107,
        "namaKECAMATAN": "KLAMONO"
      },
      {
        "kodeKECAMATAN": 9107112,
        "kodeKABUPATEN": 9107,
        "namaKECAMATAN": "KLABOT"
      },
      {
        "kodeKECAMATAN": 9107113,
        "kodeKABUPATEN": 9107,
        "namaKECAMATAN": "KLAWAK"
      },
      {
        "kodeKECAMATAN": 9107120,
        "kodeKABUPATEN": 9107,
        "namaKECAMATAN": "SALAWATI"
      },
      {
        "kodeKECAMATAN": 9107121,
        "kodeKABUPATEN": 9107,
        "namaKECAMATAN": "MAYAMUK"
      },
      {
        "kodeKECAMATAN": 9107122,
        "kodeKABUPATEN": 9107,
        "namaKECAMATAN": "SALAWATI TIMUR"
      },
      {
        "kodeKECAMATAN": 9107130,
        "kodeKABUPATEN": 9107,
        "namaKECAMATAN": "SEGET"
      },
      {
        "kodeKECAMATAN": 9107131,
        "kodeKABUPATEN": 9107,
        "namaKECAMATAN": "SEGUN"
      },
      {
        "kodeKECAMATAN": 9107132,
        "kodeKABUPATEN": 9107,
        "namaKECAMATAN": "SALAWATI SELATAN"
      },
      {
        "kodeKECAMATAN": 9107170,
        "kodeKABUPATEN": 9107,
        "namaKECAMATAN": "AIMAS"
      },
      {
        "kodeKECAMATAN": 9107171,
        "kodeKABUPATEN": 9107,
        "namaKECAMATAN": "MARIAT"
      },
      {
        "kodeKECAMATAN": 9107172,
        "kodeKABUPATEN": 9107,
        "namaKECAMATAN": "SORONG"
      },
      {
        "kodeKECAMATAN": 9107180,
        "kodeKABUPATEN": 9107,
        "namaKECAMATAN": "SAYOSA"
      },
      {
        "kodeKECAMATAN": 9107181,
        "kodeKABUPATEN": 9107,
        "namaKECAMATAN": "MAUDUS"
      },
      {
        "kodeKECAMATAN": 9108011,
        "kodeKABUPATEN": 9108,
        "namaKECAMATAN": "MISOOL SELATAN"
      },
      {
        "kodeKECAMATAN": 9108012,
        "kodeKABUPATEN": 9108,
        "namaKECAMATAN": "MISOOL BARAT"
      },
      {
        "kodeKECAMATAN": 9108020,
        "kodeKABUPATEN": 9108,
        "namaKECAMATAN": "MISOOL"
      },
      {
        "kodeKECAMATAN": 9108021,
        "kodeKABUPATEN": 9108,
        "namaKECAMATAN": "KOFIAU"
      },
      {
        "kodeKECAMATAN": 9108022,
        "kodeKABUPATEN": 9108,
        "namaKECAMATAN": "MISOOL TIMUR"
      },
      {
        "kodeKECAMATAN": 9108023,
        "kodeKABUPATEN": 9108,
        "namaKECAMATAN": "KEPULAUAN SEMBILAN"
      },
      {
        "kodeKECAMATAN": 9108031,
        "kodeKABUPATEN": 9108,
        "namaKECAMATAN": "SALAWATI UTARA"
      },
      {
        "kodeKECAMATAN": 9108033,
        "kodeKABUPATEN": 9108,
        "namaKECAMATAN": "SALAWATI TENGAH"
      },
      {
        "kodeKECAMATAN": 9108034,
        "kodeKABUPATEN": 9108,
        "namaKECAMATAN": "SALAWATI BARAT"
      },
      {
        "kodeKECAMATAN": 9108035,
        "kodeKABUPATEN": 9108,
        "namaKECAMATAN": "BATANTA SELATAN"
      },
      {
        "kodeKECAMATAN": 9108036,
        "kodeKABUPATEN": 9108,
        "namaKECAMATAN": "BATANTA UTARA"
      },
      {
        "kodeKECAMATAN": 9108040,
        "kodeKABUPATEN": 9108,
        "namaKECAMATAN": "WAIGEO SELATAN"
      },
      {
        "kodeKECAMATAN": 9108041,
        "kodeKABUPATEN": 9108,
        "namaKECAMATAN": "TELUK MAYALIBIT"
      },
      {
        "kodeKECAMATAN": 9108042,
        "kodeKABUPATEN": 9108,
        "namaKECAMATAN": "MEOS MANSAR"
      },
      {
        "kodeKECAMATAN": 9108043,
        "kodeKABUPATEN": 9108,
        "namaKECAMATAN": "KOTA WAISAI"
      },
      {
        "kodeKECAMATAN": 9108044,
        "kodeKABUPATEN": 9108,
        "namaKECAMATAN": "TIPLOL MAYALIBIT"
      },
      {
        "kodeKECAMATAN": 9108050,
        "kodeKABUPATEN": 9108,
        "namaKECAMATAN": "WAIGEO BARAT"
      },
      {
        "kodeKECAMATAN": 9108051,
        "kodeKABUPATEN": 9108,
        "namaKECAMATAN": "WAIGEO BARAT KEPULAUAN"
      },
      {
        "kodeKECAMATAN": 9108060,
        "kodeKABUPATEN": 9108,
        "namaKECAMATAN": "WAIGEO UTARA"
      },
      {
        "kodeKECAMATAN": 9108061,
        "kodeKABUPATEN": 9108,
        "namaKECAMATAN": "WARWARBOMI"
      },
      {
        "kodeKECAMATAN": 9108062,
        "kodeKABUPATEN": 9108,
        "namaKECAMATAN": "SUPNIN"
      },
      {
        "kodeKECAMATAN": 9108070,
        "kodeKABUPATEN": 9108,
        "namaKECAMATAN": "KEPULAUAN AYAU"
      },
      {
        "kodeKECAMATAN": 9108071,
        "kodeKABUPATEN": 9108,
        "namaKECAMATAN": "AYAU"
      },
      {
        "kodeKECAMATAN": 9108080,
        "kodeKABUPATEN": 9108,
        "namaKECAMATAN": "WAIGEO TIMUR"
      },
      {
        "kodeKECAMATAN": 9109010,
        "kodeKABUPATEN": 9109,
        "namaKECAMATAN": "FEF"
      },
      {
        "kodeKECAMATAN": 9109011,
        "kodeKABUPATEN": 9109,
        "namaKECAMATAN": "SYUJAK"
      },
      {
        "kodeKECAMATAN": 9109020,
        "kodeKABUPATEN": 9109,
        "namaKECAMATAN": "MIYAH"
      },
      {
        "kodeKECAMATAN": 9109030,
        "kodeKABUPATEN": 9109,
        "namaKECAMATAN": "ABUN"
      },
      {
        "kodeKECAMATAN": 9109040,
        "kodeKABUPATEN": 9109,
        "namaKECAMATAN": "KWOOR"
      },
      {
        "kodeKECAMATAN": 9109050,
        "kodeKABUPATEN": 9109,
        "namaKECAMATAN": "SAUSAPOR"
      },
      {
        "kodeKECAMATAN": 9109060,
        "kodeKABUPATEN": 9109,
        "namaKECAMATAN": "YEMBUN"
      },
      {
        "kodeKECAMATAN": 9109070,
        "kodeKABUPATEN": 9109,
        "namaKECAMATAN": "KEBAR"
      },
      {
        "kodeKECAMATAN": 9109080,
        "kodeKABUPATEN": 9109,
        "namaKECAMATAN": "SENOPI"
      },
      {
        "kodeKECAMATAN": 9109090,
        "kodeKABUPATEN": 9109,
        "namaKECAMATAN": "AMBERBAKEN"
      },
      {
        "kodeKECAMATAN": 9109100,
        "kodeKABUPATEN": 9109,
        "namaKECAMATAN": "MUBARNI / ARFU"
      },
      {
        "kodeKECAMATAN": 9110010,
        "kodeKABUPATEN": 9110,
        "namaKECAMATAN": "AITINYO BARAT/ATHABU"
      },
      {
        "kodeKECAMATAN": 9110011,
        "kodeKABUPATEN": 9110,
        "namaKECAMATAN": "AYAMARU SELATAN JAYA"
      },
      {
        "kodeKECAMATAN": 9110020,
        "kodeKABUPATEN": 9110,
        "namaKECAMATAN": "AITINYO"
      },
      {
        "kodeKECAMATAN": 9110021,
        "kodeKABUPATEN": 9110,
        "namaKECAMATAN": "AITINYO TENGAH"
      },
      {
        "kodeKECAMATAN": 9110030,
        "kodeKABUPATEN": 9110,
        "namaKECAMATAN": "AIFAT SELATAN"
      },
      {
        "kodeKECAMATAN": 9110031,
        "kodeKABUPATEN": 9110,
        "namaKECAMATAN": "AIFAT TIMUR SELATAN"
      },
      {
        "kodeKECAMATAN": 9110040,
        "kodeKABUPATEN": 9110,
        "namaKECAMATAN": "AIFAT"
      },
      {
        "kodeKECAMATAN": 9110050,
        "kodeKABUPATEN": 9110,
        "namaKECAMATAN": "AITINYO UTARA"
      },
      {
        "kodeKECAMATAN": 9110051,
        "kodeKABUPATEN": 9110,
        "namaKECAMATAN": "AITINYO RAYA"
      },
      {
        "kodeKECAMATAN": 9110060,
        "kodeKABUPATEN": 9110,
        "namaKECAMATAN": "AYAMARU TIMUR"
      },
      {
        "kodeKECAMATAN": 9110061,
        "kodeKABUPATEN": 9110,
        "namaKECAMATAN": "AYAMARU TIMUR SELATAN"
      },
      {
        "kodeKECAMATAN": 9110070,
        "kodeKABUPATEN": 9110,
        "namaKECAMATAN": "AYAMARU"
      },
      {
        "kodeKECAMATAN": 9110071,
        "kodeKABUPATEN": 9110,
        "namaKECAMATAN": "AYAMARU SELATAN"
      },
      {
        "kodeKECAMATAN": 9110072,
        "kodeKABUPATEN": 9110,
        "namaKECAMATAN": "AYAMARU JAYA"
      },
      {
        "kodeKECAMATAN": 9110073,
        "kodeKABUPATEN": 9110,
        "namaKECAMATAN": "AYAMARU TENGAH"
      },
      {
        "kodeKECAMATAN": 9110074,
        "kodeKABUPATEN": 9110,
        "namaKECAMATAN": "AYAMARU BARAT"
      },
      {
        "kodeKECAMATAN": 9110080,
        "kodeKABUPATEN": 9110,
        "namaKECAMATAN": "AYAMARU UTARA"
      },
      {
        "kodeKECAMATAN": 9110081,
        "kodeKABUPATEN": 9110,
        "namaKECAMATAN": "AYAMARU UTARA TIMUR"
      },
      {
        "kodeKECAMATAN": 9110090,
        "kodeKABUPATEN": 9110,
        "namaKECAMATAN": "MARE"
      },
      {
        "kodeKECAMATAN": 9110091,
        "kodeKABUPATEN": 9110,
        "namaKECAMATAN": "MARE SELATAN"
      },
      {
        "kodeKECAMATAN": 9110100,
        "kodeKABUPATEN": 9110,
        "namaKECAMATAN": "AIFAT UTARA"
      },
      {
        "kodeKECAMATAN": 9110110,
        "kodeKABUPATEN": 9110,
        "namaKECAMATAN": "AIFAT TIMUR"
      },
      {
        "kodeKECAMATAN": 9110111,
        "kodeKABUPATEN": 9110,
        "namaKECAMATAN": "AIFAT TIMUR TENGAH"
      },
      {
        "kodeKECAMATAN": 9110112,
        "kodeKABUPATEN": 9110,
        "namaKECAMATAN": "AIFAT TIMUR JAUH"
      },
      {
        "kodeKECAMATAN": 9111010,
        "kodeKABUPATEN": 9111,
        "namaKECAMATAN": "TAHOTA"
      },
      {
        "kodeKECAMATAN": 9111020,
        "kodeKABUPATEN": 9111,
        "namaKECAMATAN": "DATARAN ISIM"
      },
      {
        "kodeKECAMATAN": 9111030,
        "kodeKABUPATEN": 9111,
        "namaKECAMATAN": "NENEI"
      },
      {
        "kodeKECAMATAN": 9111040,
        "kodeKABUPATEN": 9111,
        "namaKECAMATAN": "MOMI WAREN"
      },
      {
        "kodeKECAMATAN": 9111050,
        "kodeKABUPATEN": 9111,
        "namaKECAMATAN": "RANSIKI"
      },
      {
        "kodeKECAMATAN": 9111060,
        "kodeKABUPATEN": 9111,
        "namaKECAMATAN": "ORANSBARI"
      },
      {
        "kodeKECAMATAN": 9112010,
        "kodeKABUPATEN": 9112,
        "namaKECAMATAN": "DIDOHU"
      },
      {
        "kodeKECAMATAN": 9112020,
        "kodeKABUPATEN": 9112,
        "namaKECAMATAN": "SURUREY"
      },
      {
        "kodeKECAMATAN": 9112030,
        "kodeKABUPATEN": 9112,
        "namaKECAMATAN": "ANGGI GIDA"
      },
      {
        "kodeKECAMATAN": 9112040,
        "kodeKABUPATEN": 9112,
        "namaKECAMATAN": "MEMBEY"
      },
      {
        "kodeKECAMATAN": 9112050,
        "kodeKABUPATEN": 9112,
        "namaKECAMATAN": "ANGGI"
      },
      {
        "kodeKECAMATAN": 9112060,
        "kodeKABUPATEN": 9112,
        "namaKECAMATAN": "TAIGE"
      },
      {
        "kodeKECAMATAN": 9112070,
        "kodeKABUPATEN": 9112,
        "namaKECAMATAN": "HINGK"
      },
      {
        "kodeKECAMATAN": 9112080,
        "kodeKABUPATEN": 9112,
        "namaKECAMATAN": "MENYAMBOUW"
      },
      {
        "kodeKECAMATAN": 9112090,
        "kodeKABUPATEN": 9112,
        "namaKECAMATAN": "CATUBOUW"
      },
      {
        "kodeKECAMATAN": 9112100,
        "kodeKABUPATEN": 9112,
        "namaKECAMATAN": "TESTEGA"
      },
      {
        "kodeKECAMATAN": 9171010,
        "kodeKABUPATEN": 9171,
        "namaKECAMATAN": "SORONG BARAT"
      },
      {
        "kodeKECAMATAN": 9171011,
        "kodeKABUPATEN": 9171,
        "namaKECAMATAN": "SORONG KEPULAUAN"
      },
      {
        "kodeKECAMATAN": 9171012,
        "kodeKABUPATEN": 9171,
        "namaKECAMATAN": "MALADOMES"
      },
      {
        "kodeKECAMATAN": 9171020,
        "kodeKABUPATEN": 9171,
        "namaKECAMATAN": "SORONG TIMUR"
      },
      {
        "kodeKECAMATAN": 9171021,
        "kodeKABUPATEN": 9171,
        "namaKECAMATAN": "SORONG UTARA"
      },
      {
        "kodeKECAMATAN": 9171022,
        "kodeKABUPATEN": 9171,
        "namaKECAMATAN": "SORONG"
      },
      {
        "kodeKECAMATAN": 9171023,
        "kodeKABUPATEN": 9171,
        "namaKECAMATAN": "SORONG MANOI"
      },
      {
        "kodeKECAMATAN": 9171024,
        "kodeKABUPATEN": 9171,
        "namaKECAMATAN": "KLAURUNG"
      },
      {
        "kodeKECAMATAN": 9171025,
        "kodeKABUPATEN": 9171,
        "namaKECAMATAN": "MALAIMSIMSA"
      },
      {
        "kodeKECAMATAN": 9171026,
        "kodeKABUPATEN": 9171,
        "namaKECAMATAN": "SORONG KOTA"
      },
      {
        "kodeKECAMATAN": 9401010,
        "kodeKABUPATEN": 9401,
        "namaKECAMATAN": "KIMAAM"
      },
      {
        "kodeKECAMATAN": 9401011,
        "kodeKABUPATEN": 9401,
        "namaKECAMATAN": "WAAN"
      },
      {
        "kodeKECAMATAN": 9401012,
        "kodeKABUPATEN": 9401,
        "namaKECAMATAN": "TABONJI"
      },
      {
        "kodeKECAMATAN": 9401013,
        "kodeKABUPATEN": 9401,
        "namaKECAMATAN": "ILWAYAB"
      },
      {
        "kodeKECAMATAN": 9401020,
        "kodeKABUPATEN": 9401,
        "namaKECAMATAN": "OKABA"
      },
      {
        "kodeKECAMATAN": 9401021,
        "kodeKABUPATEN": 9401,
        "namaKECAMATAN": "TUBANG"
      },
      {
        "kodeKECAMATAN": 9401022,
        "kodeKABUPATEN": 9401,
        "namaKECAMATAN": "NGGUTI"
      },
      {
        "kodeKECAMATAN": 9401023,
        "kodeKABUPATEN": 9401,
        "namaKECAMATAN": "KAPTEL"
      },
      {
        "kodeKECAMATAN": 9401030,
        "kodeKABUPATEN": 9401,
        "namaKECAMATAN": "KURIK"
      },
      {
        "kodeKECAMATAN": 9401031,
        "kodeKABUPATEN": 9401,
        "namaKECAMATAN": "MALIND"
      },
      {
        "kodeKECAMATAN": 9401032,
        "kodeKABUPATEN": 9401,
        "namaKECAMATAN": "ANIMHA"
      },
      {
        "kodeKECAMATAN": 9401040,
        "kodeKABUPATEN": 9401,
        "namaKECAMATAN": "MERAUKE"
      },
      {
        "kodeKECAMATAN": 9401041,
        "kodeKABUPATEN": 9401,
        "namaKECAMATAN": "SEMANGGA"
      },
      {
        "kodeKECAMATAN": 9401042,
        "kodeKABUPATEN": 9401,
        "namaKECAMATAN": "TANAH MIRING"
      },
      {
        "kodeKECAMATAN": 9401043,
        "kodeKABUPATEN": 9401,
        "namaKECAMATAN": "JAGEBOB"
      },
      {
        "kodeKECAMATAN": 9401044,
        "kodeKABUPATEN": 9401,
        "namaKECAMATAN": "SOTA"
      },
      {
        "kodeKECAMATAN": 9401045,
        "kodeKABUPATEN": 9401,
        "namaKECAMATAN": "NAUKENJERAI"
      },
      {
        "kodeKECAMATAN": 9401050,
        "kodeKABUPATEN": 9401,
        "namaKECAMATAN": "MUTING"
      },
      {
        "kodeKECAMATAN": 9401051,
        "kodeKABUPATEN": 9401,
        "namaKECAMATAN": "ELIGOBEL"
      },
      {
        "kodeKECAMATAN": 9401052,
        "kodeKABUPATEN": 9401,
        "namaKECAMATAN": "ULILIN"
      },
      {
        "kodeKECAMATAN": 9402110,
        "kodeKABUPATEN": 9402,
        "namaKECAMATAN": "WAMENA"
      },
      {
        "kodeKECAMATAN": 9402111,
        "kodeKABUPATEN": 9402,
        "namaKECAMATAN": "ASOLOKOBAL"
      },
      {
        "kodeKECAMATAN": 9402112,
        "kodeKABUPATEN": 9402,
        "namaKECAMATAN": "WALELAGAMA"
      },
      {
        "kodeKECAMATAN": 9402113,
        "kodeKABUPATEN": 9402,
        "namaKECAMATAN": "TRIKORA"
      },
      {
        "kodeKECAMATAN": 9402114,
        "kodeKABUPATEN": 9402,
        "namaKECAMATAN": "NAPUA"
      },
      {
        "kodeKECAMATAN": 9402115,
        "kodeKABUPATEN": 9402,
        "namaKECAMATAN": "WALAIK"
      },
      {
        "kodeKECAMATAN": 9402116,
        "kodeKABUPATEN": 9402,
        "namaKECAMATAN": "WOUMA"
      },
      {
        "kodeKECAMATAN": 9402117,
        "kodeKABUPATEN": 9402,
        "namaKECAMATAN": "WALESI"
      },
      {
        "kodeKECAMATAN": 9402118,
        "kodeKABUPATEN": 9402,
        "namaKECAMATAN": "ASOTIPO"
      },
      {
        "kodeKECAMATAN": 9402119,
        "kodeKABUPATEN": 9402,
        "namaKECAMATAN": "MAIMA"
      },
      {
        "kodeKECAMATAN": 9402120,
        "kodeKABUPATEN": 9402,
        "namaKECAMATAN": "HUBIKOSI"
      },
      {
        "kodeKECAMATAN": 9402121,
        "kodeKABUPATEN": 9402,
        "namaKECAMATAN": "PELEBAGA"
      },
      {
        "kodeKECAMATAN": 9402122,
        "kodeKABUPATEN": 9402,
        "namaKECAMATAN": "IBELE"
      },
      {
        "kodeKECAMATAN": 9402123,
        "kodeKABUPATEN": 9402,
        "namaKECAMATAN": "TAILAREK"
      },
      {
        "kodeKECAMATAN": 9402124,
        "kodeKABUPATEN": 9402,
        "namaKECAMATAN": "HUBIKIAK"
      },
      {
        "kodeKECAMATAN": 9402180,
        "kodeKABUPATEN": 9402,
        "namaKECAMATAN": "ASOLOGAIMA"
      },
      {
        "kodeKECAMATAN": 9402181,
        "kodeKABUPATEN": 9402,
        "namaKECAMATAN": "MUSATFAK"
      },
      {
        "kodeKECAMATAN": 9402182,
        "kodeKABUPATEN": 9402,
        "namaKECAMATAN": "SILO KARNO DOGA"
      },
      {
        "kodeKECAMATAN": 9402183,
        "kodeKABUPATEN": 9402,
        "namaKECAMATAN": "PYRAMID"
      },
      {
        "kodeKECAMATAN": 9402184,
        "kodeKABUPATEN": 9402,
        "namaKECAMATAN": "MULIAMA"
      },
      {
        "kodeKECAMATAN": 9402185,
        "kodeKABUPATEN": 9402,
        "namaKECAMATAN": "WAME"
      },
      {
        "kodeKECAMATAN": 9402190,
        "kodeKABUPATEN": 9402,
        "namaKECAMATAN": "KURULU"
      },
      {
        "kodeKECAMATAN": 9402191,
        "kodeKABUPATEN": 9402,
        "namaKECAMATAN": "USILIMO"
      },
      {
        "kodeKECAMATAN": 9402192,
        "kodeKABUPATEN": 9402,
        "namaKECAMATAN": "WITA WAYA"
      },
      {
        "kodeKECAMATAN": 9402193,
        "kodeKABUPATEN": 9402,
        "namaKECAMATAN": "LIBAREK"
      },
      {
        "kodeKECAMATAN": 9402194,
        "kodeKABUPATEN": 9402,
        "namaKECAMATAN": "WADANGKU"
      },
      {
        "kodeKECAMATAN": 9402195,
        "kodeKABUPATEN": 9402,
        "namaKECAMATAN": "PISUGI"
      },
      {
        "kodeKECAMATAN": 9402220,
        "kodeKABUPATEN": 9402,
        "namaKECAMATAN": "BOLAKME"
      },
      {
        "kodeKECAMATAN": 9402221,
        "kodeKABUPATEN": 9402,
        "namaKECAMATAN": "WOLLO"
      },
      {
        "kodeKECAMATAN": 9402222,
        "kodeKABUPATEN": 9402,
        "namaKECAMATAN": "YALENGGA"
      },
      {
        "kodeKECAMATAN": 9402223,
        "kodeKABUPATEN": 9402,
        "namaKECAMATAN": "TAGIME"
      },
      {
        "kodeKECAMATAN": 9402224,
        "kodeKABUPATEN": 9402,
        "namaKECAMATAN": "MOLAGALOME"
      },
      {
        "kodeKECAMATAN": 9402225,
        "kodeKABUPATEN": 9402,
        "namaKECAMATAN": "TAGINERI"
      },
      {
        "kodeKECAMATAN": 9402226,
        "kodeKABUPATEN": 9402,
        "namaKECAMATAN": "BUGI"
      },
      {
        "kodeKECAMATAN": 9402227,
        "kodeKABUPATEN": 9402,
        "namaKECAMATAN": "BPIRI"
      },
      {
        "kodeKECAMATAN": 9402228,
        "kodeKABUPATEN": 9402,
        "namaKECAMATAN": "KORAGI"
      },
      {
        "kodeKECAMATAN": 9402611,
        "kodeKABUPATEN": 9402,
        "namaKECAMATAN": "ITLAY HASIGE"
      },
      {
        "kodeKECAMATAN": 9402612,
        "kodeKABUPATEN": 9402,
        "namaKECAMATAN": "SIEPKOSI"
      },
      {
        "kodeKECAMATAN": 9402614,
        "kodeKABUPATEN": 9402,
        "namaKECAMATAN": "POPUGOBA"
      },
      {
        "kodeKECAMATAN": 9403080,
        "kodeKABUPATEN": 9403,
        "namaKECAMATAN": "KAUREH"
      },
      {
        "kodeKECAMATAN": 9403081,
        "kodeKABUPATEN": 9403,
        "namaKECAMATAN": "AIRU"
      },
      {
        "kodeKECAMATAN": 9403082,
        "kodeKABUPATEN": 9403,
        "namaKECAMATAN": "YAPSI"
      },
      {
        "kodeKECAMATAN": 9403140,
        "kodeKABUPATEN": 9403,
        "namaKECAMATAN": "KEMTUK"
      },
      {
        "kodeKECAMATAN": 9403150,
        "kodeKABUPATEN": 9403,
        "namaKECAMATAN": "KEMTUK GRESI"
      },
      {
        "kodeKECAMATAN": 9403151,
        "kodeKABUPATEN": 9403,
        "namaKECAMATAN": "GRESI SELATAN"
      },
      {
        "kodeKECAMATAN": 9403160,
        "kodeKABUPATEN": 9403,
        "namaKECAMATAN": "NIMBORAN"
      },
      {
        "kodeKECAMATAN": 9403161,
        "kodeKABUPATEN": 9403,
        "namaKECAMATAN": "NIMBORAN TIMUR / NAMBLONG"
      },
      {
        "kodeKECAMATAN": 9403170,
        "kodeKABUPATEN": 9403,
        "namaKECAMATAN": "NIMBOKRANG"
      },
      {
        "kodeKECAMATAN": 9403180,
        "kodeKABUPATEN": 9403,
        "namaKECAMATAN": "UNURUM GUAY"
      },
      {
        "kodeKECAMATAN": 9403200,
        "kodeKABUPATEN": 9403,
        "namaKECAMATAN": "DEMTA"
      },
      {
        "kodeKECAMATAN": 9403201,
        "kodeKABUPATEN": 9403,
        "namaKECAMATAN": "YOKARI"
      },
      {
        "kodeKECAMATAN": 9403210,
        "kodeKABUPATEN": 9403,
        "namaKECAMATAN": "DEPAPRE"
      },
      {
        "kodeKECAMATAN": 9403211,
        "kodeKABUPATEN": 9403,
        "namaKECAMATAN": "RAVENIRARA"
      },
      {
        "kodeKECAMATAN": 9403220,
        "kodeKABUPATEN": 9403,
        "namaKECAMATAN": "SENTANI BARAT"
      },
      {
        "kodeKECAMATAN": 9403221,
        "kodeKABUPATEN": 9403,
        "namaKECAMATAN": "WAIBU"
      },
      {
        "kodeKECAMATAN": 9403230,
        "kodeKABUPATEN": 9403,
        "namaKECAMATAN": "SENTANI"
      },
      {
        "kodeKECAMATAN": 9403231,
        "kodeKABUPATEN": 9403,
        "namaKECAMATAN": "EBUNGFAU"
      },
      {
        "kodeKECAMATAN": 9403240,
        "kodeKABUPATEN": 9403,
        "namaKECAMATAN": "SENTANI TIMUR"
      },
      {
        "kodeKECAMATAN": 9404050,
        "kodeKABUPATEN": 9404,
        "namaKECAMATAN": "UWAPA"
      },
      {
        "kodeKECAMATAN": 9404051,
        "kodeKABUPATEN": 9404,
        "namaKECAMATAN": "MENOU"
      },
      {
        "kodeKECAMATAN": 9404052,
        "kodeKABUPATEN": 9404,
        "namaKECAMATAN": "DIPA"
      },
      {
        "kodeKECAMATAN": 9404060,
        "kodeKABUPATEN": 9404,
        "namaKECAMATAN": "YAUR"
      },
      {
        "kodeKECAMATAN": 9404061,
        "kodeKABUPATEN": 9404,
        "namaKECAMATAN": "TELUK UMAR"
      },
      {
        "kodeKECAMATAN": 9404070,
        "kodeKABUPATEN": 9404,
        "namaKECAMATAN": "WANGGAR"
      },
      {
        "kodeKECAMATAN": 9404071,
        "kodeKABUPATEN": 9404,
        "namaKECAMATAN": "NABIRE BARAT"
      },
      {
        "kodeKECAMATAN": 9404080,
        "kodeKABUPATEN": 9404,
        "namaKECAMATAN": "NABIRE"
      },
      {
        "kodeKECAMATAN": 9404081,
        "kodeKABUPATEN": 9404,
        "namaKECAMATAN": "TELUK KIMI"
      },
      {
        "kodeKECAMATAN": 9404090,
        "kodeKABUPATEN": 9404,
        "namaKECAMATAN": "NAPAN"
      },
      {
        "kodeKECAMATAN": 9404091,
        "kodeKABUPATEN": 9404,
        "namaKECAMATAN": "MAKIMI"
      },
      {
        "kodeKECAMATAN": 9404092,
        "kodeKABUPATEN": 9404,
        "namaKECAMATAN": "WAPOGA"
      },
      {
        "kodeKECAMATAN": 9404093,
        "kodeKABUPATEN": 9404,
        "namaKECAMATAN": "KEPULAUAN MOORA"
      },
      {
        "kodeKECAMATAN": 9404100,
        "kodeKABUPATEN": 9404,
        "namaKECAMATAN": "SIRIWO"
      },
      {
        "kodeKECAMATAN": 9404110,
        "kodeKABUPATEN": 9404,
        "namaKECAMATAN": "YARO"
      },
      {
        "kodeKECAMATAN": 9408040,
        "kodeKABUPATEN": 9408,
        "namaKECAMATAN": "YAPEN TIMUR"
      },
      {
        "kodeKECAMATAN": 9408041,
        "kodeKABUPATEN": 9408,
        "namaKECAMATAN": "PANTURA YAPEN"
      },
      {
        "kodeKECAMATAN": 9408042,
        "kodeKABUPATEN": 9408,
        "namaKECAMATAN": "TELUK AMPIMOI"
      },
      {
        "kodeKECAMATAN": 9408043,
        "kodeKABUPATEN": 9408,
        "namaKECAMATAN": "RAIMBAWI"
      },
      {
        "kodeKECAMATAN": 9408044,
        "kodeKABUPATEN": 9408,
        "namaKECAMATAN": "PULAU KURUDU"
      },
      {
        "kodeKECAMATAN": 9408050,
        "kodeKABUPATEN": 9408,
        "namaKECAMATAN": "ANGKAISERA"
      },
      {
        "kodeKECAMATAN": 9408051,
        "kodeKABUPATEN": 9408,
        "namaKECAMATAN": "KEP. AMBAI"
      },
      {
        "kodeKECAMATAN": 9408052,
        "kodeKABUPATEN": 9408,
        "namaKECAMATAN": "YAWAKUKAT"
      },
      {
        "kodeKECAMATAN": 9408060,
        "kodeKABUPATEN": 9408,
        "namaKECAMATAN": "YAPEN SELATAN"
      },
      {
        "kodeKECAMATAN": 9408061,
        "kodeKABUPATEN": 9408,
        "namaKECAMATAN": "KOSIWO"
      },
      {
        "kodeKECAMATAN": 9408062,
        "kodeKABUPATEN": 9408,
        "namaKECAMATAN": "ANATAUREI"
      },
      {
        "kodeKECAMATAN": 9408070,
        "kodeKABUPATEN": 9408,
        "namaKECAMATAN": "YAPEN BARAT"
      },
      {
        "kodeKECAMATAN": 9408071,
        "kodeKABUPATEN": 9408,
        "namaKECAMATAN": "WONAWA"
      },
      {
        "kodeKECAMATAN": 9408072,
        "kodeKABUPATEN": 9408,
        "namaKECAMATAN": "PULAU YERUI"
      },
      {
        "kodeKECAMATAN": 9408080,
        "kodeKABUPATEN": 9408,
        "namaKECAMATAN": "POOM"
      },
      {
        "kodeKECAMATAN": 9408081,
        "kodeKABUPATEN": 9408,
        "namaKECAMATAN": "WINDESI"
      },
      {
        "kodeKECAMATAN": 9409010,
        "kodeKABUPATEN": 9409,
        "namaKECAMATAN": "NUMFOR BARAT"
      },
      {
        "kodeKECAMATAN": 9409011,
        "kodeKABUPATEN": 9409,
        "namaKECAMATAN": "ORKERI"
      },
      {
        "kodeKECAMATAN": 9409020,
        "kodeKABUPATEN": 9409,
        "namaKECAMATAN": "NUMFOR TIMUR"
      },
      {
        "kodeKECAMATAN": 9409021,
        "kodeKABUPATEN": 9409,
        "namaKECAMATAN": "BRUYADORI"
      },
      {
        "kodeKECAMATAN": 9409022,
        "kodeKABUPATEN": 9409,
        "namaKECAMATAN": "POIRU"
      },
      {
        "kodeKECAMATAN": 9409030,
        "kodeKABUPATEN": 9409,
        "namaKECAMATAN": "PADAIDO"
      },
      {
        "kodeKECAMATAN": 9409031,
        "kodeKABUPATEN": 9409,
        "namaKECAMATAN": "AIMANDO PADAIDO"
      },
      {
        "kodeKECAMATAN": 9409040,
        "kodeKABUPATEN": 9409,
        "namaKECAMATAN": "BIAK TIMUR"
      },
      {
        "kodeKECAMATAN": 9409041,
        "kodeKABUPATEN": 9409,
        "namaKECAMATAN": "ORIDEK"
      },
      {
        "kodeKECAMATAN": 9409050,
        "kodeKABUPATEN": 9409,
        "namaKECAMATAN": "BIAK KOTA"
      },
      {
        "kodeKECAMATAN": 9409060,
        "kodeKABUPATEN": 9409,
        "namaKECAMATAN": "SAMOFA"
      },
      {
        "kodeKECAMATAN": 9409070,
        "kodeKABUPATEN": 9409,
        "namaKECAMATAN": "YENDIDORI"
      },
      {
        "kodeKECAMATAN": 9409080,
        "kodeKABUPATEN": 9409,
        "namaKECAMATAN": "BIAK UTARA"
      },
      {
        "kodeKECAMATAN": 9409081,
        "kodeKABUPATEN": 9409,
        "namaKECAMATAN": "ANDEY"
      },
      {
        "kodeKECAMATAN": 9409090,
        "kodeKABUPATEN": 9409,
        "namaKECAMATAN": "WARSA"
      },
      {
        "kodeKECAMATAN": 9409091,
        "kodeKABUPATEN": 9409,
        "namaKECAMATAN": "YAWOSI"
      },
      {
        "kodeKECAMATAN": 9409092,
        "kodeKABUPATEN": 9409,
        "namaKECAMATAN": "BONDIFUAR"
      },
      {
        "kodeKECAMATAN": 9409100,
        "kodeKABUPATEN": 9409,
        "namaKECAMATAN": "BIAK BARAT"
      },
      {
        "kodeKECAMATAN": 9409101,
        "kodeKABUPATEN": 9409,
        "namaKECAMATAN": "SWANDIWE"
      },
      {
        "kodeKECAMATAN": 9410030,
        "kodeKABUPATEN": 9410,
        "namaKECAMATAN": "PANIAI TIMUR"
      },
      {
        "kodeKECAMATAN": 9410031,
        "kodeKABUPATEN": 9410,
        "namaKECAMATAN": "YATAMO"
      },
      {
        "kodeKECAMATAN": 9410032,
        "kodeKABUPATEN": 9410,
        "namaKECAMATAN": "KEBO"
      },
      {
        "kodeKECAMATAN": 9410040,
        "kodeKABUPATEN": 9410,
        "namaKECAMATAN": "BIBIDA"
      },
      {
        "kodeKECAMATAN": 9410041,
        "kodeKABUPATEN": 9410,
        "namaKECAMATAN": "DUMADAMA"
      },
      {
        "kodeKECAMATAN": 9410070,
        "kodeKABUPATEN": 9410,
        "namaKECAMATAN": "ARADIDE"
      },
      {
        "kodeKECAMATAN": 9410071,
        "kodeKABUPATEN": 9410,
        "namaKECAMATAN": "EKADIDE"
      },
      {
        "kodeKECAMATAN": 9410080,
        "kodeKABUPATEN": 9410,
        "namaKECAMATAN": "PANIAI BARAT"
      },
      {
        "kodeKECAMATAN": 9410081,
        "kodeKABUPATEN": 9410,
        "namaKECAMATAN": "SIRIWO"
      },
      {
        "kodeKECAMATAN": 9410090,
        "kodeKABUPATEN": 9410,
        "namaKECAMATAN": "BOGOBAIDA"
      },
      {
        "kodeKECAMATAN": 9411040,
        "kodeKABUPATEN": 9411,
        "namaKECAMATAN": "FAWI"
      },
      {
        "kodeKECAMATAN": 9411041,
        "kodeKABUPATEN": 9411,
        "namaKECAMATAN": "DAGAI"
      },
      {
        "kodeKECAMATAN": 9411042,
        "kodeKABUPATEN": 9411,
        "namaKECAMATAN": "KIYAGE"
      },
      {
        "kodeKECAMATAN": 9411050,
        "kodeKABUPATEN": 9411,
        "namaKECAMATAN": "MULIA"
      },
      {
        "kodeKECAMATAN": 9411053,
        "kodeKABUPATEN": 9411,
        "namaKECAMATAN": "YAMBI"
      },
      {
        "kodeKECAMATAN": 9411054,
        "kodeKABUPATEN": 9411,
        "namaKECAMATAN": "ILAMBURAWI"
      },
      {
        "kodeKECAMATAN": 9411055,
        "kodeKABUPATEN": 9411,
        "namaKECAMATAN": "MUARA"
      },
      {
        "kodeKECAMATAN": 9411056,
        "kodeKABUPATEN": 9411,
        "namaKECAMATAN": "PAGALEME"
      },
      {
        "kodeKECAMATAN": 9411057,
        "kodeKABUPATEN": 9411,
        "namaKECAMATAN": "GURAGE"
      },
      {
        "kodeKECAMATAN": 9411058,
        "kodeKABUPATEN": 9411,
        "namaKECAMATAN": "IRIMULI"
      },
      {
        "kodeKECAMATAN": 9411060,
        "kodeKABUPATEN": 9411,
        "namaKECAMATAN": "ILU"
      },
      {
        "kodeKECAMATAN": 9411061,
        "kodeKABUPATEN": 9411,
        "namaKECAMATAN": "TORERE"
      },
      {
        "kodeKECAMATAN": 9411063,
        "kodeKABUPATEN": 9411,
        "namaKECAMATAN": "YAMONERI"
      },
      {
        "kodeKECAMATAN": 9411064,
        "kodeKABUPATEN": 9411,
        "namaKECAMATAN": "WAEGI"
      },
      {
        "kodeKECAMATAN": 9411065,
        "kodeKABUPATEN": 9411,
        "namaKECAMATAN": "NUME"
      },
      {
        "kodeKECAMATAN": 9411066,
        "kodeKABUPATEN": 9411,
        "namaKECAMATAN": "NIOGA"
      },
      {
        "kodeKECAMATAN": 9411067,
        "kodeKABUPATEN": 9411,
        "namaKECAMATAN": "GUBUME"
      },
      {
        "kodeKECAMATAN": 9411068,
        "kodeKABUPATEN": 9411,
        "namaKECAMATAN": "TAGANOMBAK"
      },
      {
        "kodeKECAMATAN": 9411070,
        "kodeKABUPATEN": 9411,
        "namaKECAMATAN": "TINGGINAMBUT"
      },
      {
        "kodeKECAMATAN": 9411071,
        "kodeKABUPATEN": 9411,
        "namaKECAMATAN": "KALOME"
      },
      {
        "kodeKECAMATAN": 9411072,
        "kodeKABUPATEN": 9411,
        "namaKECAMATAN": "WANWI"
      },
      {
        "kodeKECAMATAN": 9411080,
        "kodeKABUPATEN": 9411,
        "namaKECAMATAN": "MEWOLUK"
      },
      {
        "kodeKECAMATAN": 9411081,
        "kodeKABUPATEN": 9411,
        "namaKECAMATAN": "LUMO"
      },
      {
        "kodeKECAMATAN": 9411082,
        "kodeKABUPATEN": 9411,
        "namaKECAMATAN": "MOLANIKIME"
      },
      {
        "kodeKECAMATAN": 9411090,
        "kodeKABUPATEN": 9411,
        "namaKECAMATAN": "YAMO"
      },
      {
        "kodeKECAMATAN": 9411091,
        "kodeKABUPATEN": 9411,
        "namaKECAMATAN": "DOKOME"
      },
      {
        "kodeKECAMATAN": 9412010,
        "kodeKABUPATEN": 9412,
        "namaKECAMATAN": "MIMIKA BARAT"
      },
      {
        "kodeKECAMATAN": 9412011,
        "kodeKABUPATEN": 9412,
        "namaKECAMATAN": "MIMIKA BARAT JAUH"
      },
      {
        "kodeKECAMATAN": 9412012,
        "kodeKABUPATEN": 9412,
        "namaKECAMATAN": "MIMIKA BARAT TENGAH"
      },
      {
        "kodeKECAMATAN": 9412013,
        "kodeKABUPATEN": 9412,
        "namaKECAMATAN": "AMAR"
      },
      {
        "kodeKECAMATAN": 9412020,
        "kodeKABUPATEN": 9412,
        "namaKECAMATAN": "MIMIKA TIMUR"
      },
      {
        "kodeKECAMATAN": 9412021,
        "kodeKABUPATEN": 9412,
        "namaKECAMATAN": "MIMIKA TENGAH"
      },
      {
        "kodeKECAMATAN": 9412022,
        "kodeKABUPATEN": 9412,
        "namaKECAMATAN": "MIMIKA TIMUR JAUH"
      },
      {
        "kodeKECAMATAN": 9412030,
        "kodeKABUPATEN": 9412,
        "namaKECAMATAN": "MIMIKA BARU"
      },
      {
        "kodeKECAMATAN": 9412031,
        "kodeKABUPATEN": 9412,
        "namaKECAMATAN": "KUALA KENCANA"
      },
      {
        "kodeKECAMATAN": 9412032,
        "kodeKABUPATEN": 9412,
        "namaKECAMATAN": "TEMBAGAPURA"
      },
      {
        "kodeKECAMATAN": 9412033,
        "kodeKABUPATEN": 9412,
        "namaKECAMATAN": "WANIA"
      },
      {
        "kodeKECAMATAN": 9412034,
        "kodeKABUPATEN": 9412,
        "namaKECAMATAN": "IWAKA"
      },
      {
        "kodeKECAMATAN": 9412035,
        "kodeKABUPATEN": 9412,
        "namaKECAMATAN": "KWAMKI NARAMA"
      },
      {
        "kodeKECAMATAN": 9412040,
        "kodeKABUPATEN": 9412,
        "namaKECAMATAN": "AGIMUGA"
      },
      {
        "kodeKECAMATAN": 9412041,
        "kodeKABUPATEN": 9412,
        "namaKECAMATAN": "JILA"
      },
      {
        "kodeKECAMATAN": 9412042,
        "kodeKABUPATEN": 9412,
        "namaKECAMATAN": "JITA"
      },
      {
        "kodeKECAMATAN": 9412043,
        "kodeKABUPATEN": 9412,
        "namaKECAMATAN": "ALAMA"
      },
      {
        "kodeKECAMATAN": 9412044,
        "kodeKABUPATEN": 9412,
        "namaKECAMATAN": "HOYA"
      },
      {
        "kodeKECAMATAN": 9413010,
        "kodeKABUPATEN": 9413,
        "namaKECAMATAN": "JAIR"
      },
      {
        "kodeKECAMATAN": 9413011,
        "kodeKABUPATEN": 9413,
        "namaKECAMATAN": "SUBUR"
      },
      {
        "kodeKECAMATAN": 9413013,
        "kodeKABUPATEN": 9413,
        "namaKECAMATAN": "KIA"
      },
      {
        "kodeKECAMATAN": 9413020,
        "kodeKABUPATEN": 9413,
        "namaKECAMATAN": "MINDIPTANA"
      },
      {
        "kodeKECAMATAN": 9413021,
        "kodeKABUPATEN": 9413,
        "namaKECAMATAN": "INIYANDIT"
      },
      {
        "kodeKECAMATAN": 9413022,
        "kodeKABUPATEN": 9413,
        "namaKECAMATAN": "KOMBUT"
      },
      {
        "kodeKECAMATAN": 9413023,
        "kodeKABUPATEN": 9413,
        "namaKECAMATAN": "SESNUK"
      },
      {
        "kodeKECAMATAN": 9413030,
        "kodeKABUPATEN": 9413,
        "namaKECAMATAN": "MANDOBO"
      },
      {
        "kodeKECAMATAN": 9413031,
        "kodeKABUPATEN": 9413,
        "namaKECAMATAN": "FOFI"
      },
      {
        "kodeKECAMATAN": 9413032,
        "kodeKABUPATEN": 9413,
        "namaKECAMATAN": "ARIMOP"
      },
      {
        "kodeKECAMATAN": 9413040,
        "kodeKABUPATEN": 9413,
        "namaKECAMATAN": "KOUH"
      },
      {
        "kodeKECAMATAN": 9413041,
        "kodeKABUPATEN": 9413,
        "namaKECAMATAN": "BOMAKIA"
      },
      {
        "kodeKECAMATAN": 9413042,
        "kodeKABUPATEN": 9413,
        "namaKECAMATAN": "FIRIWAGE"
      },
      {
        "kodeKECAMATAN": 9413043,
        "kodeKABUPATEN": 9413,
        "namaKECAMATAN": "MANGGELUM"
      },
      {
        "kodeKECAMATAN": 9413044,
        "kodeKABUPATEN": 9413,
        "namaKECAMATAN": "YANIRUMA"
      },
      {
        "kodeKECAMATAN": 9413045,
        "kodeKABUPATEN": 9413,
        "namaKECAMATAN": "KAWAGIT"
      },
      {
        "kodeKECAMATAN": 9413046,
        "kodeKABUPATEN": 9413,
        "namaKECAMATAN": "KOMBAY"
      },
      {
        "kodeKECAMATAN": 9413050,
        "kodeKABUPATEN": 9413,
        "namaKECAMATAN": "WAROPKO"
      },
      {
        "kodeKECAMATAN": 9413051,
        "kodeKABUPATEN": 9413,
        "namaKECAMATAN": "AMBATKWI"
      },
      {
        "kodeKECAMATAN": 9413052,
        "kodeKABUPATEN": 9413,
        "namaKECAMATAN": "NINATI"
      },
      {
        "kodeKECAMATAN": 9414010,
        "kodeKABUPATEN": 9414,
        "namaKECAMATAN": "NAMBIOMAN BAPAI"
      },
      {
        "kodeKECAMATAN": 9414011,
        "kodeKABUPATEN": 9414,
        "namaKECAMATAN": "MINYAMUR"
      },
      {
        "kodeKECAMATAN": 9414020,
        "kodeKABUPATEN": 9414,
        "namaKECAMATAN": "EDERA"
      },
      {
        "kodeKECAMATAN": 9414021,
        "kodeKABUPATEN": 9414,
        "namaKECAMATAN": "VENAHA"
      },
      {
        "kodeKECAMATAN": 9414022,
        "kodeKABUPATEN": 9414,
        "namaKECAMATAN": "SYAHCAME"
      },
      {
        "kodeKECAMATAN": 9414023,
        "kodeKABUPATEN": 9414,
        "namaKECAMATAN": "BAMGI"
      },
      {
        "kodeKECAMATAN": 9414024,
        "kodeKABUPATEN": 9414,
        "namaKECAMATAN": "YAKOMI"
      },
      {
        "kodeKECAMATAN": 9414030,
        "kodeKABUPATEN": 9414,
        "namaKECAMATAN": "OBAA"
      },
      {
        "kodeKECAMATAN": 9414031,
        "kodeKABUPATEN": 9414,
        "namaKECAMATAN": "PASSUE"
      },
      {
        "kodeKECAMATAN": 9414040,
        "kodeKABUPATEN": 9414,
        "namaKECAMATAN": "HAJU"
      },
      {
        "kodeKECAMATAN": 9414050,
        "kodeKABUPATEN": 9414,
        "namaKECAMATAN": "ASSUE"
      },
      {
        "kodeKECAMATAN": 9414060,
        "kodeKABUPATEN": 9414,
        "namaKECAMATAN": "CITAKMITAK"
      },
      {
        "kodeKECAMATAN": 9414061,
        "kodeKABUPATEN": 9414,
        "namaKECAMATAN": "KAIBAR"
      },
      {
        "kodeKECAMATAN": 9414062,
        "kodeKABUPATEN": 9414,
        "namaKECAMATAN": "PASSUE BAWAH"
      },
      {
        "kodeKECAMATAN": 9414063,
        "kodeKABUPATEN": 9414,
        "namaKECAMATAN": "TI-ZAIN"
      },
      {
        "kodeKECAMATAN": 9415010,
        "kodeKABUPATEN": 9415,
        "namaKECAMATAN": "PANTAI KASUARI"
      },
      {
        "kodeKECAMATAN": 9415011,
        "kodeKABUPATEN": 9415,
        "namaKECAMATAN": "KOPAY"
      },
      {
        "kodeKECAMATAN": 9415012,
        "kodeKABUPATEN": 9415,
        "namaKECAMATAN": "DER KOUMUR"
      },
      {
        "kodeKECAMATAN": 9415013,
        "kodeKABUPATEN": 9415,
        "namaKECAMATAN": "SAFAN"
      },
      {
        "kodeKECAMATAN": 9415020,
        "kodeKABUPATEN": 9415,
        "namaKECAMATAN": "FAYIT"
      },
      {
        "kodeKECAMATAN": 9415030,
        "kodeKABUPATEN": 9415,
        "namaKECAMATAN": "ATSY"
      },
      {
        "kodeKECAMATAN": 9415031,
        "kodeKABUPATEN": 9415,
        "namaKECAMATAN": "SIRETS"
      },
      {
        "kodeKECAMATAN": 9415032,
        "kodeKABUPATEN": 9415,
        "namaKECAMATAN": "AYIP"
      },
      {
        "kodeKECAMATAN": 9415033,
        "kodeKABUPATEN": 9415,
        "namaKECAMATAN": "BECTBAMU"
      },
      {
        "kodeKECAMATAN": 9415040,
        "kodeKABUPATEN": 9415,
        "namaKECAMATAN": "SUATOR"
      },
      {
        "kodeKECAMATAN": 9415041,
        "kodeKABUPATEN": 9415,
        "namaKECAMATAN": "KOLF BRAZA"
      },
      {
        "kodeKECAMATAN": 9415050,
        "kodeKABUPATEN": 9415,
        "namaKECAMATAN": "AKAT"
      },
      {
        "kodeKECAMATAN": 9415051,
        "kodeKABUPATEN": 9415,
        "namaKECAMATAN": "JETSY"
      },
      {
        "kodeKECAMATAN": 9415060,
        "kodeKABUPATEN": 9415,
        "namaKECAMATAN": "AGATS"
      },
      {
        "kodeKECAMATAN": 9415070,
        "kodeKABUPATEN": 9415,
        "namaKECAMATAN": "SAWA ERMA"
      },
      {
        "kodeKECAMATAN": 9415071,
        "kodeKABUPATEN": 9415,
        "namaKECAMATAN": "SURU-SURU"
      },
      {
        "kodeKECAMATAN": 9415072,
        "kodeKABUPATEN": 9415,
        "namaKECAMATAN": "UNIR SIRAU"
      },
      {
        "kodeKECAMATAN": 9415073,
        "kodeKABUPATEN": 9415,
        "namaKECAMATAN": "JOERAT"
      },
      {
        "kodeKECAMATAN": 9415074,
        "kodeKABUPATEN": 9415,
        "namaKECAMATAN": "PULAU TIGA"
      },
      {
        "kodeKECAMATAN": 9416010,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "KURIMA"
      },
      {
        "kodeKECAMATAN": 9416011,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "MUSAIK"
      },
      {
        "kodeKECAMATAN": 9416013,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "DEKAI"
      },
      {
        "kodeKECAMATAN": 9416014,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "OBIO"
      },
      {
        "kodeKECAMATAN": 9416015,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "PASEMA"
      },
      {
        "kodeKECAMATAN": 9416016,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "AMUMA"
      },
      {
        "kodeKECAMATAN": 9416017,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "SURU-SURU"
      },
      {
        "kodeKECAMATAN": 9416018,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "WUSAMA"
      },
      {
        "kodeKECAMATAN": 9416019,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "SILIMO"
      },
      {
        "kodeKECAMATAN": 9416020,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "NINIA"
      },
      {
        "kodeKECAMATAN": 9416021,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "HOLUWON"
      },
      {
        "kodeKECAMATAN": 9416022,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "LOLAT"
      },
      {
        "kodeKECAMATAN": 9416023,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "LANGDA"
      },
      {
        "kodeKECAMATAN": 9416024,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "BOMELA"
      },
      {
        "kodeKECAMATAN": 9416025,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "SUNTAMON"
      },
      {
        "kodeKECAMATAN": 9416026,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "SOBAHAM"
      },
      {
        "kodeKECAMATAN": 9416027,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "KORUPUN"
      },
      {
        "kodeKECAMATAN": 9416028,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "SELA"
      },
      {
        "kodeKECAMATAN": 9416029,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "KWELAMDUA"
      },
      {
        "kodeKECAMATAN": 9416030,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "ANGGRUK"
      },
      {
        "kodeKECAMATAN": 9416031,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "PANGGEMA"
      },
      {
        "kodeKECAMATAN": 9416032,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "WALMA"
      },
      {
        "kodeKECAMATAN": 9416033,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "KOSAREK"
      },
      {
        "kodeKECAMATAN": 9416034,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "UBAHAK"
      },
      {
        "kodeKECAMATAN": 9416035,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "NALCA"
      },
      {
        "kodeKECAMATAN": 9416036,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "PULDAMA"
      },
      {
        "kodeKECAMATAN": 9416037,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "NIPSAN"
      },
      {
        "kodeKECAMATAN": 9416041,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "SAMENAGE"
      },
      {
        "kodeKECAMATAN": 9416042,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "TANGMA"
      },
      {
        "kodeKECAMATAN": 9416043,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "SOBA"
      },
      {
        "kodeKECAMATAN": 9416044,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "MUGI"
      },
      {
        "kodeKECAMATAN": 9416045,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "YOGOSEM"
      },
      {
        "kodeKECAMATAN": 9416046,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "KAYO"
      },
      {
        "kodeKECAMATAN": 9416047,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "SUMO"
      },
      {
        "kodeKECAMATAN": 9416048,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "HOGIO"
      },
      {
        "kodeKECAMATAN": 9416049,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "UKHA"
      },
      {
        "kodeKECAMATAN": 9416051,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "WERIMA"
      },
      {
        "kodeKECAMATAN": 9416052,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "SOLOIKMA"
      },
      {
        "kodeKECAMATAN": 9416053,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "SERADALA"
      },
      {
        "kodeKECAMATAN": 9416054,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "KABIANGGAMA"
      },
      {
        "kodeKECAMATAN": 9416055,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "KWIKMA"
      },
      {
        "kodeKECAMATAN": 9416056,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "HILIPUK"
      },
      {
        "kodeKECAMATAN": 9416057,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "YAHULIAMBUT"
      },
      {
        "kodeKECAMATAN": 9416058,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "HEREAPINI"
      },
      {
        "kodeKECAMATAN": 9416059,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "UBALIHI"
      },
      {
        "kodeKECAMATAN": 9416061,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "TALAMBO"
      },
      {
        "kodeKECAMATAN": 9416062,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "PRONGGOLI"
      },
      {
        "kodeKECAMATAN": 9416063,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "ENDOMEN"
      },
      {
        "kodeKECAMATAN": 9416065,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "KONA"
      },
      {
        "kodeKECAMATAN": 9416066,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "DURAM"
      },
      {
        "kodeKECAMATAN": 9416067,
        "kodeKABUPATEN": 9416,
        "namaKECAMATAN": "DIRWEMNA"
      },
      {
        "kodeKECAMATAN": 9417010,
        "kodeKABUPATEN": 9417,
        "namaKECAMATAN": "IWUR"
      },
      {
        "kodeKECAMATAN": 9417011,
        "kodeKABUPATEN": 9417,
        "namaKECAMATAN": "KAWOR"
      },
      {
        "kodeKECAMATAN": 9417012,
        "kodeKABUPATEN": 9417,
        "namaKECAMATAN": "TARUP"
      },
      {
        "kodeKECAMATAN": 9417013,
        "kodeKABUPATEN": 9417,
        "namaKECAMATAN": "AWINBON"
      },
      {
        "kodeKECAMATAN": 9417020,
        "kodeKABUPATEN": 9417,
        "namaKECAMATAN": "OKSIBIL"
      },
      {
        "kodeKECAMATAN": 9417021,
        "kodeKABUPATEN": 9417,
        "namaKECAMATAN": "PEPERA"
      },
      {
        "kodeKECAMATAN": 9417022,
        "kodeKABUPATEN": 9417,
        "namaKECAMATAN": "ALEMSOM"
      },
      {
        "kodeKECAMATAN": 9417023,
        "kodeKABUPATEN": 9417,
        "namaKECAMATAN": "SERAMBAKON"
      },
      {
        "kodeKECAMATAN": 9417024,
        "kodeKABUPATEN": 9417,
        "namaKECAMATAN": "KOLOMDOL"
      },
      {
        "kodeKECAMATAN": 9417025,
        "kodeKABUPATEN": 9417,
        "namaKECAMATAN": "OKSOP"
      },
      {
        "kodeKECAMATAN": 9417026,
        "kodeKABUPATEN": 9417,
        "namaKECAMATAN": "OK BAPE"
      },
      {
        "kodeKECAMATAN": 9417027,
        "kodeKABUPATEN": 9417,
        "namaKECAMATAN": "OK AON"
      },
      {
        "kodeKECAMATAN": 9417030,
        "kodeKABUPATEN": 9417,
        "namaKECAMATAN": "BORME"
      },
      {
        "kodeKECAMATAN": 9417031,
        "kodeKABUPATEN": 9417,
        "namaKECAMATAN": "BIME"
      },
      {
        "kodeKECAMATAN": 9417032,
        "kodeKABUPATEN": 9417,
        "namaKECAMATAN": "EPUMEK"
      },
      {
        "kodeKECAMATAN": 9417033,
        "kodeKABUPATEN": 9417,
        "namaKECAMATAN": "WEIME"
      },
      {
        "kodeKECAMATAN": 9417034,
        "kodeKABUPATEN": 9417,
        "namaKECAMATAN": "PAMEK"
      },
      {
        "kodeKECAMATAN": 9417035,
        "kodeKABUPATEN": 9417,
        "namaKECAMATAN": "NONGME"
      },
      {
        "kodeKECAMATAN": 9417036,
        "kodeKABUPATEN": 9417,
        "namaKECAMATAN": "BATANI"
      },
      {
        "kodeKECAMATAN": 9417040,
        "kodeKABUPATEN": 9417,
        "namaKECAMATAN": "OKBI"
      },
      {
        "kodeKECAMATAN": 9417041,
        "kodeKABUPATEN": 9417,
        "namaKECAMATAN": "ABOY"
      },
      {
        "kodeKECAMATAN": 9417042,
        "kodeKABUPATEN": 9417,
        "namaKECAMATAN": "OKBAB"
      },
      {
        "kodeKECAMATAN": 9417043,
        "kodeKABUPATEN": 9417,
        "namaKECAMATAN": "TEIRAPLU"
      },
      {
        "kodeKECAMATAN": 9417044,
        "kodeKABUPATEN": 9417,
        "namaKECAMATAN": "YEFTA"
      },
      {
        "kodeKECAMATAN": 9417050,
        "kodeKABUPATEN": 9417,
        "namaKECAMATAN": "KIWIROK"
      },
      {
        "kodeKECAMATAN": 9417051,
        "kodeKABUPATEN": 9417,
        "namaKECAMATAN": "KIWIROK TIMUR"
      },
      {
        "kodeKECAMATAN": 9417052,
        "kodeKABUPATEN": 9417,
        "namaKECAMATAN": "OKSEBANG"
      },
      {
        "kodeKECAMATAN": 9417053,
        "kodeKABUPATEN": 9417,
        "namaKECAMATAN": "OKHIKA"
      },
      {
        "kodeKECAMATAN": 9417054,
        "kodeKABUPATEN": 9417,
        "namaKECAMATAN": "OKLIP"
      },
      {
        "kodeKECAMATAN": 9417055,
        "kodeKABUPATEN": 9417,
        "namaKECAMATAN": "OKSAMOL"
      },
      {
        "kodeKECAMATAN": 9417056,
        "kodeKABUPATEN": 9417,
        "namaKECAMATAN": "OKBEMTA"
      },
      {
        "kodeKECAMATAN": 9417060,
        "kodeKABUPATEN": 9417,
        "namaKECAMATAN": "BATOM"
      },
      {
        "kodeKECAMATAN": 9417061,
        "kodeKABUPATEN": 9417,
        "namaKECAMATAN": "MURKIM"
      },
      {
        "kodeKECAMATAN": 9417062,
        "kodeKABUPATEN": 9417,
        "namaKECAMATAN": "MOFINOP"
      },
      {
        "kodeKECAMATAN": 9418010,
        "kodeKABUPATEN": 9418,
        "namaKECAMATAN": "KANGGIME"
      },
      {
        "kodeKECAMATAN": 9418011,
        "kodeKABUPATEN": 9418,
        "namaKECAMATAN": "WONIKI"
      },
      {
        "kodeKECAMATAN": 9418012,
        "kodeKABUPATEN": 9418,
        "namaKECAMATAN": "NABUNAGE"
      },
      {
        "kodeKECAMATAN": 9418013,
        "kodeKABUPATEN": 9418,
        "namaKECAMATAN": "GILUBANDU"
      },
      {
        "kodeKECAMATAN": 9418014,
        "kodeKABUPATEN": 9418,
        "namaKECAMATAN": "WAKUO"
      },
      {
        "kodeKECAMATAN": 9418015,
        "kodeKABUPATEN": 9418,
        "namaKECAMATAN": "AWEKU"
      },
      {
        "kodeKECAMATAN": 9418016,
        "kodeKABUPATEN": 9418,
        "namaKECAMATAN": "BOGONUK"
      },
      {
        "kodeKECAMATAN": 9418020,
        "kodeKABUPATEN": 9418,
        "namaKECAMATAN": "KARUBAGA"
      },
      {
        "kodeKECAMATAN": 9418021,
        "kodeKABUPATEN": 9418,
        "namaKECAMATAN": "GOYAGE"
      },
      {
        "kodeKECAMATAN": 9418022,
        "kodeKABUPATEN": 9418,
        "namaKECAMATAN": "WUNIN"
      },
      {
        "kodeKECAMATAN": 9418023,
        "kodeKABUPATEN": 9418,
        "namaKECAMATAN": "KONDAGA"
      },
      {
        "kodeKECAMATAN": 9418024,
        "kodeKABUPATEN": 9418,
        "namaKECAMATAN": "NELAWI"
      },
      {
        "kodeKECAMATAN": 9418025,
        "kodeKABUPATEN": 9418,
        "namaKECAMATAN": "KUARI"
      },
      {
        "kodeKECAMATAN": 9418026,
        "kodeKABUPATEN": 9418,
        "namaKECAMATAN": "LIANOGOMA"
      },
      {
        "kodeKECAMATAN": 9418027,
        "kodeKABUPATEN": 9418,
        "namaKECAMATAN": "BIUK"
      },
      {
        "kodeKECAMATAN": 9418030,
        "kodeKABUPATEN": 9418,
        "namaKECAMATAN": "BOKONDINI"
      },
      {
        "kodeKECAMATAN": 9418031,
        "kodeKABUPATEN": 9418,
        "namaKECAMATAN": "BOKONERI"
      },
      {
        "kodeKECAMATAN": 9418032,
        "kodeKABUPATEN": 9418,
        "namaKECAMATAN": "BEWANI"
      },
      {
        "kodeKECAMATAN": 9418040,
        "kodeKABUPATEN": 9418,
        "namaKECAMATAN": "KEMBU"
      },
      {
        "kodeKECAMATAN": 9418041,
        "kodeKABUPATEN": 9418,
        "namaKECAMATAN": "WINA"
      },
      {
        "kodeKECAMATAN": 9418042,
        "kodeKABUPATEN": 9418,
        "namaKECAMATAN": "UMAGI"
      },
      {
        "kodeKECAMATAN": 9418043,
        "kodeKABUPATEN": 9418,
        "namaKECAMATAN": "PANAGA"
      },
      {
        "kodeKECAMATAN": 9418044,
        "kodeKABUPATEN": 9418,
        "namaKECAMATAN": "POGANERI"
      },
      {
        "kodeKECAMATAN": 9418045,
        "kodeKABUPATEN": 9418,
        "namaKECAMATAN": "KAMBONERI"
      },
      {
        "kodeKECAMATAN": 9418046,
        "kodeKABUPATEN": 9418,
        "namaKECAMATAN": "AIR GARAM"
      },
      {
        "kodeKECAMATAN": 9418047,
        "kodeKABUPATEN": 9418,
        "namaKECAMATAN": "DOW"
      },
      {
        "kodeKECAMATAN": 9418048,
        "kodeKABUPATEN": 9418,
        "namaKECAMATAN": "WARI / TAIYEVE"
      },
      {
        "kodeKECAMATAN": 9418049,
        "kodeKABUPATEN": 9418,
        "namaKECAMATAN": "EGIAM"
      },
      {
        "kodeKECAMATAN": 9418051,
        "kodeKABUPATEN": 9418,
        "namaKECAMATAN": "NUNGGAWI"
      },
      {
        "kodeKECAMATAN": 9418060,
        "kodeKABUPATEN": 9418,
        "namaKECAMATAN": "KUBU"
      },
      {
        "kodeKECAMATAN": 9418061,
        "kodeKABUPATEN": 9418,
        "namaKECAMATAN": "ANAWI"
      },
      {
        "kodeKECAMATAN": 9418062,
        "kodeKABUPATEN": 9418,
        "namaKECAMATAN": "WUGI"
      },
      {
        "kodeKECAMATAN": 9418070,
        "kodeKABUPATEN": 9418,
        "namaKECAMATAN": "GEYA"
      },
      {
        "kodeKECAMATAN": 9418071,
        "kodeKABUPATEN": 9418,
        "namaKECAMATAN": "WENAM"
      },
      {
        "kodeKECAMATAN": 9418080,
        "kodeKABUPATEN": 9418,
        "namaKECAMATAN": "NUMBA"
      },
      {
        "kodeKECAMATAN": 9418081,
        "kodeKABUPATEN": 9418,
        "namaKECAMATAN": "KAI"
      },
      {
        "kodeKECAMATAN": 9418090,
        "kodeKABUPATEN": 9418,
        "namaKECAMATAN": "DUNDU"
      },
      {
        "kodeKECAMATAN": 9418100,
        "kodeKABUPATEN": 9418,
        "namaKECAMATAN": "GUNDAGI"
      },
      {
        "kodeKECAMATAN": 9418110,
        "kodeKABUPATEN": 9418,
        "namaKECAMATAN": "TIMORI"
      },
      {
        "kodeKECAMATAN": 9418121,
        "kodeKABUPATEN": 9418,
        "namaKECAMATAN": "YUNERI"
      },
      {
        "kodeKECAMATAN": 9418125,
        "kodeKABUPATEN": 9418,
        "namaKECAMATAN": "TAGIME"
      },
      {
        "kodeKECAMATAN": 9418126,
        "kodeKABUPATEN": 9418,
        "namaKECAMATAN": "DANIME"
      },
      {
        "kodeKECAMATAN": 9418127,
        "kodeKABUPATEN": 9418,
        "namaKECAMATAN": "YUKO"
      },
      {
        "kodeKECAMATAN": 9418541,
        "kodeKABUPATEN": 9418,
        "namaKECAMATAN": "TELENGGEME"
      },
      {
        "kodeKECAMATAN": 9418542,
        "kodeKABUPATEN": 9418,
        "namaKECAMATAN": "GIKA"
      },
      {
        "kodeKECAMATAN": 9418543,
        "kodeKABUPATEN": 9418,
        "namaKECAMATAN": "TAGINERI"
      },
      {
        "kodeKECAMATAN": 9419021,
        "kodeKABUPATEN": 9419,
        "namaKECAMATAN": "PANTAI TIMUR BAGIAN BARAT"
      },
      {
        "kodeKECAMATAN": 9419022,
        "kodeKABUPATEN": 9419,
        "namaKECAMATAN": "PANTAI TIMUR"
      },
      {
        "kodeKECAMATAN": 9419024,
        "kodeKABUPATEN": 9419,
        "namaKECAMATAN": "SUNGAI BIRI"
      },
      {
        "kodeKECAMATAN": 9419031,
        "kodeKABUPATEN": 9419,
        "namaKECAMATAN": "BONGGO"
      },
      {
        "kodeKECAMATAN": 9419032,
        "kodeKABUPATEN": 9419,
        "namaKECAMATAN": "BONGGO TIMUR"
      },
      {
        "kodeKECAMATAN": 9419033,
        "kodeKABUPATEN": 9419,
        "namaKECAMATAN": "BONGGO BARAT"
      },
      {
        "kodeKECAMATAN": 9419040,
        "kodeKABUPATEN": 9419,
        "namaKECAMATAN": "TOR ATAS"
      },
      {
        "kodeKECAMATAN": 9419041,
        "kodeKABUPATEN": 9419,
        "namaKECAMATAN": "ISMARI"
      },
      {
        "kodeKECAMATAN": 9419050,
        "kodeKABUPATEN": 9419,
        "namaKECAMATAN": "SARMI"
      },
      {
        "kodeKECAMATAN": 9419051,
        "kodeKABUPATEN": 9419,
        "namaKECAMATAN": "SARMI TIMUR"
      },
      {
        "kodeKECAMATAN": 9419052,
        "kodeKABUPATEN": 9419,
        "namaKECAMATAN": "SARMI SELATAN"
      },
      {
        "kodeKECAMATAN": 9419053,
        "kodeKABUPATEN": 9419,
        "namaKECAMATAN": "SOBEY"
      },
      {
        "kodeKECAMATAN": 9419054,
        "kodeKABUPATEN": 9419,
        "namaKECAMATAN": "MUARA TOR"
      },
      {
        "kodeKECAMATAN": 9419055,
        "kodeKABUPATEN": 9419,
        "namaKECAMATAN": "VERKAM"
      },
      {
        "kodeKECAMATAN": 9419060,
        "kodeKABUPATEN": 9419,
        "namaKECAMATAN": "PANTAI BARAT"
      },
      {
        "kodeKECAMATAN": 9419061,
        "kodeKABUPATEN": 9419,
        "namaKECAMATAN": "APAWER HULU"
      },
      {
        "kodeKECAMATAN": 9419062,
        "kodeKABUPATEN": 9419,
        "namaKECAMATAN": "APAWER HILIR"
      },
      {
        "kodeKECAMATAN": 9419063,
        "kodeKABUPATEN": 9419,
        "namaKECAMATAN": "APAWER TENGAH"
      },
      {
        "kodeKECAMATAN": 9420010,
        "kodeKABUPATEN": 9420,
        "namaKECAMATAN": "WEB"
      },
      {
        "kodeKECAMATAN": 9420011,
        "kodeKABUPATEN": 9420,
        "namaKECAMATAN": "TOWE"
      },
      {
        "kodeKECAMATAN": 9420020,
        "kodeKABUPATEN": 9420,
        "namaKECAMATAN": "SENGGI"
      },
      {
        "kodeKECAMATAN": 9420030,
        "kodeKABUPATEN": 9420,
        "namaKECAMATAN": "WARIS"
      },
      {
        "kodeKECAMATAN": 9420040,
        "kodeKABUPATEN": 9420,
        "namaKECAMATAN": "ARSO"
      },
      {
        "kodeKECAMATAN": 9420041,
        "kodeKABUPATEN": 9420,
        "namaKECAMATAN": "ARSO TIMUR"
      },
      {
        "kodeKECAMATAN": 9420050,
        "kodeKABUPATEN": 9420,
        "namaKECAMATAN": "SKANTO"
      },
      {
        "kodeKECAMATAN": 9426010,
        "kodeKABUPATEN": 9426,
        "namaKECAMATAN": "WAROPEN BAWAH"
      },
      {
        "kodeKECAMATAN": 9426011,
        "kodeKABUPATEN": 9426,
        "namaKECAMATAN": "INGGERUS"
      },
      {
        "kodeKECAMATAN": 9426012,
        "kodeKABUPATEN": 9426,
        "namaKECAMATAN": "UREI FAISEI"
      },
      {
        "kodeKECAMATAN": 9426013,
        "kodeKABUPATEN": 9426,
        "namaKECAMATAN": "OUDATE"
      },
      {
        "kodeKECAMATAN": 9426014,
        "kodeKABUPATEN": 9426,
        "namaKECAMATAN": "WAPOGA"
      },
      {
        "kodeKECAMATAN": 9426020,
        "kodeKABUPATEN": 9426,
        "namaKECAMATAN": "MASIREI"
      },
      {
        "kodeKECAMATAN": 9426021,
        "kodeKABUPATEN": 9426,
        "namaKECAMATAN": "RISEI SAYATI"
      },
      {
        "kodeKECAMATAN": 9426022,
        "kodeKABUPATEN": 9426,
        "namaKECAMATAN": "DEMBA"
      },
      {
        "kodeKECAMATAN": 9426030,
        "kodeKABUPATEN": 9426,
        "namaKECAMATAN": "WALANI"
      },
      {
        "kodeKECAMATAN": 9426040,
        "kodeKABUPATEN": 9426,
        "namaKECAMATAN": "KIRIHI"
      },
      {
        "kodeKECAMATAN": 9427010,
        "kodeKABUPATEN": 9427,
        "namaKECAMATAN": "SUPIORI SELATAN"
      },
      {
        "kodeKECAMATAN": 9427011,
        "kodeKABUPATEN": 9427,
        "namaKECAMATAN": "KEPULAUAN ARURI"
      },
      {
        "kodeKECAMATAN": 9427020,
        "kodeKABUPATEN": 9427,
        "namaKECAMATAN": "SUPIORI UTARA"
      },
      {
        "kodeKECAMATAN": 9427021,
        "kodeKABUPATEN": 9427,
        "namaKECAMATAN": "SUPIORI BARAT"
      },
      {
        "kodeKECAMATAN": 9427030,
        "kodeKABUPATEN": 9427,
        "namaKECAMATAN": "SUPIORI TIMUR"
      },
      {
        "kodeKECAMATAN": 9428030,
        "kodeKABUPATEN": 9428,
        "namaKECAMATAN": "WAROPEN ATAS"
      },
      {
        "kodeKECAMATAN": 9428031,
        "kodeKABUPATEN": 9428,
        "namaKECAMATAN": "BENUKI"
      },
      {
        "kodeKECAMATAN": 9428032,
        "kodeKABUPATEN": 9428,
        "namaKECAMATAN": "SAWAI"
      },
      {
        "kodeKECAMATAN": 9428040,
        "kodeKABUPATEN": 9428,
        "namaKECAMATAN": "MAMBERAMO ILIR"
      },
      {
        "kodeKECAMATAN": 9428050,
        "kodeKABUPATEN": 9428,
        "namaKECAMATAN": "MAMBERAMO TENGAH"
      },
      {
        "kodeKECAMATAN": 9428051,
        "kodeKABUPATEN": 9428,
        "namaKECAMATAN": "IWASO"
      },
      {
        "kodeKECAMATAN": 9428060,
        "kodeKABUPATEN": 9428,
        "namaKECAMATAN": "MAMBERAMO TENGAH TIMUR"
      },
      {
        "kodeKECAMATAN": 9428070,
        "kodeKABUPATEN": 9428,
        "namaKECAMATAN": "ROFAER"
      },
      {
        "kodeKECAMATAN": 9428080,
        "kodeKABUPATEN": 9428,
        "namaKECAMATAN": "MAMBERAMO ULU"
      },
      {
        "kodeKECAMATAN": 9429010,
        "kodeKABUPATEN": 9429,
        "namaKECAMATAN": "WOSAK"
      },
      {
        "kodeKECAMATAN": 9429020,
        "kodeKABUPATEN": 9429,
        "namaKECAMATAN": "KENYAM"
      },
      {
        "kodeKECAMATAN": 9429030,
        "kodeKABUPATEN": 9429,
        "namaKECAMATAN": "GESELMA"
      },
      {
        "kodeKECAMATAN": 9429040,
        "kodeKABUPATEN": 9429,
        "namaKECAMATAN": "MAPENDUMA"
      },
      {
        "kodeKECAMATAN": 9429050,
        "kodeKABUPATEN": 9429,
        "namaKECAMATAN": "MUGI"
      },
      {
        "kodeKECAMATAN": 9429060,
        "kodeKABUPATEN": 9429,
        "namaKECAMATAN": "YIGI"
      },
      {
        "kodeKECAMATAN": 9429070,
        "kodeKABUPATEN": 9429,
        "namaKECAMATAN": "MBUWA"
      },
      {
        "kodeKECAMATAN": 9429080,
        "kodeKABUPATEN": 9429,
        "namaKECAMATAN": "GEAREK"
      },
      {
        "kodeKECAMATAN": 9430010,
        "kodeKABUPATEN": 9430,
        "namaKECAMATAN": "MAKKI"
      },
      {
        "kodeKECAMATAN": 9430011,
        "kodeKABUPATEN": 9430,
        "namaKECAMATAN": "GUPURA"
      },
      {
        "kodeKECAMATAN": 9430012,
        "kodeKABUPATEN": 9430,
        "namaKECAMATAN": "KOLAWA"
      },
      {
        "kodeKECAMATAN": 9430013,
        "kodeKABUPATEN": 9430,
        "namaKECAMATAN": "GELOK BEAM"
      },
      {
        "kodeKECAMATAN": 9430020,
        "kodeKABUPATEN": 9430,
        "namaKECAMATAN": "PIRIME"
      },
      {
        "kodeKECAMATAN": 9430021,
        "kodeKABUPATEN": 9430,
        "namaKECAMATAN": "BUGUK GONA"
      },
      {
        "kodeKECAMATAN": 9430022,
        "kodeKABUPATEN": 9430,
        "namaKECAMATAN": "MILIMBO"
      },
      {
        "kodeKECAMATAN": 9430023,
        "kodeKABUPATEN": 9430,
        "namaKECAMATAN": "GOLLO"
      },
      {
        "kodeKECAMATAN": 9430024,
        "kodeKABUPATEN": 9430,
        "namaKECAMATAN": "WIRINGGABUT"
      },
      {
        "kodeKECAMATAN": 9430030,
        "kodeKABUPATEN": 9430,
        "namaKECAMATAN": "TIOM"
      },
      {
        "kodeKECAMATAN": 9430031,
        "kodeKABUPATEN": 9430,
        "namaKECAMATAN": "NOGI"
      },
      {
        "kodeKECAMATAN": 9430032,
        "kodeKABUPATEN": 9430,
        "namaKECAMATAN": "MOKONI"
      },
      {
        "kodeKECAMATAN": 9430033,
        "kodeKABUPATEN": 9430,
        "namaKECAMATAN": "NINAME"
      },
      {
        "kodeKECAMATAN": 9430034,
        "kodeKABUPATEN": 9430,
        "namaKECAMATAN": "YIGINUA"
      },
      {
        "kodeKECAMATAN": 9430040,
        "kodeKABUPATEN": 9430,
        "namaKECAMATAN": "BALINGGA"
      },
      {
        "kodeKECAMATAN": 9430041,
        "kodeKABUPATEN": 9430,
        "namaKECAMATAN": "BALINGGA BARAT"
      },
      {
        "kodeKECAMATAN": 9430042,
        "kodeKABUPATEN": 9430,
        "namaKECAMATAN": "BRUWA"
      },
      {
        "kodeKECAMATAN": 9430050,
        "kodeKABUPATEN": 9430,
        "namaKECAMATAN": "KUYAWAGE"
      },
      {
        "kodeKECAMATAN": 9430051,
        "kodeKABUPATEN": 9430,
        "namaKECAMATAN": "WANO BARAT"
      },
      {
        "kodeKECAMATAN": 9430060,
        "kodeKABUPATEN": 9430,
        "namaKECAMATAN": "MALAGAINERI"
      },
      {
        "kodeKECAMATAN": 9430061,
        "kodeKABUPATEN": 9430,
        "namaKECAMATAN": "MELAGAI"
      },
      {
        "kodeKECAMATAN": 9430070,
        "kodeKABUPATEN": 9430,
        "namaKECAMATAN": "TIOMNERI"
      },
      {
        "kodeKECAMATAN": 9430071,
        "kodeKABUPATEN": 9430,
        "namaKECAMATAN": "WEREKA"
      },
      {
        "kodeKECAMATAN": 9430080,
        "kodeKABUPATEN": 9430,
        "namaKECAMATAN": "DIMBA"
      },
      {
        "kodeKECAMATAN": 9430081,
        "kodeKABUPATEN": 9430,
        "namaKECAMATAN": "KELULOME"
      },
      {
        "kodeKECAMATAN": 9430090,
        "kodeKABUPATEN": 9430,
        "namaKECAMATAN": "GAMELIA"
      },
      {
        "kodeKECAMATAN": 9430091,
        "kodeKABUPATEN": 9430,
        "namaKECAMATAN": "KARU"
      },
      {
        "kodeKECAMATAN": 9430092,
        "kodeKABUPATEN": 9430,
        "namaKECAMATAN": "YILUK"
      },
      {
        "kodeKECAMATAN": 9430093,
        "kodeKABUPATEN": 9430,
        "namaKECAMATAN": "GUNA"
      },
      {
        "kodeKECAMATAN": 9430100,
        "kodeKABUPATEN": 9430,
        "namaKECAMATAN": "POGA"
      },
      {
        "kodeKECAMATAN": 9430101,
        "kodeKABUPATEN": 9430,
        "namaKECAMATAN": "MUARA"
      },
      {
        "kodeKECAMATAN": 9431010,
        "kodeKABUPATEN": 9431,
        "namaKECAMATAN": "KOBAKMA"
      },
      {
        "kodeKECAMATAN": 9431020,
        "kodeKABUPATEN": 9431,
        "namaKECAMATAN": "ILUGWA"
      },
      {
        "kodeKECAMATAN": 9431030,
        "kodeKABUPATEN": 9431,
        "namaKECAMATAN": "KELILA"
      },
      {
        "kodeKECAMATAN": 9431040,
        "kodeKABUPATEN": 9431,
        "namaKECAMATAN": "ERAGAYAM"
      },
      {
        "kodeKECAMATAN": 9431050,
        "kodeKABUPATEN": 9431,
        "namaKECAMATAN": "MEGAMBILIS"
      },
      {
        "kodeKECAMATAN": 9432010,
        "kodeKABUPATEN": 9432,
        "namaKECAMATAN": "WELAREK"
      },
      {
        "kodeKECAMATAN": 9432020,
        "kodeKABUPATEN": 9432,
        "namaKECAMATAN": "APALAPSILI"
      },
      {
        "kodeKECAMATAN": 9432030,
        "kodeKABUPATEN": 9432,
        "namaKECAMATAN": "ABENAHO"
      },
      {
        "kodeKECAMATAN": 9432040,
        "kodeKABUPATEN": 9432,
        "namaKECAMATAN": "ELELIM"
      },
      {
        "kodeKECAMATAN": 9432050,
        "kodeKABUPATEN": 9432,
        "namaKECAMATAN": "BENAWA"
      },
      {
        "kodeKECAMATAN": 9433010,
        "kodeKABUPATEN": 9433,
        "namaKECAMATAN": "AGADUGUME"
      },
      {
        "kodeKECAMATAN": 9433020,
        "kodeKABUPATEN": 9433,
        "namaKECAMATAN": "GOME"
      },
      {
        "kodeKECAMATAN": 9433030,
        "kodeKABUPATEN": 9433,
        "namaKECAMATAN": "ILAGA"
      },
      {
        "kodeKECAMATAN": 9433040,
        "kodeKABUPATEN": 9433,
        "namaKECAMATAN": "SINAK"
      },
      {
        "kodeKECAMATAN": 9433050,
        "kodeKABUPATEN": 9433,
        "namaKECAMATAN": "POGOMA"
      },
      {
        "kodeKECAMATAN": 9433060,
        "kodeKABUPATEN": 9433,
        "namaKECAMATAN": "WANGBE"
      },
      {
        "kodeKECAMATAN": 9433070,
        "kodeKABUPATEN": 9433,
        "namaKECAMATAN": "BEOGA"
      },
      {
        "kodeKECAMATAN": 9433080,
        "kodeKABUPATEN": 9433,
        "namaKECAMATAN": "DOUFO"
      },
      {
        "kodeKECAMATAN": 9434010,
        "kodeKABUPATEN": 9434,
        "namaKECAMATAN": "SUKIKAI SELATAN"
      },
      {
        "kodeKECAMATAN": 9434020,
        "kodeKABUPATEN": 9434,
        "namaKECAMATAN": "PIYAIYE"
      },
      {
        "kodeKECAMATAN": 9434030,
        "kodeKABUPATEN": 9434,
        "namaKECAMATAN": "MAPIA BARAT"
      },
      {
        "kodeKECAMATAN": 9434040,
        "kodeKABUPATEN": 9434,
        "namaKECAMATAN": "MAPIA TENGAH"
      },
      {
        "kodeKECAMATAN": 9434050,
        "kodeKABUPATEN": 9434,
        "namaKECAMATAN": "MAPIA"
      },
      {
        "kodeKECAMATAN": 9434060,
        "kodeKABUPATEN": 9434,
        "namaKECAMATAN": "DOGIYAI"
      },
      {
        "kodeKECAMATAN": 9434070,
        "kodeKABUPATEN": 9434,
        "namaKECAMATAN": "KAMU SELATAN"
      },
      {
        "kodeKECAMATAN": 9434080,
        "kodeKABUPATEN": 9434,
        "namaKECAMATAN": "KAMU"
      },
      {
        "kodeKECAMATAN": 9434090,
        "kodeKABUPATEN": 9434,
        "namaKECAMATAN": "KAMU TIMUR"
      },
      {
        "kodeKECAMATAN": 9434100,
        "kodeKABUPATEN": 9434,
        "namaKECAMATAN": "KAMU UTARA"
      },
      {
        "kodeKECAMATAN": 9435010,
        "kodeKABUPATEN": 9435,
        "namaKECAMATAN": "HOMEYO"
      },
      {
        "kodeKECAMATAN": 9435020,
        "kodeKABUPATEN": 9435,
        "namaKECAMATAN": "SUGAPA"
      },
      {
        "kodeKECAMATAN": 9435030,
        "kodeKABUPATEN": 9435,
        "namaKECAMATAN": "HITADIPA"
      },
      {
        "kodeKECAMATAN": 9435040,
        "kodeKABUPATEN": 9435,
        "namaKECAMATAN": "AGISIGA"
      },
      {
        "kodeKECAMATAN": 9435050,
        "kodeKABUPATEN": 9435,
        "namaKECAMATAN": "BIANDOGA"
      },
      {
        "kodeKECAMATAN": 9435060,
        "kodeKABUPATEN": 9435,
        "namaKECAMATAN": "WANDAI"
      },
      {
        "kodeKECAMATAN": 9436010,
        "kodeKABUPATEN": 9436,
        "namaKECAMATAN": "KAPIRAYA"
      },
      {
        "kodeKECAMATAN": 9436020,
        "kodeKABUPATEN": 9436,
        "namaKECAMATAN": "TIGI BARAT"
      },
      {
        "kodeKECAMATAN": 9436030,
        "kodeKABUPATEN": 9436,
        "namaKECAMATAN": "TIGI"
      },
      {
        "kodeKECAMATAN": 9436040,
        "kodeKABUPATEN": 9436,
        "namaKECAMATAN": "TIGI TIMUR"
      },
      {
        "kodeKECAMATAN": 9436050,
        "kodeKABUPATEN": 9436,
        "namaKECAMATAN": "BOWOBADO"
      },
      {
        "kodeKECAMATAN": 9471010,
        "kodeKABUPATEN": 9471,
        "namaKECAMATAN": "MUARA TAMI"
      },
      {
        "kodeKECAMATAN": 9471020,
        "kodeKABUPATEN": 9471,
        "namaKECAMATAN": "ABEPURA"
      },
      {
        "kodeKECAMATAN": 9471021,
        "kodeKABUPATEN": 9471,
        "namaKECAMATAN": "HERAM"
      },
      {
        "kodeKECAMATAN": 9471030,
        "kodeKABUPATEN": 9471,
        "namaKECAMATAN": "JAYAPURA SELATAN"
      },
      {
        "kodeKECAMATAN": 9471040,
        "kodeKABUPATEN": 9471,
        "namaKECAMATAN": "JAYAPURA UTARA"
      }
    ].forEach(function (dataKECAMATAN) {
      KECAMATAN.insert(dataKECAMATAN);
    })
  }
});
