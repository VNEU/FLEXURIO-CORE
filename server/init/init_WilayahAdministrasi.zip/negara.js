Meteor.startup(function(){
  if(NEGARA.find().count() == 0) {
    [
      {
        "kodeNEGARA": "ID",
        "namaNEGARA": "INDONESIA"
      }
    ].forEach(function (dataNEGARA) {
      NEGARA.insert(dataNEGARA);
    })
  }
});
