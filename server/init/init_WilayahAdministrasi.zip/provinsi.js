Meteor.startup(function(){
  if(PROVINSI.find().count() == 0) {
    [
      {
        "kodePROVINSI": 11,
        "namaPROVINSI": "ACEH",
        "kodeNEGARA": "ID",
        "namaNEGARA": "INDONESIA"
      },
      {
        "kodePROVINSI": 12,
        "namaPROVINSI": "SUMATERA UTARA",
        "kodeNEGARA": "ID",
        "namaNEGARA": "INDONESIA"
      },
      {
        "kodePROVINSI": 13,
        "namaPROVINSI": "SUMATERA BARAT",
        "kodeNEGARA": "ID",
        "namaNEGARA": "INDONESIA"
      },
      {
        "kodePROVINSI": 14,
        "namaPROVINSI": "RIAU",
        "kodeNEGARA": "ID",
        "namaNEGARA": "INDONESIA"
      },
      {
        "kodePROVINSI": 15,
        "namaPROVINSI": "JAMBI",
        "kodeNEGARA": "ID",
        "namaNEGARA": "INDONESIA"
      },
      {
        "kodePROVINSI": 16,
        "namaPROVINSI": "SUMATERA SELATAN",
        "kodeNEGARA": "ID",
        "namaNEGARA": "INDONESIA"
      },
      {
        "kodePROVINSI": 17,
        "namaPROVINSI": "BENGKULU",
        "kodeNEGARA": "ID",
        "namaNEGARA": "INDONESIA"
      },
      {
        "kodePROVINSI": 18,
        "namaPROVINSI": "LAMPUNG",
        "kodeNEGARA": "ID",
        "namaNEGARA": "INDONESIA"
      },
      {
        "kodePROVINSI": 19,
        "namaPROVINSI": "KEPULAUAN BANGKA BELITUNG",
        "kodeNEGARA": "ID",
        "namaNEGARA": "INDONESIA"
      },
      {
        "kodePROVINSI": 21,
        "namaPROVINSI": "KEPULAUAN RIAU",
        "kodeNEGARA": "ID",
        "namaNEGARA": "INDONESIA"
      },
      {
        "kodePROVINSI": 31,
        "namaPROVINSI": "DKI JAKARTA",
        "kodeNEGARA": "ID",
        "namaNEGARA": "INDONESIA"
      },
      {
        "kodePROVINSI": 32,
        "namaPROVINSI": "JAWA BARAT",
        "kodeNEGARA": "ID",
        "namaNEGARA": "INDONESIA"
      },
      {
        "kodePROVINSI": 33,
        "namaPROVINSI": "JAWA TENGAH",
        "kodeNEGARA": "ID",
        "namaNEGARA": "INDONESIA"
      },
      {
        "kodePROVINSI": 34,
        "namaPROVINSI": "DI YOGYAKARTA",
        "kodeNEGARA": "ID",
        "namaNEGARA": "INDONESIA"
      },
      {
        "kodePROVINSI": 35,
        "namaPROVINSI": "JAWA TIMUR",
        "kodeNEGARA": "ID",
        "namaNEGARA": "INDONESIA"
      },
      {
        "kodePROVINSI": 36,
        "namaPROVINSI": "BANTEN",
        "kodeNEGARA": "ID",
        "namaNEGARA": "INDONESIA"
      },
      {
        "kodePROVINSI": 51,
        "namaPROVINSI": "BALI",
        "kodeNEGARA": "ID",
        "namaNEGARA": "INDONESIA"
      },
      {
        "kodePROVINSI": 52,
        "namaPROVINSI": "NUSA TENGGARA BARAT",
        "kodeNEGARA": "ID",
        "namaNEGARA": "INDONESIA"
      },
      {
        "kodePROVINSI": 53,
        "namaPROVINSI": "NUSA TENGGARA TIMUR",
        "kodeNEGARA": "ID",
        "namaNEGARA": "INDONESIA"
      },
      {
        "kodePROVINSI": 61,
        "namaPROVINSI": "KALIMANTAN BARAT",
        "kodeNEGARA": "ID",
        "namaNEGARA": "INDONESIA"
      },
      {
        "kodePROVINSI": 62,
        "namaPROVINSI": "KALIMANTAN TENGAH",
        "kodeNEGARA": "ID",
        "namaNEGARA": "INDONESIA"
      },
      {
        "kodePROVINSI": 63,
        "namaPROVINSI": "KALIMANTAN SELATAN",
        "kodeNEGARA": "ID",
        "namaNEGARA": "INDONESIA"
      },
      {
        "kodePROVINSI": 64,
        "namaPROVINSI": "KALIMANTAN TIMUR",
        "kodeNEGARA": "ID",
        "namaNEGARA": "INDONESIA"
      },
      {
        "kodePROVINSI": 65,
        "namaPROVINSI": "KALIMANTAN UTARA",
        "kodeNEGARA": "ID",
        "namaNEGARA": "INDONESIA"
      },
      {
        "kodePROVINSI": 71,
        "namaPROVINSI": "SULAWESI UTARA",
        "kodeNEGARA": "ID",
        "namaNEGARA": "INDONESIA"
      },
      {
        "kodePROVINSI": 72,
        "namaPROVINSI": "SULAWESI TENGAH",
        "kodeNEGARA": "ID",
        "namaNEGARA": "INDONESIA"
      },
      {
        "kodePROVINSI": 73,
        "namaPROVINSI": "SULAWESI SELATAN",
        "kodeNEGARA": "ID",
        "namaNEGARA": "INDONESIA"
      },
      {
        "kodePROVINSI": 74,
        "namaPROVINSI": "SULAWESI TENGGARA",
        "kodeNEGARA": "ID",
        "namaNEGARA": "INDONESIA"
      },
      {
        "kodePROVINSI": 75,
        "namaPROVINSI": "GORONTALO",
        "kodeNEGARA": "ID",
        "namaNEGARA": "INDONESIA"
      },
      {
        "kodePROVINSI": 76,
        "namaPROVINSI": "SULAWESI BARAT",
        "kodeNEGARA": "ID",
        "namaNEGARA": "INDONESIA"
      },
      {
        "kodePROVINSI": 81,
        "namaPROVINSI": "MALUKU",
        "kodeNEGARA": "ID",
        "namaNEGARA": "INDONESIA"
      },
      {
        "kodePROVINSI": 82,
        "namaPROVINSI": "MALUKU UTARA",
        "kodeNEGARA": "ID",
        "namaNEGARA": "INDONESIA"
      },
      {
        "kodePROVINSI": 91,
        "namaPROVINSI": "PAPUA BARAT",
        "kodeNEGARA": "ID",
        "namaNEGARA": "INDONESIA"
      },
      {
        "kodePROVINSI": 94,
        "namaPROVINSI": "PAPUA",
        "kodeNEGARA": "ID",
        "namaNEGARA": "INDONESIA"
      }
    ].forEach(function (dataPROVINSI) {
      PROVINSI.insert(dataPROVINSI);
    })
  }
});
