Meteor.startup(function(){
  if(KABUPATEN.find().count() == 0) {
    [
    {
      "kodeKABUPATEN": 1101,
      "kodePROVINSI": 11,
      "namaKABUPATEN": "KABUPATEN SIMEULUE"
    },
    {
      "kodeKABUPATEN": 1102,
      "kodePROVINSI": 11,
      "namaKABUPATEN": "KABUPATEN ACEH SINGKIL"
    },
    {
      "kodeKABUPATEN": 1103,
      "kodePROVINSI": 11,
      "namaKABUPATEN": "KABUPATEN ACEH SELATAN"
    },
    {
      "kodeKABUPATEN": 1104,
      "kodePROVINSI": 11,
      "namaKABUPATEN": "KABUPATEN ACEH TENGGARA"
    },
    {
      "kodeKABUPATEN": 1105,
      "kodePROVINSI": 11,
      "namaKABUPATEN": "KABUPATEN ACEH TIMUR"
    },
    {
      "kodeKABUPATEN": 1106,
      "kodePROVINSI": 11,
      "namaKABUPATEN": "KABUPATEN ACEH TENGAH"
    },
    {
      "kodeKABUPATEN": 1107,
      "kodePROVINSI": 11,
      "namaKABUPATEN": "KABUPATEN ACEH BARAT"
    },
    {
      "kodeKABUPATEN": 1108,
      "kodePROVINSI": 11,
      "namaKABUPATEN": "KABUPATEN ACEH BESAR"
    },
    {
      "kodeKABUPATEN": 1109,
      "kodePROVINSI": 11,
      "namaKABUPATEN": "KABUPATEN PIDIE"
    },
    {
      "kodeKABUPATEN": 1110,
      "kodePROVINSI": 11,
      "namaKABUPATEN": "KABUPATEN BIREUEN"
    },
    {
      "kodeKABUPATEN": 1111,
      "kodePROVINSI": 11,
      "namaKABUPATEN": "KABUPATEN ACEH UTARA"
    },
    {
      "kodeKABUPATEN": 1112,
      "kodePROVINSI": 11,
      "namaKABUPATEN": "KABUPATEN ACEH BARAT DAYA"
    },
    {
      "kodeKABUPATEN": 1113,
      "kodePROVINSI": 11,
      "namaKABUPATEN": "KABUPATEN GAYO LUES"
    },
    {
      "kodeKABUPATEN": 1114,
      "kodePROVINSI": 11,
      "namaKABUPATEN": "KABUPATEN ACEH TAMIANG"
    },
    {
      "kodeKABUPATEN": 1115,
      "kodePROVINSI": 11,
      "namaKABUPATEN": "KABUPATEN NAGAN RAYA"
    },
    {
      "kodeKABUPATEN": 1116,
      "kodePROVINSI": 11,
      "namaKABUPATEN": "KABUPATEN ACEH JAYA"
    },
    {
      "kodeKABUPATEN": 1117,
      "kodePROVINSI": 11,
      "namaKABUPATEN": "KABUPATEN BENER MERIAH"
    },
    {
      "kodeKABUPATEN": 1118,
      "kodePROVINSI": 11,
      "namaKABUPATEN": "KABUPATEN PIDIE JAYA"
    },
    {
      "kodeKABUPATEN": 1171,
      "kodePROVINSI": 11,
      "namaKABUPATEN": "KOTA BANDA ACEH"
    },
    {
      "kodeKABUPATEN": 1172,
      "kodePROVINSI": 11,
      "namaKABUPATEN": "KOTA SABANG"
    },
    {
      "kodeKABUPATEN": 1173,
      "kodePROVINSI": 11,
      "namaKABUPATEN": "KOTA LANGSA"
    },
    {
      "kodeKABUPATEN": 1174,
      "kodePROVINSI": 11,
      "namaKABUPATEN": "KOTA LHOKSEUMAWE"
    },
    {
      "kodeKABUPATEN": 1175,
      "kodePROVINSI": 11,
      "namaKABUPATEN": "KOTA SUBULUSSALAM"
    },
    {
      "kodeKABUPATEN": 1201,
      "kodePROVINSI": 12,
      "namaKABUPATEN": "KABUPATEN NIAS"
    },
    {
      "kodeKABUPATEN": 1202,
      "kodePROVINSI": 12,
      "namaKABUPATEN": "KABUPATEN MANDAILING NATAL"
    },
    {
      "kodeKABUPATEN": 1203,
      "kodePROVINSI": 12,
      "namaKABUPATEN": "KABUPATEN TAPANULI SELATAN"
    },
    {
      "kodeKABUPATEN": 1204,
      "kodePROVINSI": 12,
      "namaKABUPATEN": "KABUPATEN TAPANULI TENGAH"
    },
    {
      "kodeKABUPATEN": 1205,
      "kodePROVINSI": 12,
      "namaKABUPATEN": "KABUPATEN TAPANULI UTARA"
    },
    {
      "kodeKABUPATEN": 1206,
      "kodePROVINSI": 12,
      "namaKABUPATEN": "KABUPATEN TOBA SAMOSIR"
    },
    {
      "kodeKABUPATEN": 1207,
      "kodePROVINSI": 12,
      "namaKABUPATEN": "KABUPATEN LABUHAN BATU"
    },
    {
      "kodeKABUPATEN": 1208,
      "kodePROVINSI": 12,
      "namaKABUPATEN": "KABUPATEN ASAHAN"
    },
    {
      "kodeKABUPATEN": 1209,
      "kodePROVINSI": 12,
      "namaKABUPATEN": "KABUPATEN SIMALUNGUN"
    },
    {
      "kodeKABUPATEN": 1210,
      "kodePROVINSI": 12,
      "namaKABUPATEN": "KABUPATEN DAIRI"
    },
    {
      "kodeKABUPATEN": 1211,
      "kodePROVINSI": 12,
      "namaKABUPATEN": "KABUPATEN KARO"
    },
    {
      "kodeKABUPATEN": 1212,
      "kodePROVINSI": 12,
      "namaKABUPATEN": "KABUPATEN DELI SERDANG"
    },
    {
      "kodeKABUPATEN": 1213,
      "kodePROVINSI": 12,
      "namaKABUPATEN": "KABUPATEN LANGKAT"
    },
    {
      "kodeKABUPATEN": 1214,
      "kodePROVINSI": 12,
      "namaKABUPATEN": "KABUPATEN NIAS SELATAN"
    },
    {
      "kodeKABUPATEN": 1215,
      "kodePROVINSI": 12,
      "namaKABUPATEN": "KABUPATEN HUMBANG HASUNDUTAN"
    },
    {
      "kodeKABUPATEN": 1216,
      "kodePROVINSI": 12,
      "namaKABUPATEN": "KABUPATEN PAKPAK BHARAT"
    },
    {
      "kodeKABUPATEN": 1217,
      "kodePROVINSI": 12,
      "namaKABUPATEN": "KABUPATEN SAMOSIR"
    },
    {
      "kodeKABUPATEN": 1218,
      "kodePROVINSI": 12,
      "namaKABUPATEN": "KABUPATEN SERDANG BEDAGAI"
    },
    {
      "kodeKABUPATEN": 1219,
      "kodePROVINSI": 12,
      "namaKABUPATEN": "KABUPATEN BATU BARA"
    },
    {
      "kodeKABUPATEN": 1220,
      "kodePROVINSI": 12,
      "namaKABUPATEN": "KABUPATEN PADANG LAWAS UTARA"
    },
    {
      "kodeKABUPATEN": 1221,
      "kodePROVINSI": 12,
      "namaKABUPATEN": "KABUPATEN PADANG LAWAS"
    },
    {
      "kodeKABUPATEN": 1222,
      "kodePROVINSI": 12,
      "namaKABUPATEN": "KABUPATEN LABUHAN BATU SELATAN"
    },
    {
      "kodeKABUPATEN": 1223,
      "kodePROVINSI": 12,
      "namaKABUPATEN": "KABUPATEN LABUHAN BATU UTARA"
    },
    {
      "kodeKABUPATEN": 1224,
      "kodePROVINSI": 12,
      "namaKABUPATEN": "KABUPATEN NIAS UTARA"
    },
    {
      "kodeKABUPATEN": 1225,
      "kodePROVINSI": 12,
      "namaKABUPATEN": "KABUPATEN NIAS BARAT"
    },
    {
      "kodeKABUPATEN": 1271,
      "kodePROVINSI": 12,
      "namaKABUPATEN": "KOTA SIBOLGA"
    },
    {
      "kodeKABUPATEN": 1272,
      "kodePROVINSI": 12,
      "namaKABUPATEN": "KOTA TANJUNG BALAI"
    },
    {
      "kodeKABUPATEN": 1273,
      "kodePROVINSI": 12,
      "namaKABUPATEN": "KOTA PEMATANG SIANTAR"
    },
    {
      "kodeKABUPATEN": 1274,
      "kodePROVINSI": 12,
      "namaKABUPATEN": "KOTA TEBING TINGGI"
    },
    {
      "kodeKABUPATEN": 1275,
      "kodePROVINSI": 12,
      "namaKABUPATEN": "KOTA MEDAN"
    },
    {
      "kodeKABUPATEN": 1276,
      "kodePROVINSI": 12,
      "namaKABUPATEN": "KOTA BINJAI"
    },
    {
      "kodeKABUPATEN": 1277,
      "kodePROVINSI": 12,
      "namaKABUPATEN": "KOTA PADANGSIDIMPUAN"
    },
    {
      "kodeKABUPATEN": 1278,
      "kodePROVINSI": 12,
      "namaKABUPATEN": "KOTA GUNUNGSITOLI"
    },
    {
      "kodeKABUPATEN": 1301,
      "kodePROVINSI": 13,
      "namaKABUPATEN": "KABUPATEN KEPULAUAN MENTAWAI"
    },
    {
      "kodeKABUPATEN": 1302,
      "kodePROVINSI": 13,
      "namaKABUPATEN": "KABUPATEN PESISIR SELATAN"
    },
    {
      "kodeKABUPATEN": 1303,
      "kodePROVINSI": 13,
      "namaKABUPATEN": "KABUPATEN SOLOK"
    },
    {
      "kodeKABUPATEN": 1304,
      "kodePROVINSI": 13,
      "namaKABUPATEN": "KABUPATEN SIJUNJUNG"
    },
    {
      "kodeKABUPATEN": 1305,
      "kodePROVINSI": 13,
      "namaKABUPATEN": "KABUPATEN TANAH DATAR"
    },
    {
      "kodeKABUPATEN": 1306,
      "kodePROVINSI": 13,
      "namaKABUPATEN": "KABUPATEN PADANG PARIAMAN"
    },
    {
      "kodeKABUPATEN": 1307,
      "kodePROVINSI": 13,
      "namaKABUPATEN": "KABUPATEN AGAM"
    },
    {
      "kodeKABUPATEN": 1308,
      "kodePROVINSI": 13,
      "namaKABUPATEN": "KABUPATEN LIMA PULUH KOTA"
    },
    {
      "kodeKABUPATEN": 1309,
      "kodePROVINSI": 13,
      "namaKABUPATEN": "KABUPATEN PASAMAN"
    },
    {
      "kodeKABUPATEN": 1310,
      "kodePROVINSI": 13,
      "namaKABUPATEN": "KABUPATEN SOLOK SELATAN"
    },
    {
      "kodeKABUPATEN": 1311,
      "kodePROVINSI": 13,
      "namaKABUPATEN": "KABUPATEN DHARMASRAYA"
    },
    {
      "kodeKABUPATEN": 1312,
      "kodePROVINSI": 13,
      "namaKABUPATEN": "KABUPATEN PASAMAN BARAT"
    },
    {
      "kodeKABUPATEN": 1371,
      "kodePROVINSI": 13,
      "namaKABUPATEN": "KOTA PADANG"
    },
    {
      "kodeKABUPATEN": 1372,
      "kodePROVINSI": 13,
      "namaKABUPATEN": "KOTA SOLOK"
    },
    {
      "kodeKABUPATEN": 1373,
      "kodePROVINSI": 13,
      "namaKABUPATEN": "KOTA SAWAH LUNTO"
    },
    {
      "kodeKABUPATEN": 1374,
      "kodePROVINSI": 13,
      "namaKABUPATEN": "KOTA PADANG PANJANG"
    },
    {
      "kodeKABUPATEN": 1375,
      "kodePROVINSI": 13,
      "namaKABUPATEN": "KOTA BUKITTINGGI"
    },
    {
      "kodeKABUPATEN": 1376,
      "kodePROVINSI": 13,
      "namaKABUPATEN": "KOTA PAYAKUMBUH"
    },
    {
      "kodeKABUPATEN": 1377,
      "kodePROVINSI": 13,
      "namaKABUPATEN": "KOTA PARIAMAN"
    },
    {
      "kodeKABUPATEN": 1401,
      "kodePROVINSI": 14,
      "namaKABUPATEN": "KABUPATEN KUANTAN SINGINGI"
    },
    {
      "kodeKABUPATEN": 1402,
      "kodePROVINSI": 14,
      "namaKABUPATEN": "KABUPATEN INDRAGIRI HULU"
    },
    {
      "kodeKABUPATEN": 1403,
      "kodePROVINSI": 14,
      "namaKABUPATEN": "KABUPATEN INDRAGIRI HILIR"
    },
    {
      "kodeKABUPATEN": 1404,
      "kodePROVINSI": 14,
      "namaKABUPATEN": "KABUPATEN PELALAWAN"
    },
    {
      "kodeKABUPATEN": 1405,
      "kodePROVINSI": 14,
      "namaKABUPATEN": "KABUPATEN S I A K"
    },
    {
      "kodeKABUPATEN": 1406,
      "kodePROVINSI": 14,
      "namaKABUPATEN": "KABUPATEN KAMPAR"
    },
    {
      "kodeKABUPATEN": 1407,
      "kodePROVINSI": 14,
      "namaKABUPATEN": "KABUPATEN ROKAN HULU"
    },
    {
      "kodeKABUPATEN": 1408,
      "kodePROVINSI": 14,
      "namaKABUPATEN": "KABUPATEN BENGKALIS"
    },
    {
      "kodeKABUPATEN": 1409,
      "kodePROVINSI": 14,
      "namaKABUPATEN": "KABUPATEN ROKAN HILIR"
    },
    {
      "kodeKABUPATEN": 1410,
      "kodePROVINSI": 14,
      "namaKABUPATEN": "KABUPATEN KEPULAUAN MERANTI"
    },
    {
      "kodeKABUPATEN": 1471,
      "kodePROVINSI": 14,
      "namaKABUPATEN": "KOTA PEKANBARU"
    },
    {
      "kodeKABUPATEN": 1473,
      "kodePROVINSI": 14,
      "namaKABUPATEN": "KOTA D U M A I"
    },
    {
      "kodeKABUPATEN": 1501,
      "kodePROVINSI": 15,
      "namaKABUPATEN": "KABUPATEN KERINCI"
    },
    {
      "kodeKABUPATEN": 1502,
      "kodePROVINSI": 15,
      "namaKABUPATEN": "KABUPATEN MERANGIN"
    },
    {
      "kodeKABUPATEN": 1503,
      "kodePROVINSI": 15,
      "namaKABUPATEN": "KABUPATEN SAROLANGUN"
    },
    {
      "kodeKABUPATEN": 1504,
      "kodePROVINSI": 15,
      "namaKABUPATEN": "KABUPATEN BATANG HARI"
    },
    {
      "kodeKABUPATEN": 1505,
      "kodePROVINSI": 15,
      "namaKABUPATEN": "KABUPATEN MUARO JAMBI"
    },
    {
      "kodeKABUPATEN": 1506,
      "kodePROVINSI": 15,
      "namaKABUPATEN": "KABUPATEN TANJUNG JABUNG TIMUR"
    },
    {
      "kodeKABUPATEN": 1507,
      "kodePROVINSI": 15,
      "namaKABUPATEN": "KABUPATEN TANJUNG JABUNG BARAT"
    },
    {
      "kodeKABUPATEN": 1508,
      "kodePROVINSI": 15,
      "namaKABUPATEN": "KABUPATEN TEBO"
    },
    {
      "kodeKABUPATEN": 1509,
      "kodePROVINSI": 15,
      "namaKABUPATEN": "KABUPATEN BUNGO"
    },
    {
      "kodeKABUPATEN": 1571,
      "kodePROVINSI": 15,
      "namaKABUPATEN": "KOTA JAMBI"
    },
    {
      "kodeKABUPATEN": 1572,
      "kodePROVINSI": 15,
      "namaKABUPATEN": "KOTA SUNGAI PENUH"
    },
    {
      "kodeKABUPATEN": 1601,
      "kodePROVINSI": 16,
      "namaKABUPATEN": "KABUPATEN OGAN KOMERING ULU"
    },
    {
      "kodeKABUPATEN": 1602,
      "kodePROVINSI": 16,
      "namaKABUPATEN": "KABUPATEN OGAN KOMERING ILIR"
    },
    {
      "kodeKABUPATEN": 1603,
      "kodePROVINSI": 16,
      "namaKABUPATEN": "KABUPATEN MUARA ENIM"
    },
    {
      "kodeKABUPATEN": 1604,
      "kodePROVINSI": 16,
      "namaKABUPATEN": "KABUPATEN LAHAT"
    },
    {
      "kodeKABUPATEN": 1605,
      "kodePROVINSI": 16,
      "namaKABUPATEN": "KABUPATEN MUSI RAWAS"
    },
    {
      "kodeKABUPATEN": 1606,
      "kodePROVINSI": 16,
      "namaKABUPATEN": "KABUPATEN MUSI BANYUASIN"
    },
    {
      "kodeKABUPATEN": 1607,
      "kodePROVINSI": 16,
      "namaKABUPATEN": "KABUPATEN BANYU ASIN"
    },
    {
      "kodeKABUPATEN": 1608,
      "kodePROVINSI": 16,
      "namaKABUPATEN": "KABUPATEN OGAN KOMERING ULU SELATAN"
    },
    {
      "kodeKABUPATEN": 1609,
      "kodePROVINSI": 16,
      "namaKABUPATEN": "KABUPATEN OGAN KOMERING ULU TIMUR"
    },
    {
      "kodeKABUPATEN": 1610,
      "kodePROVINSI": 16,
      "namaKABUPATEN": "KABUPATEN OGAN ILIR"
    },
    {
      "kodeKABUPATEN": 1611,
      "kodePROVINSI": 16,
      "namaKABUPATEN": "KABUPATEN EMPAT LAWANG"
    },
    {
      "kodeKABUPATEN": 1612,
      "kodePROVINSI": 16,
      "namaKABUPATEN": "KABUPATEN PENUKAL ABAB LEMATANG ILIR"
    },
    {
      "kodeKABUPATEN": 1613,
      "kodePROVINSI": 16,
      "namaKABUPATEN": "KABUPATEN MUSI RAWAS UTARA"
    },
    {
      "kodeKABUPATEN": 1671,
      "kodePROVINSI": 16,
      "namaKABUPATEN": "KOTA PALEMBANG"
    },
    {
      "kodeKABUPATEN": 1672,
      "kodePROVINSI": 16,
      "namaKABUPATEN": "KOTA PRABUMULIH"
    },
    {
      "kodeKABUPATEN": 1673,
      "kodePROVINSI": 16,
      "namaKABUPATEN": "KOTA PAGAR ALAM"
    },
    {
      "kodeKABUPATEN": 1674,
      "kodePROVINSI": 16,
      "namaKABUPATEN": "KOTA LUBUKLINGGAU"
    },
    {
      "kodeKABUPATEN": 1701,
      "kodePROVINSI": 17,
      "namaKABUPATEN": "KABUPATEN BENGKULU SELATAN"
    },
    {
      "kodeKABUPATEN": 1702,
      "kodePROVINSI": 17,
      "namaKABUPATEN": "KABUPATEN REJANG LEBONG"
    },
    {
      "kodeKABUPATEN": 1703,
      "kodePROVINSI": 17,
      "namaKABUPATEN": "KABUPATEN BENGKULU UTARA"
    },
    {
      "kodeKABUPATEN": 1704,
      "kodePROVINSI": 17,
      "namaKABUPATEN": "KABUPATEN KAUR"
    },
    {
      "kodeKABUPATEN": 1705,
      "kodePROVINSI": 17,
      "namaKABUPATEN": "KABUPATEN SELUMA"
    },
    {
      "kodeKABUPATEN": 1706,
      "kodePROVINSI": 17,
      "namaKABUPATEN": "KABUPATEN MUKOMUKO"
    },
    {
      "kodeKABUPATEN": 1707,
      "kodePROVINSI": 17,
      "namaKABUPATEN": "KABUPATEN LEBONG"
    },
    {
      "kodeKABUPATEN": 1708,
      "kodePROVINSI": 17,
      "namaKABUPATEN": "KABUPATEN KEPAHIANG"
    },
    {
      "kodeKABUPATEN": 1709,
      "kodePROVINSI": 17,
      "namaKABUPATEN": "KABUPATEN BENGKULU TENGAH"
    },
    {
      "kodeKABUPATEN": 1771,
      "kodePROVINSI": 17,
      "namaKABUPATEN": "KOTA BENGKULU"
    },
    {
      "kodeKABUPATEN": 1801,
      "kodePROVINSI": 18,
      "namaKABUPATEN": "KABUPATEN LAMPUNG BARAT"
    },
    {
      "kodeKABUPATEN": 1802,
      "kodePROVINSI": 18,
      "namaKABUPATEN": "KABUPATEN TANGGAMUS"
    },
    {
      "kodeKABUPATEN": 1803,
      "kodePROVINSI": 18,
      "namaKABUPATEN": "KABUPATEN LAMPUNG SELATAN"
    },
    {
      "kodeKABUPATEN": 1804,
      "kodePROVINSI": 18,
      "namaKABUPATEN": "KABUPATEN LAMPUNG TIMUR"
    },
    {
      "kodeKABUPATEN": 1805,
      "kodePROVINSI": 18,
      "namaKABUPATEN": "KABUPATEN LAMPUNG TENGAH"
    },
    {
      "kodeKABUPATEN": 1806,
      "kodePROVINSI": 18,
      "namaKABUPATEN": "KABUPATEN LAMPUNG UTARA"
    },
    {
      "kodeKABUPATEN": 1807,
      "kodePROVINSI": 18,
      "namaKABUPATEN": "KABUPATEN WAY KANAN"
    },
    {
      "kodeKABUPATEN": 1808,
      "kodePROVINSI": 18,
      "namaKABUPATEN": "KABUPATEN TULANGBAWANG"
    },
    {
      "kodeKABUPATEN": 1809,
      "kodePROVINSI": 18,
      "namaKABUPATEN": "KABUPATEN PESAWARAN"
    },
    {
      "kodeKABUPATEN": 1810,
      "kodePROVINSI": 18,
      "namaKABUPATEN": "KABUPATEN PRINGSEWU"
    },
    {
      "kodeKABUPATEN": 1811,
      "kodePROVINSI": 18,
      "namaKABUPATEN": "KABUPATEN MESUJI"
    },
    {
      "kodeKABUPATEN": 1812,
      "kodePROVINSI": 18,
      "namaKABUPATEN": "KABUPATEN TULANG BAWANG BARAT"
    },
    {
      "kodeKABUPATEN": 1813,
      "kodePROVINSI": 18,
      "namaKABUPATEN": "KABUPATEN PESISIR BARAT"
    },
    {
      "kodeKABUPATEN": 1871,
      "kodePROVINSI": 18,
      "namaKABUPATEN": "KOTA BANDAR LAMPUNG"
    },
    {
      "kodeKABUPATEN": 1872,
      "kodePROVINSI": 18,
      "namaKABUPATEN": "KOTA METRO"
    },
    {
      "kodeKABUPATEN": 1901,
      "kodePROVINSI": 19,
      "namaKABUPATEN": "KABUPATEN BANGKA"
    },
    {
      "kodeKABUPATEN": 1902,
      "kodePROVINSI": 19,
      "namaKABUPATEN": "KABUPATEN BELITUNG"
    },
    {
      "kodeKABUPATEN": 1903,
      "kodePROVINSI": 19,
      "namaKABUPATEN": "KABUPATEN BANGKA BARAT"
    },
    {
      "kodeKABUPATEN": 1904,
      "kodePROVINSI": 19,
      "namaKABUPATEN": "KABUPATEN BANGKA TENGAH"
    },
    {
      "kodeKABUPATEN": 1905,
      "kodePROVINSI": 19,
      "namaKABUPATEN": "KABUPATEN BANGKA SELATAN"
    },
    {
      "kodeKABUPATEN": 1906,
      "kodePROVINSI": 19,
      "namaKABUPATEN": "KABUPATEN BELITUNG TIMUR"
    },
    {
      "kodeKABUPATEN": 1971,
      "kodePROVINSI": 19,
      "namaKABUPATEN": "KOTA PANGKAL PINANG"
    },
    {
      "kodeKABUPATEN": 2101,
      "kodePROVINSI": 21,
      "namaKABUPATEN": "KABUPATEN KARIMUN"
    },
    {
      "kodeKABUPATEN": 2102,
      "kodePROVINSI": 21,
      "namaKABUPATEN": "KABUPATEN BINTAN"
    },
    {
      "kodeKABUPATEN": 2103,
      "kodePROVINSI": 21,
      "namaKABUPATEN": "KABUPATEN NATUNA"
    },
    {
      "kodeKABUPATEN": 2104,
      "kodePROVINSI": 21,
      "namaKABUPATEN": "KABUPATEN LINGGA"
    },
    {
      "kodeKABUPATEN": 2105,
      "kodePROVINSI": 21,
      "namaKABUPATEN": "KABUPATEN KEPULAUAN ANAMBAS"
    },
    {
      "kodeKABUPATEN": 2171,
      "kodePROVINSI": 21,
      "namaKABUPATEN": "KOTA B A T A M"
    },
    {
      "kodeKABUPATEN": 2172,
      "kodePROVINSI": 21,
      "namaKABUPATEN": "KOTA TANJUNG PINANG"
    },
    {
      "kodeKABUPATEN": 3101,
      "kodePROVINSI": 31,
      "namaKABUPATEN": "KABUPATEN KEPULAUAN SERIBU"
    },
    {
      "kodeKABUPATEN": 3171,
      "kodePROVINSI": 31,
      "namaKABUPATEN": "KOTA JAKARTA SELATAN"
    },
    {
      "kodeKABUPATEN": 3172,
      "kodePROVINSI": 31,
      "namaKABUPATEN": "KOTA JAKARTA TIMUR"
    },
    {
      "kodeKABUPATEN": 3173,
      "kodePROVINSI": 31,
      "namaKABUPATEN": "KOTA JAKARTA PUSAT"
    },
    {
      "kodeKABUPATEN": 3174,
      "kodePROVINSI": 31,
      "namaKABUPATEN": "KOTA JAKARTA BARAT"
    },
    {
      "kodeKABUPATEN": 3175,
      "kodePROVINSI": 31,
      "namaKABUPATEN": "KOTA JAKARTA UTARA"
    },
    {
      "kodeKABUPATEN": 3201,
      "kodePROVINSI": 32,
      "namaKABUPATEN": "KABUPATEN BOGOR"
    },
    {
      "kodeKABUPATEN": 3202,
      "kodePROVINSI": 32,
      "namaKABUPATEN": "KABUPATEN SUKABUMI"
    },
    {
      "kodeKABUPATEN": 3203,
      "kodePROVINSI": 32,
      "namaKABUPATEN": "KABUPATEN CIANJUR"
    },
    {
      "kodeKABUPATEN": 3204,
      "kodePROVINSI": 32,
      "namaKABUPATEN": "KABUPATEN BANDUNG"
    },
    {
      "kodeKABUPATEN": 3205,
      "kodePROVINSI": 32,
      "namaKABUPATEN": "KABUPATEN GARUT"
    },
    {
      "kodeKABUPATEN": 3206,
      "kodePROVINSI": 32,
      "namaKABUPATEN": "KABUPATEN TASIKMALAYA"
    },
    {
      "kodeKABUPATEN": 3207,
      "kodePROVINSI": 32,
      "namaKABUPATEN": "KABUPATEN CIAMIS"
    },
    {
      "kodeKABUPATEN": 3208,
      "kodePROVINSI": 32,
      "namaKABUPATEN": "KABUPATEN KUNINGAN"
    },
    {
      "kodeKABUPATEN": 3209,
      "kodePROVINSI": 32,
      "namaKABUPATEN": "KABUPATEN CIREBON"
    },
    {
      "kodeKABUPATEN": 3210,
      "kodePROVINSI": 32,
      "namaKABUPATEN": "KABUPATEN MAJALENGKA"
    },
    {
      "kodeKABUPATEN": 3211,
      "kodePROVINSI": 32,
      "namaKABUPATEN": "KABUPATEN SUMEDANG"
    },
    {
      "kodeKABUPATEN": 3212,
      "kodePROVINSI": 32,
      "namaKABUPATEN": "KABUPATEN INDRAMAYU"
    },
    {
      "kodeKABUPATEN": 3213,
      "kodePROVINSI": 32,
      "namaKABUPATEN": "KABUPATEN SUBANG"
    },
    {
      "kodeKABUPATEN": 3214,
      "kodePROVINSI": 32,
      "namaKABUPATEN": "KABUPATEN PURWAKARTA"
    },
    {
      "kodeKABUPATEN": 3215,
      "kodePROVINSI": 32,
      "namaKABUPATEN": "KABUPATEN KARAWANG"
    },
    {
      "kodeKABUPATEN": 3216,
      "kodePROVINSI": 32,
      "namaKABUPATEN": "KABUPATEN BEKASI"
    },
    {
      "kodeKABUPATEN": 3217,
      "kodePROVINSI": 32,
      "namaKABUPATEN": "KABUPATEN BANDUNG BARAT"
    },
    {
      "kodeKABUPATEN": 3218,
      "kodePROVINSI": 32,
      "namaKABUPATEN": "KABUPATEN PANGANDARAN"
    },
    {
      "kodeKABUPATEN": 3271,
      "kodePROVINSI": 32,
      "namaKABUPATEN": "KOTA BOGOR"
    },
    {
      "kodeKABUPATEN": 3272,
      "kodePROVINSI": 32,
      "namaKABUPATEN": "KOTA SUKABUMI"
    },
    {
      "kodeKABUPATEN": 3273,
      "kodePROVINSI": 32,
      "namaKABUPATEN": "KOTA BANDUNG"
    },
    {
      "kodeKABUPATEN": 3274,
      "kodePROVINSI": 32,
      "namaKABUPATEN": "KOTA CIREBON"
    },
    {
      "kodeKABUPATEN": 3275,
      "kodePROVINSI": 32,
      "namaKABUPATEN": "KOTA BEKASI"
    },
    {
      "kodeKABUPATEN": 3276,
      "kodePROVINSI": 32,
      "namaKABUPATEN": "KOTA DEPOK"
    },
    {
      "kodeKABUPATEN": 3277,
      "kodePROVINSI": 32,
      "namaKABUPATEN": "KOTA CIMAHI"
    },
    {
      "kodeKABUPATEN": 3278,
      "kodePROVINSI": 32,
      "namaKABUPATEN": "KOTA TASIKMALAYA"
    },
    {
      "kodeKABUPATEN": 3279,
      "kodePROVINSI": 32,
      "namaKABUPATEN": "KOTA BANJAR"
    },
    {
      "kodeKABUPATEN": 3301,
      "kodePROVINSI": 33,
      "namaKABUPATEN": "KABUPATEN CILACAP"
    },
    {
      "kodeKABUPATEN": 3302,
      "kodePROVINSI": 33,
      "namaKABUPATEN": "KABUPATEN BANYUMAS"
    },
    {
      "kodeKABUPATEN": 3303,
      "kodePROVINSI": 33,
      "namaKABUPATEN": "KABUPATEN PURBALINGGA"
    },
    {
      "kodeKABUPATEN": 3304,
      "kodePROVINSI": 33,
      "namaKABUPATEN": "KABUPATEN BANJARNEGARA"
    },
    {
      "kodeKABUPATEN": 3305,
      "kodePROVINSI": 33,
      "namaKABUPATEN": "KABUPATEN KEBUMEN"
    },
    {
      "kodeKABUPATEN": 3306,
      "kodePROVINSI": 33,
      "namaKABUPATEN": "KABUPATEN PURWOREJO"
    },
    {
      "kodeKABUPATEN": 3307,
      "kodePROVINSI": 33,
      "namaKABUPATEN": "KABUPATEN WONOSOBO"
    },
    {
      "kodeKABUPATEN": 3308,
      "kodePROVINSI": 33,
      "namaKABUPATEN": "KABUPATEN MAGELANG"
    },
    {
      "kodeKABUPATEN": 3309,
      "kodePROVINSI": 33,
      "namaKABUPATEN": "KABUPATEN BOYOLALI"
    },
    {
      "kodeKABUPATEN": 3310,
      "kodePROVINSI": 33,
      "namaKABUPATEN": "KABUPATEN KLATEN"
    },
    {
      "kodeKABUPATEN": 3311,
      "kodePROVINSI": 33,
      "namaKABUPATEN": "KABUPATEN SUKOHARJO"
    },
    {
      "kodeKABUPATEN": 3312,
      "kodePROVINSI": 33,
      "namaKABUPATEN": "KABUPATEN WONOGIRI"
    },
    {
      "kodeKABUPATEN": 3313,
      "kodePROVINSI": 33,
      "namaKABUPATEN": "KABUPATEN KARANGANYAR"
    },
    {
      "kodeKABUPATEN": 3314,
      "kodePROVINSI": 33,
      "namaKABUPATEN": "KABUPATEN SRAGEN"
    },
    {
      "kodeKABUPATEN": 3315,
      "kodePROVINSI": 33,
      "namaKABUPATEN": "KABUPATEN GROBOGAN"
    },
    {
      "kodeKABUPATEN": 3316,
      "kodePROVINSI": 33,
      "namaKABUPATEN": "KABUPATEN BLORA"
    },
    {
      "kodeKABUPATEN": 3317,
      "kodePROVINSI": 33,
      "namaKABUPATEN": "KABUPATEN REMBANG"
    },
    {
      "kodeKABUPATEN": 3318,
      "kodePROVINSI": 33,
      "namaKABUPATEN": "KABUPATEN PATI"
    },
    {
      "kodeKABUPATEN": 3319,
      "kodePROVINSI": 33,
      "namaKABUPATEN": "KABUPATEN KUDUS"
    },
    {
      "kodeKABUPATEN": 3320,
      "kodePROVINSI": 33,
      "namaKABUPATEN": "KABUPATEN JEPARA"
    },
    {
      "kodeKABUPATEN": 3321,
      "kodePROVINSI": 33,
      "namaKABUPATEN": "KABUPATEN DEMAK"
    },
    {
      "kodeKABUPATEN": 3322,
      "kodePROVINSI": 33,
      "namaKABUPATEN": "KABUPATEN SEMARANG"
    },
    {
      "kodeKABUPATEN": 3323,
      "kodePROVINSI": 33,
      "namaKABUPATEN": "KABUPATEN TEMANGGUNG"
    },
    {
      "kodeKABUPATEN": 3324,
      "kodePROVINSI": 33,
      "namaKABUPATEN": "KABUPATEN KENDAL"
    },
    {
      "kodeKABUPATEN": 3325,
      "kodePROVINSI": 33,
      "namaKABUPATEN": "KABUPATEN BATANG"
    },
    {
      "kodeKABUPATEN": 3326,
      "kodePROVINSI": 33,
      "namaKABUPATEN": "KABUPATEN PEKALONGAN"
    },
    {
      "kodeKABUPATEN": 3327,
      "kodePROVINSI": 33,
      "namaKABUPATEN": "KABUPATEN PEMALANG"
    },
    {
      "kodeKABUPATEN": 3328,
      "kodePROVINSI": 33,
      "namaKABUPATEN": "KABUPATEN TEGAL"
    },
    {
      "kodeKABUPATEN": 3329,
      "kodePROVINSI": 33,
      "namaKABUPATEN": "KABUPATEN BREBES"
    },
    {
      "kodeKABUPATEN": 3371,
      "kodePROVINSI": 33,
      "namaKABUPATEN": "KOTA MAGELANG"
    },
    {
      "kodeKABUPATEN": 3372,
      "kodePROVINSI": 33,
      "namaKABUPATEN": "KOTA SURAKARTA"
    },
    {
      "kodeKABUPATEN": 3373,
      "kodePROVINSI": 33,
      "namaKABUPATEN": "KOTA SALATIGA"
    },
    {
      "kodeKABUPATEN": 3374,
      "kodePROVINSI": 33,
      "namaKABUPATEN": "KOTA SEMARANG"
    },
    {
      "kodeKABUPATEN": 3375,
      "kodePROVINSI": 33,
      "namaKABUPATEN": "KOTA PEKALONGAN"
    },
    {
      "kodeKABUPATEN": 3376,
      "kodePROVINSI": 33,
      "namaKABUPATEN": "KOTA TEGAL"
    },
    {
      "kodeKABUPATEN": 3401,
      "kodePROVINSI": 34,
      "namaKABUPATEN": "KABUPATEN KULON PROGO"
    },
    {
      "kodeKABUPATEN": 3402,
      "kodePROVINSI": 34,
      "namaKABUPATEN": "KABUPATEN BANTUL"
    },
    {
      "kodeKABUPATEN": 3403,
      "kodePROVINSI": 34,
      "namaKABUPATEN": "KABUPATEN GUNUNG KIDUL"
    },
    {
      "kodeKABUPATEN": 3404,
      "kodePROVINSI": 34,
      "namaKABUPATEN": "KABUPATEN SLEMAN"
    },
    {
      "kodeKABUPATEN": 3471,
      "kodePROVINSI": 34,
      "namaKABUPATEN": "KOTA YOGYAKARTA"
    },
    {
      "kodeKABUPATEN": 3501,
      "kodePROVINSI": 35,
      "namaKABUPATEN": "KABUPATEN PACITAN"
    },
    {
      "kodeKABUPATEN": 3502,
      "kodePROVINSI": 35,
      "namaKABUPATEN": "KABUPATEN PONOROGO"
    },
    {
      "kodeKABUPATEN": 3503,
      "kodePROVINSI": 35,
      "namaKABUPATEN": "KABUPATEN TRENGGALEK"
    },
    {
      "kodeKABUPATEN": 3504,
      "kodePROVINSI": 35,
      "namaKABUPATEN": "KABUPATEN TULUNGAGUNG"
    },
    {
      "kodeKABUPATEN": 3505,
      "kodePROVINSI": 35,
      "namaKABUPATEN": "KABUPATEN BLITAR"
    },
    {
      "kodeKABUPATEN": 3506,
      "kodePROVINSI": 35,
      "namaKABUPATEN": "KABUPATEN KEDIRI"
    },
    {
      "kodeKABUPATEN": 3507,
      "kodePROVINSI": 35,
      "namaKABUPATEN": "KABUPATEN MALANG"
    },
    {
      "kodeKABUPATEN": 3508,
      "kodePROVINSI": 35,
      "namaKABUPATEN": "KABUPATEN LUMAJANG"
    },
    {
      "kodeKABUPATEN": 3509,
      "kodePROVINSI": 35,
      "namaKABUPATEN": "KABUPATEN JEMBER"
    },
    {
      "kodeKABUPATEN": 3510,
      "kodePROVINSI": 35,
      "namaKABUPATEN": "KABUPATEN BANYUWANGI"
    },
    {
      "kodeKABUPATEN": 3511,
      "kodePROVINSI": 35,
      "namaKABUPATEN": "KABUPATEN BONDOWOSO"
    },
    {
      "kodeKABUPATEN": 3512,
      "kodePROVINSI": 35,
      "namaKABUPATEN": "KABUPATEN SITUBONDO"
    },
    {
      "kodeKABUPATEN": 3513,
      "kodePROVINSI": 35,
      "namaKABUPATEN": "KABUPATEN PROBOLINGGO"
    },
    {
      "kodeKABUPATEN": 3514,
      "kodePROVINSI": 35,
      "namaKABUPATEN": "KABUPATEN PASURUAN"
    },
    {
      "kodeKABUPATEN": 3515,
      "kodePROVINSI": 35,
      "namaKABUPATEN": "KABUPATEN SIDOARJO"
    },
    {
      "kodeKABUPATEN": 3516,
      "kodePROVINSI": 35,
      "namaKABUPATEN": "KABUPATEN MOJOKERTO"
    },
    {
      "kodeKABUPATEN": 3517,
      "kodePROVINSI": 35,
      "namaKABUPATEN": "KABUPATEN JOMBANG"
    },
    {
      "kodeKABUPATEN": 3518,
      "kodePROVINSI": 35,
      "namaKABUPATEN": "KABUPATEN NGANJUK"
    },
    {
      "kodeKABUPATEN": 3519,
      "kodePROVINSI": 35,
      "namaKABUPATEN": "KABUPATEN MADIUN"
    },
    {
      "kodeKABUPATEN": 3520,
      "kodePROVINSI": 35,
      "namaKABUPATEN": "KABUPATEN MAGETAN"
    },
    {
      "kodeKABUPATEN": 3521,
      "kodePROVINSI": 35,
      "namaKABUPATEN": "KABUPATEN NGAWI"
    },
    {
      "kodeKABUPATEN": 3522,
      "kodePROVINSI": 35,
      "namaKABUPATEN": "KABUPATEN BOJONEGORO"
    },
    {
      "kodeKABUPATEN": 3523,
      "kodePROVINSI": 35,
      "namaKABUPATEN": "KABUPATEN TUBAN"
    },
    {
      "kodeKABUPATEN": 3524,
      "kodePROVINSI": 35,
      "namaKABUPATEN": "KABUPATEN LAMONGAN"
    },
    {
      "kodeKABUPATEN": 3525,
      "kodePROVINSI": 35,
      "namaKABUPATEN": "KABUPATEN GRESIK"
    },
    {
      "kodeKABUPATEN": 3526,
      "kodePROVINSI": 35,
      "namaKABUPATEN": "KABUPATEN BANGKALAN"
    },
    {
      "kodeKABUPATEN": 3527,
      "kodePROVINSI": 35,
      "namaKABUPATEN": "KABUPATEN SAMPANG"
    },
    {
      "kodeKABUPATEN": 3528,
      "kodePROVINSI": 35,
      "namaKABUPATEN": "KABUPATEN PAMEKASAN"
    },
    {
      "kodeKABUPATEN": 3529,
      "kodePROVINSI": 35,
      "namaKABUPATEN": "KABUPATEN SUMENEP"
    },
    {
      "kodeKABUPATEN": 3571,
      "kodePROVINSI": 35,
      "namaKABUPATEN": "KOTA KEDIRI"
    },
    {
      "kodeKABUPATEN": 3572,
      "kodePROVINSI": 35,
      "namaKABUPATEN": "KOTA BLITAR"
    },
    {
      "kodeKABUPATEN": 3573,
      "kodePROVINSI": 35,
      "namaKABUPATEN": "KOTA MALANG"
    },
    {
      "kodeKABUPATEN": 3574,
      "kodePROVINSI": 35,
      "namaKABUPATEN": "KOTA PROBOLINGGO"
    },
    {
      "kodeKABUPATEN": 3575,
      "kodePROVINSI": 35,
      "namaKABUPATEN": "KOTA PASURUAN"
    },
    {
      "kodeKABUPATEN": 3576,
      "kodePROVINSI": 35,
      "namaKABUPATEN": "KOTA MOJOKERTO"
    },
    {
      "kodeKABUPATEN": 3577,
      "kodePROVINSI": 35,
      "namaKABUPATEN": "KOTA MADIUN"
    },
    {
      "kodeKABUPATEN": 3578,
      "kodePROVINSI": 35,
      "namaKABUPATEN": "KOTA SURABAYA"
    },
    {
      "kodeKABUPATEN": 3579,
      "kodePROVINSI": 35,
      "namaKABUPATEN": "KOTA BATU"
    },
    {
      "kodeKABUPATEN": 3601,
      "kodePROVINSI": 36,
      "namaKABUPATEN": "KABUPATEN PANDEGLANG"
    },
    {
      "kodeKABUPATEN": 3602,
      "kodePROVINSI": 36,
      "namaKABUPATEN": "KABUPATEN LEBAK"
    },
    {
      "kodeKABUPATEN": 3603,
      "kodePROVINSI": 36,
      "namaKABUPATEN": "KABUPATEN TANGERANG"
    },
    {
      "kodeKABUPATEN": 3604,
      "kodePROVINSI": 36,
      "namaKABUPATEN": "KABUPATEN SERANG"
    },
    {
      "kodeKABUPATEN": 3671,
      "kodePROVINSI": 36,
      "namaKABUPATEN": "KOTA TANGERANG"
    },
    {
      "kodeKABUPATEN": 3672,
      "kodePROVINSI": 36,
      "namaKABUPATEN": "KOTA CILEGON"
    },
    {
      "kodeKABUPATEN": 3673,
      "kodePROVINSI": 36,
      "namaKABUPATEN": "KOTA SERANG"
    },
    {
      "kodeKABUPATEN": 3674,
      "kodePROVINSI": 36,
      "namaKABUPATEN": "KOTA TANGERANG SELATAN"
    },
    {
      "kodeKABUPATEN": 5101,
      "kodePROVINSI": 51,
      "namaKABUPATEN": "KABUPATEN JEMBRANA"
    },
    {
      "kodeKABUPATEN": 5102,
      "kodePROVINSI": 51,
      "namaKABUPATEN": "KABUPATEN TABANAN"
    },
    {
      "kodeKABUPATEN": 5103,
      "kodePROVINSI": 51,
      "namaKABUPATEN": "KABUPATEN BADUNG"
    },
    {
      "kodeKABUPATEN": 5104,
      "kodePROVINSI": 51,
      "namaKABUPATEN": "KABUPATEN GIANYAR"
    },
    {
      "kodeKABUPATEN": 5105,
      "kodePROVINSI": 51,
      "namaKABUPATEN": "KABUPATEN KLUNGKUNG"
    },
    {
      "kodeKABUPATEN": 5106,
      "kodePROVINSI": 51,
      "namaKABUPATEN": "KABUPATEN BANGLI"
    },
    {
      "kodeKABUPATEN": 5107,
      "kodePROVINSI": 51,
      "namaKABUPATEN": "KABUPATEN KARANG ASEM"
    },
    {
      "kodeKABUPATEN": 5108,
      "kodePROVINSI": 51,
      "namaKABUPATEN": "KABUPATEN BULELENG"
    },
    {
      "kodeKABUPATEN": 5171,
      "kodePROVINSI": 51,
      "namaKABUPATEN": "KOTA DENPASAR"
    },
    {
      "kodeKABUPATEN": 5201,
      "kodePROVINSI": 52,
      "namaKABUPATEN": "KABUPATEN LOMBOK BARAT"
    },
    {
      "kodeKABUPATEN": 5202,
      "kodePROVINSI": 52,
      "namaKABUPATEN": "KABUPATEN LOMBOK TENGAH"
    },
    {
      "kodeKABUPATEN": 5203,
      "kodePROVINSI": 52,
      "namaKABUPATEN": "KABUPATEN LOMBOK TIMUR"
    },
    {
      "kodeKABUPATEN": 5204,
      "kodePROVINSI": 52,
      "namaKABUPATEN": "KABUPATEN SUMBAWA"
    },
    {
      "kodeKABUPATEN": 5205,
      "kodePROVINSI": 52,
      "namaKABUPATEN": "KABUPATEN DOMPU"
    },
    {
      "kodeKABUPATEN": 5206,
      "kodePROVINSI": 52,
      "namaKABUPATEN": "KABUPATEN BIMA"
    },
    {
      "kodeKABUPATEN": 5207,
      "kodePROVINSI": 52,
      "namaKABUPATEN": "KABUPATEN SUMBAWA BARAT"
    },
    {
      "kodeKABUPATEN": 5208,
      "kodePROVINSI": 52,
      "namaKABUPATEN": "KABUPATEN LOMBOK UTARA"
    },
    {
      "kodeKABUPATEN": 5271,
      "kodePROVINSI": 52,
      "namaKABUPATEN": "KOTA MATARAM"
    },
    {
      "kodeKABUPATEN": 5272,
      "kodePROVINSI": 52,
      "namaKABUPATEN": "KOTA BIMA"
    },
    {
      "kodeKABUPATEN": 5301,
      "kodePROVINSI": 53,
      "namaKABUPATEN": "KABUPATEN SUMBA BARAT"
    },
    {
      "kodeKABUPATEN": 5302,
      "kodePROVINSI": 53,
      "namaKABUPATEN": "KABUPATEN SUMBA TIMUR"
    },
    {
      "kodeKABUPATEN": 5303,
      "kodePROVINSI": 53,
      "namaKABUPATEN": "KABUPATEN KUPANG"
    },
    {
      "kodeKABUPATEN": 5304,
      "kodePROVINSI": 53,
      "namaKABUPATEN": "KABUPATEN TIMOR TENGAH SELATAN"
    },
    {
      "kodeKABUPATEN": 5305,
      "kodePROVINSI": 53,
      "namaKABUPATEN": "KABUPATEN TIMOR TENGAH UTARA"
    },
    {
      "kodeKABUPATEN": 5306,
      "kodePROVINSI": 53,
      "namaKABUPATEN": "KABUPATEN BELU"
    },
    {
      "kodeKABUPATEN": 5307,
      "kodePROVINSI": 53,
      "namaKABUPATEN": "KABUPATEN ALOR"
    },
    {
      "kodeKABUPATEN": 5308,
      "kodePROVINSI": 53,
      "namaKABUPATEN": "KABUPATEN LEMBATA"
    },
    {
      "kodeKABUPATEN": 5309,
      "kodePROVINSI": 53,
      "namaKABUPATEN": "KABUPATEN FLORES TIMUR"
    },
    {
      "kodeKABUPATEN": 5310,
      "kodePROVINSI": 53,
      "namaKABUPATEN": "KABUPATEN SIKKA"
    },
    {
      "kodeKABUPATEN": 5311,
      "kodePROVINSI": 53,
      "namaKABUPATEN": "KABUPATEN ENDE"
    },
    {
      "kodeKABUPATEN": 5312,
      "kodePROVINSI": 53,
      "namaKABUPATEN": "KABUPATEN NGADA"
    },
    {
      "kodeKABUPATEN": 5313,
      "kodePROVINSI": 53,
      "namaKABUPATEN": "KABUPATEN MANGGARAI"
    },
    {
      "kodeKABUPATEN": 5314,
      "kodePROVINSI": 53,
      "namaKABUPATEN": "KABUPATEN ROTE NDAO"
    },
    {
      "kodeKABUPATEN": 5315,
      "kodePROVINSI": 53,
      "namaKABUPATEN": "KABUPATEN MANGGARAI BARAT"
    },
    {
      "kodeKABUPATEN": 5316,
      "kodePROVINSI": 53,
      "namaKABUPATEN": "KABUPATEN SUMBA TENGAH"
    },
    {
      "kodeKABUPATEN": 5317,
      "kodePROVINSI": 53,
      "namaKABUPATEN": "KABUPATEN SUMBA BARAT DAYA"
    },
    {
      "kodeKABUPATEN": 5318,
      "kodePROVINSI": 53,
      "namaKABUPATEN": "KABUPATEN NAGEKEO"
    },
    {
      "kodeKABUPATEN": 5319,
      "kodePROVINSI": 53,
      "namaKABUPATEN": "KABUPATEN MANGGARAI TIMUR"
    },
    {
      "kodeKABUPATEN": 5320,
      "kodePROVINSI": 53,
      "namaKABUPATEN": "KABUPATEN SABU RAIJUA"
    },
    {
      "kodeKABUPATEN": 5321,
      "kodePROVINSI": 53,
      "namaKABUPATEN": "KABUPATEN MALAKA"
    },
    {
      "kodeKABUPATEN": 5371,
      "kodePROVINSI": 53,
      "namaKABUPATEN": "KOTA KUPANG"
    },
    {
      "kodeKABUPATEN": 6101,
      "kodePROVINSI": 61,
      "namaKABUPATEN": "KABUPATEN SAMBAS"
    },
    {
      "kodeKABUPATEN": 6102,
      "kodePROVINSI": 61,
      "namaKABUPATEN": "KABUPATEN BENGKAYANG"
    },
    {
      "kodeKABUPATEN": 6103,
      "kodePROVINSI": 61,
      "namaKABUPATEN": "KABUPATEN LANDAK"
    },
    {
      "kodeKABUPATEN": 6104,
      "kodePROVINSI": 61,
      "namaKABUPATEN": "KABUPATEN MEMPAWAH"
    },
    {
      "kodeKABUPATEN": 6105,
      "kodePROVINSI": 61,
      "namaKABUPATEN": "KABUPATEN SANGGAU"
    },
    {
      "kodeKABUPATEN": 6106,
      "kodePROVINSI": 61,
      "namaKABUPATEN": "KABUPATEN KETAPANG"
    },
    {
      "kodeKABUPATEN": 6107,
      "kodePROVINSI": 61,
      "namaKABUPATEN": "KABUPATEN SINTANG"
    },
    {
      "kodeKABUPATEN": 6108,
      "kodePROVINSI": 61,
      "namaKABUPATEN": "KABUPATEN KAPUAS HULU"
    },
    {
      "kodeKABUPATEN": 6109,
      "kodePROVINSI": 61,
      "namaKABUPATEN": "KABUPATEN SEKADAU"
    },
    {
      "kodeKABUPATEN": 6110,
      "kodePROVINSI": 61,
      "namaKABUPATEN": "KABUPATEN MELAWI"
    },
    {
      "kodeKABUPATEN": 6111,
      "kodePROVINSI": 61,
      "namaKABUPATEN": "KABUPATEN KAYONG UTARA"
    },
    {
      "kodeKABUPATEN": 6112,
      "kodePROVINSI": 61,
      "namaKABUPATEN": "KABUPATEN KUBU RAYA"
    },
    {
      "kodeKABUPATEN": 6171,
      "kodePROVINSI": 61,
      "namaKABUPATEN": "KOTA PONTIANAK"
    },
    {
      "kodeKABUPATEN": 6172,
      "kodePROVINSI": 61,
      "namaKABUPATEN": "KOTA SINGKAWANG"
    },
    {
      "kodeKABUPATEN": 6201,
      "kodePROVINSI": 62,
      "namaKABUPATEN": "KABUPATEN KOTAWARINGIN BARAT"
    },
    {
      "kodeKABUPATEN": 6202,
      "kodePROVINSI": 62,
      "namaKABUPATEN": "KABUPATEN KOTAWARINGIN TIMUR"
    },
    {
      "kodeKABUPATEN": 6203,
      "kodePROVINSI": 62,
      "namaKABUPATEN": "KABUPATEN KAPUAS"
    },
    {
      "kodeKABUPATEN": 6204,
      "kodePROVINSI": 62,
      "namaKABUPATEN": "KABUPATEN BARITO SELATAN"
    },
    {
      "kodeKABUPATEN": 6205,
      "kodePROVINSI": 62,
      "namaKABUPATEN": "KABUPATEN BARITO UTARA"
    },
    {
      "kodeKABUPATEN": 6206,
      "kodePROVINSI": 62,
      "namaKABUPATEN": "KABUPATEN SUKAMARA"
    },
    {
      "kodeKABUPATEN": 6207,
      "kodePROVINSI": 62,
      "namaKABUPATEN": "KABUPATEN LAMANDAU"
    },
    {
      "kodeKABUPATEN": 6208,
      "kodePROVINSI": 62,
      "namaKABUPATEN": "KABUPATEN SERUYAN"
    },
    {
      "kodeKABUPATEN": 6209,
      "kodePROVINSI": 62,
      "namaKABUPATEN": "KABUPATEN KATINGAN"
    },
    {
      "kodeKABUPATEN": 6210,
      "kodePROVINSI": 62,
      "namaKABUPATEN": "KABUPATEN PULANG PISAU"
    },
    {
      "kodeKABUPATEN": 6211,
      "kodePROVINSI": 62,
      "namaKABUPATEN": "KABUPATEN GUNUNG MAS"
    },
    {
      "kodeKABUPATEN": 6212,
      "kodePROVINSI": 62,
      "namaKABUPATEN": "KABUPATEN BARITO TIMUR"
    },
    {
      "kodeKABUPATEN": 6213,
      "kodePROVINSI": 62,
      "namaKABUPATEN": "KABUPATEN MURUNG RAYA"
    },
    {
      "kodeKABUPATEN": 6271,
      "kodePROVINSI": 62,
      "namaKABUPATEN": "KOTA PALANGKA RAYA"
    },
    {
      "kodeKABUPATEN": 6301,
      "kodePROVINSI": 63,
      "namaKABUPATEN": "KABUPATEN TANAH LAUT"
    },
    {
      "kodeKABUPATEN": 6302,
      "kodePROVINSI": 63,
      "namaKABUPATEN": "KABUPATEN KOTA BARU"
    },
    {
      "kodeKABUPATEN": 6303,
      "kodePROVINSI": 63,
      "namaKABUPATEN": "KABUPATEN BANJAR"
    },
    {
      "kodeKABUPATEN": 6304,
      "kodePROVINSI": 63,
      "namaKABUPATEN": "KABUPATEN BARITO KUALA"
    },
    {
      "kodeKABUPATEN": 6305,
      "kodePROVINSI": 63,
      "namaKABUPATEN": "KABUPATEN TAPIN"
    },
    {
      "kodeKABUPATEN": 6306,
      "kodePROVINSI": 63,
      "namaKABUPATEN": "KABUPATEN HULU SUNGAI SELATAN"
    },
    {
      "kodeKABUPATEN": 6307,
      "kodePROVINSI": 63,
      "namaKABUPATEN": "KABUPATEN HULU SUNGAI TENGAH"
    },
    {
      "kodeKABUPATEN": 6308,
      "kodePROVINSI": 63,
      "namaKABUPATEN": "KABUPATEN HULU SUNGAI UTARA"
    },
    {
      "kodeKABUPATEN": 6309,
      "kodePROVINSI": 63,
      "namaKABUPATEN": "KABUPATEN TABALONG"
    },
    {
      "kodeKABUPATEN": 6310,
      "kodePROVINSI": 63,
      "namaKABUPATEN": "KABUPATEN TANAH BUMBU"
    },
    {
      "kodeKABUPATEN": 6311,
      "kodePROVINSI": 63,
      "namaKABUPATEN": "KABUPATEN BALANGAN"
    },
    {
      "kodeKABUPATEN": 6371,
      "kodePROVINSI": 63,
      "namaKABUPATEN": "KOTA BANJARMASIN"
    },
    {
      "kodeKABUPATEN": 6372,
      "kodePROVINSI": 63,
      "namaKABUPATEN": "KOTA BANJAR BARU"
    },
    {
      "kodeKABUPATEN": 6401,
      "kodePROVINSI": 64,
      "namaKABUPATEN": "KABUPATEN PASER"
    },
    {
      "kodeKABUPATEN": 6402,
      "kodePROVINSI": 64,
      "namaKABUPATEN": "KABUPATEN KUTAI BARAT"
    },
    {
      "kodeKABUPATEN": 6403,
      "kodePROVINSI": 64,
      "namaKABUPATEN": "KABUPATEN KUTAI KARTANEGARA"
    },
    {
      "kodeKABUPATEN": 6404,
      "kodePROVINSI": 64,
      "namaKABUPATEN": "KABUPATEN KUTAI TIMUR"
    },
    {
      "kodeKABUPATEN": 6405,
      "kodePROVINSI": 64,
      "namaKABUPATEN": "KABUPATEN BERAU"
    },
    {
      "kodeKABUPATEN": 6409,
      "kodePROVINSI": 64,
      "namaKABUPATEN": "KABUPATEN PENAJAM PASER UTARA"
    },
    {
      "kodeKABUPATEN": 6411,
      "kodePROVINSI": 64,
      "namaKABUPATEN": "KABUPATEN MAHAKAM HULU"
    },
    {
      "kodeKABUPATEN": 6471,
      "kodePROVINSI": 64,
      "namaKABUPATEN": "KOTA BALIKPAPAN"
    },
    {
      "kodeKABUPATEN": 6472,
      "kodePROVINSI": 64,
      "namaKABUPATEN": "KOTA SAMARINDA"
    },
    {
      "kodeKABUPATEN": 6474,
      "kodePROVINSI": 64,
      "namaKABUPATEN": "KOTA BONTANG"
    },
    {
      "kodeKABUPATEN": 6501,
      "kodePROVINSI": 65,
      "namaKABUPATEN": "KABUPATEN MALINAU"
    },
    {
      "kodeKABUPATEN": 6502,
      "kodePROVINSI": 65,
      "namaKABUPATEN": "KABUPATEN BULUNGAN"
    },
    {
      "kodeKABUPATEN": 6503,
      "kodePROVINSI": 65,
      "namaKABUPATEN": "KABUPATEN TANA TIDUNG"
    },
    {
      "kodeKABUPATEN": 6504,
      "kodePROVINSI": 65,
      "namaKABUPATEN": "KABUPATEN NUNUKAN"
    },
    {
      "kodeKABUPATEN": 6571,
      "kodePROVINSI": 65,
      "namaKABUPATEN": "KOTA TARAKAN"
    },
    {
      "kodeKABUPATEN": 7101,
      "kodePROVINSI": 71,
      "namaKABUPATEN": "KABUPATEN BOLAANG MONGONDOW"
    },
    {
      "kodeKABUPATEN": 7102,
      "kodePROVINSI": 71,
      "namaKABUPATEN": "KABUPATEN MINAHASA"
    },
    {
      "kodeKABUPATEN": 7103,
      "kodePROVINSI": 71,
      "namaKABUPATEN": "KABUPATEN KEPULAUAN SANGIHE"
    },
    {
      "kodeKABUPATEN": 7104,
      "kodePROVINSI": 71,
      "namaKABUPATEN": "KABUPATEN KEPULAUAN TALAUD"
    },
    {
      "kodeKABUPATEN": 7105,
      "kodePROVINSI": 71,
      "namaKABUPATEN": "KABUPATEN MINAHASA SELATAN"
    },
    {
      "kodeKABUPATEN": 7106,
      "kodePROVINSI": 71,
      "namaKABUPATEN": "KABUPATEN MINAHASA UTARA"
    },
    {
      "kodeKABUPATEN": 7107,
      "kodePROVINSI": 71,
      "namaKABUPATEN": "KABUPATEN BOLAANG MONGONDOW UTARA"
    },
    {
      "kodeKABUPATEN": 7108,
      "kodePROVINSI": 71,
      "namaKABUPATEN": "KABUPATEN SIAU TAGULANDANG BIARO"
    },
    {
      "kodeKABUPATEN": 7109,
      "kodePROVINSI": 71,
      "namaKABUPATEN": "KABUPATEN MINAHASA TENGGARA"
    },
    {
      "kodeKABUPATEN": 7110,
      "kodePROVINSI": 71,
      "namaKABUPATEN": "KABUPATEN BOLAANG MONGONDOW SELATAN"
    },
    {
      "kodeKABUPATEN": 7111,
      "kodePROVINSI": 71,
      "namaKABUPATEN": "KABUPATEN BOLAANG MONGONDOW TIMUR"
    },
    {
      "kodeKABUPATEN": 7171,
      "kodePROVINSI": 71,
      "namaKABUPATEN": "KOTA MANADO"
    },
    {
      "kodeKABUPATEN": 7172,
      "kodePROVINSI": 71,
      "namaKABUPATEN": "KOTA BITUNG"
    },
    {
      "kodeKABUPATEN": 7173,
      "kodePROVINSI": 71,
      "namaKABUPATEN": "KOTA TOMOHON"
    },
    {
      "kodeKABUPATEN": 7174,
      "kodePROVINSI": 71,
      "namaKABUPATEN": "KOTA KOTAMOBAGU"
    },
    {
      "kodeKABUPATEN": 7201,
      "kodePROVINSI": 72,
      "namaKABUPATEN": "KABUPATEN BANGGAI KEPULAUAN"
    },
    {
      "kodeKABUPATEN": 7202,
      "kodePROVINSI": 72,
      "namaKABUPATEN": "KABUPATEN BANGGAI"
    },
    {
      "kodeKABUPATEN": 7203,
      "kodePROVINSI": 72,
      "namaKABUPATEN": "KABUPATEN MOROWALI"
    },
    {
      "kodeKABUPATEN": 7204,
      "kodePROVINSI": 72,
      "namaKABUPATEN": "KABUPATEN POSO"
    },
    {
      "kodeKABUPATEN": 7205,
      "kodePROVINSI": 72,
      "namaKABUPATEN": "KABUPATEN DONGGALA"
    },
    {
      "kodeKABUPATEN": 7206,
      "kodePROVINSI": 72,
      "namaKABUPATEN": "KABUPATEN TOLI-TOLI"
    },
    {
      "kodeKABUPATEN": 7207,
      "kodePROVINSI": 72,
      "namaKABUPATEN": "KABUPATEN BUOL"
    },
    {
      "kodeKABUPATEN": 7208,
      "kodePROVINSI": 72,
      "namaKABUPATEN": "KABUPATEN PARIGI MOUTONG"
    },
    {
      "kodeKABUPATEN": 7209,
      "kodePROVINSI": 72,
      "namaKABUPATEN": "KABUPATEN TOJO UNA-UNA"
    },
    {
      "kodeKABUPATEN": 7210,
      "kodePROVINSI": 72,
      "namaKABUPATEN": "KABUPATEN SIGI"
    },
    {
      "kodeKABUPATEN": 7211,
      "kodePROVINSI": 72,
      "namaKABUPATEN": "KABUPATEN BANGGAI LAUT"
    },
    {
      "kodeKABUPATEN": 7212,
      "kodePROVINSI": 72,
      "namaKABUPATEN": "KABUPATEN MOROWALI UTARA"
    },
    {
      "kodeKABUPATEN": 7271,
      "kodePROVINSI": 72,
      "namaKABUPATEN": "KOTA PALU"
    },
    {
      "kodeKABUPATEN": 7301,
      "kodePROVINSI": 73,
      "namaKABUPATEN": "KABUPATEN KEPULAUAN SELAYAR"
    },
    {
      "kodeKABUPATEN": 7302,
      "kodePROVINSI": 73,
      "namaKABUPATEN": "KABUPATEN BULUKUMBA"
    },
    {
      "kodeKABUPATEN": 7303,
      "kodePROVINSI": 73,
      "namaKABUPATEN": "KABUPATEN BANTAENG"
    },
    {
      "kodeKABUPATEN": 7304,
      "kodePROVINSI": 73,
      "namaKABUPATEN": "KABUPATEN JENEPONTO"
    },
    {
      "kodeKABUPATEN": 7305,
      "kodePROVINSI": 73,
      "namaKABUPATEN": "KABUPATEN TAKALAR"
    },
    {
      "kodeKABUPATEN": 7306,
      "kodePROVINSI": 73,
      "namaKABUPATEN": "KABUPATEN GOWA"
    },
    {
      "kodeKABUPATEN": 7307,
      "kodePROVINSI": 73,
      "namaKABUPATEN": "KABUPATEN SINJAI"
    },
    {
      "kodeKABUPATEN": 7308,
      "kodePROVINSI": 73,
      "namaKABUPATEN": "KABUPATEN MAROS"
    },
    {
      "kodeKABUPATEN": 7309,
      "kodePROVINSI": 73,
      "namaKABUPATEN": "KABUPATEN PANGKAJENE DAN KEPULAUAN"
    },
    {
      "kodeKABUPATEN": 7310,
      "kodePROVINSI": 73,
      "namaKABUPATEN": "KABUPATEN BARRU"
    },
    {
      "kodeKABUPATEN": 7311,
      "kodePROVINSI": 73,
      "namaKABUPATEN": "KABUPATEN BONE"
    },
    {
      "kodeKABUPATEN": 7312,
      "kodePROVINSI": 73,
      "namaKABUPATEN": "KABUPATEN SOPPENG"
    },
    {
      "kodeKABUPATEN": 7313,
      "kodePROVINSI": 73,
      "namaKABUPATEN": "KABUPATEN WAJO"
    },
    {
      "kodeKABUPATEN": 7314,
      "kodePROVINSI": 73,
      "namaKABUPATEN": "KABUPATEN SIDENRENG RAPPANG"
    },
    {
      "kodeKABUPATEN": 7315,
      "kodePROVINSI": 73,
      "namaKABUPATEN": "KABUPATEN PINRANG"
    },
    {
      "kodeKABUPATEN": 7316,
      "kodePROVINSI": 73,
      "namaKABUPATEN": "KABUPATEN ENREKANG"
    },
    {
      "kodeKABUPATEN": 7317,
      "kodePROVINSI": 73,
      "namaKABUPATEN": "KABUPATEN LUWU"
    },
    {
      "kodeKABUPATEN": 7318,
      "kodePROVINSI": 73,
      "namaKABUPATEN": "KABUPATEN TANA TORAJA"
    },
    {
      "kodeKABUPATEN": 7322,
      "kodePROVINSI": 73,
      "namaKABUPATEN": "KABUPATEN LUWU UTARA"
    },
    {
      "kodeKABUPATEN": 7325,
      "kodePROVINSI": 73,
      "namaKABUPATEN": "KABUPATEN LUWU TIMUR"
    },
    {
      "kodeKABUPATEN": 7326,
      "kodePROVINSI": 73,
      "namaKABUPATEN": "KABUPATEN TORAJA UTARA"
    },
    {
      "kodeKABUPATEN": 7371,
      "kodePROVINSI": 73,
      "namaKABUPATEN": "KOTA MAKASSAR"
    },
    {
      "kodeKABUPATEN": 7372,
      "kodePROVINSI": 73,
      "namaKABUPATEN": "KOTA PAREPARE"
    },
    {
      "kodeKABUPATEN": 7373,
      "kodePROVINSI": 73,
      "namaKABUPATEN": "KOTA PALOPO"
    },
    {
      "kodeKABUPATEN": 7401,
      "kodePROVINSI": 74,
      "namaKABUPATEN": "KABUPATEN BUTON"
    },
    {
      "kodeKABUPATEN": 7402,
      "kodePROVINSI": 74,
      "namaKABUPATEN": "KABUPATEN MUNA"
    },
    {
      "kodeKABUPATEN": 7403,
      "kodePROVINSI": 74,
      "namaKABUPATEN": "KABUPATEN KONAWE"
    },
    {
      "kodeKABUPATEN": 7404,
      "kodePROVINSI": 74,
      "namaKABUPATEN": "KABUPATEN KOLAKA"
    },
    {
      "kodeKABUPATEN": 7405,
      "kodePROVINSI": 74,
      "namaKABUPATEN": "KABUPATEN KONAWE SELATAN"
    },
    {
      "kodeKABUPATEN": 7406,
      "kodePROVINSI": 74,
      "namaKABUPATEN": "KABUPATEN BOMBANA"
    },
    {
      "kodeKABUPATEN": 7407,
      "kodePROVINSI": 74,
      "namaKABUPATEN": "KABUPATEN WAKATOBI"
    },
    {
      "kodeKABUPATEN": 7408,
      "kodePROVINSI": 74,
      "namaKABUPATEN": "KABUPATEN KOLAKA UTARA"
    },
    {
      "kodeKABUPATEN": 7409,
      "kodePROVINSI": 74,
      "namaKABUPATEN": "KABUPATEN BUTON UTARA"
    },
    {
      "kodeKABUPATEN": 7410,
      "kodePROVINSI": 74,
      "namaKABUPATEN": "KABUPATEN KONAWE UTARA"
    },
    {
      "kodeKABUPATEN": 7411,
      "kodePROVINSI": 74,
      "namaKABUPATEN": "KABUPATEN KOLAKA TIMUR"
    },
    {
      "kodeKABUPATEN": 7412,
      "kodePROVINSI": 74,
      "namaKABUPATEN": "KABUPATEN KONAWE KEPULAUAN"
    },
    {
      "kodeKABUPATEN": 7413,
      "kodePROVINSI": 74,
      "namaKABUPATEN": "KABUPATEN MUNA BARAT"
    },
    {
      "kodeKABUPATEN": 7414,
      "kodePROVINSI": 74,
      "namaKABUPATEN": "KABUPATEN BUTON TENGAH"
    },
    {
      "kodeKABUPATEN": 7415,
      "kodePROVINSI": 74,
      "namaKABUPATEN": "KABUPATEN BUTON SELATAN"
    },
    {
      "kodeKABUPATEN": 7471,
      "kodePROVINSI": 74,
      "namaKABUPATEN": "KOTA KENDARI"
    },
    {
      "kodeKABUPATEN": 7472,
      "kodePROVINSI": 74,
      "namaKABUPATEN": "KOTA BAUBAU"
    },
    {
      "kodeKABUPATEN": 7501,
      "kodePROVINSI": 75,
      "namaKABUPATEN": "KABUPATEN BOALEMO"
    },
    {
      "kodeKABUPATEN": 7502,
      "kodePROVINSI": 75,
      "namaKABUPATEN": "KABUPATEN GORONTALO"
    },
    {
      "kodeKABUPATEN": 7503,
      "kodePROVINSI": 75,
      "namaKABUPATEN": "KABUPATEN POHUWATO"
    },
    {
      "kodeKABUPATEN": 7504,
      "kodePROVINSI": 75,
      "namaKABUPATEN": "KABUPATEN BONE BOLANGO"
    },
    {
      "kodeKABUPATEN": 7505,
      "kodePROVINSI": 75,
      "namaKABUPATEN": "KABUPATEN GORONTALO UTARA"
    },
    {
      "kodeKABUPATEN": 7571,
      "kodePROVINSI": 75,
      "namaKABUPATEN": "KOTA GORONTALO"
    },
    {
      "kodeKABUPATEN": 7601,
      "kodePROVINSI": 76,
      "namaKABUPATEN": "KABUPATEN MAJENE"
    },
    {
      "kodeKABUPATEN": 7602,
      "kodePROVINSI": 76,
      "namaKABUPATEN": "KABUPATEN POLEWALI MANDAR"
    },
    {
      "kodeKABUPATEN": 7603,
      "kodePROVINSI": 76,
      "namaKABUPATEN": "KABUPATEN MAMASA"
    },
    {
      "kodeKABUPATEN": 7604,
      "kodePROVINSI": 76,
      "namaKABUPATEN": "KABUPATEN MAMUJU"
    },
    {
      "kodeKABUPATEN": 7605,
      "kodePROVINSI": 76,
      "namaKABUPATEN": "KABUPATEN MAMUJU UTARA"
    },
    {
      "kodeKABUPATEN": 7606,
      "kodePROVINSI": 76,
      "namaKABUPATEN": "KABUPATEN MAMUJU TENGAH"
    },
    {
      "kodeKABUPATEN": 8101,
      "kodePROVINSI": 81,
      "namaKABUPATEN": "KABUPATEN MALUKU TENGGARA BARAT"
    },
    {
      "kodeKABUPATEN": 8102,
      "kodePROVINSI": 81,
      "namaKABUPATEN": "KABUPATEN MALUKU TENGGARA"
    },
    {
      "kodeKABUPATEN": 8103,
      "kodePROVINSI": 81,
      "namaKABUPATEN": "KABUPATEN MALUKU TENGAH"
    },
    {
      "kodeKABUPATEN": 8104,
      "kodePROVINSI": 81,
      "namaKABUPATEN": "KABUPATEN BURU"
    },
    {
      "kodeKABUPATEN": 8105,
      "kodePROVINSI": 81,
      "namaKABUPATEN": "KABUPATEN KEPULAUAN ARU"
    },
    {
      "kodeKABUPATEN": 8106,
      "kodePROVINSI": 81,
      "namaKABUPATEN": "KABUPATEN SERAM BAGIAN BARAT"
    },
    {
      "kodeKABUPATEN": 8107,
      "kodePROVINSI": 81,
      "namaKABUPATEN": "KABUPATEN SERAM BAGIAN TIMUR"
    },
    {
      "kodeKABUPATEN": 8108,
      "kodePROVINSI": 81,
      "namaKABUPATEN": "KABUPATEN MALUKU BARAT DAYA"
    },
    {
      "kodeKABUPATEN": 8109,
      "kodePROVINSI": 81,
      "namaKABUPATEN": "KABUPATEN BURU SELATAN"
    },
    {
      "kodeKABUPATEN": 8171,
      "kodePROVINSI": 81,
      "namaKABUPATEN": "KOTA AMBON"
    },
    {
      "kodeKABUPATEN": 8172,
      "kodePROVINSI": 81,
      "namaKABUPATEN": "KOTA TUAL"
    },
    {
      "kodeKABUPATEN": 8201,
      "kodePROVINSI": 82,
      "namaKABUPATEN": "KABUPATEN HALMAHERA BARAT"
    },
    {
      "kodeKABUPATEN": 8202,
      "kodePROVINSI": 82,
      "namaKABUPATEN": "KABUPATEN HALMAHERA TENGAH"
    },
    {
      "kodeKABUPATEN": 8203,
      "kodePROVINSI": 82,
      "namaKABUPATEN": "KABUPATEN KEPULAUAN SULA"
    },
    {
      "kodeKABUPATEN": 8204,
      "kodePROVINSI": 82,
      "namaKABUPATEN": "KABUPATEN HALMAHERA SELATAN"
    },
    {
      "kodeKABUPATEN": 8205,
      "kodePROVINSI": 82,
      "namaKABUPATEN": "KABUPATEN HALMAHERA UTARA"
    },
    {
      "kodeKABUPATEN": 8206,
      "kodePROVINSI": 82,
      "namaKABUPATEN": "KABUPATEN HALMAHERA TIMUR"
    },
    {
      "kodeKABUPATEN": 8207,
      "kodePROVINSI": 82,
      "namaKABUPATEN": "KABUPATEN PULAU MOROTAI"
    },
    {
      "kodeKABUPATEN": 8208,
      "kodePROVINSI": 82,
      "namaKABUPATEN": "KABUPATEN PULAU TALIABU"
    },
    {
      "kodeKABUPATEN": 8271,
      "kodePROVINSI": 82,
      "namaKABUPATEN": "KOTA TERNATE"
    },
    {
      "kodeKABUPATEN": 8272,
      "kodePROVINSI": 82,
      "namaKABUPATEN": "KOTA TIDORE KEPULAUAN"
    },
    {
      "kodeKABUPATEN": 9101,
      "kodePROVINSI": 91,
      "namaKABUPATEN": "KABUPATEN FAKFAK"
    },
    {
      "kodeKABUPATEN": 9102,
      "kodePROVINSI": 91,
      "namaKABUPATEN": "KABUPATEN KAIMANA"
    },
    {
      "kodeKABUPATEN": 9103,
      "kodePROVINSI": 91,
      "namaKABUPATEN": "KABUPATEN TELUK WONDAMA"
    },
    {
      "kodeKABUPATEN": 9104,
      "kodePROVINSI": 91,
      "namaKABUPATEN": "KABUPATEN TELUK BINTUNI"
    },
    {
      "kodeKABUPATEN": 9105,
      "kodePROVINSI": 91,
      "namaKABUPATEN": "KABUPATEN MANOKWARI"
    },
    {
      "kodeKABUPATEN": 9106,
      "kodePROVINSI": 91,
      "namaKABUPATEN": "KABUPATEN SORONG SELATAN"
    },
    {
      "kodeKABUPATEN": 9107,
      "kodePROVINSI": 91,
      "namaKABUPATEN": "KABUPATEN SORONG"
    },
    {
      "kodeKABUPATEN": 9108,
      "kodePROVINSI": 91,
      "namaKABUPATEN": "KABUPATEN RAJA AMPAT"
    },
    {
      "kodeKABUPATEN": 9109,
      "kodePROVINSI": 91,
      "namaKABUPATEN": "KABUPATEN TAMBRAUW"
    },
    {
      "kodeKABUPATEN": 9110,
      "kodePROVINSI": 91,
      "namaKABUPATEN": "KABUPATEN MAYBRAT"
    },
    {
      "kodeKABUPATEN": 9111,
      "kodePROVINSI": 91,
      "namaKABUPATEN": "KABUPATEN MANOKWARI SELATAN"
    },
    {
      "kodeKABUPATEN": 9112,
      "kodePROVINSI": 91,
      "namaKABUPATEN": "KABUPATEN PEGUNUNGAN ARFAK"
    },
    {
      "kodeKABUPATEN": 9171,
      "kodePROVINSI": 91,
      "namaKABUPATEN": "KOTA SORONG"
    },
    {
      "kodeKABUPATEN": 9401,
      "kodePROVINSI": 94,
      "namaKABUPATEN": "KABUPATEN MERAUKE"
    },
    {
      "kodeKABUPATEN": 9402,
      "kodePROVINSI": 94,
      "namaKABUPATEN": "KABUPATEN JAYAWIJAYA"
    },
    {
      "kodeKABUPATEN": 9403,
      "kodePROVINSI": 94,
      "namaKABUPATEN": "KABUPATEN JAYAPURA"
    },
    {
      "kodeKABUPATEN": 9404,
      "kodePROVINSI": 94,
      "namaKABUPATEN": "KABUPATEN NABIRE"
    },
    {
      "kodeKABUPATEN": 9408,
      "kodePROVINSI": 94,
      "namaKABUPATEN": "KABUPATEN KEPULAUAN YAPEN"
    },
    {
      "kodeKABUPATEN": 9409,
      "kodePROVINSI": 94,
      "namaKABUPATEN": "KABUPATEN BIAK NUMFOR"
    },
    {
      "kodeKABUPATEN": 9410,
      "kodePROVINSI": 94,
      "namaKABUPATEN": "KABUPATEN PANIAI"
    },
    {
      "kodeKABUPATEN": 9411,
      "kodePROVINSI": 94,
      "namaKABUPATEN": "KABUPATEN PUNCAK JAYA"
    },
    {
      "kodeKABUPATEN": 9412,
      "kodePROVINSI": 94,
      "namaKABUPATEN": "KABUPATEN MIMIKA"
    },
    {
      "kodeKABUPATEN": 9413,
      "kodePROVINSI": 94,
      "namaKABUPATEN": "KABUPATEN BOVEN DIGOEL"
    },
    {
      "kodeKABUPATEN": 9414,
      "kodePROVINSI": 94,
      "namaKABUPATEN": "KABUPATEN MAPPI"
    },
    {
      "kodeKABUPATEN": 9415,
      "kodePROVINSI": 94,
      "namaKABUPATEN": "KABUPATEN ASMAT"
    },
    {
      "kodeKABUPATEN": 9416,
      "kodePROVINSI": 94,
      "namaKABUPATEN": "KABUPATEN YAHUKIMO"
    },
    {
      "kodeKABUPATEN": 9417,
      "kodePROVINSI": 94,
      "namaKABUPATEN": "KABUPATEN PEGUNUNGAN BINTANG"
    },
    {
      "kodeKABUPATEN": 9418,
      "kodePROVINSI": 94,
      "namaKABUPATEN": "KABUPATEN TOLIKARA"
    },
    {
      "kodeKABUPATEN": 9419,
      "kodePROVINSI": 94,
      "namaKABUPATEN": "KABUPATEN SARMI"
    },
    {
      "kodeKABUPATEN": 9420,
      "kodePROVINSI": 94,
      "namaKABUPATEN": "KABUPATEN KEEROM"
    },
    {
      "kodeKABUPATEN": 9426,
      "kodePROVINSI": 94,
      "namaKABUPATEN": "KABUPATEN WAROPEN"
    },
    {
      "kodeKABUPATEN": 9427,
      "kodePROVINSI": 94,
      "namaKABUPATEN": "KABUPATEN SUPIORI"
    },
    {
      "kodeKABUPATEN": 9428,
      "kodePROVINSI": 94,
      "namaKABUPATEN": "KABUPATEN MAMBERAMO RAYA"
    },
    {
      "kodeKABUPATEN": 9429,
      "kodePROVINSI": 94,
      "namaKABUPATEN": "KABUPATEN NDUGA"
    },
    {
      "kodeKABUPATEN": 9430,
      "kodePROVINSI": 94,
      "namaKABUPATEN": "KABUPATEN LANNY JAYA"
    },
    {
      "kodeKABUPATEN": 9431,
      "kodePROVINSI": 94,
      "namaKABUPATEN": "KABUPATEN MAMBERAMO TENGAH"
    },
    {
      "kodeKABUPATEN": 9432,
      "kodePROVINSI": 94,
      "namaKABUPATEN": "KABUPATEN YALIMO"
    },
    {
      "kodeKABUPATEN": 9433,
      "kodePROVINSI": 94,
      "namaKABUPATEN": "KABUPATEN PUNCAK"
    },
    {
      "kodeKABUPATEN": 9434,
      "kodePROVINSI": 94,
      "namaKABUPATEN": "KABUPATEN DOGIYAI"
    },
    {
      "kodeKABUPATEN": 9435,
      "kodePROVINSI": 94,
      "namaKABUPATEN": "KABUPATEN INTAN JAYA"
    },
    {
      "kodeKABUPATEN": 9436,
      "kodePROVINSI": 94,
      "namaKABUPATEN": "KABUPATEN DEIYAI"
    },
    {
      "kodeKABUPATEN": 9471,
      "kodePROVINSI": 94,
      "namaKABUPATEN": "KOTA JAYAPURA"
    }
  ].forEach(function (dataKABUPATEN) {
      KABUPATEN.insert(dataKABUPATEN);
    })
  }
});
